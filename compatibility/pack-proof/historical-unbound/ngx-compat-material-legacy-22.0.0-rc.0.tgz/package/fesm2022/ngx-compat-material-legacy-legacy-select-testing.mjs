import { parallel, HarnessPredicate } from '@angular/cdk/testing';
import { MatLegacyOptionHarness, MatLegacyOptgroupHarness } from '@ngx-compat/material-legacy/legacy-core/testing';
import { MatFormFieldControlHarness } from '@angular/material/form-field/testing/control';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatSelectHarnessBase` (removed from Angular Material 22).
 */
class _MatSelectHarnessBase extends MatFormFieldControlHarness {
    _documentRootLocator = this.documentRootLocatorFactory();
    _backdrop = this._documentRootLocator.locatorFor('.cdk-overlay-backdrop');
    async isDisabled() {
        return (await this.host()).hasClass(`${this._prefix}-select-disabled`);
    }
    async isValid() {
        return !(await (await this.host()).hasClass('ng-invalid'));
    }
    async isRequired() {
        return (await this.host()).hasClass(`${this._prefix}-select-required`);
    }
    async isEmpty() {
        return (await this.host()).hasClass(`${this._prefix}-select-empty`);
    }
    async isMultiple() {
        return (await this.host()).hasClass(`${this._prefix}-select-multiple`);
    }
    async getValueText() {
        const value = await this.locatorFor(`.${this._prefix}-select-value`)();
        return value.text();
    }
    async focus() {
        return (await this.host()).focus();
    }
    async blur() {
        return (await this.host()).blur();
    }
    async isFocused() {
        return (await this.host()).isFocused();
    }
    async getOptions(filter) {
        return this._documentRootLocator.locatorForAll(this._optionClass.with({
            ...(filter || {}),
            ancestor: await this._getPanelSelector(),
        }))();
    }
    async getOptionGroups(filter) {
        return this._documentRootLocator.locatorForAll(this._optionGroupClass.with({
            ...(filter || {}),
            ancestor: await this._getPanelSelector(),
        }))();
    }
    async isOpen() {
        return !!(await this._documentRootLocator.locatorForOptional(await this._getPanelSelector())());
    }
    async open() {
        if (!(await this.isOpen())) {
            const trigger = await this.locatorFor(`.${this._prefix}-select-trigger`)();
            return trigger.click();
        }
    }
    async clickOptions(filter) {
        await this.open();
        const [isMultiple, options] = await parallel(() => [
            this.isMultiple(),
            this.getOptions(filter),
        ]);
        if (options.length === 0) {
            throw Error('Select does not have options matching the specified filter');
        }
        if (isMultiple) {
            await parallel(() => options.map(option => option.click()));
        }
        else {
            await options[0].click();
        }
    }
    async close() {
        if (await this.isOpen()) {
            return (await this._backdrop()).click();
        }
    }
    async _getPanelSelector() {
        const id = await (await this.host()).getAttribute('id');
        return `#${id}-panel`;
    }
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Harness for interacting with a standard mat-select in tests.
 * @deprecated Use `MatSelectHarness` from `@angular/material/select/testing` instead.
 * @breaking-change 17.0.0
 */
class MatLegacySelectHarness extends _MatSelectHarnessBase {
    static hostSelector = '.mat-select';
    _prefix = 'mat';
    _optionClass = MatLegacyOptionHarness;
    _optionGroupClass = MatLegacyOptgroupHarness;
    static with(options = {}) {
        return new HarnessPredicate(MatLegacySelectHarness, options).addOption('disabled', options.disabled, async (harness, disabled) => {
            return (await harness.isDisabled()) === disabled;
        });
    }
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MatLegacySelectHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-select-testing.mjs.map
