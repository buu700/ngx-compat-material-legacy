import { ComponentHarness, HarnessPredicate } from '@angular/cdk/testing';
import { coerceBooleanProperty } from '@angular/cdk/coercion';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatCheckboxHarnessBase` (removed from Angular Material 22).
 */
class _MatCheckboxHarnessBase extends ComponentHarness {
    async isChecked() {
        const checked = (await this._input()).getProperty('checked');
        return coerceBooleanProperty(await checked);
    }
    async isIndeterminate() {
        const indeterminate = (await this._input()).getProperty('indeterminate');
        return coerceBooleanProperty(await indeterminate);
    }
    async isDisabled() {
        const disabled = (await this._input()).getAttribute('disabled');
        return coerceBooleanProperty(await disabled);
    }
    async isRequired() {
        const required = (await this._input()).getProperty('required');
        return coerceBooleanProperty(await required);
    }
    async isValid() {
        const invalid = (await this.host()).hasClass('ng-invalid');
        return !(await invalid);
    }
    async getName() {
        return (await this._input()).getAttribute('name');
    }
    async getValue() {
        return (await this._input()).getProperty('value');
    }
    async getAriaLabel() {
        return (await this._input()).getAttribute('aria-label');
    }
    async getAriaLabelledby() {
        return (await this._input()).getAttribute('aria-labelledby');
    }
    async getLabelText() {
        return (await this._label()).text();
    }
    async focus() {
        return (await this._input()).focus();
    }
    async blur() {
        return (await this._input()).blur();
    }
    async isFocused() {
        return (await this._input()).isFocused();
    }
    async check() {
        if (!(await this.isChecked())) {
            await this.toggle();
        }
    }
    async uncheck() {
        if (await this.isChecked()) {
            await this.toggle();
        }
    }
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Harness for interacting with a standard mat-checkbox in tests.
 * @deprecated Use `MatCheckboxHarness` from `@angular/material/checkbox/testing` instead.
 * @breaking-change 17.0.0
 */
class MatLegacyCheckboxHarness extends _MatCheckboxHarnessBase {
    static hostSelector = '.mat-checkbox';
    static with(options = {}) {
        return new HarnessPredicate(MatLegacyCheckboxHarness, options)
            .addOption('label', options.label, (harness, label) => HarnessPredicate.stringMatches(harness.getLabelText(), label))
            .addOption('name', options.name, async (harness, name) => (await harness.getName()) === name)
            .addOption('checked', options.checked, async (harness, checked) => (await harness.isChecked()) == checked)
            .addOption('disabled', options.disabled, async (harness, disabled) => {
            return (await harness.isDisabled()) === disabled;
        });
    }
    _input = this.locatorFor('input');
    _label = this.locatorFor('.mat-checkbox-label');
    _inputContainer = this.locatorFor('.mat-checkbox-inner-container');
    async toggle() {
        return (await this._inputContainer()).click();
    }
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MatLegacyCheckboxHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-checkbox-testing.mjs.map
