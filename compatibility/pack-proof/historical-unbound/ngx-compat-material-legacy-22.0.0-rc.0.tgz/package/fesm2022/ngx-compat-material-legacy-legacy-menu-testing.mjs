import { ContentContainerComponentHarness, TestKey, HarnessPredicate } from '@angular/cdk/testing';
import { coerceBooleanProperty } from '@angular/cdk/coercion';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatMenuHarnessBase` / `_MatMenuItemHarnessBase`
 * (removed from Angular Material 22).
 */
class _MatMenuHarnessBase extends ContentContainerComponentHarness {
    _documentRootLocator = this.documentRootLocatorFactory();
    async isDisabled() {
        const disabled = (await this.host()).getAttribute('disabled');
        return coerceBooleanProperty(await disabled);
    }
    async isOpen() {
        return !!(await this._getMenuPanel());
    }
    async getTriggerText() {
        return (await this.host()).text();
    }
    async focus() {
        return (await this.host()).focus();
    }
    async blur() {
        return (await this.host()).blur();
    }
    async isFocused() {
        return (await this.host()).isFocused();
    }
    async open() {
        if (!(await this.isOpen())) {
            return (await this.host()).click();
        }
    }
    async close() {
        const panel = await this._getMenuPanel();
        if (panel) {
            return panel.sendKeys(TestKey.ESCAPE);
        }
    }
    async getItems(filters) {
        const panelId = await this._getPanelId();
        if (panelId) {
            return this._documentRootLocator.locatorForAll(this._itemClass.with({
                ...(filters || {}),
                ancestor: `#${panelId}`,
            }))();
        }
        return [];
    }
    async clickItem(itemFilter, ...subItemFilters) {
        await this.open();
        const items = await this.getItems(itemFilter);
        if (!items.length) {
            throw Error(`Could not find item matching ${JSON.stringify(itemFilter)}`);
        }
        if (!subItemFilters.length) {
            return await items[0].click();
        }
        const menu = await items[0].getSubmenu();
        if (!menu) {
            throw Error(`Item matching ${JSON.stringify(itemFilter)} does not have a submenu`);
        }
        return menu.clickItem(...subItemFilters);
    }
    async getRootHarnessLoader() {
        const panelId = await this._getPanelId();
        return this.documentRootLocatorFactory().harnessLoaderFor(`#${panelId}`);
    }
    async _getMenuPanel() {
        const panelId = await this._getPanelId();
        return panelId ? this._documentRootLocator.locatorForOptional(`#${panelId}`)() : null;
    }
    async _getPanelId() {
        const panelId = await (await this.host()).getAttribute('aria-controls');
        return panelId || null;
    }
}
class _MatMenuItemHarnessBase extends ContentContainerComponentHarness {
    async isDisabled() {
        const disabled = (await this.host()).getAttribute('disabled');
        return coerceBooleanProperty(await disabled);
    }
    async getText() {
        return (await this.host()).text();
    }
    async focus() {
        return (await this.host()).focus();
    }
    async blur() {
        return (await this.host()).blur();
    }
    async isFocused() {
        return (await this.host()).isFocused();
    }
    async click() {
        return (await this.host()).click();
    }
    async hasSubmenu() {
        return (await this.host()).matchesSelector(this._menuClass.hostSelector);
    }
    async getSubmenu() {
        if (await this.hasSubmenu()) {
            return new this._menuClass(this.locatorFactory);
        }
        return null;
    }
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Harness for interacting with a standard mat-menu in tests.
 * @deprecated Use `MatMenuHarness` from `@angular/material/menu/testing` instead.
 * @breaking-change 17.0.0
 */
class MatLegacyMenuHarness extends _MatMenuHarnessBase {
    static hostSelector = '.mat-menu-trigger';
    _itemClass = MatLegacyMenuItemHarness;
    static with(options = {}) {
        return new HarnessPredicate(MatLegacyMenuHarness, options).addOption('triggerText', options.triggerText, (harness, text) => HarnessPredicate.stringMatches(harness.getTriggerText(), text));
    }
}
/**
 * Harness for interacting with a standard mat-menu-item in tests.
 * @deprecated Use `MatMenuItemHarness` from `@angular/material/menu/testing` instead.
 * @breaking-change 17.0.0
 */
class MatLegacyMenuItemHarness extends _MatMenuItemHarnessBase {
    static hostSelector = '.mat-menu-item';
    _menuClass = MatLegacyMenuHarness;
    static with(options = {}) {
        return new HarnessPredicate(MatLegacyMenuItemHarness, options)
            .addOption('text', options.text, (harness, text) => HarnessPredicate.stringMatches(harness.getText(), text))
            .addOption('hasSubmenu', options.hasSubmenu, async (harness, hasSubmenu) => (await harness.hasSubmenu()) === hasSubmenu);
    }
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MatLegacyMenuHarness, MatLegacyMenuItemHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-menu-testing.mjs.map
