export { MatInputHarness as MatLegacyInputHarness, MatNativeOptionHarness as MatLegacyNativeOptionHarness, MatNativeSelectHarness as MatLegacyNativeSelectHarness } from '@angular/material/input/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ngx-compat-material-legacy-legacy-input-testing.mjs.map
