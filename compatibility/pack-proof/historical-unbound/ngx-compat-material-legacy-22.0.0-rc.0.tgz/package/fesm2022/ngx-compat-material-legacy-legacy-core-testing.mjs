import { ComponentHarness, HarnessPredicate } from '@angular/cdk/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Harness for interacting with a legacy `mat-option` in tests.
 * @deprecated Use `MatOptionHarness` from `@angular/material/core/testing` instead.
 * @breaking-change 17.0.0
 */
class MatLegacyOptionHarness extends ComponentHarness {
    static hostSelector = '.mat-option';
    _text = this.locatorFor('.mat-option-text');
    static with(options = {}) {
        return new HarnessPredicate(MatLegacyOptionHarness, options)
            .addOption('text', options.text, async (harness, title) => HarnessPredicate.stringMatches(await harness.getText(), title))
            .addOption('isSelected', options.isSelected, async (harness, isSelected) => (await harness.isSelected()) === isSelected);
    }
    async click() {
        return (await this.host()).click();
    }
    async getText() {
        return (await this._text()).text();
    }
    async isDisabled() {
        return (await this.host()).hasClass('mat-option-disabled');
    }
    async isSelected() {
        return (await this.host()).hasClass('mat-selected');
    }
    async isActive() {
        return (await this.host()).hasClass('mat-active');
    }
    async isMultiple() {
        return (await this.host()).hasClass('mat-option-multiple');
    }
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Harness for interacting with a legacy `mat-optgroup` in tests.
 * @deprecated Use `MatOptgroupHarness` from `@angular/material/core/testing` instead.
 * @breaking-change 17.0.0
 */
class MatLegacyOptgroupHarness extends ComponentHarness {
    static hostSelector = '.mat-optgroup';
    _label = this.locatorFor('.mat-optgroup-label');
    static with(options = {}) {
        return new HarnessPredicate(MatLegacyOptgroupHarness, options).addOption('labelText', options.labelText, async (harness, title) => HarnessPredicate.stringMatches(await harness.getLabelText(), title));
    }
    async getLabelText() {
        return (await this._label()).text();
    }
    async isDisabled() {
        return (await this.host()).hasClass('mat-optgroup-disabled');
    }
    async getOptions(filter = {}) {
        return this.locatorForAll(MatLegacyOptionHarness.with(filter))();
    }
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MatLegacyOptgroupHarness, MatLegacyOptionHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-core-testing.mjs.map
