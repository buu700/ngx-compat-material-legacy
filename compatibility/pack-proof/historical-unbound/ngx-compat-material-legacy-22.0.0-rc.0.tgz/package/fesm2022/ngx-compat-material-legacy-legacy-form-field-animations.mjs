import { trigger, state, style, transition, animate } from '@angular/animations';

/**
 * Optional Angular animation recipes for legacy form-field.
 * Primary form-field uses CSS transitions for subscript messages.
 */
const matFormFieldAnimations = {
    transitionMessages: trigger('transitionMessages', [
        state('enter', style({ opacity: 1, transform: 'translateY(0%)' })),
        transition('void => enter', [
            style({ opacity: 0, transform: 'translateY(-5px)' }),
            animate('{{transitionDuration}} cubic-bezier(0.55, 0, 0.55, 0.2)'),
        ], { params: { transitionDuration: '300ms' } }),
    ]),
};

/**
 * Generated bundle index. Do not edit.
 */

export { matFormFieldAnimations, matFormFieldAnimations as matLegacyFormFieldAnimations };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-form-field-animations.mjs.map
