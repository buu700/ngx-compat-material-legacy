import { HarnessPredicate, ComponentHarnessConstructor, ComponentHarness, ContentContainerComponentHarness } from '@angular/cdk/testing';
import { _MatCellHarnessBase, CellHarnessFilters, _MatRowHarnessBase, RowHarnessFilters, MatRowHarnessColumnsText, TableHarnessFilters } from '@angular/material/table/testing';
export { CellHarnessFilters as LegacyCellHarnessFilters, RowHarnessFilters as LegacyRowHarnessFilters, TableHarnessFilters as LegacyTableHarnessFilters, MatRowHarnessColumnsText as MatLegacyRowHarnessColumnsText, MatTableHarnessColumnsText as MatLegacyTableHarnessColumnsText, _MatCellHarnessBase as _MatLegacyCellHarnessBase, _MatRowHarnessBase as _MatLegacyRowHarnessBase } from '@angular/material/table/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a standard Angular Material table cell.
 * @deprecated Use `MatCellHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyCellHarness extends _MatCellHarnessBase {
    /** The selector for the host element of a `MatCellHarness` instance. */
    static hostSelector: string;
    /**
     * Gets a `HarnessPredicate` that can be used to search for a table cell with specific attributes.
     * @param options Options for narrowing the search
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: CellHarnessFilters): HarnessPredicate<MatLegacyCellHarness>;
}
/**
 * Harness for interacting with a standard Angular Material table header cell.
 * @deprecated Use `MatHeaderCellHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyHeaderCellHarness extends _MatCellHarnessBase {
    /** The selector for the host element of a `MatHeaderCellHarness` instance. */
    static hostSelector: string;
    /**
     * Gets a `HarnessPredicate` that can be used to search for
     * a table header cell with specific attributes.
     * @param options Options for narrowing the search
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: CellHarnessFilters): HarnessPredicate<MatLegacyHeaderCellHarness>;
}
/**
 * Harness for interacting with a standard Angular Material table footer cell.
 * @deprecated Use `MatFooterCellHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyFooterCellHarness extends _MatCellHarnessBase {
    /** The selector for the host element of a `MatFooterCellHarness` instance. */
    static hostSelector: string;
    /**
     * Gets a `HarnessPredicate` that can be used to search for
     * a table footer cell with specific attributes.
     * @param options Options for narrowing the search
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: CellHarnessFilters): HarnessPredicate<MatLegacyFooterCellHarness>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a standard Angular Material table row.
 * @deprecated Use `MatRowHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyRowHarness extends _MatRowHarnessBase<typeof MatLegacyCellHarness, MatLegacyCellHarness> {
    /** The selector for the host element of a `MatRowHarness` instance. */
    static hostSelector: string;
    protected _cellHarness: typeof MatLegacyCellHarness;
    /**
     * Gets a `HarnessPredicate` that can be used to search for a table row with specific attributes.
     * @param options Options for narrowing the search
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: RowHarnessFilters): HarnessPredicate<MatLegacyRowHarness>;
}
/**
 * Harness for interacting with a standard Angular Material table header row.
 * @deprecated Use `MatHeaderRowHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyHeaderRowHarness extends _MatRowHarnessBase<typeof MatLegacyHeaderCellHarness, MatLegacyHeaderCellHarness> {
    /** The selector for the host element of a `MatHeaderRowHarness` instance. */
    static hostSelector: string;
    protected _cellHarness: typeof MatLegacyHeaderCellHarness;
    /**
     * Gets a `HarnessPredicate` that can be used to search for
     * a table header row with specific attributes.
     * @param options Options for narrowing the search
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: RowHarnessFilters): HarnessPredicate<MatLegacyHeaderRowHarness>;
}
/**
 * Harness for interacting with a standard Angular Material table footer row.
 * @deprecated Use `MatFooterRowHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyFooterRowHarness extends _MatRowHarnessBase<typeof MatLegacyFooterCellHarness, MatLegacyFooterCellHarness> {
    /** The selector for the host element of a `MatFooterRowHarness` instance. */
    static hostSelector: string;
    protected _cellHarness: typeof MatLegacyFooterCellHarness;
    /**
     * Gets a `HarnessPredicate` that can be used to search for
     * a table footer row cell with specific attributes.
     * @param options Options for narrowing the search
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: RowHarnessFilters): HarnessPredicate<MatLegacyFooterRowHarness>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 harness base(s) removed from Angular Material 22.
 */

/** Text extracted from a table organized by columns. */
interface MatTableHarnessColumnsText {
    [columnName: string]: {
        text: string[];
        headerText: string[];
        footerText: string[];
    };
}
interface RowBase extends ComponentHarness {
    getCellTextByColumnName(): Promise<MatRowHarnessColumnsText>;
    getCellTextByIndex(): Promise<string[]>;
}
declare abstract class _MatTableHarnessBase<HeaderRowType extends ComponentHarnessConstructor<HeaderRow> & {
    with: (options?: RowHarnessFilters) => HarnessPredicate<HeaderRow>;
}, HeaderRow extends RowBase, RowType extends ComponentHarnessConstructor<Row> & {
    with: (options?: RowHarnessFilters) => HarnessPredicate<Row>;
}, Row extends RowBase, FooterRowType extends ComponentHarnessConstructor<FooterRow> & {
    with: (options?: RowHarnessFilters) => HarnessPredicate<FooterRow>;
}, FooterRow extends RowBase> extends ContentContainerComponentHarness<string> {
    protected abstract _headerRowHarness: HeaderRowType;
    protected abstract _rowHarness: RowType;
    protected abstract _footerRowHarness: FooterRowType;
    /** Gets all of the header rows in a table. */
    getHeaderRows(filter?: RowHarnessFilters): Promise<HeaderRow[]>;
    /** Gets all of the regular data rows in a table. */
    getRows(filter?: RowHarnessFilters): Promise<Row[]>;
    /** Gets all of the footer rows in a table. */
    getFooterRows(filter?: RowHarnessFilters): Promise<FooterRow[]>;
    /** Gets the text inside the entire table organized by rows. */
    getCellTextByIndex(): Promise<string[][]>;
    /** Gets the text inside the entire table organized by columns. */
    getCellTextByColumnName(): Promise<MatTableHarnessColumnsText>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a standard mat-table in tests.
 * @deprecated Use `MatTableHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyTableHarness extends _MatTableHarnessBase<typeof MatLegacyHeaderRowHarness, MatLegacyHeaderRowHarness, typeof MatLegacyRowHarness, MatLegacyRowHarness, typeof MatLegacyFooterRowHarness, MatLegacyFooterRowHarness> {
    /** The selector for the host element of a `MatTableHarness` instance. */
    static hostSelector: string;
    protected _headerRowHarness: typeof MatLegacyHeaderRowHarness;
    protected _rowHarness: typeof MatLegacyRowHarness;
    protected _footerRowHarness: typeof MatLegacyFooterRowHarness;
    /**
     * Gets a `HarnessPredicate` that can be used to search for a table with specific attributes.
     * @param options Options for narrowing the search
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: TableHarnessFilters): HarnessPredicate<MatLegacyTableHarness>;
}

export { MatLegacyCellHarness, MatLegacyFooterCellHarness, MatLegacyFooterRowHarness, MatLegacyHeaderCellHarness, MatLegacyHeaderRowHarness, MatLegacyRowHarness, MatLegacyTableHarness, _MatTableHarnessBase as _MatLegacyTableHarnessBase };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-table-testing.d.ts.map
