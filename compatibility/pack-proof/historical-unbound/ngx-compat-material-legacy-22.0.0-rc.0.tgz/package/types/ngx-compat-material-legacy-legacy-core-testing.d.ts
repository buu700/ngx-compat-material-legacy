import { BaseHarnessFilters, ComponentHarness, HarnessPredicate } from '@angular/cdk/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * @deprecated Use `OptionHarnessFilters` from `@angular/material/core/testing` instead.
 * @breaking-change 17.0.0
 */
interface LegacyOptionHarnessFilters extends BaseHarnessFilters {
    text?: string | RegExp;
    isSelected?: boolean;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a legacy `mat-option` in tests.
 * @deprecated Use `MatOptionHarness` from `@angular/material/core/testing` instead.
 * @breaking-change 17.0.0
 */
declare class MatLegacyOptionHarness extends ComponentHarness {
    static hostSelector: string;
    private _text;
    static with(options?: LegacyOptionHarnessFilters): HarnessPredicate<MatLegacyOptionHarness>;
    click(): Promise<void>;
    getText(): Promise<string>;
    isDisabled(): Promise<boolean>;
    isSelected(): Promise<boolean>;
    isActive(): Promise<boolean>;
    isMultiple(): Promise<boolean>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * @deprecated Use `OptgroupHarnessFilters` from `@angular/material/core/testing` instead.
 * @breaking-change 17.0.0
 */
interface LegacyOptgroupHarnessFilters extends BaseHarnessFilters {
    labelText?: string | RegExp;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a legacy `mat-optgroup` in tests.
 * @deprecated Use `MatOptgroupHarness` from `@angular/material/core/testing` instead.
 * @breaking-change 17.0.0
 */
declare class MatLegacyOptgroupHarness extends ComponentHarness {
    static hostSelector: string;
    private _label;
    static with(options?: LegacyOptgroupHarnessFilters): HarnessPredicate<MatLegacyOptgroupHarness>;
    getLabelText(): Promise<string>;
    isDisabled(): Promise<boolean>;
    getOptions(filter?: LegacyOptionHarnessFilters): Promise<MatLegacyOptionHarness[]>;
}

export { MatLegacyOptgroupHarness, MatLegacyOptionHarness };
export type { LegacyOptgroupHarnessFilters, LegacyOptionHarnessFilters };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-core-testing.d.ts.map
