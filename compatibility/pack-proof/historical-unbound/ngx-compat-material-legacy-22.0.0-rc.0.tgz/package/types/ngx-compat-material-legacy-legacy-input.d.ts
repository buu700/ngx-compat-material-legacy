import { MatInput } from '@angular/material/input';
export { MAT_INPUT_VALUE_ACCESSOR as MAT_LEGACY_INPUT_VALUE_ACCESSOR, getMatInputUnsupportedTypeError as getMatLegacyInputUnsupportedTypeError } from '@angular/material/input';
import * as i0 from '@angular/core';
import * as i2 from '@angular/cdk/text-field';
import * as i3 from '@ngx-compat/material-legacy/legacy-form-field';
import * as i1 from '@angular/cdk/bidi';

/**
 * Directive that allows a native input to work inside a `MatFormField`.
 * @deprecated Use `MatInput` from `@angular/material/input` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyInput extends MatInput {
    private _legacyFormField;
    protected _getPlaceholder(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyInput, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyInput, "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", ["matInput"], {}, {}, never, never, false, never>;
}

declare class MatCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatCommonModule, never, [typeof i1.BidiModule], [typeof i1.BidiModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatCommonModule>;
}

/**
 * @deprecated Use `MatInputModule` from `@angular/material/input` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacyInputModule, [typeof MatLegacyInput], [typeof i2.TextFieldModule, typeof i3.MatLegacyFormFieldModule, typeof MatCommonModule], [typeof i2.TextFieldModule, typeof i3.MatLegacyFormFieldModule, typeof MatLegacyInput]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacyInputModule>;
}

export { MatCommonModule, MatLegacyInput, MatLegacyInputModule };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-input.d.ts.map
