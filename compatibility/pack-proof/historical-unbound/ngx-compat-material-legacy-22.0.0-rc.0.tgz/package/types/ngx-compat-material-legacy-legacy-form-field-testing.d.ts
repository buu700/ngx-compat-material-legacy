import * as _angular_cdk_testing from '@angular/cdk/testing';
import { ComponentHarness, ComponentHarnessConstructor, HarnessPredicate, AsyncFactoryFn, TestElement } from '@angular/cdk/testing';
import { MatDatepickerInputHarness, MatDateRangeInputHarness } from '@angular/material/datepicker/testing';
import { ErrorHarnessFilters, FormFieldHarnessFilters } from '@angular/material/form-field/testing';
export { ErrorHarnessFilters as LegacyErrorHarnessFilters, FormFieldHarnessFilters as LegacyFormFieldHarnessFilters } from '@angular/material/form-field/testing';
import { MatLegacyInputHarness } from '@ngx-compat/material-legacy/legacy-input/testing';
import { MatLegacySelectHarness } from '@ngx-compat/material-legacy/legacy-select/testing';
import { MatFormFieldControlHarness } from '@angular/material/form-field/testing/control';
export { MatFormFieldControlHarness as MatLegacyFormFieldControlHarness } from '@angular/material/form-field/testing/control';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a legacy `mat-error` in tests.
 * @deprecated Use `MatErrorHarness` from `@angular/material/form-field/testing` instead.
 * @breaking-change 17.0.0
 */
declare class MatLegacyErrorHarness extends ComponentHarness {
    static hostSelector: string;
    static with<T extends MatLegacyErrorHarness>(this: ComponentHarnessConstructor<T>, options?: ErrorHarnessFilters): HarnessPredicate<T>;
    getText(): Promise<string>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatFormFieldHarnessBase` (removed from Angular Material 22).
 */

interface ErrorBase extends ComponentHarness {
    getText(): Promise<string>;
}
declare abstract class _MatFormFieldHarnessBase<ControlHarness extends MatFormFieldControlHarness, ErrorType extends ComponentHarnessConstructor<ErrorBase> & {
    with: (options?: ErrorHarnessFilters) => HarnessPredicate<ErrorBase>;
}> extends ComponentHarness {
    protected abstract _prefixContainer: AsyncFactoryFn<TestElement | null>;
    protected abstract _suffixContainer: AsyncFactoryFn<TestElement | null>;
    protected abstract _label: AsyncFactoryFn<TestElement | null>;
    protected abstract _hints: AsyncFactoryFn<TestElement[]>;
    protected abstract _inputControl: AsyncFactoryFn<ControlHarness | null>;
    protected abstract _selectControl: AsyncFactoryFn<ControlHarness | null>;
    protected abstract _datepickerInputControl: AsyncFactoryFn<ControlHarness | null>;
    protected abstract _dateRangeInputControl: AsyncFactoryFn<ControlHarness | null>;
    protected abstract _errorHarness: ErrorType;
    abstract getAppearance(): Promise<string>;
    abstract isLabelFloating(): Promise<boolean>;
    abstract hasLabel(): Promise<boolean>;
    getLabel(): Promise<string | null>;
    hasErrors(): Promise<boolean>;
    isDisabled(): Promise<boolean>;
    isAutofilled(): Promise<boolean>;
    getControl(): Promise<ControlHarness | null>;
    getControl<X extends MatFormFieldControlHarness>(type: ComponentHarnessConstructor<X>): Promise<X | null>;
    getControl<X extends MatFormFieldControlHarness>(type: HarnessPredicate<X>): Promise<X | null>;
    getThemeColor(): Promise<'primary' | 'accent' | 'warn'>;
    getTextErrors(): Promise<string[]>;
    getErrors(filter?: ErrorHarnessFilters): Promise<ErrorBase[]>;
    getTextHints(): Promise<string[]>;
    getPrefixText(): Promise<string>;
    getSuffixText(): Promise<string>;
    isControlTouched(): Promise<boolean | null>;
    isControlDirty(): Promise<boolean | null>;
    isControlValid(): Promise<boolean | null>;
    isControlPending(): Promise<boolean | null>;
    private _hasFormControl;
}

/**
 * Possible harnesses of controls which can be bound to a form-field.
 * @deprecated Use `FormFieldControlHarness` from `@angular/material/form-field/testing` instead.
 * @breaking-change 17.0.0
 */
type LegacyFormFieldControlHarness = MatLegacyInputHarness | MatLegacySelectHarness | MatDatepickerInputHarness | MatDateRangeInputHarness;
/**
 * Harness for interacting with a standard Material form-field's in tests.
 * @deprecated Use `MatFormFieldHarness` from `@angular/material/form-field/testing` instead.
 * @breaking-change 17.0.0
 */
declare class MatLegacyFormFieldHarness extends _MatFormFieldHarnessBase<LegacyFormFieldControlHarness, typeof MatLegacyErrorHarness> {
    static hostSelector: string;
    static with(options?: FormFieldHarnessFilters): HarnessPredicate<MatLegacyFormFieldHarness>;
    protected _prefixContainer: () => Promise<_angular_cdk_testing.TestElement | null>;
    protected _suffixContainer: () => Promise<_angular_cdk_testing.TestElement | null>;
    protected _label: () => Promise<_angular_cdk_testing.TestElement | null>;
    protected _errors: () => Promise<_angular_cdk_testing.TestElement[]>;
    protected _hints: () => Promise<_angular_cdk_testing.TestElement[]>;
    protected _inputControl: () => Promise<MatLegacyInputHarness | null>;
    protected _selectControl: () => Promise<MatLegacySelectHarness | null>;
    protected _datepickerInputControl: () => Promise<MatDatepickerInputHarness | null>;
    protected _dateRangeInputControl: () => Promise<MatDateRangeInputHarness | null>;
    protected _errorHarness: typeof MatLegacyErrorHarness;
    getAppearance(): Promise<'legacy' | 'standard' | 'fill' | 'outline'>;
    hasLabel(): Promise<boolean>;
    isLabelFloating(): Promise<boolean>;
}

export { MatLegacyErrorHarness, MatLegacyFormFieldHarness };
export type { LegacyFormFieldControlHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-form-field-testing.d.ts.map
