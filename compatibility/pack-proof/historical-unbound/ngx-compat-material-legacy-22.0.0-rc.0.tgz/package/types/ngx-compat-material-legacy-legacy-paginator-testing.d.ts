import * as _angular_cdk_testing from '@angular/cdk/testing';
import { ComponentHarness, AsyncFactoryFn, TestElement, HarnessPredicate } from '@angular/cdk/testing';
import { MatLegacySelectHarness } from '@ngx-compat/material-legacy/legacy-select/testing';
import { PaginatorHarnessFilters } from '@angular/material/paginator/testing';
export { PaginatorHarnessFilters as LegacyPaginatorHarnessFilters } from '@angular/material/paginator/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 harness base(s) removed from Angular Material 22.
 */

declare abstract class _MatPaginatorHarnessBase extends ComponentHarness {
    protected abstract _nextButton: AsyncFactoryFn<TestElement>;
    protected abstract _previousButton: AsyncFactoryFn<TestElement>;
    protected abstract _firstPageButton: AsyncFactoryFn<TestElement | null>;
    protected abstract _lastPageButton: AsyncFactoryFn<TestElement | null>;
    protected abstract _select: AsyncFactoryFn<(ComponentHarness & {
        getValueText(): Promise<string>;
        clickOptions(...filters: unknown[]): Promise<void>;
    }) | null>;
    protected abstract _pageSizeFallback: AsyncFactoryFn<TestElement>;
    protected abstract _rangeLabel: AsyncFactoryFn<TestElement>;
    /** Goes to the next page in the paginator. */
    goToNextPage(): Promise<void>;
    /** Returns whether or not the next page button is disabled. */
    isNextPageDisabled(): Promise<boolean>;
    isPreviousPageDisabled(): Promise<boolean>;
    /** Goes to the previous page in the paginator. */
    goToPreviousPage(): Promise<void>;
    /** Goes to the first page in the paginator. */
    goToFirstPage(): Promise<void>;
    /** Goes to the last page in the paginator. */
    goToLastPage(): Promise<void>;
    /**
     * Sets the page size of the paginator.
     * @param size Page size that should be select.
     */
    setPageSize(size: number): Promise<void>;
    /** Gets the page size of the paginator. */
    getPageSize(): Promise<number>;
    /** Gets the text of the range label of the paginator. */
    getRangeLabel(): Promise<string>;
}

/**
 * Harness for interacting with a standard mat-paginator in tests.
 * @deprecated Use `MatPaginatorHarness` from `@angular/material/paginator/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyPaginatorHarness extends _MatPaginatorHarnessBase {
    /** Selector used to find paginator instances. */
    static hostSelector: string;
    protected _nextButton: () => Promise<_angular_cdk_testing.TestElement>;
    protected _previousButton: () => Promise<_angular_cdk_testing.TestElement>;
    protected _firstPageButton: () => Promise<_angular_cdk_testing.TestElement | null>;
    protected _lastPageButton: () => Promise<_angular_cdk_testing.TestElement | null>;
    protected _select: () => Promise<MatLegacySelectHarness | null>;
    protected _pageSizeFallback: () => Promise<_angular_cdk_testing.TestElement>;
    protected _rangeLabel: () => Promise<_angular_cdk_testing.TestElement>;
    /**
     * Gets a `HarnessPredicate` that can be used to search for a `MatPaginatorHarness` that meets
     * certain criteria.
     * @param options Options for filtering which paginator instances are considered a match.
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: PaginatorHarnessFilters): HarnessPredicate<MatLegacyPaginatorHarness>;
}

export { MatLegacyPaginatorHarness, _MatPaginatorHarnessBase as _MatLegacyPaginatorHarnessBase };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-paginator-testing.d.ts.map
