import { BaseHarnessFilters, ContentContainerComponentHarness, HarnessPredicate } from '@angular/cdk/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Historical legacy button variants (Material 16).
 * Current Material's ButtonVariant no longer includes raised/flat/stroked.
 */
type LegacyButtonVariant = 'basic' | 'raised' | 'flat' | 'icon' | 'stroked' | 'fab' | 'mini-fab';
/** @deprecated Use filters with MatButtonHarness from @angular/material/button/testing for MDC buttons. */
interface LegacyButtonHarnessFilters extends BaseHarnessFilters {
    text?: string | RegExp;
    variant?: LegacyButtonVariant;
    disabled?: boolean;
}
/**
 * Harness for interacting with a standard mat-button in tests.
 * @deprecated Use `MatButtonHarness` from `@angular/material/button/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyButtonHarness extends ContentContainerComponentHarness {
    /** The selector for the host element of a button instance. */
    static hostSelector: string;
    /**
     * Gets a `HarnessPredicate` that can be used to search for a button harness that meets
     * certain criteria.
     * @param options Options for filtering which button instances are considered a match.
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: LegacyButtonHarnessFilters): HarnessPredicate<MatLegacyButtonHarness>;
    /**
     * Clicks the button at the given position relative to its top-left.
     * @param relativeX The relative x position of the click.
     * @param relativeY The relative y position of the click.
     */
    click(relativeX: number, relativeY: number): Promise<void>;
    /** Clicks the button at its center. */
    click(location: 'center'): Promise<void>;
    /** Clicks the button. */
    click(): Promise<void>;
    /** Whether the button is disabled. */
    isDisabled(): Promise<boolean>;
    /** Gets the button's label text. */
    getText(): Promise<string>;
    /** Focuses the button. */
    focus(): Promise<void>;
    /** Blurs the button. */
    blur(): Promise<void>;
    /** Whether the button is focused. */
    isFocused(): Promise<boolean>;
    /** Gets the variant of the button. */
    getVariant(): Promise<LegacyButtonVariant>;
}

export { MatLegacyButtonHarness };
export type { LegacyButtonHarnessFilters, LegacyButtonVariant };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-button-testing.d.ts.map
