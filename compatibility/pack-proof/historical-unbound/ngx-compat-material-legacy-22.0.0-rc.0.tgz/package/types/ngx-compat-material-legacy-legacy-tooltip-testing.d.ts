import * as _angular_cdk_testing from '@angular/cdk/testing';
import { ComponentHarness, AsyncFactoryFn, TestElement, HarnessPredicate } from '@angular/cdk/testing';
import { TooltipHarnessFilters } from '@angular/material/tooltip/testing';
export { TooltipHarnessFilters as LegacyTooltipHarnessFilters } from '@angular/material/tooltip/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 harness base(s) removed from Angular Material 22.
 */

declare abstract class _MatTooltipHarnessBase extends ComponentHarness {
    protected abstract _optionalPanel: AsyncFactoryFn<TestElement | null>;
    protected abstract _hiddenClass: string;
    protected abstract _disabledClass: string;
    protected abstract _showAnimationName: string;
    protected abstract _hideAnimationName: string;
    /** Shows the tooltip. */
    show(): Promise<void>;
    /** Hides the tooltip. */
    hide(): Promise<void>;
    /** Gets whether the tooltip is open. */
    isOpen(): Promise<boolean>;
    /** Gets whether the tooltip is disabled */
    isDisabled(): Promise<boolean>;
    /** Gets a promise for the tooltip panel's text. */
    getTooltipText(): Promise<string>;
}

/**
 * Harness for interacting with a standard mat-tooltip in tests.
 * @deprecated Use `MatTooltipHarness` from `@angular/material/tooltip/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyTooltipHarness extends _MatTooltipHarnessBase {
    protected _optionalPanel: () => Promise<_angular_cdk_testing.TestElement | null>;
    protected _hiddenClass: string;
    protected _disabledClass: string;
    protected _showAnimationName: string;
    protected _hideAnimationName: string;
    static hostSelector: string;
    /**
     * Gets a `HarnessPredicate` that can be used to search
     * for a tooltip trigger with specific attributes.
     * @param options Options for narrowing the search.
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: TooltipHarnessFilters): HarnessPredicate<MatLegacyTooltipHarness>;
}

export { MatLegacyTooltipHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-tooltip-testing.d.ts.map
