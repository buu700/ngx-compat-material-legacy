import * as i0 from '@angular/core';
import { ElementRef, InjectionToken, AfterContentInit, AfterContentChecked, AfterViewInit, OnDestroy, QueryList, ChangeDetectorRef, NgZone } from '@angular/core';
import { AbstractControlDirective } from '@angular/forms';
import { ThemePalette as ThemePalette$1 } from '@angular/material/core';
import * as i1 from '@angular/cdk/bidi';
import { Directionality } from '@angular/cdk/bidi';
import { BooleanInput } from '@angular/cdk/coercion';
import { Platform } from '@angular/cdk/platform';
import { MatFormFieldControl } from '@angular/material/form-field';
export { MAT_ERROR as MAT_LEGACY_ERROR, MAT_FORM_FIELD as MAT_LEGACY_FORM_FIELD, MAT_PREFIX as MAT_LEGACY_PREFIX, MAT_SUFFIX as MAT_LEGACY_SUFFIX, MatFormFieldControl as MatLegacyFormFieldControl, getMatFormFieldDuplicatedHintError as getMatLegacyFormFieldDuplicatedHintError, getMatFormFieldMissingControlError as getMatLegacyFormFieldMissingControlError, getMatFormFieldPlaceholderConflictError as getMatLegacyFormFieldPlaceholderConflictError } from '@angular/material/form-field';
import * as i8 from '@angular/common';
import * as i10 from '@angular/cdk/observers';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Single error message to be shown underneath the form field.
 * @deprecated Use `MatError` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyError {
    id: string;
    constructor(ariaLive: string, elementRef: ElementRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyError, [{ attribute: "aria-live"; }, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyError, "mat-error", never, { "id": { "alias": "id"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** @docs-private */
type Constructor<T> = new (...args: any[]) => T;
/**
 * This is a permissive type for abstract class constructors.
 * @docs-private
 */
type AbstractConstructor<T = object> = abstract new (...args: any[]) => T;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** @docs-private */
interface CanColor {
    /** Theme color palette for the component. */
    color: ThemePalette;
    /** Default color to fall back to if no value is set. */
    defaultColor: ThemePalette | undefined;
}
/** Possible color palette values. */
type ThemePalette = 'primary' | 'accent' | 'warn' | undefined;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Injection token that can be used to reference instances of `MatHint`. It serves as
 * alternative token to the actual `MatHint` class which could cause unnecessary
 * retention of the class and its directive metadata.
 *
 * *Note*: This is not part of the public API as the MDC-based form-field will not
 * need a lightweight token for `MatHint` and we want to reduce breaking changes.
 *
 * @deprecated Use `_MAT_HINT` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare const _MAT_LEGACY_HINT: InjectionToken<MatLegacyHint>;
/**
 * Hint text to be shown underneath the form field control.
 * @deprecated Use `MatHint` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyHint {
    /** Whether to align the hint label at the start or end of the line. */
    align: 'start' | 'end';
    /** Unique ID for the hint. Used for the aria-describedby on the form field control. */
    id: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyHint, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyHint, "mat-hint", never, { "align": { "alias": "align"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * The floating label for a `mat-form-field`.
 * @deprecated Use `MatLabel` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyLabel {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyLabel, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyLabel, "mat-label", never, {}, {}, never, never, false, never>;
}

/**
 * The placeholder text for an `MatFormField`.
 * @deprecated Use `<mat-label>` to specify the label and the `placeholder` attribute to specify the
 *     placeholder.
 * @breaking-change 8.0.0
 */
declare class MatLegacyPlaceholder {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyPlaceholder, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyPlaceholder, "mat-placeholder", never, {}, {}, never, never, false, never>;
}

/**
 * Prefix to be placed in front of the form field.
 * @deprecated Use `MatPrefix` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyPrefix {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyPrefix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyPrefix, "[matPrefix]", never, {}, {}, never, never, false, never>;
}

/**
 * Suffix to be placed at the end of the form field.
 * @deprecated Use `MatSuffix` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacySuffix {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacySuffix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacySuffix, "[matSuffix]", never, {}, {}, never, never, false, never>;
}

/**
 * Boilerplate for applying mixins to MatFormField.
 * @docs-private
 */
declare const _MatFormFieldBase: Constructor<CanColor> & AbstractConstructor<CanColor> & {
    new (_elementRef: ElementRef): {
        _elementRef: ElementRef;
    };
};
/**
 * Possible appearance styles for the form field.
 * @deprecated Use `MatFormFieldAppearance` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
type MatLegacyFormFieldAppearance = 'legacy' | 'standard' | 'fill' | 'outline';
/**
 * Possible values for the "floatLabel" form field input.
 * @deprecated Use `FloatLabelType` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
type LegacyFloatLabelType = 'always' | 'never' | 'auto';
/**
 * Represents the default options for the form field that can be configured
 * using the `MAT_FORM_FIELD_DEFAULT_OPTIONS` injection token.
 * @deprecated Use `MatFormFieldDefaultOptions` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
interface MatLegacyFormFieldDefaultOptions {
    /** Default form field appearance style. */
    appearance?: MatLegacyFormFieldAppearance;
    /** Default color of the form field. */
    color?: ThemePalette$1;
    /** Whether the required marker should be hidden by default. */
    hideRequiredMarker?: boolean;
    /**
     * Whether the label for form fields should by default float `always`,
     * `never`, or `auto` (only when necessary).
     */
    floatLabel?: LegacyFloatLabelType;
}
/**
 * Injection token that can be used to configure the
 * default options for all form field within an app.
 * @deprecated Use `MAT_FORM_FIELD_DEFAULT_OPTIONS` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare const MAT_LEGACY_FORM_FIELD_DEFAULT_OPTIONS: InjectionToken<MatLegacyFormFieldDefaultOptions>;
/**
 * Container for form controls that applies Material Design styling and behavior.
 * @deprecated Use `MatFormField` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyFormField extends _MatFormFieldBase implements AfterContentInit, AfterContentChecked, AfterViewInit, OnDestroy, CanColor {
    private _changeDetectorRef;
    private _dir;
    private _defaults;
    private _platform;
    private _ngZone;
    /**
     * Whether the outline gap needs to be calculated
     * immediately on the next change detection run.
     */
    private _outlineGapCalculationNeededImmediately;
    /** Whether the outline gap needs to be calculated next time the zone has stabilized. */
    private _outlineGapCalculationNeededOnStable;
    private readonly _destroyed;
    /** The form field appearance style. */
    get appearance(): MatLegacyFormFieldAppearance;
    set appearance(value: MatLegacyFormFieldAppearance);
    _appearance: MatLegacyFormFieldAppearance;
    /** Whether the required marker should be hidden. */
    get hideRequiredMarker(): boolean;
    set hideRequiredMarker(value: BooleanInput);
    private _hideRequiredMarker;
    /** Override for the logic that disables the label animation in certain cases. */
    private _showAlwaysAnimate;
    /** Whether the floating label should always float or not. */
    _shouldAlwaysFloat(): boolean;
    /** Whether the label can float or not. */
    _canLabelFloat(): boolean;
    /** State of the mat-hint and mat-error animations. */
    _subscriptAnimationState: string;
    /** Text for the form field hint. */
    get hintLabel(): string;
    set hintLabel(value: string);
    private _hintLabel;
    readonly _hintLabelId: string;
    readonly _labelId: string;
    /**
     * Whether the label should always float, never float or float as the user types.
     *
     * Note: only the legacy appearance supports the `never` option. `never` was originally added as a
     * way to make the floating label emulate the behavior of a standard input placeholder. However
     * the form field now supports both floating labels and placeholders. Therefore in the non-legacy
     * appearances the `never` option has been disabled in favor of just using the placeholder.
     */
    get floatLabel(): LegacyFloatLabelType;
    set floatLabel(value: LegacyFloatLabelType);
    private _floatLabel;
    /** Whether the Angular animations are enabled. */
    _animationsEnabled: boolean;
    /** Captured in injection context for MATERIAL_ANIMATIONS / NoopAnimations. */
    private _legacyAnimationsDisabled;
    _connectionContainerRef: ElementRef;
    _inputContainerRef: ElementRef;
    private _label;
    _controlNonStatic: MatFormFieldControl<any>;
    _controlStatic: MatFormFieldControl<any>;
    get _control(): MatFormFieldControl<any>;
    set _control(value: MatFormFieldControl<any>);
    private _explicitFormFieldControl;
    _labelChildNonStatic: MatLegacyLabel;
    _labelChildStatic: MatLegacyLabel;
    _placeholderChild: MatLegacyPlaceholder;
    _errorChildren: QueryList<MatLegacyError>;
    _hintChildren: QueryList<MatLegacyHint>;
    _prefixChildren: QueryList<MatLegacyPrefix>;
    _suffixChildren: QueryList<MatLegacySuffix>;
    constructor(elementRef: ElementRef, _changeDetectorRef: ChangeDetectorRef, _dir: Directionality, _defaults: MatLegacyFormFieldDefaultOptions, _platform: Platform, _ngZone: NgZone, _animationMode: string);
    /**
     * Gets the id of the label element. If no label is present, returns `null`.
     */
    getLabelId(): string | null;
    /**
     * Gets an ElementRef for the element that a overlay attached to the form field should be
     * positioned relative to.
     */
    getConnectedOverlayOrigin(): ElementRef;
    ngAfterContentInit(): void;
    ngAfterContentChecked(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * Determines whether a class from the AbstractControlDirective
     * should be forwarded to the host element.
     */
    _shouldForward(prop: keyof AbstractControlDirective): boolean;
    _hasPlaceholder(): boolean;
    _hasLabel(): boolean;
    _shouldLabelFloat(): boolean;
    _hideControlPlaceholder(): boolean;
    _hasFloatingLabel(): boolean;
    /** Determines whether to display hints or errors. */
    _getDisplayedMessages(): 'error' | 'hint';
    /** Animates the placeholder up and locks it in position. */
    _animateAndLockLabel(): void;
    /**
     * Ensure that there is only one placeholder (either `placeholder` attribute on the child control
     * or child element with the `mat-placeholder` directive).
     */
    private _validatePlaceholders;
    /** Does any extra processing that is required when handling the hints. */
    private _processHints;
    /**
     * Ensure that there is a maximum of one of each `<mat-hint>` alignment specified, with the
     * attribute being considered as `align="start"`.
     */
    private _validateHints;
    /** Gets the default float label state. */
    private _getDefaultFloatLabelState;
    /**
     * Sets the list of element IDs that describe the child control. This allows the control to update
     * its `aria-describedby` attribute accordingly.
     */
    private _syncDescribedByIds;
    /** Throws an error if the form field's control is missing. */
    protected _validateControlChild(): void;
    /**
     * Updates the width and position of the gap in the outline. Only relevant for the outline
     * appearance.
     */
    updateOutlineGap(): void;
    /** Gets the start end of the rect considering the current directionality. */
    private _getStartEnd;
    /** Checks whether the form field is attached to the DOM. */
    private _isAttachedToDOM;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyFormField, [null, null, { optional: true; }, { optional: true; }, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyFormField, "mat-form-field", ["matFormField"], { "color": { "alias": "color"; "required": false; }; "appearance": { "alias": "appearance"; "required": false; }; "hideRequiredMarker": { "alias": "hideRequiredMarker"; "required": false; }; "hintLabel": { "alias": "hintLabel"; "required": false; }; "floatLabel": { "alias": "floatLabel"; "required": false; }; }, {}, ["_controlNonStatic", "_controlStatic", "_labelChildNonStatic", "_labelChildStatic", "_placeholderChild", "_errorChildren", "_hintChildren", "_prefixChildren", "_suffixChildren"], ["[matPrefix]", "*", "mat-placeholder", "mat-label", "[matSuffix]", "mat-error", "mat-hint:not([align='end'])", "mat-hint[align='end']"], false, never>;
}

declare class MatCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatCommonModule, never, [typeof i1.BidiModule], [typeof i1.BidiModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatCommonModule>;
}

/**
 * @deprecated Use `MatFormFieldModule` from `@angular/material/form-field` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyFormFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyFormFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacyFormFieldModule, [typeof MatLegacyError, typeof MatLegacyFormField, typeof MatLegacyHint, typeof MatLegacyLabel, typeof MatLegacyPlaceholder, typeof MatLegacyPrefix, typeof MatLegacySuffix], [typeof i8.CommonModule, typeof MatCommonModule, typeof i10.ObserversModule], [typeof MatCommonModule, typeof MatLegacyError, typeof MatLegacyFormField, typeof MatLegacyHint, typeof MatLegacyLabel, typeof MatLegacyPlaceholder, typeof MatLegacyPrefix, typeof MatLegacySuffix]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacyFormFieldModule>;
}

export { MAT_LEGACY_FORM_FIELD_DEFAULT_OPTIONS, MatCommonModule, MatLegacyError, MatLegacyFormField, MatLegacyFormFieldModule, MatLegacyHint, MatLegacyLabel, MatLegacyPlaceholder, MatLegacyPrefix, MatLegacySuffix, _MAT_LEGACY_HINT };
export type { LegacyFloatLabelType, MatLegacyFormFieldAppearance, MatLegacyFormFieldDefaultOptions };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-form-field.d.ts.map
