import { AnimationTriggerMetadata } from '@angular/animations';

/**
 * Optional Angular animation recipes for legacy form-field.
 * Primary form-field uses CSS transitions for subscript messages.
 */

declare const matFormFieldAnimations: {
    readonly transitionMessages: AnimationTriggerMetadata;
};

export { matFormFieldAnimations, matFormFieldAnimations as matLegacyFormFieldAnimations };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-form-field-animations.d.ts.map
