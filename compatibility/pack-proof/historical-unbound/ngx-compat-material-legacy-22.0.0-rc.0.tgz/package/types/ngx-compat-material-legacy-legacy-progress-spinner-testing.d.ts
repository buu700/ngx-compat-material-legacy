import { ComponentHarness, HarnessPredicate } from '@angular/cdk/testing';
import { LegacyProgressSpinnerMode } from '@ngx-compat/material-legacy/legacy-progress-spinner';
import { ProgressSpinnerHarnessFilters } from '@angular/material/progress-spinner/testing';
export { ProgressSpinnerHarnessFilters as LegacyProgressSpinnerHarnessFilters } from '@angular/material/progress-spinner/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a standard mat-progress-spinner in tests.
 * @deprecated Use `MatProgressSpinnerHarness` from `@angular/material/progress-spinner/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyProgressSpinnerHarness extends ComponentHarness {
    /** The selector for the host element of a Progress Spinner instance. */
    static hostSelector: string;
    /**
     * Gets a `HarnessPredicate` that can be used to search for a `MatProgressSpinnerHarness` that
     * meets certain criteria.
     * @param options Options for filtering which progress spinner instances are considered a match.
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: ProgressSpinnerHarnessFilters): HarnessPredicate<MatLegacyProgressSpinnerHarness>;
    /** Gets the progress spinner's value. */
    getValue(): Promise<number | null>;
    /** Gets the progress spinner's mode. */
    getMode(): Promise<LegacyProgressSpinnerMode>;
}

export { MatLegacyProgressSpinnerHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-progress-spinner-testing.d.ts.map
