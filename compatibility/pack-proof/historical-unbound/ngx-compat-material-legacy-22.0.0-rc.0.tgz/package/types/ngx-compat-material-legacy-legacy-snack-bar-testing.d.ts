import { ContentContainerComponentHarness, HarnessPredicate } from '@angular/cdk/testing';
import { SnackBarHarnessFilters } from '@angular/material/snack-bar/testing';
export { SnackBarHarnessFilters as LegacySnackBarHarnessFilters } from '@angular/material/snack-bar/testing';
import { AriaLivePoliteness } from '@angular/cdk/a11y';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 harness base(s) removed from Angular Material 22.
 */

declare abstract class _MatSnackBarHarnessBase extends ContentContainerComponentHarness<string> {
    protected abstract _messageSelector: string;
    protected abstract _actionButtonSelector: string;
    private _snackBarLiveRegion;
    /**
     * Gets the role of the snack-bar. The role of a snack-bar is determined based
     * on the ARIA politeness specified in the snack-bar config.
     * @deprecated Use `getAriaLive` instead.
     * @breaking-change 13.0.0
     */
    getRole(): Promise<'alert' | 'status' | null>;
    /**
     * Gets the aria-live of the snack-bar's live region. The aria-live of a snack-bar is
     * determined based on the ARIA politeness specified in the snack-bar config.
     */
    getAriaLive(): Promise<AriaLivePoliteness>;
    /**
     * Whether the snack-bar has an action. Method cannot be used for snack-bar's with custom content.
     */
    hasAction(): Promise<boolean>;
    /**
     * Gets the description of the snack-bar. Method cannot be used for snack-bar's without action or
     * with custom content.
     */
    getActionDescription(): Promise<string>;
    /**
     * Dismisses the snack-bar by clicking the action button. Method cannot be used for snack-bar's
     * without action or with custom content.
     */
    dismissWithAction(): Promise<void>;
    /**
     * Gets the message of the snack-bar. Method cannot be used for snack-bar's with custom content.
     */
    getMessage(): Promise<string>;
    /** Gets whether the snack-bar has been dismissed. */
    isDismissed(): Promise<boolean>;
    /**
     * Asserts that the current snack-bar has annotated content. Promise reject
     * if content is not annotated.
     */
    protected abstract _assertContentAnnotated(): Promise<void>;
    /**
     * Asserts that the current snack-bar has an action defined. Otherwise the
     * promise will reject.
     */
    protected _assertHasAction(): Promise<void>;
    /** Gets the simple snack bar action button. */
    private _getActionButton;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a standard mat-snack-bar in tests.
 * @deprecated Use `MatSnackBarHarness` from `@angular/material/snack-bar/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacySnackBarHarness extends _MatSnackBarHarnessBase {
    /** The selector for the host element of a `MatSnackBar` instance. */
    static hostSelector: string;
    protected _messageSelector: string;
    protected _actionButtonSelector: string;
    /**
     * Gets a `HarnessPredicate` that can be used to search for a snack bar with specific attributes.
     * @param options Options for filtering which snack bar instances are considered a match.
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: SnackBarHarnessFilters): HarnessPredicate<MatLegacySnackBarHarness>;
    protected _assertContentAnnotated(): Promise<void>;
    /** Whether the snack-bar is using the default content template. */
    private _isSimpleSnackBar;
}

export { MatLegacySnackBarHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-snack-bar-testing.d.ts.map
