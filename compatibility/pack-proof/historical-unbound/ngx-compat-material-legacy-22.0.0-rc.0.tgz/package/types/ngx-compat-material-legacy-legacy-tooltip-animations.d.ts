import { AnimationTriggerMetadata } from '@angular/animations';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Animations used by MatTooltip.
 * @docs-private
 * @deprecated Use `matTooltipAnimations` from `@angular/material/tooltip` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare const matLegacyTooltipAnimations: {
    readonly tooltipState: AnimationTriggerMetadata;
};

export { matLegacyTooltipAnimations };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-tooltip-animations.d.ts.map
