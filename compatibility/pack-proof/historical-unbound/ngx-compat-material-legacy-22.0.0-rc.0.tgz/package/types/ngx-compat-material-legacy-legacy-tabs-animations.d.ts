import { AnimationTriggerMetadata } from '@angular/animations';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `matTabsAnimations` (removed from Angular Material 22).
 */

/**
 * Animations used by the Material tabs.
 * @docs-private
 */
declare const matTabsAnimations: {
    readonly translateTab: AnimationTriggerMetadata;
};

export { matTabsAnimations as matLegacyTabsAnimations, matTabsAnimations };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-tabs-animations.d.ts.map
