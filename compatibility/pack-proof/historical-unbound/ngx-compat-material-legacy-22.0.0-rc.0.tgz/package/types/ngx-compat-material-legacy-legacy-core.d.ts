import * as i0 from '@angular/core';
import { InjectionToken, AfterViewChecked, OnDestroy, ChangeDetectorRef, EventEmitter, ElementRef, QueryList } from '@angular/core';
import { FocusableOption, FocusOrigin } from '@angular/cdk/a11y';
import { BooleanInput } from '@angular/cdk/coercion';
import { Subject } from 'rxjs';
import * as i3 from '@angular/material/core';
export { MATERIAL_ANIMATIONS } from '@angular/material/core';
import * as i4 from '@angular/common';
import * as i1 from '@angular/cdk/bidi';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Describes a parent component that manages a list of options.
 * Contains properties that the options can inherit.
 * @docs-private
 */
interface MatOptionParentComponent {
    disableRipple?: boolean;
    multiple?: boolean;
    inertGroups?: boolean;
    hideSingleSelectionIndicator?: boolean;
}
/**
 * Injection token used to provide the parent component to options.
 */
declare const MAT_OPTION_PARENT_COMPONENT: InjectionToken<MatOptionParentComponent>;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** @docs-private */
type Constructor<T> = new (...args: any[]) => T;
/**
 * This is a permissive type for abstract class constructors.
 * @docs-private
 */
type AbstractConstructor<T = object> = abstract new (...args: any[]) => T;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** @docs-private */
interface CanDisable {
    /** Whether the component is disabled. */
    disabled: boolean;
}

/** @docs-private */
declare const _MatOptgroupMixinBase: Constructor<CanDisable> & AbstractConstructor<CanDisable> & {
    new (): {};
};
declare class _MatOptgroupBase extends _MatOptgroupMixinBase implements CanDisable {
    /** Label for the option group. */
    label: string;
    /** Unique id for the underlying label. */
    _labelId: string;
    /** Whether the group is in inert a11y mode. */
    _inert: boolean;
    constructor(parent?: MatOptionParentComponent);
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatOptgroupBase, [{ optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_MatOptgroupBase, never, never, { "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
/**
 * Injection token that can be used to reference instances of `MatOptgroup`. It serves as
 * alternative token to the actual `MatOptgroup` class which could cause unnecessary
 * retention of the class and its component metadata.
 */
declare const MAT_OPTGROUP: InjectionToken<_MatOptgroupBase>;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Event object emitted by MatOption when selected or deselected. */
declare class MatOptionSelectionChange<T = any> {
    /** Reference to the option that emitted the event. */
    source: _MatOptionBase<T>;
    /** Whether the change in the option's value was a result of a user action. */
    isUserInput: boolean;
    constructor(
    /** Reference to the option that emitted the event. */
    source: _MatOptionBase<T>, 
    /** Whether the change in the option's value was a result of a user action. */
    isUserInput?: boolean);
}
declare class _MatOptionBase<T = any> implements FocusableOption, AfterViewChecked, OnDestroy {
    private _element;
    _changeDetectorRef: ChangeDetectorRef;
    private _parent;
    readonly group: _MatOptgroupBase;
    private _selected;
    private _active;
    private _disabled;
    private _mostRecentViewValue;
    /** Whether the wrapping component is in multiple selection mode. */
    get multiple(): boolean | undefined;
    /** Whether or not the option is currently selected. */
    get selected(): boolean;
    /** The form value of the option. */
    value: T;
    /** The unique ID of the option. */
    id: string;
    /** Whether the option is disabled. */
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    /** Whether ripples for the option are disabled. */
    get disableRipple(): boolean;
    /** Whether to display checkmark for single-selection. */
    get hideSingleSelectionIndicator(): boolean;
    /** Event emitted when the option is selected or deselected. */
    readonly onSelectionChange: EventEmitter<MatOptionSelectionChange<T>>;
    /** Element containing the option's text. */
    _text: ElementRef<HTMLElement> | undefined;
    /** Emits when the state of the option changes and any parents have to be notified. */
    readonly _stateChanges: Subject<void>;
    constructor(_element: ElementRef<HTMLElement>, _changeDetectorRef: ChangeDetectorRef, _parent: MatOptionParentComponent, group: _MatOptgroupBase);
    /**
     * Whether or not the option is currently active and ready to be selected.
     * An active option displays styles as if it is focused, but the
     * focus is actually retained somewhere else. This comes in handy
     * for components like autocomplete where focus must remain on the input.
     */
    get active(): boolean;
    /**
     * The displayed value of the option. It is necessary to show the selected option in the
     * select's trigger.
     */
    get viewValue(): string;
    /** Selects the option. */
    select(emitEvent?: boolean): void;
    /** Deselects the option. */
    deselect(emitEvent?: boolean): void;
    /** Sets focus onto this option. */
    focus(_origin?: FocusOrigin, options?: FocusOptions): void;
    /**
     * This method sets display styles on the option to make it appear
     * active. This is used by the ActiveDescendantKeyManager so key
     * events will display the proper options as active on arrow key events.
     */
    setActiveStyles(): void;
    /**
     * This method removes display styles on the option that made it appear
     * active. This is used by the ActiveDescendantKeyManager so key
     * events will display the proper options as active on arrow key events.
     */
    setInactiveStyles(): void;
    /** Gets the label to be used when determining whether the option should be focused. */
    getLabel(): string;
    /** Ensures the option is selected when activated from the keyboard. */
    _handleKeydown(event: KeyboardEvent): void;
    /**
     * `Selects the option while indicating the selection came from the user. Used to
     * determine if the select's view -> model callback should be invoked.`
     */
    _selectViaInteraction(): void;
    /** Returns the correct tabindex for the option depending on disabled state. */
    _getTabIndex(): string;
    /** Gets the host DOM element. */
    _getHostElement(): HTMLElement;
    ngAfterViewChecked(): void;
    ngOnDestroy(): void;
    /** Emits the selection change event. */
    private _emitSelectionChangeEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatOptionBase<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_MatOptionBase<any>, never, never, { "value": { "alias": "value"; "required": false; }; "id": { "alias": "id"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "onSelectionChange": "onSelectionChange"; }, never, never, true, never>;
}

/**
 * Component that is used to group instances of `mat-option`.
 * @deprecated Use `MatOptgroup` from `@angular/material/core` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyOptgroup extends _MatOptgroupBase {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyOptgroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyOptgroup, "mat-optgroup", ["matOptgroup"], { "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, ["*", "mat-option, ng-container"], false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Single option inside of a `<mat-select>` element.
 * @deprecated Use `MatOption` from `@angular/material/core` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyOption<T = any> extends _MatOptionBase<T> {
    constructor(element: ElementRef<HTMLElement>, changeDetectorRef: ChangeDetectorRef, parent: MatOptionParentComponent, group: MatLegacyOptgroup);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyOption<any>, [null, null, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyOption<any>, "mat-option", ["matOption"], {}, {}, never, ["*"], false, never>;
}

declare class MatCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatCommonModule, never, [typeof i1.BidiModule], [typeof i1.BidiModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatCommonModule>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 */

declare function _countGroupLabelsBeforeOption(optionIndex: number, options: QueryList<_MatOptionBase>, optionGroups: QueryList<_MatOptgroupBase>): number;
/**
 * Determines the position to which to scroll a panel in order for an option to be into view.
 * @param optionOffset Offset of the option from the top of the panel.
 * @param optionHeight Height of the options.
 * @param currentScrollPosition Current scroll position of the panel.
 * @param panelHeight Height of the panel.
 * @docs-private
 */
declare function _getOptionScrollPosition(optionOffset: number, optionHeight: number, currentScrollPosition: number, panelHeight: number): number;

/**
 * @deprecated Use `MatOptionModule` from `@angular/material/core` instead.
 * @breaking-change 17.0.0
 */
declare class MatLegacyOptionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyOptionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacyOptionModule, [typeof MatLegacyOption, typeof MatLegacyOptgroup], [typeof i3.MatRippleModule, typeof i4.CommonModule, typeof MatCommonModule, typeof i3.MatPseudoCheckboxModule], [typeof MatLegacyOption, typeof MatLegacyOptgroup]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacyOptionModule>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned legacy motion helper. Reads the public MATERIAL_ANIMATIONS token and
 * public ANIMATION_MODULE_TYPE. Does not call private Material helpers
 * (_getAnimationsState / _animationsDisabled).
 */

/** Owned state labels for lifecycle/tests (mirrors Material public semantics). */
type LegacyAnimationsState = 'enabled' | 'di-disabled' | 'reduced-motion';
/**
 * Optional override token for unit tests that cannot construct Material's
 * MATERIAL_ANIMATIONS provider graph. Production code should prefer
 * MATERIAL_ANIMATIONS / ANIMATION_MODULE_TYPE.
 */
declare const LEGACY_ANIMATIONS_TEST_OVERRIDE: InjectionToken<LegacyAnimationsState | null>;
/**
 * Resolves whether legacy overlay motion should run.
 * Must be called in an injection context.
 */
declare function getLegacyAnimationsState(): LegacyAnimationsState;
/** True when DI or reduced-motion asks overlays to skip meaningful motion. */
declare function legacyAnimationsDisabled(): boolean;
/** Zero-duration params used when dialog (and similar) should noop motion. */
declare const LEGACY_ZERO_ANIMATION_PARAMS: {
    readonly enterAnimationDuration: "0ms";
    readonly exitAnimationDuration: "0ms";
};
/** Generic zero map for parameterized overlay recipes. */
declare function zeroAnimationParams<T extends Record<string, string>>(defaults: T): T;
/**
 * Build `{value, params}` for Angular animation host bindings.
 * When disabled, every provided default duration becomes `0ms`.
 */
declare function legacyAnimationTriggerState<T extends Record<string, string>>(value: string, defaults: T, disabled: boolean): {
    value: string;
    params: T;
};

export { LEGACY_ANIMATIONS_TEST_OVERRIDE, LEGACY_ZERO_ANIMATION_PARAMS, MAT_OPTGROUP as MAT_LEGACY_OPTGROUP, MAT_OPTION_PARENT_COMPONENT as MAT_LEGACY_OPTION_PARENT_COMPONENT, MatCommonModule, MatLegacyOptgroup, MatLegacyOption, MatLegacyOptionModule, MatOptionSelectionChange as MatLegacyOptionSelectionChange, _MatOptgroupBase as _MatLegacyOptgroupBase, _MatOptionBase as _MatLegacyOptionBase, _MatOptgroupBase, _MatOptionBase, _countGroupLabelsBeforeOption as _countGroupLabelsBeforeLegacyOption, _getOptionScrollPosition as _getLegacyOptionScrollPosition, getLegacyAnimationsState, legacyAnimationTriggerState, legacyAnimationsDisabled, zeroAnimationParams };
export type { LegacyAnimationsState, MatOptionParentComponent as MatLegacyOptionParentComponent };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-core.d.ts.map
