import * as i0 from '@angular/core';
import { OnDestroy, ElementRef, NgZone, ChangeDetectorRef, ComponentRef, EmbeddedViewRef, Type, Injector, TemplateRef } from '@angular/core';
import { AriaLivePoliteness, LiveAnnouncer } from '@angular/cdk/a11y';
import { Platform } from '@angular/cdk/platform';
import * as i4 from '@angular/cdk/portal';
import { BasePortalOutlet, CdkPortalOutlet, ComponentPortal, TemplatePortal, DomPortal } from '@angular/cdk/portal';
import { MatSnackBarConfig } from '@angular/material/snack-bar';
export { MAT_SNACK_BAR_DATA as MAT_LEGACY_SNACK_BAR_DATA, MAT_SNACK_BAR_DEFAULT_OPTIONS as MAT_LEGACY_SNACK_BAR_DEFAULT_OPTIONS, MatSnackBarConfig as MatLegacySnackBarConfig, MatSnackBarHorizontalPosition as MatLegacySnackBarHorizontalPosition, MatSnackBarVerticalPosition as MatLegacySnackBarVerticalPosition } from '@angular/material/snack-bar';
import { Subject, Observable } from 'rxjs';
import * as i3 from '@angular/cdk/overlay';
import { OverlayRef, Overlay, ComponentType } from '@angular/cdk/overlay';
import * as i5 from '@angular/common';
import * as i6 from '@ngx-compat/material-legacy/legacy-button';
import * as i1 from '@angular/cdk/bidi';
import { BreakpointObserver } from '@angular/cdk/layout';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatSnackBarContainerBase` (removed from Angular Material 22).
 */

declare abstract class _MatSnackBarContainerBase extends BasePortalOutlet implements OnDestroy {
    private _ngZone;
    protected _elementRef: ElementRef<HTMLElement>;
    private _changeDetectorRef;
    private _platform;
    /** The snack bar configuration. */
    snackBarConfig: MatSnackBarConfig;
    private _document;
    private _trackedModals;
    /** The number of milliseconds to wait before announcing the snack bar's content. */
    private readonly _announceDelay;
    /** The timeout for announcing the snack bar's content. */
    private _announceTimeoutId;
    /** Whether the component has been destroyed. */
    private _destroyed;
    /** The portal outlet inside of this container into which the snack bar content will be loaded. */
    _portalOutlet: CdkPortalOutlet;
    /** Subject for notifying that the snack bar has announced to screen readers. */
    readonly _onAnnounce: Subject<void>;
    /** Subject for notifying that the snack bar has exited from view. */
    readonly _onExit: Subject<void>;
    /** Subject for notifying that the snack bar has finished entering the view. */
    readonly _onEnter: Subject<void>;
    /** The state of the snack bar animations. */
    _animationState: string;
    /** aria-live value for the live region. */
    _live: AriaLivePoliteness;
    /**
     * Role of the live region. This is only for Firefox as there is a known issue where Firefox +
     * JAWS does not read out aria-live message.
     */
    _role?: 'status' | 'alert';
    /** Unique ID of the aria-live element. */
    readonly _liveElementId: string;
    constructor(_ngZone: NgZone, _elementRef: ElementRef<HTMLElement>, _changeDetectorRef: ChangeDetectorRef, _platform: Platform, 
    /** The snack bar configuration. */
    snackBarConfig: MatSnackBarConfig);
    /** Attach a component portal as content to this snack bar container. */
    attachComponentPortal<T>(portal: ComponentPortal<T>): ComponentRef<T>;
    /** Attach a template portal as content to this snack bar container. */
    attachTemplatePortal<C>(portal: TemplatePortal<C>): EmbeddedViewRef<C>;
    /**
     * Attaches a DOM portal to the snack bar container.
     * @deprecated To be turned into a method.
     * @breaking-change 10.0.0
     */
    attachDomPortal: (portal: DomPortal) => void;
    /**
     * Handle end of enter/exit motion.
     * Accepts a CSS `animationName`, or a historical `{fromState,toState}` shape.
     */
    onAnimationEnd(event: string | {
        fromState?: string;
        toState?: string;
        animationName?: string;
    }): void;
    /** Used by CSS-motion subclasses when animations are disabled. */
    protected _notifyEnter(): void;
    /** Used by CSS-motion subclasses when animations are disabled. */
    protected _notifyExitComplete(): void;
    /** Begin animation of snack bar entrance into view. */
    enter(): void;
    /** Hook for CSS-motion subclasses after enter state is applied. */
    protected _afterEnterMotionStarted(): void;
    /** Begin animation of the snack bar exiting from view. */
    exit(): Observable<void>;
    /** Hook for CSS-motion subclasses after exit state is applied. */
    protected _afterExitMotionStarted(): void;
    /** Makes sure the exit callbacks have been invoked when the element is destroyed. */
    ngOnDestroy(): void;
    /**
     * Waits for the zone to settle before removing the element. Helps prevent
     * errors where we end up removing an element which is in the middle of an animation.
     */
    private _completeExit;
    /**
     * Called after the portal contents have been attached. Can be
     * used to modify the DOM once it's guaranteed to be in place.
     */
    protected _afterPortalAttached(): void;
    /**
     * Some browsers won't expose the accessibility node of the live element if there is an
     * `aria-modal` and the live element is outside of it. This method works around the issue by
     * pointing the `aria-owns` of all modals to the live element.
     */
    private _exposeToModals;
    /** Clears the references to the live element from any modals it was added to. */
    private _clearFromModals;
    /** Asserts that no content is already attached to the container. */
    private _assertNotAttached;
    /**
     * Starts a timeout to move the snack bar content to the live region so screen readers will
     * announce it.
     */
    private _screenReaderAnnounce;
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatSnackBarContainerBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_MatSnackBarContainerBase, never, never, {}, {}, never, never, true, never>;
}

/**
 * Internal component that wraps user-provided snack bar content.
 * @docs-private
 * @deprecated Use `MatSnackBarContainer` from `@angular/material/snack-bar` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacySnackBarContainer extends _MatSnackBarContainerBase {
    private readonly _legacyAnimationsDisabled;
    readonly _animationsEnabled: boolean;
    private _enterFallback;
    private _exitFallback;
    protected _afterEnterMotionStarted(): void;
    protected _afterExitMotionStarted(): void;
    onAnimationEnd(event: string | {
        fromState?: string;
        toState?: string;
        animationName?: string;
    }): void;
    ngOnDestroy(): void;
    protected _afterPortalAttached(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacySnackBarContainer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacySnackBarContainer, "snack-bar-container", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `MatSnackBarRef` (M22 version is coupled to MDC MatSnackBarContainer).
 */

/** Event that is emitted when a snack bar is dismissed. */
interface MatSnackBarDismiss {
    /** Whether the snack bar was dismissed using the action button. */
    dismissedByAction: boolean;
}
/**
 * Reference to a snack bar dispatched from the snack bar service.
 */
declare class MatSnackBarRef<T> {
    private _overlayRef;
    /** The instance of the component making up the content of the snack bar. */
    instance: T;
    /**
     * The instance of the component making up the content of the snack bar.
     * @docs-private
     */
    containerInstance: _MatSnackBarContainerBase;
    /** Subject for notifying the user that the snack bar has been dismissed. */
    private readonly _afterDismissed;
    /** Subject for notifying the user that the snack bar has opened and appeared. */
    private readonly _afterOpened;
    /** Subject for notifying the user that the snack bar action was called. */
    private readonly _onAction;
    /**
     * Timeout ID for the duration setTimeout call. Used to clear the timeout if the snackbar is
     * dismissed before the duration passes.
     */
    private _durationTimeoutId;
    /** Whether the snack bar was dismissed using the action button. */
    private _dismissedByAction;
    constructor(containerInstance: _MatSnackBarContainerBase, _overlayRef: OverlayRef);
    /** Dismisses the snack bar. */
    dismiss(): void;
    /** Marks the snackbar action clicked. */
    dismissWithAction(): void;
    /**
     * Marks the snackbar action clicked.
     * @deprecated Use `dismissWithAction` instead.
     * @breaking-change 8.0.0
     */
    closeWithAction(): void;
    /** Dismisses the snack bar after some duration */
    _dismissAfter(duration: number): void;
    /** Marks the snackbar as opened */
    _open(): void;
    /** Cleans up the DOM after closing. */
    private _finishDismiss;
    /** Gets an observable that is notified when the snack bar is finished closing. */
    afterDismissed(): Observable<MatSnackBarDismiss>;
    /** Gets an observable that is notified when the snack bar has opened and appeared. */
    afterOpened(): Observable<void>;
    /** Gets an observable that is notified when the snack bar action is called. */
    onAction(): Observable<void>;
}

/**
 * Interface for a simple snack bar component that has a message and a single action.
 * @deprecated Use `TextOnlySnackBar` from `@angular/material/snack-bar` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
interface LegacyTextOnlySnackBar {
    data: {
        message: string;
        action: string;
    };
    snackBarRef: MatSnackBarRef<LegacyTextOnlySnackBar>;
    action: () => void;
    hasAction: boolean;
}
/**
 * A component used to open as the default snack bar, matching material spec.
 * This should only be used internally by the snack bar service.
 * @deprecated Use `SimpleSnackBar` from `@angular/material/snack-bar` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class LegacySimpleSnackBar implements LegacyTextOnlySnackBar {
    snackBarRef: MatSnackBarRef<LegacySimpleSnackBar>;
    /** Data that was injected into the snack bar. */
    data: {
        message: string;
        action: string;
    };
    constructor(snackBarRef: MatSnackBarRef<LegacySimpleSnackBar>, data: any);
    /** Performs the action on the snack bar. */
    action(): void;
    /** If the action button should be shown. */
    get hasAction(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LegacySimpleSnackBar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LegacySimpleSnackBar, "simple-snack-bar", never, {}, {}, never, never, false, never>;
}

declare class MatCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatCommonModule, never, [typeof i1.BidiModule], [typeof i1.BidiModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatCommonModule>;
}

/**
 * @deprecated Use `MatSnackBarModule` from `@angular/material/snack-bar` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacySnackBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacySnackBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacySnackBarModule, [typeof MatLegacySnackBarContainer, typeof LegacySimpleSnackBar], [typeof i3.OverlayModule, typeof i4.PortalModule, typeof i5.CommonModule, typeof i6.MatLegacyButtonModule, typeof MatCommonModule], [typeof MatLegacySnackBarContainer, typeof MatCommonModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacySnackBarModule>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatSnackBarBase` (removed from Angular Material 22).
 */

/** @docs-private */
declare function MAT_SNACK_BAR_DEFAULT_OPTIONS_FACTORY(): MatSnackBarConfig;
declare abstract class _MatSnackBarBase implements OnDestroy {
    private _overlay;
    private _live;
    private _injector;
    private _breakpointObserver;
    private _parentSnackBar;
    private _defaultConfig;
    /**
     * Reference to the current snack bar in the view *at this level* (in the Angular injector tree).
     * If there is a parent snack-bar service, all operations should delegate to that parent
     * via `_openedSnackBarRef`.
     */
    private _snackBarRefAtThisLevel;
    /** The component that should be rendered as the snack bar's simple component. */
    protected abstract simpleSnackBarComponent: Type<LegacyTextOnlySnackBar>;
    /** The container component that attaches the provided template or component. */
    protected abstract snackBarContainerComponent: Type<_MatSnackBarContainerBase>;
    /** The CSS class to apply for handset mode. */
    protected abstract handsetCssClass: string;
    /** Reference to the currently opened snackbar at *any* level. */
    get _openedSnackBarRef(): MatSnackBarRef<any> | null;
    set _openedSnackBarRef(value: MatSnackBarRef<any> | null);
    constructor(_overlay: Overlay, _live: LiveAnnouncer, _injector: Injector, _breakpointObserver: BreakpointObserver, _parentSnackBar: _MatSnackBarBase, _defaultConfig: MatSnackBarConfig);
    /**
     * Creates and dispatches a snack bar with a custom component for the content, removing any
     * currently opened snack bars.
     *
     * @param component Component to be instantiated.
     * @param config Extra configuration for the snack bar.
     */
    openFromComponent<T, D = any>(component: ComponentType<T>, config?: MatSnackBarConfig<D>): MatSnackBarRef<T>;
    /**
     * Creates and dispatches a snack bar with a custom template for the content, removing any
     * currently opened snack bars.
     *
     * @param template Template to be instantiated.
     * @param config Extra configuration for the snack bar.
     */
    openFromTemplate(template: TemplateRef<any>, config?: MatSnackBarConfig): MatSnackBarRef<EmbeddedViewRef<any>>;
    /**
     * Opens a snackbar with a message and an optional action.
     * @param message The message to show in the snackbar.
     * @param action The label for the snackbar action.
     * @param config Additional configuration options for the snackbar.
     */
    open(message: string, action?: string, config?: MatSnackBarConfig): MatSnackBarRef<LegacyTextOnlySnackBar>;
    /**
     * Dismisses the currently-visible snack bar.
     */
    dismiss(): void;
    ngOnDestroy(): void;
    /**
     * Attaches the snack bar container component to the overlay.
     */
    private _attachSnackBarContainer;
    /**
     * Places a new component or a template as the content of the snack bar container.
     */
    private _attach;
    /** Animates the old snack bar out and the new one in. */
    private _animateSnackBar;
    /**
     * Creates a new overlay and places it in the correct location.
     * @param config The user-specified snack bar config.
     */
    private _createOverlay;
    /**
     * Creates an injector to be used inside of a snack bar component.
     * @param config Config that was used to create the snack bar.
     * @param snackBarRef Reference to the snack bar.
     */
    private _createInjector;
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatSnackBarBase, [null, null, null, null, { optional: true; skipSelf: true; }, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_MatSnackBarBase, never, never, {}, {}, never, never, true, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Service to dispatch Material Design snack bar messages.
 * @deprecated Use `MatSnackBar` from `@angular/material/snack-bar` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacySnackBar extends _MatSnackBarBase {
    protected simpleSnackBarComponent: typeof LegacySimpleSnackBar;
    protected snackBarContainerComponent: typeof MatLegacySnackBarContainer;
    protected handsetCssClass: string;
    constructor(overlay: Overlay, live: LiveAnnouncer, injector: Injector, breakpointObserver: BreakpointObserver, parentSnackBar: MatLegacySnackBar, defaultConfig: MatSnackBarConfig);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacySnackBar, [null, null, null, null, { optional: true; skipSelf: true; }, null]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}

export { LegacySimpleSnackBar, MAT_SNACK_BAR_DEFAULT_OPTIONS_FACTORY as MAT_LEGACY_SNACK_BAR_DEFAULT_OPTIONS_FACTORY, MatCommonModule, MatLegacySnackBar, MatLegacySnackBarContainer, MatLegacySnackBarModule, MatSnackBarRef as MatLegacySnackBarRef, _MatSnackBarBase as _MatLegacySnackBarBase, _MatSnackBarContainerBase as _MatLegacySnackBarContainerBase };
export type { LegacyTextOnlySnackBar, MatSnackBarDismiss as MatLegacySnackBarDismiss };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-snack-bar.d.ts.map
