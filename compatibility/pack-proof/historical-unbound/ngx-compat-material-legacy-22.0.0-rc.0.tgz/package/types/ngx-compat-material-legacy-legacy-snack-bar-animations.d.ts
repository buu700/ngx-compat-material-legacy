import { AnimationTriggerMetadata } from '@angular/animations';

/**
 * Optional Angular animation recipes for legacy snack-bar.
 * Primary snack-bar container uses CSS keyframes and does not load this entry.
 */

/**
 * Animations used by the Material snack bar.
 * @docs-private
 */
declare const matSnackBarAnimations: {
    readonly snackBarState: AnimationTriggerMetadata;
};

export { matSnackBarAnimations as matLegacySnackBarAnimations, matSnackBarAnimations };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-snack-bar-animations.d.ts.map
