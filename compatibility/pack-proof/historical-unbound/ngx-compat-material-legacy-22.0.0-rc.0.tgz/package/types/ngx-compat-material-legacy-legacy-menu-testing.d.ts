import { ComponentHarnessConstructor, HarnessPredicate, ComponentHarness, BaseHarnessFilters, ContentContainerComponentHarness, HarnessLoader } from '@angular/cdk/testing';
import { MenuItemHarnessFilters, MenuHarnessFilters } from '@angular/material/menu/testing';
export { MenuHarnessFilters as LegacyMenuHarnessFilters, MenuItemHarnessFilters as LegacyMenuItemHarnessFilters } from '@angular/material/menu/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatMenuHarnessBase` / `_MatMenuItemHarnessBase`
 * (removed from Angular Material 22).
 */

declare abstract class _MatMenuHarnessBase<ItemType extends ComponentHarnessConstructor<Item> & {
    with: (options?: ItemFilters) => HarnessPredicate<Item>;
}, Item extends ComponentHarness & {
    click(): Promise<void>;
    getSubmenu(): Promise<_MatMenuHarnessBase<ItemType, Item, ItemFilters> | null>;
}, ItemFilters extends BaseHarnessFilters> extends ContentContainerComponentHarness<string> {
    private _documentRootLocator;
    protected abstract _itemClass: ItemType;
    isDisabled(): Promise<boolean>;
    isOpen(): Promise<boolean>;
    getTriggerText(): Promise<string>;
    focus(): Promise<void>;
    blur(): Promise<void>;
    isFocused(): Promise<boolean>;
    open(): Promise<void>;
    close(): Promise<void>;
    getItems(filters?: Omit<ItemFilters, 'ancestor'>): Promise<Item[]>;
    clickItem(itemFilter: Omit<ItemFilters, 'ancestor'>, ...subItemFilters: Omit<ItemFilters, 'ancestor'>[]): Promise<void>;
    protected getRootHarnessLoader(): Promise<HarnessLoader>;
    private _getMenuPanel;
    private _getPanelId;
}
declare abstract class _MatMenuItemHarnessBase<MenuType extends ComponentHarnessConstructor<Menu>, Menu extends ComponentHarness> extends ContentContainerComponentHarness<string> {
    protected abstract _menuClass: MenuType;
    isDisabled(): Promise<boolean>;
    getText(): Promise<string>;
    focus(): Promise<void>;
    blur(): Promise<void>;
    isFocused(): Promise<boolean>;
    click(): Promise<void>;
    hasSubmenu(): Promise<boolean>;
    getSubmenu(): Promise<Menu | null>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a standard mat-menu in tests.
 * @deprecated Use `MatMenuHarness` from `@angular/material/menu/testing` instead.
 * @breaking-change 17.0.0
 */
declare class MatLegacyMenuHarness extends _MatMenuHarnessBase<typeof MatLegacyMenuItemHarness, MatLegacyMenuItemHarness, MenuItemHarnessFilters> {
    static hostSelector: string;
    protected _itemClass: typeof MatLegacyMenuItemHarness;
    static with(options?: MenuHarnessFilters): HarnessPredicate<MatLegacyMenuHarness>;
}
/**
 * Harness for interacting with a standard mat-menu-item in tests.
 * @deprecated Use `MatMenuItemHarness` from `@angular/material/menu/testing` instead.
 * @breaking-change 17.0.0
 */
declare class MatLegacyMenuItemHarness extends _MatMenuItemHarnessBase<typeof MatLegacyMenuHarness, MatLegacyMenuHarness> {
    static hostSelector: string;
    protected _menuClass: typeof MatLegacyMenuHarness;
    static with(options?: MenuItemHarnessFilters): HarnessPredicate<MatLegacyMenuItemHarness>;
}

export { MatLegacyMenuHarness, MatLegacyMenuItemHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-menu-testing.d.ts.map
