import * as _angular_cdk_testing from '@angular/cdk/testing';
import { ComponentHarness, AsyncFactoryFn, TestElement, HarnessPredicate } from '@angular/cdk/testing';
import { CheckboxHarnessFilters } from '@angular/material/checkbox/testing';
export { CheckboxHarnessFilters as LegacyCheckboxHarnessFilters } from '@angular/material/checkbox/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatCheckboxHarnessBase` (removed from Angular Material 22).
 */

declare abstract class _MatCheckboxHarnessBase extends ComponentHarness {
    protected abstract _input: AsyncFactoryFn<TestElement>;
    protected abstract _label: AsyncFactoryFn<TestElement>;
    isChecked(): Promise<boolean>;
    isIndeterminate(): Promise<boolean>;
    isDisabled(): Promise<boolean>;
    isRequired(): Promise<boolean>;
    isValid(): Promise<boolean>;
    getName(): Promise<string | null>;
    getValue(): Promise<string | null>;
    getAriaLabel(): Promise<string | null>;
    getAriaLabelledby(): Promise<string | null>;
    getLabelText(): Promise<string>;
    focus(): Promise<void>;
    blur(): Promise<void>;
    isFocused(): Promise<boolean>;
    abstract toggle(): Promise<void>;
    check(): Promise<void>;
    uncheck(): Promise<void>;
}

/**
 * Harness for interacting with a standard mat-checkbox in tests.
 * @deprecated Use `MatCheckboxHarness` from `@angular/material/checkbox/testing` instead.
 * @breaking-change 17.0.0
 */
declare class MatLegacyCheckboxHarness extends _MatCheckboxHarnessBase {
    static hostSelector: string;
    static with(options?: CheckboxHarnessFilters): HarnessPredicate<MatLegacyCheckboxHarness>;
    protected _input: () => Promise<_angular_cdk_testing.TestElement>;
    protected _label: () => Promise<_angular_cdk_testing.TestElement>;
    private _inputContainer;
    toggle(): Promise<void>;
}

export { MatLegacyCheckboxHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-checkbox-testing.d.ts.map
