import * as i0 from '@angular/core';
import * as i1 from '@angular/cdk/bidi';

declare class MatCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatCommonModule, never, [typeof i1.BidiModule], [typeof i1.BidiModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatCommonModule>;
}

/**
 * Package root TypeScript facade.
 * Component entry points are secondary packages (e.g. legacy-button).
 * Sass consumers use `@use '@ngx-compat/material-legacy' as mat` via `_index.scss`.
 */
declare const NGX_MATERIAL_LEGACY_PACKAGE: "@ngx-compat/material-legacy";

export { MatCommonModule, NGX_MATERIAL_LEGACY_PACKAGE };
//# sourceMappingURL=ngx-compat-material-legacy.d.ts.map
