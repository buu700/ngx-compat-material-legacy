import { AnimationTriggerMetadata } from '@angular/animations';

/**
 * Optional Angular animation recipes for legacy dialog.
 * Import only when you need historical `AnimationTriggerMetadata` objects;
 * the primary dialog container uses CSS + timers and does not load this entry.
 */

/** @docs-private */
declare const _defaultParams: {
    params: {
        enterAnimationDuration: string;
        exitAnimationDuration: string;
    };
};
/** @docs-private @deprecated Use `_defaultParams` instead. */
declare const defaultParams: {
    params: {
        enterAnimationDuration: string;
        exitAnimationDuration: string;
    };
};
/**
 * Animations used by MatDialog.
 * @docs-private
 */
declare const matDialogAnimations: {
    readonly dialogContainer: AnimationTriggerMetadata;
};

export { _defaultParams, defaultParams, matDialogAnimations, matDialogAnimations as matLegacyDialogAnimations };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-dialog-animations.d.ts.map
