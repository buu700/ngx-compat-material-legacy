import * as _angular_cdk_testing from '@angular/cdk/testing';
import { ComponentHarness, AsyncFactoryFn, TestElement, HarnessPredicate } from '@angular/cdk/testing';
import { SlideToggleHarnessFilters } from '@angular/material/slide-toggle/testing';
export { SlideToggleHarnessFilters as LegacySlideToggleHarnessFilters } from '@angular/material/slide-toggle/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 harness base(s) removed from Angular Material 22.
 */

declare abstract class _MatSlideToggleHarnessBase extends ComponentHarness {
    private _label;
    protected abstract _nativeElement: AsyncFactoryFn<TestElement>;
    /** Toggle the checked state of the slide-toggle. */
    abstract toggle(): Promise<void>;
    /** Whether the slide-toggle is checked. */
    abstract isChecked(): Promise<boolean>;
    /** Whether the slide-toggle is disabled. */
    isDisabled(): Promise<boolean>;
    /** Whether the slide-toggle is required. */
    isRequired(): Promise<boolean>;
    /** Whether the slide-toggle is valid. */
    isValid(): Promise<boolean>;
    /** Gets the slide-toggle's name. */
    getName(): Promise<string | null>;
    /** Gets the slide-toggle's aria-label. */
    getAriaLabel(): Promise<string | null>;
    /** Gets the slide-toggle's aria-labelledby. */
    getAriaLabelledby(): Promise<string | null>;
    /** Gets the slide-toggle's label text. */
    getLabelText(): Promise<string>;
    /** Focuses the slide-toggle. */
    focus(): Promise<void>;
    /** Blurs the slide-toggle. */
    blur(): Promise<void>;
    /** Whether the slide-toggle is focused. */
    isFocused(): Promise<boolean>;
    /**
     * Puts the slide-toggle in a checked state by toggling it if it is currently unchecked, or doing
     * nothing if it is already checked.
     */
    check(): Promise<void>;
    /**
     * Puts the slide-toggle in an unchecked state by toggling it if it is currently checked, or doing
     * nothing if it is already unchecked.
     */
    uncheck(): Promise<void>;
}

/**
 * Harness for interacting with a standard mat-slide-toggle in tests.
 * @deprecated Use `MatSlideToggleHarness` from `@angular/material/slide-toggle/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacySlideToggleHarness extends _MatSlideToggleHarnessBase {
    private _inputContainer;
    protected _nativeElement: () => Promise<_angular_cdk_testing.TestElement>;
    /** The selector for the host element of a `MatSlideToggle` instance. */
    static hostSelector: string;
    /**
     * Gets a `HarnessPredicate` that can be used to search for a `MatSlideToggleHarness` that meets
     * certain criteria.
     * @param options Options for filtering which slide toggle instances are considered a match.
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: SlideToggleHarnessFilters): HarnessPredicate<MatLegacySlideToggleHarness>;
    /** Toggle the checked state of the slide-toggle. */
    toggle(): Promise<void>;
    /** Whether the slide-toggle is checked. */
    isChecked(): Promise<boolean>;
}

export { MatLegacySlideToggleHarness, _MatSlideToggleHarnessBase as _MatLegacySlideToggleHarnessBase };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-slide-toggle-testing.d.ts.map
