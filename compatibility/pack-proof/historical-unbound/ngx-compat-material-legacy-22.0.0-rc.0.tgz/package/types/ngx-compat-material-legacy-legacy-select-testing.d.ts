import { BaseHarnessFilters, ComponentHarnessConstructor, HarnessPredicate, ComponentHarness } from '@angular/cdk/testing';
import { MatLegacyOptionHarness, LegacyOptionHarnessFilters, MatLegacyOptgroupHarness, LegacyOptgroupHarnessFilters } from '@ngx-compat/material-legacy/legacy-core/testing';
import { MatFormFieldControlHarness } from '@angular/material/form-field/testing/control';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * A set of criteria that can be used to filter a list of `MatSelectHarness` instances.
 * @deprecated Use `SelectHarnessFilters` from `@angular/material/select/testing` instead.
 * @breaking-change 17.0.0
 */
interface LegacySelectHarnessFilters extends BaseHarnessFilters {
    /** Only find instances which match the given disabled state. */
    disabled?: boolean;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatSelectHarnessBase` (removed from Angular Material 22).
 */

declare abstract class _MatSelectHarnessBase<OptionType extends ComponentHarnessConstructor<Option> & {
    with: (options?: OptionFilters) => HarnessPredicate<Option>;
}, Option extends ComponentHarness & {
    click(): Promise<void>;
}, OptionFilters extends BaseHarnessFilters, OptionGroupType extends ComponentHarnessConstructor<OptionGroup> & {
    with: (options?: OptionGroupFilters) => HarnessPredicate<OptionGroup>;
}, OptionGroup extends ComponentHarness, OptionGroupFilters extends BaseHarnessFilters> extends MatFormFieldControlHarness {
    protected abstract _prefix: string;
    protected abstract _optionClass: OptionType;
    protected abstract _optionGroupClass: OptionGroupType;
    private _documentRootLocator;
    private _backdrop;
    isDisabled(): Promise<boolean>;
    isValid(): Promise<boolean>;
    isRequired(): Promise<boolean>;
    isEmpty(): Promise<boolean>;
    isMultiple(): Promise<boolean>;
    getValueText(): Promise<string>;
    focus(): Promise<void>;
    blur(): Promise<void>;
    isFocused(): Promise<boolean>;
    getOptions(filter?: Omit<OptionFilters, 'ancestor'>): Promise<Option[]>;
    getOptionGroups(filter?: Omit<OptionGroupFilters, 'ancestor'>): Promise<OptionGroup[]>;
    isOpen(): Promise<boolean>;
    open(): Promise<void>;
    clickOptions(filter?: OptionFilters): Promise<void>;
    close(): Promise<void>;
    private _getPanelSelector;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a standard mat-select in tests.
 * @deprecated Use `MatSelectHarness` from `@angular/material/select/testing` instead.
 * @breaking-change 17.0.0
 */
declare class MatLegacySelectHarness extends _MatSelectHarnessBase<typeof MatLegacyOptionHarness, MatLegacyOptionHarness, LegacyOptionHarnessFilters, typeof MatLegacyOptgroupHarness, MatLegacyOptgroupHarness, LegacyOptgroupHarnessFilters> {
    static hostSelector: string;
    protected _prefix: string;
    protected _optionClass: typeof MatLegacyOptionHarness;
    protected _optionGroupClass: typeof MatLegacyOptgroupHarness;
    static with(options?: LegacySelectHarnessFilters): HarnessPredicate<MatLegacySelectHarness>;
}

export { MatLegacySelectHarness };
export type { LegacySelectHarnessFilters };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-select-testing.d.ts.map
