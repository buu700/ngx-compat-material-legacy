import { AnimationTriggerMetadata } from '@angular/animations';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Optional Angular animation recipes for legacy menu.
 * Primary menu uses CSS keyframes; import this entry only for historical APIs.
 */ /**
* Optional Angular animation recipes for legacy menu.
* Primary menu uses CSS keyframes; import this entry only for historical APIs.
*/

/**
 * Animations used by the mat-menu component.
 * Durations are parameterized so MATERIAL_ANIMATIONS / NoopAnimations can force 0ms.
 * @docs-private
 */
declare const matMenuAnimations: {
    readonly transformMenu: AnimationTriggerMetadata;
    readonly fadeInItems: AnimationTriggerMetadata;
};
/**
 * @deprecated
 * @breaking-change 8.0.0
 * @docs-private
 */
declare const fadeInItems: AnimationTriggerMetadata;
/**
 * @deprecated
 * @breaking-change 8.0.0
 * @docs-private
 */
declare const transformMenu: AnimationTriggerMetadata;

export { fadeInItems, matMenuAnimations as matLegacyMenuAnimations, matMenuAnimations, transformMenu };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-menu-animations.d.ts.map
