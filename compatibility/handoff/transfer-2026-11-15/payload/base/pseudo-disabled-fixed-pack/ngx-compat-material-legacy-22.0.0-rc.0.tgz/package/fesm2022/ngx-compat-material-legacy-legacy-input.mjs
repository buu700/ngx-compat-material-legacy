import * as i0 from '@angular/core';
import { inject, ElementRef, Directive, NgModule } from '@angular/core';
import { MatInput } from '@angular/material/input';
export { MAT_INPUT_VALUE_ACCESSOR as MAT_LEGACY_INPUT_VALUE_ACCESSOR } from '@angular/material/input';
import { MAT_LEGACY_FORM_FIELD, MatLegacyFormFieldControl, MatLegacyFormFieldModule } from '@ngx-compat/material-legacy/legacy-form-field';
import { TextFieldModule } from '@angular/cdk/text-field';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatLegacyCommonModule } from '@ngx-compat/material-legacy/legacy-core';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Directive that allows a native input to work inside a `MatFormField`.
 */
class MatLegacyInput extends MatInput {
    _legacyFormField = inject(MAT_LEGACY_FORM_FIELD, { optional: true });
    _legacyElement = inject(ElementRef);
    _legacyPlaceholderChecked = false;
    /** @docs-private Host binding preserves the consumer-supplied aria-disabled value. */
    _legacyAriaDisabled = null;
    ngDoCheck() {
        // The frozen legacy control has always been natively disabled.
        this.disabledInteractive = false;
        super.ngDoCheck();
        // The peer initializes its placeholder cache to null. The historical peer's
        // first check also removed an authored placeholder promoted to a label.
        if (!this._legacyPlaceholderChecked) {
            this._legacyPlaceholderChecked = true;
            if (this._legacyFormField?.appearance === 'legacy' && !this._legacyFormField._hasLabel?.()) {
                this._legacyElement.nativeElement.removeAttribute('placeholder');
            }
        }
        this._legacyAriaDisabled = this._legacyElement.nativeElement.getAttribute('aria-disabled');
    }
    /** @docs-private Host binding preserves the historical native readonly behavior. */
    _legacyReadonlyAttribute() {
        return this.readonly && this._legacyElement.nativeElement.nodeName.toLowerCase() !== 'select'
            ? 'true' : null;
    }
    /** Construct through Angular node DI; retired dependency arguments must not be ignored. */
    constructor() {
        if (arguments.length) {
            throw new Error('MatLegacyInput manual dependency arguments are not supported.');
        }
        super();
        this.disabledInteractive = false;
    }
    _getPlaceholder() {
        // If we're hiding the native placeholder, it should also be cleared from the DOM, otherwise
        // screen readers will read it out twice: once from the label and once from the attribute.
        // TODO: can be removed once we get rid of the `legacy` style for the form field, because it's
        // the only one that supports promoting the placeholder to a label.
        const formField = this._legacyFormField;
        return formField && formField.appearance === 'legacy' && !formField._hasLabel?.()
            ? null
            : this.placeholder;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: MatLegacyInput, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.7", type: MatLegacyInput, isStandalone: false, selector: "input[matInput], textarea[matInput], select[matNativeControl],\n      input[matNativeControl], textarea[matNativeControl]", host: { properties: { "class.mat-input-server": "_isServer", "class.mat-mdc-input-element": "false", "class.mat-mdc-form-field-textarea-control": "false", "class.mat-mdc-form-field-input-control": "false", "class.mdc-text-field__input": "false", "class.mat-mdc-native-select-inline": "false", "class.mat-mdc-input-disabled-interactive": "false", "disabled": "disabled", "attr.readonly": "_legacyReadonlyAttribute()", "attr.aria-disabled": "_legacyAriaDisabled", "attr.data-placeholder": "placeholder", "class.mat-native-select-inline": "_isInlineSelect()" }, classAttribute: "mat-input-element mat-form-field-autofill-control" }, providers: [{ provide: MatLegacyFormFieldControl, useExisting: MatLegacyInput }], exportAs: ["matInput"], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: MatLegacyInput, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: `input[matInput], textarea[matInput], select[matNativeControl],
      input[matNativeControl], textarea[matNativeControl]`,
                    exportAs: 'matInput',
                    host: {
                        /**
                         * @breaking-change 8.0.0 remove .mat-form-field-autofill-control in favor of AutofillMonitor.
                         */
                        'class': 'mat-input-element mat-form-field-autofill-control',
                        '[class.mat-input-server]': '_isServer',
                        // These classes are inherited from the base input class and need to be cleared.
                        '[class.mat-mdc-input-element]': 'false',
                        '[class.mat-mdc-form-field-textarea-control]': 'false',
                        '[class.mat-mdc-form-field-input-control]': 'false',
                        '[class.mdc-text-field__input]': 'false',
                        '[class.mat-mdc-native-select-inline]': 'false',
                        '[class.mat-mdc-input-disabled-interactive]': 'false',
                        // Preserve native disabled/readonly behavior even when the current peer enables
                        // interactive-disabled controls globally.
                        '[disabled]': 'disabled',
                        '[attr.readonly]': '_legacyReadonlyAttribute()',
                        '[attr.aria-disabled]': '_legacyAriaDisabled',
                        // At the time of writing, we have a lot of customer tests that look up the input based on its
                        // placeholder. Since we sometimes omit the placeholder attribute from the DOM to prevent screen
                        // readers from reading it twice, we have to keep it somewhere in the DOM for the lookup.
                        '[attr.data-placeholder]': 'placeholder',
                        '[class.mat-native-select-inline]': '_isInlineSelect()',
                    },
                    providers: [{ provide: MatLegacyFormFieldControl, useExisting: MatLegacyInput }],
                }]
        }], ctorParameters: () => [] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
class MatLegacyInputModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: MatLegacyInputModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.7", ngImport: i0, type: MatLegacyInputModule, declarations: [MatLegacyInput], imports: [TextFieldModule, MatLegacyFormFieldModule, MatLegacyCommonModule], exports: [TextFieldModule,
            // We re-export the `MatLegacyFormFieldModule` since `MatLegacyInput` will almost always
            // be used together with `MatLegacyFormField`.
            MatLegacyFormFieldModule,
            MatLegacyInput] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: MatLegacyInputModule, providers: [ErrorStateMatcher], imports: [TextFieldModule, MatLegacyFormFieldModule, MatLegacyCommonModule, TextFieldModule,
            // We re-export the `MatLegacyFormFieldModule` since `MatLegacyInput` will almost always
            // be used together with `MatLegacyFormField`.
            MatLegacyFormFieldModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: MatLegacyInputModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [MatLegacyInput],
                    imports: [TextFieldModule, MatLegacyFormFieldModule, MatLegacyCommonModule],
                    exports: [
                        TextFieldModule,
                        // We re-export the `MatLegacyFormFieldModule` since `MatLegacyInput` will almost always
                        // be used together with `MatLegacyFormField`.
                        MatLegacyFormFieldModule,
                        MatLegacyInput,
                    ],
                    providers: [ErrorStateMatcher],
                }]
        }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** @docs-private */
function getMatInputUnsupportedTypeError(type) {
    return Error(`Input type "${type}" isn't supported by matInput.`);
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MatLegacyInput, MatLegacyInputModule, getMatInputUnsupportedTypeError as getMatLegacyInputUnsupportedTypeError };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-input.mjs.map
