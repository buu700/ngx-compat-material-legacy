import * as i0 from '@angular/core';
import { Optional, OnInit, OnDestroy, EventEmitter, ChangeDetectorRef, InjectionToken } from '@angular/core';
import { MatLegacyFormFieldAppearance } from '@ngx-compat/material-legacy/legacy-form-field';
import { MatPaginatorIntl, MatPaginatorSelectConfig, PageEvent } from '@angular/material/paginator';
export { PageEvent as LegacyPageEvent, MatPaginatorIntl as MatLegacyPaginatorIntl, MatPaginatorSelectConfig as MatLegacyPaginatorSelectConfig } from '@angular/material/paginator';
import { ThemePalette } from '@angular/material/core';
import { Observable } from 'rxjs';
import * as i3 from '@angular/common';
import * as i4 from '@ngx-compat/material-legacy/legacy-button';
import * as i5 from '@ngx-compat/material-legacy/legacy-select';
import * as i6 from '@ngx-compat/material-legacy/legacy-tooltip';
import * as i7 from '@ngx-compat/material-legacy/legacy-core';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** @docs-private */
type Constructor<T> = new (...args: any[]) => T;
/**
 * This is a permissive type for abstract class constructors.
 * @docs-private
 */
type AbstractConstructor<T = object> = abstract new (...args: any[]) => T;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** @docs-private */
interface CanDisable {
    /** Whether the component is disabled. */
    disabled: boolean;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Mixin that adds an initialized property to a directive which, when subscribed to, will emit a
 * value once markInitialized has been called, which should be done during the ngOnInit function.
 * If the subscription is made after it has already been marked as initialized, then it will trigger
 * an emit immediately.
 * @docs-private
 */
interface HasInitialized {
    /** Stream that emits once during the directive/component's ngOnInit. */
    initialized: Observable<void>;
    /**
     * Sets the state as initialized and must be called during ngOnInit to notify subscribers that
     * the directive has been initialized.
     * @docs-private
     */
    _markInitialized: () => void;
}

type BooleanInput = string | boolean | null | undefined;
type NumberInput = string | number | null | undefined;
/** @docs-private */
declare const _MatPaginatorMixinBase: Constructor<CanDisable> & AbstractConstructor<CanDisable> & (new (...args: any[]) => HasInitialized) & {
    new (): {};
};
/**
 * Base class with all of the `MatPaginator` functionality.
 * @docs-private
 */
declare abstract class _MatPaginatorBase<O extends {
    pageSize?: number;
    pageSizeOptions?: number[];
    hidePageSize?: boolean;
    showFirstLastButtons?: boolean;
}> extends _MatPaginatorMixinBase implements OnInit, OnDestroy, CanDisable, HasInitialized {
    _intl: MatPaginatorIntl;
    private _changeDetectorRef;
    private _initialized;
    private _intlChanges;
    /** Theme color to be used for the underlying form controls. */
    color: ThemePalette;
    /** The zero-based page index of the displayed list of items. Defaulted to 0. */
    get pageIndex(): number;
    set pageIndex(value: NumberInput);
    private _pageIndex;
    /** The length of the total number of items that are being paginated. Defaulted to 0. */
    get length(): number;
    set length(value: NumberInput);
    private _length;
    /** Number of items to display on a page. By default set to 50. */
    get pageSize(): number;
    set pageSize(value: NumberInput);
    private _pageSize;
    /** The set of provided page size options to display to the user. */
    get pageSizeOptions(): number[];
    set pageSizeOptions(value: number[] | readonly number[]);
    private _pageSizeOptions;
    /** Whether to hide the page size selection UI from the user. */
    get hidePageSize(): boolean;
    set hidePageSize(value: BooleanInput);
    private _hidePageSize;
    /** Whether to show the first/last buttons UI to the user. */
    get showFirstLastButtons(): boolean;
    set showFirstLastButtons(value: BooleanInput);
    private _showFirstLastButtons;
    /** Used to configure the underlying `MatSelect` inside the paginator. */
    selectConfig: MatPaginatorSelectConfig;
    /** Event emitted when the paginator changes the page size or page index. */
    readonly page: EventEmitter<PageEvent>;
    /** Displayed set of page size options. Will be sorted and include current page size. */
    _displayedPageSizeOptions: number[];
    constructor(_intl: MatPaginatorIntl, _changeDetectorRef: ChangeDetectorRef, defaults?: O);
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Advances to the next page if it exists. */
    nextPage(): void;
    /** Move back to the previous page if it exists. */
    previousPage(): void;
    /** Move to the first page if not already there. */
    firstPage(): void;
    /** Move to the last page if not already there. */
    lastPage(): void;
    /** Whether there is a previous page. */
    hasPreviousPage(): boolean;
    /** Whether there is a next page. */
    hasNextPage(): boolean;
    /** Calculate the number of pages */
    getNumberOfPages(): number;
    /**
     * Changes the page size so that the first item displayed on the page will still be
     * displayed using the new page size.
     *
     * For example, if the page size is 10 and on the second page (items indexed 10-19) then
     * switching so that the page size is 5 will set the third page as the current page so
     * that the 10th item will still be displayed.
     */
    _changePageSize(pageSize: number): void;
    /** Checks whether the buttons for going forwards should be disabled. */
    _nextButtonsDisabled(): boolean;
    /** Checks whether the buttons for going backwards should be disabled. */
    _previousButtonsDisabled(): boolean;
    /**
     * Updates the list of page size options to display to the user. Includes making sure that
     * the page size is an option and that the list is sorted.
     */
    private _updateDisplayedPageSizeOptions;
    /** Emits an event notifying that a change of the paginator's properties has been triggered. */
    private _emitPageEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatPaginatorBase<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_MatPaginatorBase<any>, never, never, { "color": { "alias": "color"; "required": false; }; "pageIndex": { "alias": "pageIndex"; "required": false; }; "length": { "alias": "length"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; }; "hidePageSize": { "alias": "hidePageSize"; "required": false; }; "showFirstLastButtons": { "alias": "showFirstLastButtons"; "required": false; }; "selectConfig": { "alias": "selectConfig"; "required": false; }; }, { "page": "page"; }, never, never, false, never>;
}
/** @docs-private */
declare function MAT_PAGINATOR_INTL_PROVIDER_FACTORY(parentIntl: MatPaginatorIntl): MatPaginatorIntl;
/** @docs-private */
declare const MAT_PAGINATOR_INTL_PROVIDER: {
    provide: typeof MatPaginatorIntl;
    deps: Optional[][];
    useFactory: typeof MAT_PAGINATOR_INTL_PROVIDER_FACTORY;
};

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Object that can be used to configure the default options for the paginator module.
 */
interface MatLegacyPaginatorDefaultOptions {
    /** Number of items to display on a page. By default set to 50. */
    pageSize?: number;
    /** The set of provided page size options to display to the user. */
    pageSizeOptions?: number[];
    /** Whether to hide the page size selection UI from the user. */
    hidePageSize?: boolean;
    /** Whether to show the first/last buttons UI to the user. */
    showFirstLastButtons?: boolean;
    /** The default form-field appearance to apply to the page size options selector. */
    formFieldAppearance?: MatLegacyFormFieldAppearance;
}
/**
 * Injection token that can be used to provide the default options for the paginator module.
 */
declare const MAT_LEGACY_PAGINATOR_DEFAULT_OPTIONS: InjectionToken<MatLegacyPaginatorDefaultOptions>;
/**
 * Component to provide navigation between paged information. Displays the size of the current
 * page, user-selectable options to change that size, what items are being shown, and
 * navigational button to go to the previous or next page.
 */
declare class MatLegacyPaginator extends _MatPaginatorBase<MatLegacyPaginatorDefaultOptions> {
    /** If set, styles the "page size" form field with the designated style. */
    _formFieldAppearance?: MatLegacyFormFieldAppearance;
    private _pageSizeSelect?;
    private _pageSizeSelectElement?;
    /** Extend the page-size pointer target without changing the historical field layout. */
    protected _handlePageSizeTargetClick(event: MouseEvent): void;
    constructor(intl: MatPaginatorIntl, changeDetectorRef: ChangeDetectorRef, defaults?: MatLegacyPaginatorDefaultOptions);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyPaginator, [null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyPaginator, "mat-paginator", ["matPaginator"], { "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, never, false, never>;
}

/** Internal view-scoped identities for the paginator's possibly repeated page sizes. */
declare class _MatLegacyPaginatorOptions {
    values: readonly number[] | null | undefined;
    private _differs;
    private _differ;
    private _items;
    get items(): readonly {
        value: number;
    }[];
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatLegacyPaginatorOptions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_MatLegacyPaginatorOptions, "[matLegacyPaginatorOptions]", ["matLegacyPaginatorOptions"], { "values": { "alias": "matLegacyPaginatorOptions"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MatLegacyPaginatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyPaginatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacyPaginatorModule, [typeof MatLegacyPaginator, typeof _MatLegacyPaginatorOptions], [typeof i3.CommonModule, typeof i4.MatLegacyButtonModule, typeof i5.MatLegacySelectModule, typeof i6.MatLegacyTooltipModule, typeof i7.MatLegacyCommonModule], [typeof MatLegacyPaginator]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacyPaginatorModule>;
}

export { MAT_LEGACY_PAGINATOR_DEFAULT_OPTIONS, MAT_PAGINATOR_INTL_PROVIDER as MAT_LEGACY_PAGINATOR_INTL_PROVIDER, MAT_PAGINATOR_INTL_PROVIDER_FACTORY as MAT_LEGACY_PAGINATOR_INTL_PROVIDER_FACTORY, MatLegacyPaginator, MatLegacyPaginatorModule, _MatPaginatorBase as _MatLegacyPaginatorBase };
export type { MatLegacyPaginatorDefaultOptions };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-paginator.d.ts.map
