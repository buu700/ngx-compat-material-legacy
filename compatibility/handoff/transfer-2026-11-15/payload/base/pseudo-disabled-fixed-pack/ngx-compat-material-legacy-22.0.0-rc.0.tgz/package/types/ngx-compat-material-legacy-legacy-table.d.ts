import * as i0 from '@angular/core';
import { ElementRef, TemplateRef, IterableDiffers, OnInit, ViewContainerRef } from '@angular/core';
import * as i8 from '@angular/cdk/table';
import { CdkTable, CdkCell, CdkColumnDef, CdkCellDef, CdkFooterCell, CdkFooterCellDef, CdkHeaderCell, CdkHeaderCellDef, CdkFooterRow, CdkFooterRowDef, CdkHeaderRow, CdkHeaderRowDef, CdkNoDataRow, CdkRow, CdkRowDef, CdkTextColumn, TextColumnOptions } from '@angular/cdk/table';
import * as i9 from '@ngx-compat/material-legacy/legacy-core';
import { MatLegacyPaginator } from '@ngx-compat/material-legacy/legacy-paginator';
import { Subject, Observable, Subscription, BehaviorSubject } from 'rxjs';
import { DataSource } from '@angular/cdk/collections';
import { MatSort } from '@angular/material/sort';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

type BooleanInput$1 = string | boolean | null | undefined;
/**
 * Enables the recycle view repeater strategy, which reduces rendering latency. Not compatible with
 * tables that animate rows.
 */
declare class MatLegacyRecycleRows {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyRecycleRows, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyRecycleRows, "mat-table[recycleRows], table[mat-table][recycleRows]", never, {}, {}, never, never, false, never>;
}
/**
 * Wrapper for the CdkTable with Material design styles.
 */
declare class MatLegacyTable<T> extends CdkTable<T> {
    /** Construct through Angular node DI; manual dependency arguments are unsupported. */
    constructor();
    /** Preserve original coercion for direct writes as well as template inputs. */
    get fixedLayout(): boolean;
    set fixedLayout(value: BooleanInput$1);
    get multiTemplateDataRows(): boolean;
    set multiTemplateDataRows(value: BooleanInput$1);
    /** Overrides the sticky CSS class set by the `CdkTable`. */
    protected stickyCssClass: string;
    /** Overrides the need to add position: sticky on every sticky cell element in `CdkTable`. */
    protected needsPositionStickyOnElement: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyTable<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyTable<any>, "mat-table, table[mat-table]", ["matTable"], {}, {}, never, ["caption", "colgroup, col", "*"], false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

type BooleanInput = string | boolean | null | undefined;
/**
 * Cell definition for the mat-table.
 * Captures the template of a column's data row cell as well as cell-specific properties.
 */
declare class MatLegacyCellDef extends CdkCellDef {
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCellDef, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCellDef, "[matCellDef]", never, {}, {}, never, never, false, never>;
}
/**
 * Header cell definition for the mat-table.
 * Captures the template of a column's header cell and as well as cell-specific properties.
 */
declare class MatLegacyHeaderCellDef extends CdkHeaderCellDef {
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyHeaderCellDef, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyHeaderCellDef, "[matHeaderCellDef]", never, {}, {}, never, never, false, never>;
}
/**
 * Footer cell definition for the mat-table.
 * Captures the template of a column's footer cell and as well as cell-specific properties.
 */
declare class MatLegacyFooterCellDef extends CdkFooterCellDef {
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyFooterCellDef, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyFooterCellDef, "[matFooterCellDef]", never, {}, {}, never, never, false, never>;
}
/**
 * Column definition for the mat-table.
 * Defines a set of cells available for a table column.
 */
declare class MatLegacyColumnDef extends CdkColumnDef {
    constructor(table?: any);
    get sticky(): boolean;
    set sticky(value: boolean);
    get stickyEnd(): boolean;
    set stickyEnd(value: BooleanInput);
    /** Unique name for this column. */
    get name(): string;
    set name(name: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyColumnDef, [{ optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyColumnDef, "[matColumnDef]", never, { "sticky": { "alias": "sticky"; "required": false; }; "name": { "alias": "matColumnDef"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Header cell template container that adds the right classes and role.
 */
declare class MatLegacyHeaderCell extends CdkHeaderCell {
    constructor(columnDef: CdkColumnDef, elementRef: ElementRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyHeaderCell, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyHeaderCell, "mat-header-cell, th[mat-header-cell]", never, {}, {}, never, never, false, never>;
}
/**
 * Footer cell template container that adds the right classes and role.
 */
declare class MatLegacyFooterCell extends CdkFooterCell {
    constructor(columnDef: CdkColumnDef, elementRef: ElementRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyFooterCell, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyFooterCell, "mat-footer-cell, td[mat-footer-cell]", never, {}, {}, never, never, false, never>;
}
/**
 * Cell template container that adds the right classes and role.
 */
declare class MatLegacyCell extends CdkCell {
    constructor(columnDef: CdkColumnDef, elementRef: ElementRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCell, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCell, "mat-cell, td[mat-cell]", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Header row definition for the mat-table.
 * Captures the header row's template and other header properties such as the columns to display.
 */
declare class MatLegacyHeaderRowDef extends CdkHeaderRowDef {
    constructor(template: TemplateRef<any>, differs: IterableDiffers, table?: any);
    get sticky(): boolean;
    set sticky(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyHeaderRowDef, [null, null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyHeaderRowDef, "[matHeaderRowDef]", never, { "columns": { "alias": "matHeaderRowDef"; "required": false; }; "sticky": { "alias": "matHeaderRowDefSticky"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Footer row definition for the mat-table.
 * Captures the footer row's template and other footer properties such as the columns to display.
 */
declare class MatLegacyFooterRowDef extends CdkFooterRowDef {
    constructor(template: TemplateRef<any>, differs: IterableDiffers, table?: any);
    get sticky(): boolean;
    set sticky(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyFooterRowDef, [null, null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyFooterRowDef, "[matFooterRowDef]", never, { "columns": { "alias": "matFooterRowDef"; "required": false; }; "sticky": { "alias": "matFooterRowDefSticky"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Data row definition for the mat-table.
 * Captures the data row's template and other properties such as the columns to display and
 * a when predicate that describes when this row should be used.
 */
declare class MatLegacyRowDef<T> extends CdkRowDef<T> {
    constructor(template: TemplateRef<any>, differs: IterableDiffers, table?: any);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyRowDef<any>, [null, null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyRowDef<any>, "[matRowDef]", never, { "columns": { "alias": "matRowDefColumns"; "required": false; }; "when": { "alias": "matRowDefWhen"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Header template container that contains the cell outlet. Adds the right class and role.
 */
declare class MatLegacyHeaderRow extends CdkHeaderRow {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyHeaderRow, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyHeaderRow, "mat-header-row, tr[mat-header-row]", ["matHeaderRow"], {}, {}, never, never, false, never>;
}
/**
 * Footer template container that contains the cell outlet. Adds the right class and role.
 */
declare class MatLegacyFooterRow extends CdkFooterRow {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyFooterRow, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyFooterRow, "mat-footer-row, tr[mat-footer-row]", ["matFooterRow"], {}, {}, never, never, false, never>;
}
/**
 * Data row template container that contains the cell outlet. Adds the right class and role.
 */
declare class MatLegacyRow extends CdkRow {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyRow, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyRow, "mat-row, tr[mat-row]", ["matRow"], {}, {}, never, never, false, never>;
}
/**
 * Row that can be used to display a message when no data is shown in the table.
 */
declare class MatLegacyNoDataRow extends CdkNoDataRow {
    _contentClassNames: string[];
    /** Historical16 public member, retained alongside the current CDK field. */
    _contentClassName: string;
    constructor(templateRef: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyNoDataRow, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyNoDataRow, "ng-template[matNoDataRow]", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Column that simply shows text content for the header and row cells. Assumes that the table
 * is using the native table implementation (`<table>`).
 *
 * By default, the name of this column will be the header text and data property accessor.
 * The header text can be overridden with the `headerText` input. Cell values can be overridden with
 * the `dataAccessor` input. Change the text justification to the start or end using the `justify`
 * input.
 *
 */
declare class MatLegacyTextColumn<T> extends CdkTextColumn<T> {
    constructor(table: CdkTable<T>, options: TextColumnOptions<T>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyTextColumn<any>, [{ optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyTextColumn<any>, "mat-text-column", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Supplies the parent's public outlet protocol without a peer-private token. */
declare class _LegacyTableOutlet implements OnInit {
    private readonly table;
    readonly viewContainer: ViewContainerRef;
    readonly elementRef: ElementRef;
    kind: 'header' | 'data' | 'footer' | 'empty';
    constructor(table: CdkTable<unknown>, viewContainer: ViewContainerRef, elementRef: ElementRef);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<_LegacyTableOutlet, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_LegacyTableOutlet, "[legacyTableOutlet]", never, { "kind": { "alias": "legacyTableOutlet"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Raw public CDK definitions can also be used in a legacy table. Bind them to
 * the nearest public table so nested tables cannot borrow each other's defs.
 * Current tables retain their own provider and are left to the peer.
 */
declare class _LegacyTableDefinitionOwner {
    constructor(table: CdkTable<unknown> | null, column: CdkColumnDef | null, header: CdkHeaderRowDef | null, footer: CdkFooterRowDef | null, row: CdkRowDef<unknown> | null);
    static ɵfac: i0.ɵɵFactoryDeclaration<_LegacyTableDefinitionOwner, [{ optional: true; }, { optional: true; self: true; }, { optional: true; self: true; }, { optional: true; self: true; }, { optional: true; self: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_LegacyTableDefinitionOwner, "[cdkColumnDef], [cdkHeaderRowDef], [cdkFooterRowDef], [cdkRowDef]", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Preserve mixing public CDK cells with historical legacy column definitions. */
declare class _LegacyTableColumnClasses {
    constructor(elementRef: ElementRef<Element>, column: CdkColumnDef | null);
    static ɵfac: i0.ɵɵFactoryDeclaration<_LegacyTableColumnClasses, [null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_LegacyTableColumnClasses, "cdk-cell, td[cdk-cell], cdk-header-cell, th[cdk-header-cell], cdk-footer-cell, td[cdk-footer-cell]", never, {}, {}, never, never, false, never>;
}

declare class MatLegacyTableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyTableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacyTableModule, [typeof MatLegacyTable, typeof MatLegacyRecycleRows, typeof MatLegacyHeaderCellDef, typeof MatLegacyHeaderRowDef, typeof MatLegacyColumnDef, typeof MatLegacyCellDef, typeof MatLegacyRowDef, typeof MatLegacyFooterCellDef, typeof MatLegacyFooterRowDef, typeof MatLegacyHeaderCell, typeof MatLegacyCell, typeof MatLegacyFooterCell, typeof MatLegacyHeaderRow, typeof MatLegacyRow, typeof MatLegacyFooterRow, typeof MatLegacyNoDataRow, typeof MatLegacyTextColumn, typeof _LegacyTableOutlet, typeof _LegacyTableDefinitionOwner, typeof _LegacyTableColumnClasses], [typeof i8.CdkTableModule, typeof i9.MatLegacyCommonModule], [typeof i9.MatLegacyCommonModule, typeof MatLegacyTable, typeof MatLegacyRecycleRows, typeof MatLegacyHeaderCellDef, typeof MatLegacyHeaderRowDef, typeof MatLegacyColumnDef, typeof MatLegacyCellDef, typeof MatLegacyRowDef, typeof MatLegacyFooterCellDef, typeof MatLegacyFooterRowDef, typeof MatLegacyHeaderCell, typeof MatLegacyCell, typeof MatLegacyFooterCell, typeof MatLegacyHeaderRow, typeof MatLegacyRow, typeof MatLegacyFooterRow, typeof MatLegacyNoDataRow, typeof MatLegacyTextColumn, typeof _LegacyTableDefinitionOwner, typeof _LegacyTableColumnClasses]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacyTableModule>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatTableDataSource` + paginator interfaces (removed from
 * Angular Material 22 public API; M22 MatTableDataSource is coupled to MatPaginator).
 */

/**
 * Interface that matches the required API parts for the MatPaginator's PageEvent.
 * Decoupled so that users can depend on either the legacy or MDC-based paginator.
 */
interface MatTableDataSourcePageEvent {
    pageIndex: number;
    pageSize: number;
    length: number;
}
/**
 * Interface that matches the required API parts of the MatPaginator.
 * Decoupled so that users can depend on either the legacy or MDC-based paginator.
 */
interface MatTableDataSourcePaginator {
    page: Subject<MatTableDataSourcePageEvent>;
    pageIndex: number;
    initialized: Observable<void>;
    pageSize: number;
    length: number;
    firstPage: () => void;
    lastPage: () => void;
}
/** Shared base class with MDC-based implementation. */
declare class _MatTableDataSource<T, P extends MatTableDataSourcePaginator = MatTableDataSourcePaginator> extends DataSource<T> {
    /** Stream that emits when a new data array is set on the data source. */
    private readonly _data;
    /** Stream emitting render data to the table (depends on ordered data changes). */
    private readonly _renderData;
    /** Stream that emits when a new filter string is set on the data source. */
    private readonly _filter;
    /** Used to react to internal changes of the paginator that are made by the data source itself. */
    private readonly _internalPageChanges;
    /**
     * Subscription to the changes that should trigger an update to the table's rendered rows, such
     * as filtering, sorting, pagination, or base data changes.
     */
    _renderChangesSubscription: Subscription | null;
    /**
     * The filtered set of data that has been matched by the filter string, or all the data if there
     * is no filter. Useful for knowing the set of data the table represents.
     * For example, a 'selectAll()' function would likely want to select the set of filtered data
     * shown to the user rather than all the data.
     */
    filteredData: T[];
    /** Array of data that should be rendered by the table, where each object represents one row. */
    get data(): T[];
    set data(data: T[]);
    /**
     * Filter term that should be used to filter out objects from the data array. To override how
     * data objects match to this filter string, provide a custom function for filterPredicate.
     */
    get filter(): string;
    set filter(filter: string);
    /**
     * Instance of the MatSort directive used by the table to control its sorting. Sort changes
     * emitted by the MatSort will trigger an update to the table's rendered data.
     */
    get sort(): MatSort | null;
    set sort(sort: MatSort | null);
    private _sort;
    /**
     * Instance of the paginator component used by the table to control what page of the data is
     * displayed. Page changes emitted by the paginator will trigger an update to the
     * table's rendered data.
     *
     * Note that the data source uses the paginator's properties to calculate which page of data
     * should be displayed. If the paginator receives its properties as template inputs,
     * e.g. `[pageLength]=100` or `[pageIndex]=1`, then be sure that the paginator's view has been
     * initialized before assigning it to this data source.
     */
    get paginator(): P | null;
    set paginator(paginator: P | null);
    private _paginator;
    /**
     * Data accessor function that is used for accessing data properties for sorting through
     * the default sortData function.
     * This default function assumes that the sort header IDs (which defaults to the column name)
     * matches the data's properties (e.g. column Xyz represents data['Xyz']).
     * May be set to a custom function for different behavior.
     * @param data Data object that is being accessed.
     * @param sortHeaderId The name of the column that represents the data.
     */
    sortingDataAccessor: (data: T, sortHeaderId: string) => string | number;
    /**
     * Gets a sorted copy of the data array based on the state of the MatSort. Called
     * after changes are made to the filtered data or when sort changes are emitted from MatSort.
     * By default, the function retrieves the active sort and its direction and compares data
     * by retrieving data using the sortingDataAccessor. May be overridden for a custom implementation
     * of data ordering.
     * @param data The array of data that should be sorted.
     * @param sort The connected MatSort that holds the current sort state.
     */
    sortData: (data: T[], sort: MatSort) => T[];
    /**
     * Checks if a data object matches the data source's filter string. By default, each data object
     * is converted to a string of its properties and returns true if the filter has
     * at least one occurrence in that string. By default, the filter string has its whitespace
     * trimmed and the match is case-insensitive. May be overridden for a custom implementation of
     * filter matching.
     * @param data Data object used to check against the filter.
     * @param filter Filter string that has been set on the data source.
     * @returns Whether the filter matches against the data
     */
    filterPredicate: (data: T, filter: string) => boolean;
    constructor(initialData?: T[]);
    /**
     * Subscribe to changes that should trigger an update to the table's rendered rows. When the
     * changes occur, process the current state of the filter, sort, and pagination along with
     * the provided base data and send it to the table for rendering.
     */
    _updateChangeSubscription(): void;
    /**
     * Returns a filtered data array where each filter object contains the filter string within
     * the result of the filterPredicate function. If no filter is set, returns the data array
     * as provided.
     */
    _filterData(data: T[]): T[];
    /**
     * Returns a sorted copy of the data if MatSort has a sort applied, otherwise just returns the
     * data array as provided. Uses the default data accessor for data lookup, unless a
     * sortDataAccessor function is defined.
     */
    _orderData(data: T[]): T[];
    /**
     * Returns a paged slice of the provided data array according to the provided paginator's page
     * index and length. If there is no paginator provided, returns the data array as provided.
     */
    _pageData(data: T[]): T[];
    /**
     * Updates the paginator to reflect the length of the filtered data, and makes sure that the page
     * index does not exceed the paginator's last page. Values are changed in a resolved promise to
     * guard against making property changes within a round of change detection.
     */
    _updatePaginator(filteredDataLength: number): void;
    /**
     * Used by the MatTable. Called when it connects to the data source.
     * @docs-private
     */
    connect(): BehaviorSubject<T[]>;
    /**
     * Used by the MatTable. Called when it disconnects from the data source.
     * @docs-private
     */
    disconnect(): void;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Data source that accepts a client-side data array and includes native support of filtering,
 * sorting (using MatSort), and pagination (using paginator).
 *
 * Allows for sort customization by overriding sortingDataAccessor, which defines how data
 * properties are accessed. Also allows for filter customization by overriding filterPredicate,
 * which defines how row data is converted to a string for filter matching.
 *
 * **Note:** This class is meant to be a simple data source to help you get started. As such
 * it isn't equipped to handle some more advanced cases like robust i18n support or server-side
 * interactions. If your app needs to support more advanced use cases, consider implementing your
 * own `DataSource`.
 *
 */
declare class MatLegacyTableDataSource<T> extends _MatTableDataSource<T, MatLegacyPaginator> {
}

export { MatLegacyCell, MatLegacyCellDef, MatLegacyColumnDef, MatLegacyFooterCell, MatLegacyFooterCellDef, MatLegacyFooterRow, MatLegacyFooterRowDef, MatLegacyHeaderCell, MatLegacyHeaderCellDef, MatLegacyHeaderRow, MatLegacyHeaderRowDef, MatLegacyNoDataRow, MatLegacyRecycleRows, MatLegacyRow, MatLegacyRowDef, MatLegacyTable, MatLegacyTableDataSource, MatLegacyTableModule, MatLegacyTextColumn, _LegacyTableDefinitionOwner, _MatTableDataSource as _MatLegacyTableDataSource, _LegacyTableColumnClasses as ɵLegacyTableColumnClasses };
export type { MatTableDataSourcePageEvent as MatLegacyTableDataSourcePageEvent, MatTableDataSourcePaginator as MatLegacyTableDataSourcePaginator };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-table.d.ts.map
