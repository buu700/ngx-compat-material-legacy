/**
 * Package root TypeScript facade.
 * Component entry points are secondary packages (e.g. legacy-button).
 * Sass consumers use `@use '@ngx-compat/material-legacy' as mat` via `_index.scss`.
 */
declare const NGX_MATERIAL_LEGACY_PACKAGE: "@ngx-compat/material-legacy";

export { NGX_MATERIAL_LEGACY_PACKAGE };
//# sourceMappingURL=ngx-compat-material-legacy.d.ts.map
