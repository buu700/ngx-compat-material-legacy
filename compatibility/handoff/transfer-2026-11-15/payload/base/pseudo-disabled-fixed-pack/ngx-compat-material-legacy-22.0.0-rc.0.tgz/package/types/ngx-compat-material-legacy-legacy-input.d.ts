import { MatInput } from '@angular/material/input';
export { MAT_INPUT_VALUE_ACCESSOR as MAT_LEGACY_INPUT_VALUE_ACCESSOR } from '@angular/material/input';
import * as i0 from '@angular/core';
import * as i2 from '@angular/cdk/text-field';
import * as i3 from '@ngx-compat/material-legacy/legacy-form-field';
import * as i4 from '@ngx-compat/material-legacy/legacy-core';

/**
 * Directive that allows a native input to work inside a `MatFormField`.
 */
declare class MatLegacyInput extends MatInput {
    private _legacyFormField;
    private readonly _legacyElement;
    private _legacyPlaceholderChecked;
    /** @docs-private Host binding preserves the consumer-supplied aria-disabled value. */
    protected _legacyAriaDisabled: string | null;
    ngDoCheck(): void;
    /** @docs-private Host binding preserves the historical native readonly behavior. */
    protected _legacyReadonlyAttribute(): string | null;
    /** Construct through Angular node DI; retired dependency arguments must not be ignored. */
    constructor();
    protected _getPlaceholder(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyInput, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyInput, "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", ["matInput"], {}, {}, never, never, false, never>;
}

declare class MatLegacyInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacyInputModule, [typeof MatLegacyInput], [typeof i2.TextFieldModule, typeof i3.MatLegacyFormFieldModule, typeof i4.MatLegacyCommonModule], [typeof i2.TextFieldModule, typeof i3.MatLegacyFormFieldModule, typeof MatLegacyInput]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacyInputModule>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** @docs-private */
declare function getMatInputUnsupportedTypeError(type: string): Error;

export { MatLegacyInput, MatLegacyInputModule, getMatInputUnsupportedTypeError as getMatLegacyInputUnsupportedTypeError };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-input.d.ts.map
