import { ContentContainerComponentHarness, HarnessPredicate } from '@angular/cdk/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Selectors for different sections of the mat-card that can container user content.
 * @deprecated Use `MatCardSection` from `@angular/material/card/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
var MatLegacyCardSection;
(function (MatLegacyCardSection) {
    MatLegacyCardSection["HEADER"] = ".mat-card-header";
    MatLegacyCardSection["CONTENT"] = ".mat-card-content";
    MatLegacyCardSection["ACTIONS"] = ".mat-card-actions";
    MatLegacyCardSection["FOOTER"] = ".mat-card-footer";
})(MatLegacyCardSection || (MatLegacyCardSection = {}));
/**
 * Harness for interacting with a standard mat-card in tests.
 * @deprecated Use `MatCardHarness` from `@angular/material/card/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
class MatLegacyCardHarness extends ContentContainerComponentHarness {
    /** The selector for the host element of a `MatCard` instance. */
    static hostSelector = '.mat-card';
    /**
     * Gets a `HarnessPredicate` that can be used to search for a `MatCardHarness` that meets
     * certain criteria.
     * @param options Options for filtering which card instances are considered a match.
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options = {}) {
        return new HarnessPredicate(MatLegacyCardHarness, options)
            .addOption('text', options.text, (harness, text) => HarnessPredicate.stringMatches(harness.getText(), text))
            .addOption('title', options.title, (harness, title) => HarnessPredicate.stringMatches(harness.getTitleText(), title))
            .addOption('subtitle', options.subtitle, (harness, subtitle) => HarnessPredicate.stringMatches(harness.getSubtitleText(), subtitle));
    }
    _title = this.locatorForOptional('.mat-card-title');
    _subtitle = this.locatorForOptional('.mat-card-subtitle');
    /** Gets all of the card's content as text. */
    async getText() {
        return (await this.host()).text();
    }
    /** Gets the cards's title text. */
    async getTitleText() {
        return (await this._title())?.text() ?? '';
    }
    /** Gets the cards's subtitle text. */
    async getSubtitleText() {
        return (await this._subtitle())?.text() ?? '';
    }
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MatLegacyCardHarness, MatLegacyCardSection };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-card-testing.mjs.map
