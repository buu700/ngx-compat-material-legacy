from pathlib import Path
import os,subprocess,json,datetime,hashlib
state=Path('/tmp/root-radio-serial-pack-v3-state.json')
report={'pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','jobs':[]}
def save():
 temp=state.with_suffix('.tmp');temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(state)
save()
for line,flag in [('21','21.x'),('main','main')]:
 root=Path('/home/parallels/.codex/worktrees/codex-closeout-'+line+'/ngx-compat-material-legacy')
 source=root/'projects/ngx-material-legacy/legacy-radio/internal/radio-base.ts'
 before=hashlib.sha256(source.read_bytes()).hexdigest();log=Path('/tmp/root-radio-pack-'+line+'-v3.log')
 job={'line':line,'status':'running','source_sha256':before,'log':str(log),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'out':'/tmp/root-radio-packed-'+line+'-v3'};report['jobs'].append(job);save()
 env=os.environ.copy();env['PATH']='/tmp/root-radio-pack-bin-v1:/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin:'+env['PATH'];env['NODE_OPTIONS']='--max-old-space-size=1024'
 try:
  with log.open('w') as output:result=subprocess.run(['/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node','scripts/pack-library.mjs','--line',flag,'--out',job['out']],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=600)
  job['exit_code']=result.returncode;job['source_stable']=hashlib.sha256(source.read_bytes()).hexdigest()==before;job['status']='passed' if result.returncode==0 and job['source_stable'] else 'failed'
 except Exception as e:job.update(status='failed',error=repr(e))
 save()
report['status']='passed' if all(x['status']=='passed' for x in report['jobs']) else 'failed';report['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
