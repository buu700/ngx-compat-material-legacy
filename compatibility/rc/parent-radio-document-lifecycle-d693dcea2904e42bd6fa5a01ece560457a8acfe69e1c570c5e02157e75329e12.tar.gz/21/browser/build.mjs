import * as esbuild from '/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy/node_modules/esbuild/lib/main.js';
import fs from 'node:fs';
const root='/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy';
await esbuild.build({absWorkingDir:root,entryPoints:['/tmp/root-radio-browser-21-v2/entry.ts'],bundle:true,format:'iife',platform:'browser',target:['es2022'],outfile:'/tmp/root-radio-browser-21-v2/focus.iife.js',sourcemap:true,nodePaths:[root+'/node_modules'],loader:{'.html':'text','.css':'text','.svg':'text'},ignoreAnnotations:true,logOverride:{'direct-eval':'silent'}});
