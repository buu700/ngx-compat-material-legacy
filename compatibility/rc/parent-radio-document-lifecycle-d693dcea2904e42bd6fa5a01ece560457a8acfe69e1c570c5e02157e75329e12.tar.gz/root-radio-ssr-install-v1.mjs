import {spawnSync} from 'node:child_process';
import {npmToolingOptions} from '/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy/scripts/npm-tooling-options.mjs';
const cwd=process.argv[2],args=['install','--ignore-scripts','--no-audit','--no-fund','--package-lock'];
const result=spawnSync(process.execPath,['/tmp/c03-floor-sol6-GOzKraLx/npm/package/bin/npm-cli.js',...args],npmToolingOptions({cwd,encoding:'utf8',timeout:180000},args));
process.stdout.write(result.stdout||'');process.stderr.write(result.stderr||'');if(result.error)process.stderr.write(String(result.error));process.exit(result.status??1);
