import {Component, ChangeDetectionStrategy, provideZonelessChangeDetection} from '@angular/core';
import {TestBed} from '@angular/core/testing';
import {By} from '@angular/platform-browser';
import {MatLegacyRadioButton, MatLegacyRadioGroup, MatLegacyRadioModule} from '/home/parallels/.codex/worktrees/codex-closeout-main/ngx-compat-material-legacy/dist/ngx-material-legacy/fesm2022/ngx-compat-material-legacy-legacy-radio.mjs';
import {MatLegacyCheckboxModule} from '/home/parallels/.codex/worktrees/codex-closeout-main/ngx-compat-material-legacy/dist/ngx-material-legacy/fesm2022/ngx-compat-material-legacy-legacy-checkbox.mjs';

@Component({standalone:false,changeDetection:ChangeDetectionStrategy.Eager,template:`
<mat-radio-group name="group-a" [value]="valueA">
  <mat-radio-button value="a">A</mat-radio-button>
  <mat-radio-button value="b" [disabled]="disabledB">B</mat-radio-button>
</mat-radio-group>
<mat-radio-group name="group-b" [value]="valueB">
  <mat-radio-button value="c">C</mat-radio-button>
  <mat-radio-button value="d">D</mat-radio-button>
</mat-radio-group>`})
class FocusFixture {valueA='a';valueB='c';disabledB=false;}
@Component({standalone:false,changeDetection:ChangeDetectionStrategy.Eager,template:`<mat-checkbox [checked]="checked" [indeterminate]="indeterminate">Choice</mat-checkbox>`})
class CheckboxFixture {checked=false;indeterminate=false;}
function groups(f:any):MatLegacyRadioGroup[]{return f.debugElement.queryAll(By.directive(MatLegacyRadioGroup)).map((x:any)=>x.injector.get(MatLegacyRadioGroup));}
function radios(f:any):MatLegacyRadioButton[]{return f.debugElement.queryAll(By.directive(MatLegacyRadioButton)).map((x:any)=>x.injector.get(MatLegacyRadioButton));}
function inputs(f:any):HTMLInputElement[]{return Array.from(f.nativeElement.querySelectorAll('input.mat-radio-input')) as HTMLInputElement[];}
async function settle(){await Promise.resolve();await Promise.resolve();}

for(const mode of ['zoneful','zoneless']){
  describe(`C04 disposable radio and checkbox minimum-peer ${mode}`,()=>{
    beforeEach(()=>TestBed.configureTestingModule({imports:[MatLegacyRadioModule,MatLegacyCheckboxModule],declarations:[FocusFixture,CheckboxFixture],providers:mode==='zoneless'?[provideZonelessChangeDetection()]:[]}));
    it('public group setter moves focus only after selected tabindex updates',async()=>{
      const f=TestBed.createComponent(FocusFixture);f.detectChanges();expect(f.zonelessEnabled).toBe(mode==='zoneless');const x=inputs(f);expect(x.length).toBe(4);
      x[0].focus();expect(document.activeElement).toBe(x[0]);groups(f)[0].value='b';f.detectChanges();
      expect(x.map(y=>y.getAttribute('tabindex'))).toEqual(['-1','0','0','-1']);
      expect(document.activeElement).toBe(x[0]);await settle();expect(document.activeElement).toBe(x[1]);f.destroy();
    });
    it('host value binding updates with explicit fixture markForCheck',async()=>{
      const f=TestBed.createComponent(FocusFixture);f.detectChanges();const x=inputs(f);x[0].focus();
      f.componentInstance.valueA='b';f.changeDetectorRef.markForCheck();f.detectChanges();
      expect(groups(f)[0].value).toBe('b');expect(x.map(y=>y.getAttribute('tabindex')).slice(0,2)).toEqual(['-1','0']);
      expect(document.activeElement).toBe(x[0]);await settle();expect(document.activeElement).toBe(x[1]);f.destroy();
    });
    it('other named group selection leaves focus in first group',async()=>{
      const f=TestBed.createComponent(FocusFixture);f.detectChanges();const x=inputs(f);x[0].focus();
      groups(f)[1].value='d';f.detectChanges();await settle();expect(document.activeElement).toBe(x[0]);
      expect(x.map(y=>y.getAttribute('tabindex'))).toEqual(['0','-1','-1','0']);f.destroy();
    });
    it('disabled selected target blurs old focus after failed focus attempt',async()=>{
      const f=TestBed.createComponent(FocusFixture);f.detectChanges();const x=inputs(f);x[0].focus();
      f.componentInstance.disabledB=true;f.changeDetectorRef.markForCheck();f.detectChanges();await f.whenStable();f.detectChanges();
      expect(x[1].disabled).toBe(true);groups(f)[0].value='b';f.detectChanges();
      expect(x[1].checked).toBe(true);expect(document.activeElement).toBe(x[0]);
      await settle();expect(document.activeElement).not.toBe(x[0]);expect(document.activeElement).not.toBe(x[1]);f.destroy();
    });
    it('unchanged selection leaves focus intact',async()=>{
      const f=TestBed.createComponent(FocusFixture);f.detectChanges();const x=inputs(f);x[0].focus();
      f.detectChanges();await settle();expect(document.activeElement).toBe(x[0]);f.destroy();
    });
    it('uses the input owner document when the application document is an iframe',async()=>{
      const frame=document.createElement('iframe');document.body.appendChild(frame);const inside=frame.contentDocument!;
      const f=TestBed.createComponent(FocusFixture);f.detectChanges();const x=inputs(f);const group=groups(f)[0];
      inside.body.appendChild(inside.adoptNode(f.nativeElement));
      x[0].focus();expect(inside.activeElement).toBe(x[0]);expect(document.activeElement).toBe(frame);
      group.value='b';f.detectChanges();await settle();expect(inside.activeElement).toBe(x[1]);f.destroy();frame.remove();
    });
    it('does not steal focus moved outside before the queued callback',async()=>{
      const f=TestBed.createComponent(FocusFixture);f.detectChanges();const x=inputs(f);x[0].focus();groups(f)[0].value='b';f.detectChanges();
      const outside=document.createElement('button');document.body.appendChild(outside);outside.focus();await settle();
      expect(document.activeElement).toBe(outside);f.destroy();outside.remove();
    });
    it('does not focus a selected radio after the old component is destroyed',async()=>{
      const f=TestBed.createComponent(FocusFixture);f.detectChanges();const x=inputs(f);x[0].focus();groups(f)[0].value='b';f.detectChanges();f.destroy();await settle();
      expect(document.activeElement).not.toBe(x[1]);
    });
    it('checkbox ARIA mixed and absent for all checked combinations',async()=>{
      const f=TestBed.createComponent(CheckboxFixture);f.detectChanges();const input=f.nativeElement.querySelector('input.mat-checkbox-input') as HTMLInputElement;
      expect(input.hasAttribute('aria-checked')).toBe(false);
      f.componentInstance.checked=true;f.changeDetectorRef.markForCheck();f.detectChanges();await f.whenStable();f.detectChanges();expect(input.hasAttribute('aria-checked')).toBe(false);
      f.componentInstance.indeterminate=true;f.changeDetectorRef.markForCheck();f.detectChanges();await f.whenStable();f.detectChanges();expect(input.getAttribute('aria-checked')).toBe('mixed');
      f.componentInstance.checked=false;f.changeDetectorRef.markForCheck();f.detectChanges();await f.whenStable();f.detectChanges();expect(input.getAttribute('aria-checked')).toBe('mixed');
      f.componentInstance.indeterminate=false;f.changeDetectorRef.markForCheck();f.detectChanges();await f.whenStable();f.detectChanges();expect(input.hasAttribute('aria-checked')).toBe(false);
      f.destroy();
    });
  });
}
