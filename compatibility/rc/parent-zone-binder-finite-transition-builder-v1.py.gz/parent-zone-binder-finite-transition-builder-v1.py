from pathlib import Path
import hashlib,json,subprocess,difflib
R={x:Path('/home/parallels/.codex/worktrees/codex-closeout-'+y+'/ngx-compat-material-legacy') for x,y in [('21.x','21'),('main','main')]}
C={'21.x':('6bd510e8eb75f19ac9893b627e9149b4c293c038','5ef90fbc10386f774bb552a91a461a6a4c9349df'),'main':('39d1acd07aa27ef02eb23f81b42ff4b43dd76fdd','e89618076c03e8385702e45cd0915b10af3f9cb1')}
def sha(x):return hashlib.sha256(x).hexdigest()
def ref(path,b):return {'path':path,'sha256':sha(b),'bytes':len(b)}
def show(r,c,p):return subprocess.check_output(['git','--no-replace-objects','-c','gc.auto=0','-c','maintenance.auto=0','show',c+':'+p],cwd=r)
def recipe(a,b):
 a=a.decode();b=b.decode();al=a.splitlines(keepends=True);bl=b.splitlines(keepends=True);offsets=[0]
 for x in al:offsets.append(offsets[-1]+len(x.encode()))
 edits=[]
 for tag,i,j,k,l in difflib.SequenceMatcher(None,al,bl,autojunk=False).get_opcodes():
  if tag!='equal':edits.append({'offset':offsets[i],'before':''.join(al[i:j]),'after':''.join(bl[k:l])})
 cursor=0;parts=[]
 for x in edits:
  pos=x['offset'];old=x['before'].encode();assert pos>=cursor and a.encode()[pos:pos+len(old)]==old;parts.extend([a.encode()[cursor:pos],x['after'].encode()]);cursor=pos+len(old)
 assert b''.join([*parts,a.encode()[cursor:]])==b.encode();return edits
rows={};observed=[]
for line,root in R.items():
 old,new=C[line];path='scripts/browser-required-cells.mjs';before=show(root,old,path);after=show(root,new,path);current=(root/path).read_bytes();assert current==after
 profile=(root/'compatibility/rc/parent-base-class-tool-successor-inputs-v3.json').read_bytes();assert sha(profile)=='b263cc37bebdf21c6b3e73364b21e50e6a639f7f5fc2126885098a9c7f04ceb1'
 rows[line]={'old_commit':old,'new_commit':new,'path':path,'before':ref(path,before),'after':ref(path,after),'edits':recipe(before,after)};observed.append((root/path,current))
root=R['21.x'];path='scripts/packed-upstream-ledger-epoch.mjs';before=show(root,C['21.x'][1],path);after=(root/path).read_bytes();assert sha(after)=='aaf5c8d72539d2934586c8eef8a4abd6bfe065d26b3c0470c0b74a111ad77066';observed.append((root/path,after))
binder={'old_commit':C['21.x'][1],'path':path,'before':ref(path,before),'after':ref(path,after),'edits':recipe(before,after),'new_bytes_committed':False}
for p,b in observed:assert p.read_bytes()==b
packet={'schema_version':1,'role':'proposed-exact-browser-zone-and-source-binding-successor','previous_profile':{'path':'compatibility/rc/parent-base-class-tool-successor-inputs-v3.json','sha256':'b263cc37bebdf21c6b3e73364b21e50e6a639f7f5fc2126885098a9c7f04ceb1','bytes':len(profile)},'browser':rows,'binder_21':binder,'historical_packets_rewritten':False,'old_programs_executed':False,'native_or_full_audit_qualified':False,'g11_claim':'not-passed'}
out=Path('/tmp/parent-zone-binder-finite-transition-candidate-v1.json');assert not out.exists();out.write_text(json.dumps(packet,indent=2)+'\n');print(ref(str(out),out.read_bytes()))
