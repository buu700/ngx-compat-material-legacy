import {QueryList, ViewChildren} from '@angular/core';
import {CdkColumnDef} from '@angular/cdk/table';
class QueryHost {
  @ViewChildren(CdkColumnDef) columns!: QueryList<CdkColumnDef>;
}
export {QueryHost};
