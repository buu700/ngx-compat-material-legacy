import {ViewChildren} from '@angular/core';
import {CdkColumnDef} from '@angular/cdk/table';
class InvalidHost { @ViewChildren(CdkColumnDef, {descendants: true}) columns: unknown; }
