import {ViewChildren, QueryList} from '@angular/core';
import {CdkColumnDef, CdkHeaderRowDef, CdkFooterRowDef, CdkRowDef} from '@angular/cdk/table';
class _LegacyTableDefinitionOwner {}
class Host {
  @ViewChildren(_LegacyTableDefinitionOwner) definitionOwners!: QueryList<_LegacyTableDefinitionOwner>;
  @ViewChildren(CdkColumnDef) columnDefs!: QueryList<CdkColumnDef>;
  @ViewChildren(CdkHeaderRowDef) headerDefs!: QueryList<CdkHeaderRowDef>;
  @ViewChildren(CdkFooterRowDef) footerDefs!: QueryList<CdkFooterRowDef>;
  @ViewChildren(CdkRowDef) rowDefs!: QueryList<CdkRowDef<unknown>>;
}
