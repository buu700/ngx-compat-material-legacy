from pathlib import Path
import json,hashlib,os,subprocess,time,signal,sys
roots={k:Path('/home/parallels/.codex/worktrees/codex-closeout-'+v+'/ngx-compat-material-legacy') for k,v in [('21.x','21'),('main','main')]}
profile=json.loads((roots['21.x']/'compatibility/rc/parent-base-class-tool-successor-inputs-v3.json').read_bytes())
python='/nix/store/lfh101cfjj8p8npcari9hk0lbqi33yvh-python3-3.14.7/bin/python3'
env={k:v for k,v in os.environ.items() if not k.startswith('RC_')};env['PATH']='/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin:'+str(Path(python).parent)+':'+env['PATH']
def git(root,*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=0',*args],cwd=root,text=True).strip()
def snapshot():
 refs=[]
 for line,root in roots.items():
  branch=profile['branches'][line];paths={r['path'] for r in [*branch['updates'],*branch['additional_inputs']]}
  paths.update(['scripts/check-source-contract-regressions.py','compatibility/rc/parent-base-class-tool-successor-inputs-v3.json','scripts/current-sass-tool-references.mjs','scripts/current_sass_tool_references.py'])
  for p in sorted(paths):
   b=(root/p).read_bytes();refs.append(dict(line=line,path=p,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
 return refs
frozen_heads={line:git(root,'rev-parse','HEAD') for line,root in roots.items()}
assert frozen_heads == {'21.x':'1fb34a5b54b89e443522d8ca2c7d7afb981f428b','main':'df72893012ffa4e7156ffe3017ff7c0ce7337f85'}
assert (roots['21.x']/'compatibility/rc/parent-base-class-tool-successor-inputs-v3.json').read_bytes() == (roots['main']/'compatibility/rc/parent-base-class-tool-successor-inputs-v3.json').read_bytes()
assert all(not Path('/tmp/parent-source-contract-regressions-'+suffix+'-v13.json').exists() for suffix in ('21','main'))
for line,root in [(sys.argv[1],roots[sys.argv[1]])]:
 assert {name:git(path,'rev-parse','HEAD') for name,path in roots.items()}==frozen_heads
 before=snapshot();head=git(root,'rev-parse','HEAD');command=[python,'scripts/check-source-contract-regressions.py'];start=time.monotonic()
 child=subprocess.Popen(command,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 print(json.dumps(dict(line=line,state='started',pid=child.pid,source_head=head)),flush=True)
 expired=False
 try:stdout,stderr=child.communicate(timeout=900)
 except subprocess.TimeoutExpired:
  expired=True;os.killpg(child.pid,signal.SIGKILL);stdout,stderr=child.communicate()
 seconds=time.monotonic()-start;after=snapshot()
 try:report=json.loads(stdout)
 except ValueError:report=None
 record=dict(schema_version=13,line=line,role='Actual complete mandatory source regression producer; standalone no G11 admission',source_head=head,source_inputs=before,command=command,exit_code=child.returncode,seconds=seconds,outer_capture_expired=expired,child_command_budgets_changed=True, current_child_budgets_seconds={"checker":180,"browser":300}, budget_successor_profile="b08ed6163f798dc7c2463a330d29ba1622fdc9ee9fd8b1f9c1c741bf44ee2ed9",source_heads=frozen_heads,source_unchanged=before==after and {name:git(path,'rev-parse','HEAD') for name,path in roots.items()}==frozen_heads,stdout_report=report,stderr=stderr,g11_claim='not-passed')
 if report is None:record['stdout']=stdout
 target=Path('/tmp/parent-source-contract-regressions-'+('21' if line=='21.x' else 'main')+'-v13.json');assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n')
 summary=dict(line=line,state='terminal',exit_code=child.returncode,seconds=seconds,source_unchanged=record['source_unchanged'],result=report and report.get('result'),receipt=str(target))
 if report:
  summary['populations']={kind:{k:v for k,v in observation.get('report',{}).items() if k in ['bound_current_paths','cold_source_faults_rejected','late_source_faults_rejected']} for kind,observation in report.get('observations',{}).items() if isinstance(observation,dict)}
 print(json.dumps(summary),flush=True)
 if child.returncode or not record['source_unchanged'] or not report or report.get('result')!='pass':raise SystemExit(1)
