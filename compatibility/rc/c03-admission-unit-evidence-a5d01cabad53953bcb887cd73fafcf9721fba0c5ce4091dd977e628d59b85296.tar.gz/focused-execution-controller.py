"""Capture independent focused admission tests in the disposable scratch checkout."""
import json,os,subprocess,time
from pathlib import Path
root=Path('/tmp/c03-admission-unit-main-v1')
python='/nix/store/1h24n18a2wpmawy2xvfgily3yj8v3850-python3-3.14.7-env/bin/python3'
node='/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin'
env={**os.environ,'PATH':str(Path(python).parent)+':'+node+':'+os.environ['PATH']}
tests=[('archive',['test_migration_cli_archive_admission.py']),('workspace',['test_migration_workspace_admission.py']),('consumer',['test_migrated_consumer_evidence.py']),('frontend',['test_frontend_parity.py']),('acceptance',['test_rc_acceptance.py']),('coordinator-migration',['test_rc_verify_evidence_integration.py','-k','migration'])]
items=[]
for name,args in tests:
 cmd=[python,'-m','unittest','discover','-s','tests','-p',args[0],*args[1:]]
 started=time.monotonic();p=subprocess.run(cmd,cwd=root,env=env,text=True,capture_output=True,timeout=90)
 items.append(dict(name=name,argv=cmd,cwd=str(root),exit_code=p.returncode,seconds=round(time.monotonic()-started,3),stdout=p.stdout,stderr=p.stderr))
record={'scope':'Synthetic fixture and admission tests; no consumer or release qualification','python':subprocess.check_output([python,'--version'],text=True).strip(),'node':subprocess.check_output([node+'/node','--version'],text=True).strip(),'commands':items}
Path('/tmp/c03-admission-author-focused-v1.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps([(x['name'],x['exit_code']) for x in items]))
