import {MatLegacyButtonModule} from '@ngx-compat/material-legacy/legacy-button';
export {MatLegacyButtonModule};
