import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const hash=b=>createHash('sha256').update(b).digest('hex');
const observations=[];
for(const line of ['21','main']){
 const root=`/home/parallels/.codex/worktrees/codex-closeout-${line}/ngx-compat-material-legacy`;
 const {floorConfigurations}=await import(pathToFileURL(root+'/scripts/consumer-floor-roster.mjs'));
 const {runtimeProfile,verifyRuntimeArchive,verifyRuntimeExecutable}=await import(pathToFileURL(root+'/scripts/consumer-floor-runtime.mjs'));
 const plan=JSON.parse(readFileSync(root+'/compatibility/rc/consumer-floor-plan.json'));
 const manifest=JSON.parse(readFileSync(root+'/projects/ngx-material-legacy/package.json'));
 const rows=floorConfigurations(plan,line==='21'?'21.x':'main',manifest).filter(row=>row.group==='library-runtime');
 for(const configuration of rows){
  const version=configuration.node,base='/tmp/c03-floor-sol6-GOzKraLx/node-v'+version+'-linux-arm64';
  const profile=runtimeProfile(plan,'linux','arm64',version);
  verifyRuntimeArchive(readFileSync(base+'.tar.xz'),profile.pin);
  const runtime=verifyRuntimeExecutable(base+'/bin/node',version,profile.platform,(cmd,args)=>{
   const child=spawnSync(cmd,args,{encoding:'utf8'});if(child.status!==0)throw new Error(child.stderr);return child;
  });
  observations.push({line,root,configuration,runtime,archive:profile.pin,
   head:spawnSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).stdout.trim(),
   source_script_sha256:hash(readFileSync(root+'/scripts/packed-consumer-aot-smoke.mjs'))});
 }
}
writeFileSync('/tmp/root-current-library-floors-v1/preflight.json',JSON.stringify(observations,null,2)+'\n');
console.log(JSON.stringify({library_cells:observations.length,node_versions:[...new Set(observations.map(x=>x.configuration.node))]}));
