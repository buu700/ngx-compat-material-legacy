from pathlib import Path
import json,os,subprocess,datetime,hashlib,threading,concurrent.futures,signal
root=Path('/tmp/root-current-library-floors-v1');state=root/'state.json';rows=json.loads((root/'preflight.json').read_text());lock=threading.Lock();hash=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
tars={'21':Path('/tmp/root-radio-packed-21-v3/ngx-compat-material-legacy-21.0.0-rc.0.tgz'),'main':Path('/tmp/root-radio-packed-main-v3/ngx-compat-material-legacy-22.0.0-rc.0.tgz')}
expected={'21':'ee5320afb5ce045fa5d8891569d705695c2a12f832a7695cd12ab70b24e93405','main':'eab8ee40771e47406dab34272879fd510f63da94b3936a81bcff2fc9f033a801'}
for line,p in tars.items():assert hash(p)==expected[line]
catalog=json.loads((Path(rows[0]['root'])/'compatibility/toolchain-advisory-subjects.json').read_text());npm=next(p for p in catalog['packages'] if p['name']=='npm');assert hash('/tmp/c03-floor-sol6-GOzKraLx/npm-11.19.0.tgz')==npm['archive_sha256']
report={'status':'running','pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'concurrency':2,'npm_archive_sha256':npm['archive_sha256'],'jobs':[]}
for index,row in enumerate(rows):
 row.update(index=index,status='queued',tarball=str(tars[row['line']]),tarball_sha256=expected[row['line']],output=str(root/('cell-'+str(index)+'.json')),log=str(root/('cell-'+str(index)+'.log')));report['jobs'].append(row)
def save():
 tmp=state.with_suffix('.tmp');tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(state)
def run(row):
 with lock:row['status']='running';save()
 env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=1024';env['NGX_FLOOR_NPM_CLI']='/tmp/c03-floor-sol6-GOzKraLx/npm/package/bin/npm-cli.js';env['PATH']=str(Path(row['runtime']['executable']).parent)+':'+env['PATH']
 command=[row['runtime']['executable'],str(Path(row['root'])/'scripts/packed-consumer-aot-smoke.mjs'),'--tarball',row['tarball'],'--floor-case',row['configuration']['case_id'],'--floor-out',row['output']];row['command']=command
 try:
  with open(row['log'],'w') as log:
   child=subprocess.Popen(command,cwd=row['root'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   with lock:row['child_pid']=child.pid;save()
   try:code=child.wait(timeout=480)
   except subprocess.TimeoutExpired:
    os.killpg(child.pid,signal.SIGTERM);code=child.wait(timeout=15)
    row['timeout']=True
  result=json.loads(Path(row['output']).read_text()) if Path(row['output']).exists() else None
  stable=hash(Path(row['root'])/'scripts/packed-consumer-aot-smoke.mjs')==row['source_script_sha256'] and hash(row['tarball'])==row['tarball_sha256']
  row.update(exit_code=code,source_and_tar_stable=stable,result_status=result.get('status') if result else None,aot=result.get('aot',{}).get('status') if result else None,harness=result.get('harness',{}).get('status') if result else None,status='passed' if code==0 and stable and result and result.get('status')=='ok' else 'failed')
  if result:row['errors']=result.get('errors');row['report_sha256']=hash(row['output'])
 except Exception as e:row.update(status='failed',error=repr(e))
 with lock:save()
save()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,rows))
report['status']='passed' if all(r['status']=='passed' for r in rows) else 'failed';report['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
