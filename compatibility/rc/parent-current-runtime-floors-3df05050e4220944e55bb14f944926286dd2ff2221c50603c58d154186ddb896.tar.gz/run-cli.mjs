import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const base='/tmp/root-current-library-floors-v1',runtimes='/tmp/c03-floor-sol6-GOzKraLx';
const hash=b=>createHash('sha256').update(b).digest('hex');
const results=[];
for(const line of ['21','main']){
 const artifact=JSON.parse(readFileSync(`${base}/cli-${line}-artifact.json`));
 const cli=`${base}/cli-${line}/package/bin/migrate-legacy.js`;
 for(const version of ['18.0.0','24.21.0','26.0.0']){
  const node=`${runtimes}/node-v${version}-linux-arm64/bin/node`,fixture=`${base}/cli-fixture-${line}-${version}`;
  mkdirSync(fixture);
  const ts="import {MatLegacyButtonModule} from '@angular/material/legacy-button';\nexport {MatLegacyButtonModule};\n";
  const scss="@use '@angular/material' as mat;\n.example { color: mat.get-color-from-palette(mat.$indigo-palette, 500); }\n";
  writeFileSync(fixture+'/example.ts',ts);writeFileSync(fixture+'/example.scss',scss);
  const observations=[];
  for(const flags of [[],['--apply'],['--apply']]){
   const command=[cli,fixture,'--json',...flags];const child=spawnSync(node,command,{encoding:'utf8',timeout:30000});
   assert.equal(child.status,0,child.stderr||child.stdout);observations.push({command:[node,...command],exit:child.status,report:JSON.parse(child.stdout)});
  }
  assert.deepEqual(observations.map(x=>[x.report.safe_edits,x.report.applied,x.report.blocking]),[[2,0,0],[2,2,0],[0,0,0]]);
  assert.equal(readFileSync(fixture+'/example.ts','utf8'),ts.replace('@angular/material/legacy-button','@ngx-compat/material-legacy/legacy-button'));
  assert.equal(readFileSync(fixture+'/example.scss','utf8'),scss.replace('@angular/material','@ngx-compat/material-legacy'));
  const row={line,node:version,runtime_sha256:hash(readFileSync(node)),artifact_sha256:artifact.sha256,cli_sha256:hash(readFileSync(cli)),observations,namespace_and_calls_preserved:true,result:'pass'};
  writeFileSync(`${base}/cli-${line}-node-${version}.json`,JSON.stringify(row,null,2)+'\n');results.push(row);
 }
}
writeFileSync(`${base}/cli-matrix.json`,JSON.stringify({scope:'Exact packaged CLI Node-floor smoke: TS and Sass module-only migration, dry/apply/idempotence; no resulting Angular consumer build',cells:results.length,status:'passed',results},null,2)+'\n');
console.log(JSON.stringify({cli_cells:results.length,status:'passed'}));
