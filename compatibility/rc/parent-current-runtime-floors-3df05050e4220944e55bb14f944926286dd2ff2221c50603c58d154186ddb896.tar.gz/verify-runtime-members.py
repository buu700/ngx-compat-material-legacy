from pathlib import Path
import hashlib,json,tarfile
base=Path('/tmp/root-current-library-floors-v1');cache=Path('/tmp/c03-floor-sol6-GOzKraLx');preflight=json.loads((base/'preflight.json').read_text());plan=json.loads((Path(preflight[0]['root'])/'compatibility/rc/consumer-floor-plan.json').read_text());hash=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for version in sorted({r['configuration']['node'] for r in preflight}|{'18.0.0'}):
 prefix='node-v'+version+'-linux-arm64';archive=cache/(prefix+'.tar.xz');pin=plan['node_sources_by_platform']['linux-arm64'][version];assert hash(archive.read_bytes())==pin['sha256']
 with tarfile.open(archive) as t:raw=t.extractfile(prefix+'/bin/node').read()
 executable=cache/prefix/'bin/node';assert not executable.is_symlink();assert raw==executable.read_bytes();rows.append({'version':version,'archive_sha256':pin['sha256'],'executable_sha256':hash(raw),'executable_matches_archive':True,'platform':'linux-arm64','url':pin['url']})
catalog=json.loads((Path(preflight[0]['root'])/'compatibility/toolchain-advisory-subjects.json').read_text());npm=next(p for p in catalog['packages'] if p['name']=='npm');archive=cache/'npm-11.19.0.tgz';assert hash(archive.read_bytes())==npm['archive_sha256']
with tarfile.open(archive) as t:raw=t.extractfile('package/bin/npm-cli.js').read()
assert raw==(cache/'npm/package/bin/npm-cli.js').read_bytes();result={'node':rows,'npm':{'version':'11.19.0','archive_sha256':npm['archive_sha256'],'cli_sha256':hash(raw),'cli_matches_archive':True}}
(base/'runtime-member-verification.json').write_text(json.dumps(result,indent=2)+'\n');print('Verified eight Node executables and npm CLI against pinned archive members')
