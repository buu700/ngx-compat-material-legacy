"""Retain bounded v3 Chromium lifecycle evidence outside maintained checkouts.

Optional arguments are completed maintained-run receipt files. Run again with
those paths to create a new content-addressed archive and index; existing
archives are never overwritten. This script performs no integration or tests.
"""
from pathlib import Path
import gzip,hashlib,io,json,sys,tarfile,subprocess
OUT=Path('/home/parallels/.codex/qualification-evidence/c02-lifecycle-v3-retained')
OUT.mkdir(parents=True,exist_ok=True)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def ref(path,raw):return {'path':str(path),'sha256':digest(raw),'bytes':len(raw)}
paths={
 'patches/main.patch':'/tmp/c02-lifecycle-v3-portable-package/lifecycle-v3.patch',
 'patches/21.patch':'/tmp/c02-lifecycle-v3-portable-package/21.patch',
 'patches/README.md':'/tmp/c02-lifecycle-v3-portable-package/README.md',
 'frozen/helper.mjs':'/home/parallels/.codex/qualification-evidence/c02-browser-lifecycle-draft-v3/check-companion-computed-styles.mjs',
 'frozen/surface.mjs':'/home/parallels/.codex/qualification-evidence/c02-browser-lifecycle-draft-v3/browser-surface-families.mjs',
 'frozen/process-controls.mjs':'/home/parallels/.codex/qualification-evidence/c02-browser-lifecycle-draft-v3/chromium-lifecycle-process-controls.mjs',
 'controls/author-main-17.log':'/tmp/c02-lifecycle-adapter-process-v4.log',
 'controls/author-21-17.log':'/tmp/c02-lifecycle-v3-portable-package/21-process.log',
 'controls/independent-startup-v3.mjs':'/tmp/c04-lifecycle-independent-v3/tests/independent-startup-v3.mjs',
 'controls/independent-control-author-rerun.log':'/tmp/c02-lifecycle-v3-independent-control-author-rerun.log',
 'reviews/initial-v1.json':'/tmp/c04-browser-lifecycle-independent-review-v1.json',
 'reviews/review-v3.json':'/tmp/c04-browser-lifecycle-independent-review-v3.json',
 'smoke/accepted/runner.mjs':'/tmp/c02-lifecycle-v3-chromium-smoke-v3/run.mjs',
 'smoke/accepted/output.log':'/tmp/c02-lifecycle-v3-chromium-smoke-v3/output.log',
 'smoke/accepted/receipt.json':'/tmp/c02-lifecycle-v3-chromium-smoke-v3/receipt.json',
 'smoke/failed-harness-v1/runner.mjs':'/tmp/c02-lifecycle-v3-chromium-smoke-v1/run.mjs',
 'smoke/failed-harness-v1/output.log':'/tmp/c02-lifecycle-v3-chromium-smoke-v1/output.log',
 'smoke/failed-harness-v2/runner.mjs':'/tmp/c02-lifecycle-v3-chromium-smoke-v2/run.mjs',
 'smoke/failed-harness-v2/output.log':'/tmp/c02-lifecycle-v3-chromium-smoke-v2/output.log',
 'retention/retain.py':str(Path(__file__).resolve()),
}
for i,arg in enumerate(sys.argv[1:]):
 p=Path(arg).resolve();assert p.is_file() and not p.is_symlink(),p
 paths[f'maintained-receipts/{i+1:02}-{p.name}']=str(p)
observed={}
for arg in sys.argv[1:]:
 data=json.loads(Path(arg).read_bytes());line=data['line'];assert line in ('main','21.x') and data['exit_code']==0 and data['unittest_count']==2
 root=Path(data['root']);head=subprocess.check_output(['git','--no-replace-objects','rev-parse','HEAD'],cwd=root,text=True).strip()
 observed[line]={'head_at_execution':data['head_at_execution'],'head_at_retention':head,'source_watch_qualification':data['source_watch_qualification'],'post_execution_source_identities':data['post_execution_source_identities']}
 for rel,identity in data['post_execution_source_identities'].items():
  src=root/rel;assert src.is_file() and not src.is_symlink() and digest(src.read_bytes())==identity['sha256']
  paths[f'maintained-snapshots/{line}/{rel}']=str(src)
members={}
for name,path in paths.items():
 p=Path(path);assert p.is_file() and not p.is_symlink(),p;members[name]=p.read_bytes()
for line,record in observed.items():
 for rel,identity in record['post_execution_source_identities'].items():assert digest(members[f'maintained-snapshots/{line}/{rel}'])==identity['sha256']
assert digest(members['frozen/helper.mjs'])=='56a8c4d06264aee070f4cf76dd2e2bec562e28408a632cd6e4bb1a54ac2cfead'
assert digest(members['frozen/surface.mjs'])=='917a0b49f48a552bfcb63c31d86c109d1864ccb62383c1d76755ffc583bde4ff'
assert digest(members['frozen/process-controls.mjs'])=='2df781856ba39eac77f220fb8cf8a8e45c232630a023bbcee5a9f0af58c02884'
for name in ['controls/author-main-17.log','controls/author-21-17.log']:
 rows=[json.loads(l) for l in members[name].decode().splitlines() if l.startswith('{')];assert len(rows)==17 and all(r.get('pass') is True for r in rows)
rows=[json.loads(l) for l in members['controls/independent-control-author-rerun.log'].decode().splitlines() if l.startswith('{')];assert len(rows)==2 and all(r.get('pass') is True for r in rows)
review=json.loads(members['reviews/review-v3.json']);assert review['result']=='accept bounded lifecycle adapter review'
smoke=json.loads(members['smoke/accepted/receipt.json']);assert len(smoke['results'])==3 and all(r['result']=='pass' and r['fixture_server_closed'] and r['debug_endpoint_after']=='ECONNREFUSED' and not r['remaining_profile_processes'] for r in smoke['results'])
assert smoke['inputs']['helper']['sha256']==digest(members['frozen/helper.mjs'])
assert smoke['inputs']['runner']['sha256']==digest(members['smoke/accepted/runner.mjs'])
contents={name:ref(paths[name],data) for name,data in sorted(members.items())};members['CONTENTS.json']=(json.dumps(contents,indent=2,sort_keys=True)+'\n').encode()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
archive=gzip.compress(buffer.getvalue(),mtime=0);name='c02-surface-lifecycle-v3-'+digest(archive)+'.tar.gz'
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
 assert len(tar.getmembers())==len(members)
 for m in tar.getmembers():assert m.isfile() and tar.extractfile(m).read()==members[m.name]
index={'schema_version':1,'scope':'Bounded v3 surface Chromium lifecycle adaptation; no full product, matrix, C02, G11 or release qualification',
 'archive':ref(name,archive),'archive_members':len(members),'review':'reviews/review-v3.json',
 'frozen_main_helper_sha256':digest(members['frozen/helper.mjs']),
 'main_base':'9734b4a9ada49cdfe3dc8b4dfe44d1e04664a2ed','21_base':'2f5201af2294a1c99552fb1876583b4e8d11b5f2',
 'portable_process_controls':'17 spawned-process/CDP cases passed in scratch for each line; independent reviewer additionally passed detached ephemeral startup controls',
 'real_browser':'Three actual Snap Chromium 156.0.8078.79 smoke cases passed on pinned Node 24.21.0, including ephemeral and explicit announced ports and callback failure; owned endpoint/server/process closure recorded',
 'failed_harness':'Two earlier attempts failed because Snap private temporary namespace hid DevToolsActivePort; retained without product verdict',
 'maintained_receipts':[k for k in members if k.startswith('maintained-receipts/')],
 'maintained_observed_post_execution':observed,
 'maintained_test_evidence':'included as supplied; see individual receipts' if sys.argv[1:] else 'pending; not included',
 'limitations':['Maintained source identities were checked after execution only; no independent before/after full-source controller was used.','Prior v2 real-product observations do not certify the corrected v3 bytes.','Browser smoke does not qualify product behavior or the complete browser matrix.'],'g11_claim':'not-passed'}
raw=(json.dumps(index,indent=2)+'\n').encode();iname='c02-surface-lifecycle-v3-index-'+digest(raw)+'.json'
for n,b in [(name,archive),(iname,raw)]:
 p=OUT/n
 if p.exists():assert p.read_bytes()==b
 else:
  with p.open('xb') as f:f.write(b)
print(json.dumps({'archive':str(OUT/name),'index':str(OUT/iname),'index_sha256':digest(raw),'members':len(members),'maintained_receipts':len(sys.argv)-1}))
