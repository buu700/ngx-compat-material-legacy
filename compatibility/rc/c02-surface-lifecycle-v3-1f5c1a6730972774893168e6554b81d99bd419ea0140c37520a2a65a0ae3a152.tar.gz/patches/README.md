# Surface browser lifecycle v3 integration

This is a scratch proposal pending independent review. It uses the existing `withChromium` implementation and adapts only the surface producer. It does not change surface fixture assertions; merge any independent fixture correction separately. It adds the existing helper's optional surface CSP, Chromium flags and announced-endpoint handling, and adds process controls.

- `lifecycle-v3.patch`: main base `9734b4a9ada49cdfe3dc8b4dfe44d1e04664a2ed`; `git apply --check` passed against that frozen tree.
- `21.patch`: 21.x base `2f5201af2294a1c99552fb1876583b4e8d11b5f2`; `git apply --check` passed against that frozen tree. Its helper preserves 21.x-specific roster and job behavior and uses exactly the same `withChromium` function as main. The remaining changed files have the same target bytes. Apply only after checking current HEAD and local changes, and rebase the patch as needed; do not overwrite independent changes.

For each line: run the pinned Node 24.21.0 `tests/chromium-lifecycle-process-controls.mjs`. The main v3 suite output is `/tmp/c02-lifecycle-adapter-process-v4.log`; it passed 17 cases. The 21.x suite output is `21-process.log` and its exit status must be checked before using it. Run relevant actual surface consumers after merging their separate fixture work. Frozen main helper SHA-256 is `56a8c4d06264aee070f4cf76dd2e2bec562e28408a632cd6e4bb1a54ac2cfead`; the exact main helper real-Chromium smoke receipt is `/tmp/c02-lifecycle-v3-chromium-smoke-v3/receipt.json` and reports no product or matrix gate credit. The 21.x file differs outside the identical lifecycle function and was not independently run with a real browser at v3.

A separately reviewed v2 smoke is not evidence for these v3 bytes. Confirm re-review for v3 before applying to maintained worktrees. No dependency install or shared dependency refresh is needed for the process suite.
