import {withChromium} from '/tmp/c02-browser-lifecycle-scratch/scripts/check-companion-computed-styles.mjs';
import {createServer} from 'node:http';
import {readFileSync,writeFileSync,mkdtempSync,existsSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const dest='/tmp/c02-lifecycle-v3-chromium-smoke-v3';
const input='/tmp/c02-browser-lifecycle-scratch/scripts/check-companion-computed-styles.mjs';
const digest=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
assert.equal(digest(input),'56a8c4d06264aee070f4cf76dd2e2bec562e28408a632cd6e4bb1a54ac2cfead');
const dir=mkdtempSync(join(tmpdir(),'c02-lifecycle-v3-page-'));
writeFileSync(join(dir,'index.html'),'<!doctype html><title>lifecycle-v3</title><p id="probe">browser fixture</p>');
const header="default-src 'self'; img-src 'none'";
const snapshot=()=>spawnSync('ps',['-eo','pid,ppid,args'],{encoding:'utf8'}).stdout;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const unusedPort=async()=>{const s=createServer();await new Promise((r,j)=>s.once('error',j).listen(0,'127.0.0.1',r));const p=s.address().port;await new Promise(r=>s.close(r));return p;};
process.env.CHROME_BIN='/snap/bin/chromium';
const results=[];
for(const mode of ['ephemeral','explicit','callback-error']){
 console.error('stage',mode);const requested=mode==='ephemeral'?0:await unusedPort();let capture, observedError;const sentinel=new Error('callback failure sentinel');
 try {
  const result=await withChromium(dir,async ({send,evaluate,browser,port})=>{
   const fixture=`http://127.0.0.1:${port}/`;
   const lines=snapshot().split('\n').filter(x=>x.includes(fixture)&&x.includes('--user-data-dir='));
   assert.equal(lines.length,1,'unique browser command for fixture');
   const profile=lines[0].match(/--user-data-dir=([^\s]+)/)?.[1];assert.ok(profile);
   let actual=requested;
   if(!actual){
    const candidates=readFileSync('/proc/net/tcp','utf8').trim().split('\n').slice(1).map(line=>line.trim().split(/\s+/)).filter(parts=>parts[3]==='0A' && parts[1].startsWith('0100007F:')).map(parts=>parseInt(parts[1].split(':')[1],16));
    const found=[];for(const p of candidates){try{const response=await fetch(`http://127.0.0.1:${p}/json/list`,{signal:AbortSignal.timeout(150)});if(response.ok){const pages=await response.json();if(pages.some(page=>page.type==='page'&&page.url===fixture))found.push(p);}}catch{}}
    assert.equal(found.length,1,'unique endpoint serving owned fixture');actual=found[0];
   }
   const v=await (await fetch(`http://127.0.0.1:${actual}/json/version`)).json();
   const response=await fetch(fixture);assert.equal(response.headers.get('content-security-policy'),header);
   assert.equal(await evaluate('document.querySelector("#probe").textContent'),'browser fixture');
   const runtime=await send('Runtime.evaluate',{expression:'document.title',returnByValue:true,awaitPromise:false});assert.equal(runtime.result.value,'lifecycle-v3');
   capture={browser,fixture,requested_debug_port:requested,actual_debug_port:actual,browser_websocket:v.webSocketDebuggerUrl,profile,owned_browser_process:lines[0],response_csp:response.headers.get('content-security-policy')};
   if(mode==='callback-error')throw sentinel;return 'surface-observation';
  },{debugPort:requested,chromiumArgs:[],requireAnnouncedEndpoint:true,responseHeaders:{'content-security-policy':header}});
  assert.notEqual(mode,'callback-error');assert.equal(result,'surface-observation');
 } catch(error){observedError=String(error);if(mode!=='callback-error'||error!==sentinel)throw error;}
 assert.ok(capture);let refusal=null, remaining=[];
 for(let i=0;i<40;i++){
  try{await fetch(`http://127.0.0.1:${capture.actual_debug_port}/json/version`,{signal:AbortSignal.timeout(500)});}catch(error){if(error?.cause?.code==='ECONNREFUSED')refusal='ECONNREFUSED';}
  remaining=snapshot().split('\n').filter(x=>x.includes('--user-data-dir='+capture.profile));
  if(refusal&&remaining.length===0)break;await sleep(100);
 }
 assert.equal(refusal,'ECONNREFUSED');assert.deepEqual(remaining,[]);
 let fixtureClosed=false;try{await fetch(capture.fixture,{signal:AbortSignal.timeout(500)});}catch(error){fixtureClosed=error?.cause?.code==='ECONNREFUSED';}assert.ok(fixtureClosed);
 results.push({mode,...capture,callback_error:observedError||null,debug_endpoint_after:refusal,fixture_server_closed:fixtureClosed,remaining_profile_processes:remaining,result:'pass'});
}
const receipt={scope:'Frozen v3 withChromium actual Snap Chromium smoke; no product or matrix gate claim',node:process.version,node_path:process.execPath,chrome_bin:process.env.CHROME_BIN,inputs:{helper:{path:input,sha256:digest(input)},runner:{path:import.meta.filename,sha256:digest(import.meta.filename)},fixture_sha256:digest(join(dir,'index.html'))},results};
writeFileSync(join(dest,'receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));
