import pathlib, json, hashlib, subprocess, os, re
root=pathlib.Path('/tmp/main-c01-command-disposable'); os.chdir(root)
checker=root/'scripts/check-dependency-eligibility.py'; original=checker.read_bytes()
alt=root/'compatibility/rc/parent-private-npm-current-profile-inputs-v987.json'
p=json.loads((root/'compatibility/rc/parent-private-npm-current-profile-inputs-v1.json').read_bytes()); s=p['lines']['main']
suffix={'.cjs','.js','.mjs','.py','.sh','.ts'}
def files(d, suff): return sorted(x.as_posix() for x in pathlib.Path(d).rglob('*') if x.is_file() and x.suffix in suff)
def row(path):
 b=pathlib.Path(path).read_bytes(); return {'path':path,'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'bytes':len(b)}
primary=sorted(set(files('scripts',suffix)+files('.github/workflows',{'.yaml','.yml'})+['.npmrc','chainman.toml','chainman.lock','justfile','package.json','projects/ngx-material-legacy/package.json','pnpm-lock.yaml'])-{'scripts/check-dependency-eligibility.py'})
s['source_files']=[row(x) for x in primary]
for group in s['support_discovery']: group['paths']=files(group['root'],suffix)
s['support_files']=[row(x) for group in s['support_discovery'] for x in group['paths']]
inputs=[x['path'] for x in s['input_files']]+['compatibility/rc/npm-tooling-current-callers-v2.json']; s['input_files']=[row(x) for x in inputs]
for path,pair in s['historical_source_hashes'].items(): pair['current_sha256']=row(path)['sha256']
raw=(json.dumps(p,indent=2)+'\n').encode(); alt.write_bytes(raw)
text=original.decode(); text=re.sub(r'^NPM_CURRENT_PRIVATE_PROFILE_PATH = ".*"$',f'NPM_CURRENT_PRIVATE_PROFILE_PATH = "{alt.relative_to(root)}"',text,flags=re.M); text=re.sub(r'^NPM_CURRENT_PRIVATE_PROFILE_SHA256 = ".*"$',f'NPM_CURRENT_PRIVATE_PROFILE_SHA256 = "{hashlib.sha256(raw).hexdigest()}"',text,flags=re.M); checker.write_text(text)
env=os.environ.copy(); env['PATH']='/nix/store/lfh101cfjj8p8npcari9hk0lbqi33yvh-python3-3.14.7/bin:/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin:'+env['PATH']; env['NODE_PATH']='/home/parallels/.codex/worktrees/codex-closeout-main/ngx-compat-material-legacy/node_modules'
try:
 for cmd in [['/nix/store/lfh101cfjj8p8npcari9hk0lbqi33yvh-python3-3.14.7/bin/python3','-m','unittest','tests.test_dependency_report_fidelity','tests.test_npm_tooling_options']]:
  x=subprocess.run(cmd,env=env,text=True,capture_output=True); print(x.stdout,x.stderr, 'exit',x.returncode); assert x.returncode==0
finally:
 checker.write_bytes(original); alt.unlink(missing_ok=True)
