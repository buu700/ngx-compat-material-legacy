import * as i4 from '@angular/cdk/dialog';
import { DialogRef, Dialog, DialogConfig, DialogModule } from '@angular/cdk/dialog';
import * as i1$1 from '@angular/cdk/overlay';
import { Overlay, OverlayModule } from '@angular/cdk/overlay';
import { BasePortalOutlet, CdkPortalOutlet, PortalModule } from '@angular/cdk/portal';
import * as i0 from '@angular/core';
import { NgModule, assertInInjectionContext, inject, EventEmitter, ChangeDetectorRef, Renderer2, DOCUMENT, ViewChild, Optional, Inject, Component, ChangeDetectionStrategy, ViewEncapsulation, Injectable, InjectionToken, ANIMATION_MODULE_TYPE, SkipSelf, Input, Directive } from '@angular/core';
import { BidiModule } from '@angular/cdk/bidi';
import { Platform } from '@angular/cdk/platform';
import { MatDialogConfig, MatDialogState } from '@angular/material/dialog';
export { MatDialogState as MatLegacyDialogState } from '@angular/material/dialog';
import { Subject, Subscription, defer, merge } from 'rxjs';
import { take, startWith, filter } from 'rxjs/operators';
import * as i1 from '@angular/cdk/a11y';
import { legacyAnimationsDisabled } from '@ngx-compat/material-legacy/legacy-core';
import { ESCAPE, hasModifierKey } from '@angular/cdk/keycodes';
import * as i2 from '@angular/common';

/**
 * Minimal MatCommonModule stand-in for legacy NgModules.
 * Historical MatCommonModule is gone from current @angular/material/core;
 * export CDK Bidi for directionality consumers.
 */
class MatCommonModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, imports: [BidiModule], exports: [BidiModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, imports: [BidiModule, BidiModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [BidiModule],
                    exports: [BidiModule],
                }]
        }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** Resolve the active element through open shadow roots without private CDK helpers. */
function legacyDialogActiveElement() {
    let active = typeof document !== 'undefined' && document ? document.activeElement : null;
    while (active?.shadowRoot) {
        const next = active.shadowRoot.activeElement;
        if (next === active) {
            break;
        }
        active = next;
    }
    return active;
}
function legacyDialogContainsFocus(element) {
    const active = legacyDialogActiveElement();
    return element === active || !!active && element.contains(active);
}
function focusLegacyDialogInitially(context, options) {
    if (!context.isBrowser) {
        context.onFocusSettled();
        return null;
    }
    const { element, config, factory, checker, renderer, ngZone } = context;
    switch (config.autoFocus) {
        case false:
        case 'dialog':
            if (!legacyDialogContainsFocus(element)) {
                element.focus(options);
            }
            context.onFocusSettled();
            return null;
        case true:
        case 'first-tabbable': {
            // This temporary selector uses the public initial-element algorithm.
            // Defer anchors: the enclosing container already owns the real tab trap.
            const selection = factory.create(element, true);
            let focused;
            try {
                focused = selection.focusInitialElement(options);
            }
            finally {
                selection.destroy();
            }
            if (focused) {
                context.onFocusSettled();
                return null;
            }
            // The original focusInitialElementWhenReady promise deferred only its fallback.
            let canceled = false;
            Promise.resolve().then(() => {
                if (!canceled && !context.isDestroyed()) {
                    element.focus(options);
                    context.onFocusSettled();
                }
            });
            return () => { canceled = true; };
        }
    }
    const selector = config.autoFocus === 'first-heading'
        ? 'h1, h2, h3, h4, h5, h6, [role="heading"]'
        : config.autoFocus;
    const target = element.querySelector(selector);
    let cleanup = null;
    if (target) {
        if (!checker.isFocusable(target)) {
            target.tabIndex = -1;
            ngZone.runOutsideAngular(() => {
                let restored = false;
                const restore = () => {
                    if (restored) {
                        return;
                    }
                    restored = true;
                    stopBlur();
                    stopMouseDown();
                    target.removeAttribute('tabindex');
                };
                const stopBlur = renderer.listen(target, 'blur', restore);
                const stopMouseDown = renderer.listen(target, 'mousedown', restore);
                cleanup = restore;
            });
        }
        target.focus(options);
    }
    context.onFocusSettled();
    return cleanup;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
const states = new WeakMap();
function registerLegacyDialogContainerState(container, focusTrapped, changeDetector) {
    // The public peer hook is optional. Keep its runtime bridge out of the frozen
    // legacy declaration surface, without private fields that narrow assignability.
    Object.defineProperty(container, '_focusTrapped', { value: focusTrapped });
    states.set(container, { focusTrapped, changeDetector, destroyed: false, peer: null });
}
/** Bind an actual owned ref without requiring Angular injection during manual construction. */
function registerLegacyDialogContainerPeer(container, peer) {
    const state = states.get(container);
    if (state && !state.destroyed) {
        state.peer = peer;
    }
}
function legacyDialogContainerPeer(container) {
    return states.get(container)?.peer ?? null;
}
function destroyLegacyDialogContainerState(container) {
    const state = states.get(container);
    if (state) {
        state.destroyed = true;
        state.changeDetector = null;
        state.peer = null;
    }
}
/** Internal access to the owned stream, without expanding the legacy class API. */
function legacyDialogFocusNotifications(container) {
    const state = states.get(container);
    if (!state) {
        throw Error('Focus notifications require an owned legacy dialog container');
    }
    return state.focusTrapped;
}
function addLegacyDialogTitle(container, id) {
    const state = states.get(container);
    if (!state?.destroyed && container._ariaLabelledByQueue) {
        container._ariaLabelledByQueue.push(id);
        state?.changeDetector?.markForCheck();
    }
}
function removeLegacyDialogTitle(container, id) {
    const state = states.get(container);
    const queue = container._ariaLabelledByQueue;
    if (!state?.destroyed && queue) {
        const index = queue.indexOf(id);
        if (index > -1) {
            queue.splice(index, 1);
            state?.changeDetector?.markForCheck();
        }
    }
}

/** Optional Angular services must not prevent the original manual constructor. */
function ambientService(token) {
    try {
        assertInInjectionContext(ambientService);
    }
    catch {
        return null;
    }
    return inject(token, { optional: true });
}
/**
 * Base class for the legacy dialog container. Portal rendering, keyboard trapping
 * and focus monitoring remain owned by the current public peer primitives.
 */
class _MatDialogContainerBase extends BasePortalOutlet {
    _elementRef;
    _focusTrapFactory;
    _config;
    _legacyFocusChecker;
    _ngZone;
    _legacyOverlayRef;
    _legacyFocusMonitor;
    /** Emits when an animation state changes. */
    _animationStateChanged = new EventEmitter();
    _portalOutlet;
    _closeInteractionType = null;
    _ariaLabelledByQueue = [];
    _document;
    _legacyFocusNotifications = new Subject();
    _legacyFocusStableSubscriptions = new Subscription();
    _legacyChangeDetector = ambientService(ChangeDetectorRef);
    _legacyDialogRef = ambientService(DialogRef);
    _legacyFocusPlatform = ambientService(Platform);
    _legacyFocusRenderer = ambientService(Renderer2);
    _legacyFocusTrap = null;
    _legacyPreviousFocus = null;
    _legacyBackdropSubscription = null;
    _legacyFocusDestroyed = false;
    _legacyFocusCleanup = null;
    constructor(_elementRef, _focusTrapFactory, _document, _config, _legacyFocusChecker, _ngZone, _legacyOverlayRef, _legacyFocusMonitor) {
        super();
        this._elementRef = _elementRef;
        this._focusTrapFactory = _focusTrapFactory;
        this._config = _config;
        this._legacyFocusChecker = _legacyFocusChecker;
        this._ngZone = _ngZone;
        this._legacyOverlayRef = _legacyOverlayRef;
        this._legacyFocusMonitor = _legacyFocusMonitor;
        registerLegacyDialogContainerState(this, this._legacyFocusNotifications.asObservable(), this._legacyChangeDetector);
        this._document = _document;
        if (_config.ariaLabelledBy) {
            this._ariaLabelledByQueue.push(_config.ariaLabelledBy);
        }
    }
    attachComponentPortal(portal) {
        this._assertContentAvailable();
        const result = this._portalOutlet.attachComponentPortal(portal);
        this._contentAttached();
        return result;
    }
    attachTemplatePortal(portal) {
        this._assertContentAvailable();
        const result = this._portalOutlet.attachTemplatePortal(portal);
        this._contentAttached();
        return result;
    }
    /** Historical DOM-portal entry, delegated through the public generic protocol. */
    attachDomPortal = portal => {
        this._assertContentAvailable();
        // Match the historical host before and after the child's ownership handoff.
        const preserveContainerHost = (typeof ngDevMode === 'undefined' || ngDevMode) && !portal.element.parentNode;
        try {
            this._portalOutlet.attach(portal);
        }
        catch (error) {
            const portalAttached = portal.isAttached;
            this._portalOutlet.detach();
            if (portalAttached) {
                portal.setAttachedHost(preserveContainerHost ? this : this._portalOutlet);
            }
            throw error;
        }
        this._contentAttached();
    };
    hasAttached() {
        return !!this._portalOutlet?.hasAttached() || super.hasAttached();
    }
    detach() {
        this._portalOutlet?.detach();
        super.detach();
    }
    dispose() {
        this._portalOutlet?.dispose();
        super.dispose();
    }
    _contentAttached() {
        if (this._legacyFocusDestroyed) {
            return;
        }
        if (!this._legacyFocusTrap && this._isBrowser()) {
            this._legacyFocusTrap = this._focusTrapFactory.create(this._elementRef.nativeElement);
            if (this._document) {
                this._legacyPreviousFocus = legacyDialogActiveElement();
            }
        }
        // A public CDK DialogRef already recaptures on its own backdrop. A manually
        // constructed container still listens to exactly the supplied OverlayRef.
        const owner = legacyDialogContainerPeer(this) ?? this._legacyDialogRef;
        if (!this._legacyBackdropSubscription && !(owner instanceof DialogRef
            && owner.overlayRef === this._legacyOverlayRef && owner.containerInstance === this)) {
            this._legacyBackdropSubscription = this._legacyOverlayRef.backdropClick().subscribe(() => {
                if (this._config.disableClose) {
                    this._recaptureFocus();
                }
            });
        }
        this._captureInitialFocus();
    }
    _recaptureFocus() {
        if (this._legacyFocusDestroyed) {
            return;
        }
        const owner = legacyDialogContainerPeer(this) ?? this._legacyDialogRef;
        // The CDK peer is disabled for deferred closing even when the legacy dialog can close.
        // Keep that peer hook from adding focus work to an enabled legacy backdrop click.
        if (!this._config.disableClose && owner instanceof DialogRef && owner.disableClose
            && owner.overlayRef === this._legacyOverlayRef && owner.containerInstance === this) {
            return;
        }
        if (!legacyDialogContainsFocus(this._elementRef.nativeElement)) {
            this._trapFocus();
        }
    }
    /** Preserve the original direct-focus and public NgZone stability timing. */
    _trapFocus() {
        if (this._legacyFocusDestroyed) {
            return;
        }
        const focus = () => {
            if (this._legacyFocusDestroyed) {
                return;
            }
            this._legacyFocusCleanup?.();
            const cleanup = focusLegacyDialogInitially({
                element: this._elementRef.nativeElement,
                config: this._config,
                factory: this._focusTrapFactory,
                checker: this._legacyFocusChecker,
                renderer: this._legacyFocusRenderer || {
                    listen: (target, event, callback) => {
                        target.addEventListener(event, callback);
                        return () => target.removeEventListener(event, callback);
                    },
                },
                ngZone: this._ngZone,
                isBrowser: this._isBrowser(),
                isDestroyed: () => this._legacyFocusDestroyed,
                onFocusSettled: () => {
                    if (!this._legacyFocusDestroyed) {
                        this._legacyFocusNotifications.next();
                    }
                },
            });
            if (this._legacyFocusDestroyed) {
                cleanup?.();
            }
            else {
                this._legacyFocusCleanup = cleanup;
            }
        };
        if ((this._config.autoFocus === true || this._config.autoFocus === 'first-tabbable')
            && !this._ngZone.isStable) {
            this._legacyFocusStableSubscriptions.add(this._ngZone.onStable.pipe(take(1)).subscribe(focus));
        }
        else {
            focus();
        }
    }
    ngOnDestroy() {
        if (this._legacyFocusDestroyed) {
            return;
        }
        this._legacyFocusDestroyed = true;
        destroyLegacyDialogContainerState(this);
        try {
            this._legacyFocusStableSubscriptions.unsubscribe();
            this._restoreLegacyFocus();
        }
        finally {
            try {
                this._legacyBackdropSubscription?.unsubscribe();
            }
            finally {
                this._legacyBackdropSubscription = null;
                try {
                    this._legacyFocusTrap?.destroy();
                }
                finally {
                    this._legacyFocusTrap = null;
                    try {
                        this._legacyFocusCleanup?.();
                    }
                    finally {
                        this._legacyFocusCleanup = null;
                        this._legacyFocusNotifications.complete();
                    }
                }
            }
        }
    }
    _captureInitialFocus() {
        if (!this._config.delayFocusTrap) {
            this._trapFocus();
        }
    }
    _openAnimationDone(totalTime) {
        if (this._config.delayFocusTrap) {
            this._trapFocus();
        }
        this._animationStateChanged.next({ state: 'opened', totalTime });
    }
    _assertContentAvailable() {
        if (this._legacyFocusDestroyed) {
            throw Error('Attempting to attach dialog content after the container is destroyed');
        }
        if (this._portalOutlet.hasAttached()) {
            throw Error('Attempting to attach dialog content after content is already attached');
        }
    }
    _isBrowser() {
        return this._legacyFocusPlatform?.isBrowser ??
            (typeof document !== 'undefined' && !!document
                && typeof this._elementRef.nativeElement.focus === 'function');
    }
    _restoreLegacyFocus() {
        if (!this._isBrowser()) {
            return;
        }
        const config = this._config.restoreFocus;
        const target = typeof config === 'string' ? this._document.querySelector(config)
            : typeof config === 'boolean' ? config ? this._legacyPreviousFocus : null : config;
        if (config && target && typeof target.focus === 'function') {
            const active = legacyDialogActiveElement();
            const element = this._elementRef.nativeElement;
            if (!active || active === this._document?.body || active === element || element.contains(active)) {
                if (this._legacyFocusMonitor) {
                    this._legacyFocusMonitor.focusVia(target, this._closeInteractionType);
                    this._closeInteractionType = null;
                }
                else {
                    target.focus();
                }
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _MatDialogContainerBase, deps: [{ token: i0.ElementRef }, { token: i1.FocusTrapFactory }, { token: DOCUMENT, optional: true }, { token: MatDialogConfig }, { token: i1.InteractivityChecker }, { token: i0.NgZone }, { token: i1$1.OverlayRef }, { token: i1.FocusMonitor }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: _MatDialogContainerBase, isStandalone: false, selector: "ng-component", host: { classAttribute: "cdk-dialog-container" }, viewQueries: [{ propertyName: "_portalOutlet", first: true, predicate: CdkPortalOutlet, descendants: true, static: true }], usesInheritance: true, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _MatDialogContainerBase, decorators: [{
            type: Component,
            args: [{
                    template: '',
                    standalone: false,
                    host: { 'class': 'cdk-dialog-container' },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusTrapFactory }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MatDialogConfig]
                }] }, { type: i1.InteractivityChecker }, { type: i0.NgZone }, { type: i1$1.OverlayRef }, { type: i1.FocusMonitor }], propDecorators: { _portalOutlet: [{
                type: ViewChild,
                args: [CdkPortalOutlet, { static: true }]
            }] } });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Duration defaults for legacy dialog open/close (CSS or recipe path).
 * Kept free of `@angular/animations` so the primary dialog entry can omit that peer.
 */
/**
 * Default parameters for the animation for backwards compatibility.
 * @docs-private
 */
const _defaultParams = {
    params: { enterAnimationDuration: '150ms', exitAnimationDuration: '75ms' },
};
/**
 * Alias used by the legacy dialog container template binding.
 * @docs-private
 * @deprecated Use `_defaultParams` instead.
 * @breaking-change 17.0.0
 */
const defaultParams = _defaultParams;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
class MatLegacyDialogConfig extends MatDialogConfig {
    /**
     * Whether the dialog should set `aria-modal`. Current Material defaults this
     * to false; the legacy dialog set it to true.
     */
    ariaModal = true;
    /** Max-width of the dialog. Current Material leaves this unset; legacy defaults to 80vw. */
    maxWidth = '80vw';
    /** Historical autofocus policy, including boolean values handled by the owned container. */
    autoFocus = 'first-tabbable';
    /** Duration of the enter animation. Has to be a valid CSS value (e.g. 100ms). */
    enterAnimationDuration = _defaultParams.params.enterAnimationDuration;
    /** Duration of the exit animation. Has to be a valid CSS value (e.g. 50ms). */
    exitAnimationDuration = _defaultParams.params.exitAnimationDuration;
}

/** Preserve manual construction; the owned policy still governs Angular views. */
function dialogAnimationsDisabled() {
    try {
        assertInInjectionContext(dialogAnimationsDisabled);
    }
    catch {
        // The original constructor could be called outside Angular. It had no
        // injected motion-mode argument, so manual construction starts enabled.
        return false;
    }
    return legacyAnimationsDisabled();
}
const OPEN_CLASS = 'mat-legacy-dialog-container-open';
const OPENING_CLASS = 'mat-legacy-dialog-container-opening';
const CLOSING_CLASS = 'mat-legacy-dialog-container-closing';
const NOOP_CLASS = '_mat-animation-noopable';
const ENTER_DURATION_VAR = '--mat-legacy-dialog-enter-duration';
const EXIT_DURATION_VAR = '--mat-legacy-dialog-exit-duration';
const DEFAULT_ENTER_MS = 150;
const DEFAULT_EXIT_MS = 75;
function parseCssTime(value) {
    if (value == null || value === '') {
        return null;
    }
    if (typeof value === 'number') {
        return value;
    }
    const trimmed = String(value).trim();
    if (trimmed.endsWith('ms')) {
        const n = parseFloat(trimmed);
        return Number.isFinite(n) ? n : null;
    }
    if (trimmed.endsWith('s')) {
        const n = parseFloat(trimmed);
        return Number.isFinite(n) ? n * 1000 : null;
    }
    const n = parseFloat(trimmed);
    return Number.isFinite(n) ? n : null;
}
/**
 * Internal component that wraps user-provided dialog content.
 * Animation is based on https://material.io/guidelines/motion/choreography.html.
 * @docs-private
 */
class MatLegacyDialogContainer extends _MatDialogContainerBase {
    _changeDetectorRef;
    _legacyAnimationsDisabled = dialogAnimationsDisabled();
    /** Whether CSS transitions should run (MATERIAL_ANIMATIONS / reduced-motion / Noop). */
    _animationsEnabled = !this._legacyAnimationsDisabled;
    _enterAnimationDuration = this._animationsEnabled
        ? parseCssTime(this._config.enterAnimationDuration) ??
            parseCssTime(defaultParams.params.enterAnimationDuration) ??
            DEFAULT_ENTER_MS
        : 0;
    _exitAnimationDuration = this._animationsEnabled
        ? parseCssTime(this._config.exitAnimationDuration) ??
            parseCssTime(defaultParams.params.exitAnimationDuration) ??
            DEFAULT_EXIT_MS
        : 0;
    _animationTimer = null;
    _animationFrame = null;
    _animationRevision = 0;
    _animationDestroyed = false;
    _animationCompleted = false;
    _hostElement = this._elementRef.nativeElement;
    /**
     * Animation phase string kept for historical specs that asserted the
     * engine trigger state. Mapped onto CSS enter/exit lifecycle.
     * @docs-private
     */
    _state = 'enter';
    constructor(elementRef, focusTrapFactory, document, dialogConfig, checker, ngZone, overlayRef, _changeDetectorRef, focusMonitor) {
        super(elementRef, focusTrapFactory, document, dialogConfig, checker, ngZone, overlayRef, focusMonitor);
        this._changeDetectorRef = _changeDetectorRef;
    }
    _contentAttached() {
        super._contentAttached();
        this._startOpenAnimation();
    }
    _startOpenAnimation() {
        if (this._animationDestroyed) {
            return;
        }
        this._cancelAnimationWork();
        this._animationCompleted = false;
        this._state = 'enter';
        const revision = this._animationRevision;
        this._animationStateChanged.emit({
            state: 'opening',
            totalTime: this._enterAnimationDuration,
        });
        // A synchronous opening observer can close or destroy the container.
        if (this._animationDestroyed || revision !== this._animationRevision) {
            return;
        }
        if (this._animationsEnabled) {
            this._hostElement.style.setProperty(ENTER_DURATION_VAR, `${this._enterAnimationDuration}ms`);
            this._hostElement.style.setProperty(EXIT_DURATION_VAR, `${this._exitAnimationDuration}ms`);
            this._requestAnimationFrame(() => {
                this._hostElement.classList.add(OPENING_CLASS, OPEN_CLASS);
            });
            this._waitForAnimationToComplete(this._enterAnimationDuration, this._finishDialogOpen);
        }
        else {
            this._hostElement.classList.add(OPEN_CLASS, NOOP_CLASS);
            Promise.resolve().then(() => this._finishDialogOpen(revision));
        }
    }
    /** Starts the dialog exit animation. */
    _startExitAnimation() {
        if (this._animationDestroyed || this._state === 'exit') {
            return;
        }
        this._cancelAnimationWork();
        this._animationCompleted = false;
        this._state = 'exit';
        const revision = this._animationRevision;
        this._changeDetectorRef.markForCheck();
        if (this._animationDestroyed || revision !== this._animationRevision) {
            return;
        }
        this._animationStateChanged.emit({
            state: 'closing',
            totalTime: this._exitAnimationDuration,
        });
        if (this._animationDestroyed || revision !== this._animationRevision) {
            return;
        }
        this._hostElement.classList.remove(OPEN_CLASS);
        if (this._animationsEnabled) {
            this._hostElement.style.setProperty(EXIT_DURATION_VAR, `${this._exitAnimationDuration}ms`);
            this._requestAnimationFrame(() => {
                this._hostElement.classList.add(CLOSING_CLASS);
            });
            this._waitForAnimationToComplete(this._exitAnimationDuration, this._finishDialogClose);
        }
        else {
            Promise.resolve().then(() => this._finishDialogClose(revision));
        }
    }
    _finishDialogOpen = (revision = this._animationRevision) => {
        if (revision !== this._animationRevision || this._animationDestroyed || this._state !== 'enter' || this._animationCompleted) {
            return;
        }
        this._animationCompleted = true;
        this._cancelAnimationWork();
        // A zero-duration timer can finish before the first animation frame.
        this._hostElement.classList.add(OPEN_CLASS);
        this._clearAnimationClasses();
        this._openAnimationDone(this._enterAnimationDuration);
    };
    _finishDialogClose = (revision = this._animationRevision) => {
        if (revision !== this._animationRevision || this._animationDestroyed || this._state !== 'exit' || this._animationCompleted) {
            return;
        }
        this._animationCompleted = true;
        this._cancelAnimationWork();
        this._clearAnimationClasses();
        this._animationStateChanged.emit({
            state: 'closed',
            totalTime: this._exitAnimationDuration,
        });
    };
    _clearAnimationClasses() {
        this._hostElement.classList.remove(OPENING_CLASS, CLOSING_CLASS);
    }
    _waitForAnimationToComplete(duration, callback) {
        if (this._animationTimer !== null) {
            clearTimeout(this._animationTimer);
        }
        const revision = this._animationRevision;
        this._animationTimer = setTimeout(() => {
            if (!this._animationDestroyed && revision === this._animationRevision) {
                this._animationTimer = null;
                callback();
            }
        }, duration);
    }
    _requestAnimationFrame(callback) {
        const revision = this._animationRevision;
        this._ngZone.runOutsideAngular(() => {
            if (typeof requestAnimationFrame === 'function') {
                this._animationFrame = requestAnimationFrame(() => {
                    if (!this._animationDestroyed && revision === this._animationRevision) {
                        this._animationFrame = null;
                        callback();
                    }
                });
            }
            else if (!this._animationDestroyed && revision === this._animationRevision) {
                callback();
            }
        });
    }
    _cancelAnimationWork() {
        this._animationRevision++;
        if (this._animationTimer !== null) {
            clearTimeout(this._animationTimer);
            this._animationTimer = null;
        }
        if (this._animationFrame !== null) {
            if (typeof cancelAnimationFrame === 'function') {
                cancelAnimationFrame(this._animationFrame);
            }
            this._animationFrame = null;
        }
    }
    ngOnDestroy() {
        this._animationDestroyed = true;
        // Cancel before focus restoration, which may throw in consumer code.
        this._cancelAnimationWork();
        super.ngOnDestroy();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogContainer, deps: [{ token: i0.ElementRef }, { token: i1.FocusTrapFactory }, { token: DOCUMENT, optional: true }, { token: MatLegacyDialogConfig }, { token: i1.InteractivityChecker }, { token: i0.NgZone }, { token: i1$1.OverlayRef }, { token: i0.ChangeDetectorRef }, { token: i1.FocusMonitor }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyDialogContainer, isStandalone: false, selector: "mat-dialog-container", host: { attributes: { "tabindex": "-1" }, properties: { "attr.aria-modal": "_config.ariaModal", "id": "_config.id", "attr.role": "_config.role", "attr.aria-labelledby": "_config.ariaLabel ? null : _ariaLabelledByQueue[0]", "attr.aria-label": "_config.ariaLabel", "attr.aria-describedby": "_config.ariaDescribedBy || null", "class._mat-animation-noopable": "!_animationsEnabled" }, classAttribute: "mat-dialog-container" }, usesInheritance: true, ngImport: i0, template: "<ng-template cdkPortalOutlet></ng-template>\n", styles: [".mat-dialog-container{display:block;padding:24px;border-radius:4px;box-sizing:border-box;overflow:auto;outline:0;width:100%;height:100%;min-height:inherit;max-height:inherit}.cdk-high-contrast-active .mat-dialog-container{outline:solid 1px}@media(forced-colors:active){.mat-dialog-container{outline:solid 1px}}.mat-dialog-content{display:block;margin:0 -24px;padding:0 24px;max-height:65vh;overflow:auto;-webkit-overflow-scrolling:touch}.mat-dialog-title{margin:0 0 20px;display:block}.mat-dialog-actions{padding:8px 0;display:flex;flex-wrap:wrap;min-height:52px;align-items:center;box-sizing:content-box;margin-bottom:-24px}.mat-dialog-actions.mat-dialog-actions-align-center,.mat-dialog-actions[align=center]{justify-content:center}.mat-dialog-actions.mat-dialog-actions-align-end,.mat-dialog-actions[align=end]{justify-content:flex-end}.mat-dialog-actions .mat-button-base+.mat-button-base,.mat-dialog-actions .mat-mdc-button-base+.mat-mdc-button-base{margin-left:8px}[dir=rtl] .mat-dialog-actions .mat-button-base+.mat-button-base,[dir=rtl] .mat-dialog-actions .mat-mdc-button-base+.mat-mdc-button-base{margin-left:0;margin-right:8px}.mat-dialog-container{opacity:0;transform:scale(.7);transition:opacity var(--mat-legacy-dialog-exit-duration, 75ms) cubic-bezier(.4,0,.2,1),transform var(--mat-legacy-dialog-enter-duration, .15s) cubic-bezier(0,0,.2,1)}.mat-dialog-container.mat-legacy-dialog-container-open,.mat-dialog-container.mat-legacy-dialog-container-opening{opacity:1;transform:none}.mat-dialog-container.mat-legacy-dialog-container-closing{opacity:0;transform:none}.mat-dialog-container._mat-animation-noopable{transition:none;opacity:1;transform:none}\n"], dependencies: [{ kind: "directive", type: i4.ɵɵCdkPortalOutlet, selector: "[cdkPortalOutlet]", inputs: ["cdkPortalOutlet"], outputs: ["attached"], exportAs: ["cdkPortalOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.Eager, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogContainer, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'mat-dialog-container', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.Eager, host: {
                        'class': 'mat-dialog-container',
                        'tabindex': '-1',
                        '[attr.aria-modal]': '_config.ariaModal',
                        '[id]': '_config.id',
                        '[attr.role]': '_config.role',
                        '[attr.aria-labelledby]': '_config.ariaLabel ? null : _ariaLabelledByQueue[0]',
                        '[attr.aria-label]': '_config.ariaLabel',
                        '[attr.aria-describedby]': '_config.ariaDescribedBy || null',
                        '[class._mat-animation-noopable]': '!_animationsEnabled',
                    }, template: "<ng-template cdkPortalOutlet></ng-template>\n", styles: [".mat-dialog-container{display:block;padding:24px;border-radius:4px;box-sizing:border-box;overflow:auto;outline:0;width:100%;height:100%;min-height:inherit;max-height:inherit}.cdk-high-contrast-active .mat-dialog-container{outline:solid 1px}@media(forced-colors:active){.mat-dialog-container{outline:solid 1px}}.mat-dialog-content{display:block;margin:0 -24px;padding:0 24px;max-height:65vh;overflow:auto;-webkit-overflow-scrolling:touch}.mat-dialog-title{margin:0 0 20px;display:block}.mat-dialog-actions{padding:8px 0;display:flex;flex-wrap:wrap;min-height:52px;align-items:center;box-sizing:content-box;margin-bottom:-24px}.mat-dialog-actions.mat-dialog-actions-align-center,.mat-dialog-actions[align=center]{justify-content:center}.mat-dialog-actions.mat-dialog-actions-align-end,.mat-dialog-actions[align=end]{justify-content:flex-end}.mat-dialog-actions .mat-button-base+.mat-button-base,.mat-dialog-actions .mat-mdc-button-base+.mat-mdc-button-base{margin-left:8px}[dir=rtl] .mat-dialog-actions .mat-button-base+.mat-button-base,[dir=rtl] .mat-dialog-actions .mat-mdc-button-base+.mat-mdc-button-base{margin-left:0;margin-right:8px}.mat-dialog-container{opacity:0;transform:scale(.7);transition:opacity var(--mat-legacy-dialog-exit-duration, 75ms) cubic-bezier(.4,0,.2,1),transform var(--mat-legacy-dialog-enter-duration, .15s) cubic-bezier(0,0,.2,1)}.mat-dialog-container.mat-legacy-dialog-container-open,.mat-dialog-container.mat-legacy-dialog-container-opening{opacity:1;transform:none}.mat-dialog-container.mat-legacy-dialog-container-closing{opacity:0;transform:none}.mat-dialog-container._mat-animation-noopable{transition:none;opacity:1;transform:none}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusTrapFactory }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: MatLegacyDialogConfig }, { type: i1.InteractivityChecker }, { type: i0.NgZone }, { type: i1$1.OverlayRef }, { type: i0.ChangeDetectorRef }, { type: i1.FocusMonitor }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatDialogBase` (removed from Angular Material 22).
 * Adapted to current CDK Dialog / Overlay peers without private Material 22 APIs.
 */
/** @docs-private */
function MAT_DIALOG_SCROLL_STRATEGY_FACTORY(overlay) {
    return () => overlay.scrollStrategies.block();
}
/**
 * Base class for dialog services. The base dialog service allows
 * for arbitrary dialog refs and dialog container components.
 */
class _MatDialogBase {
    _overlay;
    _defaultOptions;
    _parentDialog;
    _dialogRefConstructor;
    _dialogContainerType;
    _dialogDataToken;
    _openDialogsAtThisLevel = [];
    _afterAllClosedAtThisLevel = new Subject();
    _afterOpenedAtThisLevel = new Subject();
    _scrollStrategy;
    _idPrefix = 'mat-dialog-';
    _dialog;
    dialogConfigClass = MatDialogConfig;
    /** Keeps track of the currently-open dialogs. */
    get openDialogs() {
        return this._parentDialog ? this._parentDialog.openDialogs : this._openDialogsAtThisLevel;
    }
    /** Stream that emits when a dialog has been opened. */
    get afterOpened() {
        return this._parentDialog ? this._parentDialog.afterOpened : this._afterOpenedAtThisLevel;
    }
    _getAfterAllClosed() {
        const parent = this._parentDialog;
        return parent ? parent._getAfterAllClosed() : this._afterAllClosedAtThisLevel;
    }
    /**
     * Stream that emits when all open dialog have finished closing.
     * Will emit on subscribe if there are no open dialogs to begin with.
     */
    afterAllClosed = defer(() => this.openDialogs.length
        ? this._getAfterAllClosed()
        : this._getAfterAllClosed().pipe(startWith(undefined)));
    constructor(_overlay, injector, _defaultOptions, _parentDialog, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 15.0.0
     */
    _overlayContainer, scrollStrategy, _dialogRefConstructor, _dialogContainerType, _dialogDataToken, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 14.0.0
     */
    _animationMode) {
        this._overlay = _overlay;
        this._defaultOptions = _defaultOptions;
        this._parentDialog = _parentDialog;
        this._dialogRefConstructor = _dialogRefConstructor;
        this._dialogContainerType = _dialogContainerType;
        this._dialogDataToken = _dialogDataToken;
        this._scrollStrategy = scrollStrategy;
        this._dialog = injector.get(Dialog);
    }
    open(componentOrTemplateRef, config) {
        let dialogRef;
        const defaults = this._defaultOptions || new this.dialogConfigClass();
        if (!this._defaultOptions && this.dialogConfigClass === MatDialogConfig) {
            // Keep the historical defaults when using the current peer configuration class.
            defaults.ariaModal = true;
            defaults.maxWidth = '80vw';
        }
        config = { ...defaults, ...config };
        config.id = config.id || `${this._idPrefix}${uniqueId++}`;
        config.scrollStrategy = config.scrollStrategy || this._scrollStrategy();
        const cdkRef = this._dialog.open(componentOrTemplateRef, {
            ...config,
            positionStrategy: this._overlay.position().global().centerHorizontally().centerVertically(),
            // Disable closing since we need to sync it up to the animation ourselves.
            disableClose: true,
            closePredicate: undefined,
            // Disable closing on destroy, because this service cleans up its open dialogs as well.
            closeOnDestroy: false,
            // Disable closing on detachments so that we can sync up the animation.
            closeOnOverlayDetachments: false,
            container: {
                type: this._dialogContainerType,
                providers: () => [
                    { provide: this.dialogConfigClass, useValue: config },
                    { provide: MatDialogConfig, useValue: config },
                    { provide: DialogConfig, useValue: config },
                ],
            },
            templateContext: () => ({ dialogRef }),
            providers: (ref, cdkConfig, dialogContainer) => {
                dialogRef = new this._dialogRefConstructor(ref, config, dialogContainer);
                dialogRef.updatePosition(config?.position);
                return [
                    { provide: this._dialogContainerType, useValue: dialogContainer },
                    { provide: this._dialogDataToken, useValue: cdkConfig.data },
                    { provide: this._dialogRefConstructor, useValue: dialogRef },
                    // Prevent content from resolving the CDK DialogRef accidentally.
                    { provide: DialogRef, useValue: null },
                ];
            },
        });
        dialogRef.componentRef = cdkRef.componentRef ?? undefined;
        dialogRef.componentInstance = (cdkRef.componentInstance ?? undefined);
        this.openDialogs.push(dialogRef);
        this.afterOpened.next(dialogRef);
        dialogRef.afterClosed().subscribe(() => {
            const index = this.openDialogs.indexOf(dialogRef);
            if (index > -1) {
                this.openDialogs.splice(index, 1);
                if (!this.openDialogs.length) {
                    this._getAfterAllClosed().next();
                }
            }
        });
        return dialogRef;
    }
    /** Closes all of the currently-open dialogs. */
    closeAll() {
        this._closeDialogs(this.openDialogs);
    }
    /**
     * Finds an open dialog by its id.
     * @param id ID to use when looking up the dialog.
     */
    getDialogById(id) {
        return this.openDialogs.find(dialog => dialog.id === id);
    }
    ngOnDestroy() {
        this._closeDialogs(this._openDialogsAtThisLevel);
        this._afterAllClosedAtThisLevel.complete();
        this._afterOpenedAtThisLevel.complete();
    }
    _closeDialogs(dialogs) {
        let i = dialogs.length;
        while (i--) {
            dialogs[i].close();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _MatDialogBase, deps: "invalid", target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _MatDialogBase });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _MatDialogBase, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.Overlay }, { type: i0.Injector }, { type: undefined }, { type: undefined }, { type: i1$1.OverlayContainer }, { type: undefined }, { type: i0.Type }, { type: i0.Type }, { type: i0.InjectionToken }, { type: undefined }] });
// Counter for unique dialog ids.
let uniqueId = 0;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 dialog ref adapted for Angular 22 peers. Uses shared
 * `MatDialogState` / `DialogPosition` from `@angular/material/dialog`.
 */
/**
 * Reference to a dialog opened via the MatDialog service.
 */
class MatLegacyDialogRef {
    _ref;
    _containerInstance;
    /** The instance of component opened into the dialog. */
    componentInstance;
    /**
     * `ComponentRef` of the component opened into the dialog. Will be
     * undefined when the dialog is opened using a `TemplateRef`.
     */
    componentRef;
    /** Whether the user is allowed to close the dialog. */
    disableClose;
    /** Unique ID for the dialog. */
    id;
    /** Subject for notifying the user that the dialog has finished opening. */
    _afterOpened = new Subject();
    /** Subject for notifying the user that the dialog has started closing. */
    _beforeClosed = new Subject();
    /** Result to be passed to afterClosed. */
    _result;
    /** Handle to the timeout that's running as a fallback in case the exit animation doesn't fire. */
    _closeFallbackTimeout = null;
    /** Subscriptions owned by this ref, including the pending animation phases. */
    _subscriptions = new Subscription();
    /** Prevent synchronous close observers from notifying beforeClosed twice. */
    _beforeClosedEmitted = false;
    /** Current state of the dialog. */
    _state = MatDialogState.OPEN;
    /** Interaction that caused the dialog to close. */
    _closeInteractionType;
    constructor(_ref, config, _containerInstance) {
        this._ref = _ref;
        this._containerInstance = _containerInstance;
        registerLegacyDialogContainerPeer(_containerInstance, _ref);
        this.disableClose = config.disableClose;
        this.id = _ref.id;
        this._subscriptions.add(_containerInstance._animationStateChanged
            .pipe(filter(event => event.state === 'opened'), take(1))
            .subscribe(() => {
            if (this._state === MatDialogState.OPEN) {
                this._afterOpened.next();
                this._afterOpened.complete();
            }
        }));
        this._subscriptions.add(_containerInstance._animationStateChanged
            .pipe(filter(event => event.state === 'closed'), take(1))
            .subscribe(() => this._finishDialogClose()));
        this._subscriptions.add(_ref.overlayRef.detachments().subscribe(() => {
            if (this._state === MatDialogState.CLOSED) {
                return;
            }
            this._state = MatDialogState.CLOSING;
            this._afterOpened.complete();
            this._notifyBeforeClosed();
            this._finishDialogClose();
        }));
        this._subscriptions.add(merge(this.backdropClick(), this.keydownEvents().pipe(filter(event => event.keyCode === ESCAPE && !this.disableClose && !hasModifierKey(event)))).subscribe(event => {
            if (!this.disableClose) {
                event.preventDefault();
                _closeDialogVia(this, event.type === 'keydown' ? 'keyboard' : 'mouse');
            }
        }));
    }
    /** Close the dialog. */
    close(dialogResult) {
        if (this._state !== MatDialogState.OPEN) {
            return;
        }
        this._result = dialogResult;
        this._state = MatDialogState.CLOSING;
        this._afterOpened.complete();
        // A completion observer can detach the overlay synchronously.
        if (this._state !== MatDialogState.CLOSING) {
            return;
        }
        this._subscriptions.add(this._containerInstance._animationStateChanged
            .pipe(filter(event => event.state === 'closing'), take(1))
            .subscribe(event => {
            this._notifyBeforeClosed();
            if (this._state !== MatDialogState.CLOSING) {
                return;
            }
            this._ref.overlayRef.detachBackdrop();
            this._scheduleCloseFallback(event.totalTime);
        }));
        try {
            this._containerInstance._startExitAnimation();
        }
        finally {
            // A destroyed view or a throwing detector can prevent the closing event.
            // Preserve its error while still releasing this ref after the usual margin.
            if (this._state === MatDialogState.CLOSING && this._closeFallbackTimeout === null) {
                this._notifyBeforeClosed();
                if (this._state === MatDialogState.CLOSING) {
                    this._ref.overlayRef.detachBackdrop();
                }
                this._scheduleCloseFallback(0);
            }
        }
    }
    /** Gets an observable that is notified when the dialog is finished opening. */
    afterOpened() {
        return this._afterOpened;
    }
    /** Gets an observable that is notified when the dialog is finished closing. */
    afterClosed() {
        return this._ref.closed;
    }
    /** Gets an observable that is notified when the dialog has started closing. */
    beforeClosed() {
        return this._beforeClosed;
    }
    /** Gets an observable that emits when the overlay's backdrop has been clicked. */
    backdropClick() {
        return this._ref.backdropClick;
    }
    /** Gets an observable that emits when keydown events are targeted on the overlay. */
    keydownEvents() {
        return this._ref.keydownEvents;
    }
    /** Updates the dialog's position. */
    updatePosition(position) {
        let strategy = this._ref.config.positionStrategy;
        if (position && (position.left || position.right)) {
            position.left ? strategy.left(position.left) : strategy.right(position.right);
        }
        else {
            strategy.centerHorizontally();
        }
        if (position && (position.top || position.bottom)) {
            position.top ? strategy.top(position.top) : strategy.bottom(position.bottom);
        }
        else {
            strategy.centerVertically();
        }
        this._ref.updatePosition();
        return this;
    }
    /** Updates the dialog's width and height. */
    updateSize(width = '', height = '') {
        this._ref.updateSize(width, height);
        return this;
    }
    /** Add a CSS class or an array of classes to the overlay pane. */
    addPanelClass(classes) {
        this._ref.addPanelClass(classes);
        return this;
    }
    /** Remove a CSS class or an array of classes from the overlay pane. */
    removePanelClass(classes) {
        this._ref.removePanelClass(classes);
        return this;
    }
    /** Gets the current state of the dialog's lifecycle. */
    getState() {
        return this._state;
    }
    _notifyBeforeClosed() {
        if (!this._beforeClosedEmitted) {
            this._beforeClosedEmitted = true;
            this._beforeClosed.next(this._result);
            this._beforeClosed.complete();
        }
    }
    _scheduleCloseFallback(totalTime) {
        if (this._state !== MatDialogState.CLOSING) {
            return;
        }
        if (this._closeFallbackTimeout !== null) {
            clearTimeout(this._closeFallbackTimeout);
        }
        this._closeFallbackTimeout = setTimeout(() => this._finishDialogClose(), totalTime + 100);
    }
    _finishDialogClose() {
        if (this._state === MatDialogState.CLOSED) {
            return;
        }
        if (!this._beforeClosedEmitted) {
            this._state = MatDialogState.CLOSING;
            this._notifyBeforeClosed();
            if (this._state !== MatDialogState.CLOSING) {
                return;
            }
        }
        this._state = MatDialogState.CLOSED;
        if (this._closeFallbackTimeout !== null) {
            clearTimeout(this._closeFallbackTimeout);
            this._closeFallbackTimeout = null;
        }
        this._subscriptions.unsubscribe();
        this._afterOpened.complete();
        try {
            this._ref.close(this._result, { focusOrigin: this._closeInteractionType });
        }
        finally {
            // Keep the instance available while the public CDK ref dispatches afterClosed.
            this.componentInstance = null;
        }
    }
}
/**
 * Closes the dialog with the specified interaction type.
 * @docs-private
 */
function _closeDialogVia(ref, interactionType, result) {
    if (ref.getState() !== MatDialogState.OPEN) {
        return;
    }
    ref._closeInteractionType = interactionType;
    return ref.close(result);
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Injection token that can be used to access the data that was passed in to a dialog.
 */
const MAT_LEGACY_DIALOG_DATA = new InjectionToken('MatDialogData');
/**
 * Injection token that can be used to specify default dialog options.
 */
const MAT_LEGACY_DIALOG_DEFAULT_OPTIONS = new InjectionToken('mat-dialog-default-options');
/**
 * Injection token that determines the scroll handling while the dialog is open.
 */
const MAT_LEGACY_DIALOG_SCROLL_STRATEGY = new InjectionToken('mat-dialog-scroll-strategy');
/**
 * @docs-private
 */
function MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY(overlay) {
    return () => overlay.scrollStrategies.block();
}
/**
 * @docs-private
 */
const MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER = {
    provide: MAT_LEGACY_DIALOG_SCROLL_STRATEGY,
    deps: [Overlay],
    useFactory: MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY,
};
/**
 * Service to open Material Design modal dialogs.
 */
class MatLegacyDialog extends _MatDialogBase {
    dialogConfigClass = MatLegacyDialogConfig;
    constructor(overlay, injector, 
    /**
     * @deprecated `_location` parameter to be removed.
     * @breaking-change 10.0.0
     */
    _location, defaultOptions, scrollStrategy, parentDialog, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 15.0.0
     */
    overlayContainer, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 14.0.0
     */
    animationMode) {
        super(overlay, injector, defaultOptions, parentDialog, overlayContainer, scrollStrategy, MatLegacyDialogRef, MatLegacyDialogContainer, MAT_LEGACY_DIALOG_DATA, animationMode);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialog, deps: [{ token: i1$1.Overlay }, { token: i0.Injector }, { token: i2.Location, optional: true }, { token: MAT_LEGACY_DIALOG_DEFAULT_OPTIONS, optional: true }, { token: MAT_LEGACY_DIALOG_SCROLL_STRATEGY }, { token: MatLegacyDialog, optional: true, skipSelf: true }, { token: i1$1.OverlayContainer }, { token: ANIMATION_MODULE_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialog });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialog, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.Overlay }, { type: i0.Injector }, { type: i2.Location, decorators: [{
                    type: Optional
                }] }, { type: MatLegacyDialogConfig, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [MAT_LEGACY_DIALOG_DEFAULT_OPTIONS]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_LEGACY_DIALOG_SCROLL_STRATEGY]
                }] }, { type: MatLegacyDialog, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1$1.OverlayContainer }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ANIMATION_MODULE_TYPE]
                }] }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** Counter used to generate unique IDs for dialog elements. */
let dialogElementUid = 0;
/**
 * Button that will close the current dialog.
 */
class MatLegacyDialogClose {
    dialogRef;
    _elementRef;
    _dialog;
    /** Screen reader label for the button. */
    ariaLabel;
    /** Default to "button" to prevents accidental form submits. */
    type = 'button';
    /** Dialog close input. */
    dialogResult;
    _matDialogClose;
    constructor(
    /**
     * Reference to the containing dialog.
     * @deprecated `dialogRef` property to become private.
     * @breaking-change 13.0.0
     */
    // The dialog title directive is always used in combination with a `MatDialogRef`.
    // tslint:disable-next-line: lightweight-tokens
    dialogRef, _elementRef, _dialog) {
        this.dialogRef = dialogRef;
        this._elementRef = _elementRef;
        this._dialog = _dialog;
    }
    ngOnInit() {
        if (!this.dialogRef) {
            // When this directive is included in a dialog via TemplateRef (rather than being
            // in a Component), the DialogRef isn't available via injection because embedded
            // views cannot be given a custom injector. Instead, we look up the DialogRef by
            // ID. This must occur in `onInit`, as the ID binding for the dialog container won't
            // be resolved at constructor time.
            this.dialogRef = getClosestDialog(this._elementRef, this._dialog.openDialogs);
        }
    }
    ngOnChanges(changes) {
        const proxiedChange = changes['_matDialogClose'] || changes['_matDialogCloseResult'];
        if (proxiedChange) {
            this.dialogResult = proxiedChange.currentValue;
        }
    }
    _onButtonClick(event) {
        // Determinate the focus origin using the click event, because using the FocusMonitor will
        // result in incorrect origins. Most of the time, close buttons will be auto focused in the
        // dialog, and therefore clicking the button won't result in a focus change. This means that
        // the FocusMonitor won't detect any origin change, and will always output `program`.
        _closeDialogVia(this.dialogRef, event.screenX === 0 && event.screenY === 0 ? 'keyboard' : 'mouse', this.dialogResult);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogClose, deps: [{ token: MatLegacyDialogRef, optional: true }, { token: i0.ElementRef }, { token: MatLegacyDialog }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyDialogClose, isStandalone: false, selector: "[mat-dialog-close], [matDialogClose]", inputs: { ariaLabel: ["aria-label", "ariaLabel"], type: "type", dialogResult: ["mat-dialog-close", "dialogResult"], _matDialogClose: ["matDialogClose", "_matDialogClose"] }, host: { listeners: { "click": "_onButtonClick($event)" }, properties: { "attr.aria-label": "ariaLabel || null", "attr.type": "type" } }, exportAs: ["matDialogClose"], usesOnChanges: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogClose, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[mat-dialog-close], [matDialogClose]',
                    exportAs: 'matDialogClose',
                    host: {
                        '(click)': '_onButtonClick($event)',
                        '[attr.aria-label]': 'ariaLabel || null',
                        '[attr.type]': 'type',
                    },
                }]
        }], ctorParameters: () => [{ type: MatLegacyDialogRef, decorators: [{
                    type: Optional
                }] }, { type: i0.ElementRef }, { type: MatLegacyDialog }], propDecorators: { ariaLabel: [{
                type: Input,
                args: ['aria-label']
            }], type: [{
                type: Input
            }], dialogResult: [{
                type: Input,
                args: ['mat-dialog-close']
            }], _matDialogClose: [{
                type: Input,
                args: ['matDialogClose']
            }] } });
/**
 * Title of a dialog element. Stays fixed to the top of the dialog when scrolling.
 */
class MatLegacyDialogTitle {
    _dialogRef;
    _elementRef;
    _dialog;
    /** Unique id for the dialog title. If none is supplied, it will be auto-generated. */
    id = `mat-dialog-title-${dialogElementUid++}`;
    constructor(
    // The dialog title directive is always used in combination with a `MatDialogRef`.
    // tslint:disable-next-line: lightweight-tokens
    _dialogRef, _elementRef, _dialog) {
        this._dialogRef = _dialogRef;
        this._elementRef = _elementRef;
        this._dialog = _dialog;
    }
    ngOnInit() {
        if (!this._dialogRef) {
            this._dialogRef = getClosestDialog(this._elementRef, this._dialog.openDialogs);
        }
        if (this._dialogRef) {
            Promise.resolve().then(() => {
                // Use markForCheck-aware helpers so titles work under OnPush view containers.
                const container = this._dialogRef._containerInstance;
                if (container) {
                    addLegacyDialogTitle(container, this.id);
                }
            });
        }
    }
    ngOnDestroy() {
        // Note: we null check because there are some internal
        // tests that are mocking out `MatDialogRef` incorrectly.
        const instance = this._dialogRef?._containerInstance;
        if (instance) {
            Promise.resolve().then(() => {
                removeLegacyDialogTitle(instance, this.id);
            });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogTitle, deps: [{ token: MatLegacyDialogRef, optional: true }, { token: i0.ElementRef }, { token: MatLegacyDialog }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyDialogTitle, isStandalone: false, selector: "[mat-dialog-title], [matDialogTitle]", inputs: { id: "id" }, host: { properties: { "id": "id" }, classAttribute: "mat-dialog-title" }, exportAs: ["matDialogTitle"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogTitle, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[mat-dialog-title], [matDialogTitle]',
                    exportAs: 'matDialogTitle',
                    host: {
                        'class': 'mat-dialog-title',
                        '[id]': 'id',
                    },
                }]
        }], ctorParameters: () => [{ type: MatLegacyDialogRef, decorators: [{
                    type: Optional
                }] }, { type: i0.ElementRef }, { type: MatLegacyDialog }], propDecorators: { id: [{
                type: Input
            }] } });
/**
 * Scrollable content container of a dialog.
 */
class MatLegacyDialogContent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogContent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyDialogContent, isStandalone: false, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]", host: { classAttribute: "mat-dialog-content" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogContent, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: `[mat-dialog-content], mat-dialog-content, [matDialogContent]`,
                    host: { 'class': 'mat-dialog-content' },
                }]
        }] });
/**
 * Container for the bottom action buttons in a dialog.
 * Stays fixed to the bottom when scrolling.
 */
class MatLegacyDialogActions {
    /**
     * Horizontal alignment of action buttons.
     */
    align = 'start';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogActions, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyDialogActions, isStandalone: false, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: { align: "align" }, host: { properties: { "class.mat-dialog-actions-align-center": "align === \"center\"", "class.mat-dialog-actions-align-end": "align === \"end\"" }, classAttribute: "mat-dialog-actions" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogActions, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: `[mat-dialog-actions], mat-dialog-actions, [matDialogActions]`,
                    host: {
                        'class': 'mat-dialog-actions',
                        '[class.mat-dialog-actions-align-center]': 'align === "center"',
                        '[class.mat-dialog-actions-align-end]': 'align === "end"',
                    },
                }]
        }], propDecorators: { align: [{
                type: Input
            }] } });
// TODO(crisbeto): this utility shouldn't be necessary anymore, because the dialog ref is provided
// both to component and template dialogs through DI. We need to keep it around, because there are
// some internal wrappers around `MatDialog` that happened to work by accident, because we had this
// fallback logic in place.
/**
 * Finds the closest MatDialogRef to an element by looking at the DOM.
 * @param element Element relative to which to look for a dialog.
 * @param openDialogs References to the currently-open dialogs.
 */
function getClosestDialog(element, openDialogs) {
    let parent = element.nativeElement.parentElement;
    while (parent && !parent.classList.contains('mat-dialog-container')) {
        parent = parent.parentElement;
    }
    return parent ? openDialogs.find(dialog => dialog.id === parent.id) : null;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
class MatLegacyDialogModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogModule, declarations: [MatLegacyDialogContainer,
            MatLegacyDialogClose,
            MatLegacyDialogTitle,
            MatLegacyDialogActions,
            MatLegacyDialogContent], imports: [DialogModule, OverlayModule, PortalModule, MatCommonModule], exports: [MatLegacyDialogContainer,
            MatLegacyDialogClose,
            MatLegacyDialogTitle,
            MatLegacyDialogContent,
            MatLegacyDialogActions,
            MatCommonModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogModule, providers: [MatLegacyDialog, MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER], imports: [DialogModule, OverlayModule, PortalModule, MatCommonModule, MatCommonModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyDialogModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [DialogModule, OverlayModule, PortalModule, MatCommonModule],
                    exports: [
                        MatLegacyDialogContainer,
                        MatLegacyDialogClose,
                        MatLegacyDialogTitle,
                        MatLegacyDialogContent,
                        MatLegacyDialogActions,
                        MatCommonModule,
                    ],
                    declarations: [
                        MatLegacyDialogContainer,
                        MatLegacyDialogClose,
                        MatLegacyDialogTitle,
                        MatLegacyDialogActions,
                        MatLegacyDialogContent,
                    ],
                    providers: [MatLegacyDialog, MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER],
                }]
        }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MAT_LEGACY_DIALOG_DATA, MAT_LEGACY_DIALOG_DEFAULT_OPTIONS, MAT_LEGACY_DIALOG_SCROLL_STRATEGY, MAT_DIALOG_SCROLL_STRATEGY_FACTORY as MAT_LEGACY_DIALOG_SCROLL_STRATEGY_FACTORY, MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER, MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY, MatCommonModule, MatLegacyDialog, MatLegacyDialogActions, MatLegacyDialogClose, MatLegacyDialogConfig, MatLegacyDialogContainer, MatLegacyDialogContent, MatLegacyDialogModule, MatLegacyDialogRef, MatLegacyDialogTitle, _MatDialogBase as _MatLegacyDialogBase, _MatDialogContainerBase as _MatLegacyDialogContainerBase, _closeDialogVia as _closeLegacyDialogVia, _defaultParams, defaultParams };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-dialog.mjs.map
