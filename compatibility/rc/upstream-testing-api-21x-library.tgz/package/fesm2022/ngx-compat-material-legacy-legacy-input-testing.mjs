import { HarnessPredicate } from '@angular/cdk/testing';
import { MatInputHarness } from '@angular/material/input/testing';
export { MatNativeOptionHarness as MatLegacyNativeOptionHarness, MatNativeSelectHarness as MatLegacyNativeSelectHarness } from '@angular/material/input/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** Harness for a legacy native input or textarea. */
class MatLegacyInputHarness extends MatInputHarness {
    static hostSelector = MatInputHarness.hostSelector;
    /** Keeps predicates bound to the legacy harness's native-property behavior. */
    static with(options = {}) {
        return new HarnessPredicate(MatLegacyInputHarness, options)
            .addOption('value', options.value, (harness, value) => HarnessPredicate.stringMatches(harness.getValue(), value))
            .addOption('placeholder', options.placeholder, (harness, placeholder) => HarnessPredicate.stringMatches(harness.getPlaceholder(), placeholder))
            .addOption('label', options.label, (harness, label) => HarnessPredicate.stringMatches(harness.getLabel(), label));
    }
    /** Reads the native property, as the Material 16 legacy alias did. */
    async isDisabled() {
        return (await this.host()).getProperty('disabled');
    }
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MatLegacyInputHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-input-testing.mjs.map
