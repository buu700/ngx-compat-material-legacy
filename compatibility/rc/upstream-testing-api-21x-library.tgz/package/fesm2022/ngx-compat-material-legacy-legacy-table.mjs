import * as i0 from '@angular/core';
import { Injector, inject, runInInjectionContext, Input, Directive, assertInInjectionContext, ChangeDetectionStrategy, ViewEncapsulation, Component, Optional, Inject, TemplateRef, ElementRef, IterableDiffers, NgModule, Self } from '@angular/core';
import { __decorate } from 'tslib';
import * as i1 from '@angular/cdk/table';
import { CdkTable, STICKY_POSITIONING_LISTENER, CdkColumnDef, CdkCellDef, CdkHeaderCellDef, CdkFooterCellDef, CdkHeaderCell, CdkFooterCell, CdkCell, CdkHeaderRowDef, CdkFooterRowDef, CdkRowDef, CdkHeaderRow, CDK_ROW_TEMPLATE, CdkFooterRow, CdkRow, CdkNoDataRow, CdkTextColumn, TEXT_COLUMN_OPTIONS, CdkTableModule } from '@angular/cdk/table';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { CDK_VIRTUAL_SCROLL_VIEWPORT } from '@angular/cdk/scrolling';
import { BidiModule } from '@angular/cdk/bidi';
import { BehaviorSubject, Subject, merge, of, combineLatest } from 'rxjs';
import { DataSource } from '@angular/cdk/collections';
import { legacyIsNumberValue } from '@ngx-compat/material-legacy/legacy-core';
import { map } from 'rxjs/operators';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** Borrow the node injector without enabling the current table's automatic virtualization. */
class LegacyTableConstructorInjector extends Injector {
    parent;
    constructor(parent) {
        super();
        this.parent = parent;
    }
    get(token, notFoundValue, options) {
        return token === CDK_VIRTUAL_SCROLL_VIEWPORT ? null : this.parent.get(token, notFoundValue, options);
    }
}
/**
 * Material 16 tables rendered their complete data inside an ancestor viewport.
 * Hide the public viewport token only while constructing the current CDK parent.
 * A node/view provider would also hide it from consumer cell templates.
 *
 * Wrap the constructor's `super` target, keeping the instance prototype, public
 * parent and Angular metadata intact. Reflect.construct preserves new.target and
 * normal derived field initialization. The original injector remains available
 * to the table, its descendants and consumer subclasses after super() returns.
 */
function preserveLegacyTableViewport(table) {
    Object.setPrototypeOf(table, new Proxy(CdkTable, {
        construct(parent, args, newTarget) {
            const injector = new LegacyTableConstructorInjector(inject(Injector));
            return runInInjectionContext(injector, () => Reflect.construct(parent, args, newTarget));
        },
    }));
}

/** Supplies the parent's public outlet protocol without a peer-private token. */
class _LegacyTableOutlet {
    table;
    viewContainer;
    elementRef;
    kind;
    constructor(table, viewContainer, elementRef) {
        this.table = table;
        this.viewContainer = viewContainer;
        this.elementRef = elementRef;
    }
    ngOnInit() {
        switch (this.kind) {
            case 'header':
                this.table._headerRowOutlet = this;
                break;
            case 'data':
                this.table._rowOutlet = this;
                break;
            case 'footer':
                this.table._footerRowOutlet = this;
                break;
            case 'empty':
                this.table._noDataRowOutlet = this;
                break;
            default: throw new Error('Unknown legacy table outlet.');
        }
        this.table._outletAssigned();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _LegacyTableOutlet, deps: [{ token: i1.CdkTable }, { token: i0.ViewContainerRef }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: _LegacyTableOutlet, isStandalone: false, selector: "[legacyTableOutlet]", inputs: { kind: ["legacyTableOutlet", "kind"] }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _LegacyTableOutlet, decorators: [{
            type: Directive,
            args: [{ standalone: false, selector: '[legacyTableOutlet]' }]
        }], ctorParameters: () => [{ type: i1.CdkTable }, { type: i0.ViewContainerRef }, { type: i0.ElementRef }], propDecorators: { kind: [{
                type: Input,
                args: ['legacyTableOutlet']
            }] } });

var MatLegacyTable_1;
/**
 * Enables the recycle view repeater strategy, which reduces rendering latency. Not compatible with
 * tables that animate rows.
 */
class MatLegacyRecycleRows {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyRecycleRows, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyRecycleRows, isStandalone: false, selector: "mat-table[recycleRows], table[mat-table][recycleRows]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyRecycleRows, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: 'mat-table[recycleRows], table[mat-table][recycleRows]',
                }]
        }] });
/**
 * Wrapper for the CdkTable with Material design styles.
 */
let MatLegacyTable = class MatLegacyTable extends CdkTable {
    static { MatLegacyTable_1 = this; }
    /** Construct through Angular node DI; manual dependency arguments are unsupported. */
    constructor() {
        if (arguments.length)
            throw new Error('MatLegacyTable manual dependency arguments are not supported.');
        assertInInjectionContext(MatLegacyTable_1);
        super();
    }
    /** Preserve original coercion for direct writes as well as template inputs. */
    get fixedLayout() { return super.fixedLayout; }
    set fixedLayout(value) {
        super.fixedLayout = coerceBooleanProperty(value);
    }
    get multiTemplateDataRows() { return super.multiTemplateDataRows; }
    set multiTemplateDataRows(value) {
        super.multiTemplateDataRows = coerceBooleanProperty(value);
    }
    /** Overrides the sticky CSS class set by the `CdkTable`. */
    stickyCssClass = 'mat-table-sticky';
    /** Overrides the need to add position: sticky on every sticky cell element in `CdkTable`. */
    needsPositionStickyOnElement = false;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyTable, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: MatLegacyTable, isStandalone: false, selector: "mat-table, table[mat-table]", host: { attributes: { "ngSkipHydration": "" }, properties: { "class.mat-table-fixed-layout": "fixedLayout" }, classAttribute: "mat-table" }, providers: [
            { provide: CdkTable, useExisting: MatLegacyTable },
            { provide: STICKY_POSITIONING_LISTENER, useValue: null },
        ], exportAs: ["matTable"], usesInheritance: true, ngImport: i0, template: `
    <ng-content select="caption"></ng-content>
    <ng-content select="colgroup, col"></ng-content>

    @if (_isServer) {
      <ng-content></ng-content>
    }

    @if (_isNativeHtmlTable) {
      <thead role="rowgroup">
        <ng-container legacyTableOutlet="header"></ng-container>
      </thead>
      <tbody role="rowgroup">
        <ng-container legacyTableOutlet="data"></ng-container>
        <ng-container legacyTableOutlet="empty"></ng-container>
      </tbody>
      <tfoot role="rowgroup">
        <ng-container legacyTableOutlet="footer"></ng-container>
      </tfoot>
    } @else {
      <ng-container legacyTableOutlet="header"></ng-container>
      <ng-container legacyTableOutlet="data"></ng-container>
      <ng-container legacyTableOutlet="empty"></ng-container>
      <ng-container legacyTableOutlet="footer"></ng-container>
    }
  `, isInline: true, styles: ["mat-table{display:block}mat-header-row{min-height:56px}mat-row,mat-footer-row{min-height:48px}mat-row,mat-header-row,mat-footer-row{display:flex;border-width:0;border-bottom-width:1px;border-style:solid;align-items:center;box-sizing:border-box}mat-cell:first-of-type,mat-header-cell:first-of-type,mat-footer-cell:first-of-type{padding-left:24px}[dir=rtl] mat-cell:first-of-type:not(:only-of-type),[dir=rtl] mat-header-cell:first-of-type:not(:only-of-type),[dir=rtl] mat-footer-cell:first-of-type:not(:only-of-type){padding-left:0;padding-right:24px}mat-cell:last-of-type,mat-header-cell:last-of-type,mat-footer-cell:last-of-type{padding-right:24px}[dir=rtl] mat-cell:last-of-type:not(:only-of-type),[dir=rtl] mat-header-cell:last-of-type:not(:only-of-type),[dir=rtl] mat-footer-cell:last-of-type:not(:only-of-type){padding-right:0;padding-left:24px}mat-cell,mat-header-cell,mat-footer-cell{flex:1;display:flex;align-items:center;overflow:hidden;word-wrap:break-word;min-height:inherit}table.mat-table{border-spacing:0}tr.mat-header-row{height:56px}tr.mat-row,tr.mat-footer-row{height:48px}th.mat-header-cell{text-align:left}[dir=rtl] th.mat-header-cell{text-align:right}th.mat-header-cell,td.mat-cell,td.mat-footer-cell{padding:0;border-bottom-width:1px;border-bottom-style:solid}th.mat-header-cell:first-of-type,td.mat-cell:first-of-type,td.mat-footer-cell:first-of-type{padding-left:24px}[dir=rtl] th.mat-header-cell:first-of-type:not(:only-of-type),[dir=rtl] td.mat-cell:first-of-type:not(:only-of-type),[dir=rtl] td.mat-footer-cell:first-of-type:not(:only-of-type){padding-left:0;padding-right:24px}th.mat-header-cell:last-of-type,td.mat-cell:last-of-type,td.mat-footer-cell:last-of-type{padding-right:24px}[dir=rtl] th.mat-header-cell:last-of-type:not(:only-of-type),[dir=rtl] td.mat-cell:last-of-type:not(:only-of-type),[dir=rtl] td.mat-footer-cell:last-of-type:not(:only-of-type){padding-right:0;padding-left:24px}.mat-table-sticky{position:sticky!important}.mat-table-fixed-layout{table-layout:fixed}\n"], dependencies: [{ kind: "directive", type: _LegacyTableOutlet, selector: "[legacyTableOutlet]", inputs: ["legacyTableOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.Eager, encapsulation: i0.ViewEncapsulation.None });
};
MatLegacyTable = MatLegacyTable_1 = __decorate([
    preserveLegacyTableViewport
], MatLegacyTable);
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyTable, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'mat-table, table[mat-table]', exportAs: 'matTable', template: `
    <ng-content select="caption"></ng-content>
    <ng-content select="colgroup, col"></ng-content>

    @if (_isServer) {
      <ng-content></ng-content>
    }

    @if (_isNativeHtmlTable) {
      <thead role="rowgroup">
        <ng-container legacyTableOutlet="header"></ng-container>
      </thead>
      <tbody role="rowgroup">
        <ng-container legacyTableOutlet="data"></ng-container>
        <ng-container legacyTableOutlet="empty"></ng-container>
      </tbody>
      <tfoot role="rowgroup">
        <ng-container legacyTableOutlet="footer"></ng-container>
      </tfoot>
    } @else {
      <ng-container legacyTableOutlet="header"></ng-container>
      <ng-container legacyTableOutlet="data"></ng-container>
      <ng-container legacyTableOutlet="empty"></ng-container>
      <ng-container legacyTableOutlet="footer"></ng-container>
    }
  `, host: {
                        'class': 'mat-table',
                        '[class.mat-table-fixed-layout]': 'fixedLayout',
                        'ngSkipHydration': '',
                    }, providers: [
                        { provide: CdkTable, useExisting: MatLegacyTable },
                        { provide: STICKY_POSITIONING_LISTENER, useValue: null },
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.Eager, styles: ["mat-table{display:block}mat-header-row{min-height:56px}mat-row,mat-footer-row{min-height:48px}mat-row,mat-header-row,mat-footer-row{display:flex;border-width:0;border-bottom-width:1px;border-style:solid;align-items:center;box-sizing:border-box}mat-cell:first-of-type,mat-header-cell:first-of-type,mat-footer-cell:first-of-type{padding-left:24px}[dir=rtl] mat-cell:first-of-type:not(:only-of-type),[dir=rtl] mat-header-cell:first-of-type:not(:only-of-type),[dir=rtl] mat-footer-cell:first-of-type:not(:only-of-type){padding-left:0;padding-right:24px}mat-cell:last-of-type,mat-header-cell:last-of-type,mat-footer-cell:last-of-type{padding-right:24px}[dir=rtl] mat-cell:last-of-type:not(:only-of-type),[dir=rtl] mat-header-cell:last-of-type:not(:only-of-type),[dir=rtl] mat-footer-cell:last-of-type:not(:only-of-type){padding-right:0;padding-left:24px}mat-cell,mat-header-cell,mat-footer-cell{flex:1;display:flex;align-items:center;overflow:hidden;word-wrap:break-word;min-height:inherit}table.mat-table{border-spacing:0}tr.mat-header-row{height:56px}tr.mat-row,tr.mat-footer-row{height:48px}th.mat-header-cell{text-align:left}[dir=rtl] th.mat-header-cell{text-align:right}th.mat-header-cell,td.mat-cell,td.mat-footer-cell{padding:0;border-bottom-width:1px;border-bottom-style:solid}th.mat-header-cell:first-of-type,td.mat-cell:first-of-type,td.mat-footer-cell:first-of-type{padding-left:24px}[dir=rtl] th.mat-header-cell:first-of-type:not(:only-of-type),[dir=rtl] td.mat-cell:first-of-type:not(:only-of-type),[dir=rtl] td.mat-footer-cell:first-of-type:not(:only-of-type){padding-left:0;padding-right:24px}th.mat-header-cell:last-of-type,td.mat-cell:last-of-type,td.mat-footer-cell:last-of-type{padding-right:24px}[dir=rtl] th.mat-header-cell:last-of-type:not(:only-of-type),[dir=rtl] td.mat-cell:last-of-type:not(:only-of-type),[dir=rtl] td.mat-footer-cell:last-of-type:not(:only-of-type){padding-right:0;padding-left:24px}.mat-table-sticky{position:sticky!important}.mat-table-fixed-layout{table-layout:fixed}\n"] }]
        }], ctorParameters: () => [] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** A bounded context borrows supplied objects without registering destroy hooks. */
class BorrowedDependencyInjector extends Injector {
    values;
    constructor(values) {
        super();
        this.values = values;
    }
    get(token, notFoundValue) {
        if (this.values.has(token))
            return this.values.get(token);
        return Injector.NULL.get(token, notFoundValue);
    }
}
/**
 * Construct the public parent with exactly the original supplied dependencies.
 * Only use for owned subclasses with no emitted instance fields/parameter
 * properties: returning this object skips their own instance initializers.
 * Supplied objects belong to the caller; this context must never destroy them.
 */
function constructWithPublicDependencies(parent, target, providers) {
    const context = new BorrowedDependencyInjector(new Map(providers.map(({ provide, useValue }) => [provide, useValue])));
    return runInInjectionContext(context, () => Reflect.construct(parent, [], target));
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
const legacyColumns = new WeakSet();
/** Register the returned public parent without retaining the definition. */
function markLegacyColumn(definition) {
    legacyColumns.add(definition);
}
/** Keep historical column classes without reading the CDK's private class array. */
function addLegacyColumnClass(definition, element) {
    if (definition && legacyColumns.has(definition)) {
        element.classList.add(`mat-column-${definition.cssClassFriendlyName}`);
    }
}
/** Preserve mixing public CDK cells with historical legacy column definitions. */
class _LegacyTableColumnClasses {
    constructor(elementRef, column) {
        addLegacyColumnClass(column, elementRef.nativeElement);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _LegacyTableColumnClasses, deps: [{ token: i0.ElementRef }, { token: CdkColumnDef, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: _LegacyTableColumnClasses, isStandalone: false, selector: "cdk-cell, td[cdk-cell], cdk-header-cell, th[cdk-header-cell], cdk-footer-cell, td[cdk-footer-cell]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _LegacyTableColumnClasses, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: 'cdk-cell, td[cdk-cell], cdk-header-cell, th[cdk-header-cell], cdk-footer-cell, td[cdk-footer-cell]',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.CdkColumnDef, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CdkColumnDef]
                }] }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Cell definition for the mat-table.
 * Captures the template of a column's data row cell as well as cell-specific properties.
 */
class MatLegacyCellDef extends CdkCellDef {
    // Returning the constructed object is valid ECMAScript. TS requires a lexical
    // super() even though that would discard the original manual argument here.
    // @ts-expect-error TS2377: derived constructor deliberately returns its object.
    constructor(template) {
        return constructWithPublicDependencies(CdkCellDef, new.target, [{ provide: TemplateRef, useValue: template }]);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyCellDef, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyCellDef, isStandalone: false, selector: "[matCellDef]", providers: [{ provide: CdkCellDef, useExisting: MatLegacyCellDef }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyCellDef, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[matCellDef]',
                    providers: [{ provide: CdkCellDef, useExisting: MatLegacyCellDef }],
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }] });
/**
 * Header cell definition for the mat-table.
 * Captures the template of a column's header cell and as well as cell-specific properties.
 */
class MatLegacyHeaderCellDef extends CdkHeaderCellDef {
    // Returning the constructed object is valid ECMAScript. TS requires a lexical
    // super() even though that would discard the original manual argument here.
    // @ts-expect-error TS2377: derived constructor deliberately returns its object.
    constructor(template) {
        return constructWithPublicDependencies(CdkHeaderCellDef, new.target, [{ provide: TemplateRef, useValue: template }]);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyHeaderCellDef, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyHeaderCellDef, isStandalone: false, selector: "[matHeaderCellDef]", providers: [{ provide: CdkHeaderCellDef, useExisting: MatLegacyHeaderCellDef }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyHeaderCellDef, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[matHeaderCellDef]',
                    providers: [{ provide: CdkHeaderCellDef, useExisting: MatLegacyHeaderCellDef }],
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }] });
/**
 * Footer cell definition for the mat-table.
 * Captures the template of a column's footer cell and as well as cell-specific properties.
 */
class MatLegacyFooterCellDef extends CdkFooterCellDef {
    // Returning the constructed object is valid ECMAScript. TS requires a lexical
    // super() even though that would discard the original manual argument here.
    // @ts-expect-error TS2377: derived constructor deliberately returns its object.
    constructor(template) {
        return constructWithPublicDependencies(CdkFooterCellDef, new.target, [{ provide: TemplateRef, useValue: template }]);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyFooterCellDef, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyFooterCellDef, isStandalone: false, selector: "[matFooterCellDef]", providers: [{ provide: CdkFooterCellDef, useExisting: MatLegacyFooterCellDef }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyFooterCellDef, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[matFooterCellDef]',
                    providers: [{ provide: CdkFooterCellDef, useExisting: MatLegacyFooterCellDef }],
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }] });
/**
 * Column definition for the mat-table.
 * Defines a set of cells available for a table column.
 */
class MatLegacyColumnDef extends CdkColumnDef {
    // @ts-expect-error TS2377: derived constructor deliberately returns its object.
    constructor(table) {
        const definition = constructWithPublicDependencies(CdkColumnDef, new.target, []);
        definition._table = table;
        markLegacyColumn(definition);
        return definition;
    }
    get sticky() { return super.sticky; }
    set sticky(value) {
        this.resetStickyChanged();
        super.sticky = coerceBooleanProperty(value);
    }
    get stickyEnd() { return super.stickyEnd; }
    set stickyEnd(value) {
        this.resetStickyChanged();
        super.stickyEnd = coerceBooleanProperty(value);
    }
    /** Unique name for this column. */
    get name() {
        return super.name;
    }
    set name(name) {
        super.name = name;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyColumnDef, deps: [{ token: CdkTable, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyColumnDef, isStandalone: false, selector: "[matColumnDef]", inputs: { sticky: "sticky", name: ["matColumnDef", "name"] }, providers: [
            { provide: CdkColumnDef, useExisting: MatLegacyColumnDef },
            { provide: 'MAT_SORT_HEADER_COLUMN_DEF', useExisting: MatLegacyColumnDef },
        ], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyColumnDef, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[matColumnDef]',
                    inputs: ['sticky'],
                    providers: [
                        { provide: CdkColumnDef, useExisting: MatLegacyColumnDef },
                        { provide: 'MAT_SORT_HEADER_COLUMN_DEF', useExisting: MatLegacyColumnDef },
                    ],
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CdkTable]
                }] }], propDecorators: { name: [{
                type: Input,
                args: ['matColumnDef']
            }] } });
/**
 * Header cell template container that adds the right classes and role.
 */
class MatLegacyHeaderCell extends CdkHeaderCell {
    // @ts-expect-error TS2377: valid derived object return preserves manual arguments.
    constructor(columnDef, elementRef) {
        const cell = constructWithPublicDependencies(CdkHeaderCell, new.target, [
            { provide: CdkColumnDef, useValue: columnDef },
            { provide: ElementRef, useValue: elementRef },
        ]);
        addLegacyColumnClass(columnDef, elementRef.nativeElement);
        return cell;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyHeaderCell, deps: [{ token: i1.CdkColumnDef }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyHeaderCell, isStandalone: false, selector: "mat-header-cell, th[mat-header-cell]", host: { attributes: { "role": "columnheader" }, classAttribute: "mat-header-cell" }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyHeaderCell, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: 'mat-header-cell, th[mat-header-cell]',
                    host: {
                        'class': 'mat-header-cell',
                        'role': 'columnheader',
                    },
                }]
        }], ctorParameters: () => [{ type: i1.CdkColumnDef }, { type: i0.ElementRef }] });
/**
 * Footer cell template container that adds the right classes and role.
 */
class MatLegacyFooterCell extends CdkFooterCell {
    // @ts-expect-error TS2377: valid derived object return preserves manual arguments.
    constructor(columnDef, elementRef) {
        const cell = constructWithPublicDependencies(CdkFooterCell, new.target, [
            { provide: CdkColumnDef, useValue: columnDef },
            { provide: ElementRef, useValue: elementRef },
        ]);
        addLegacyColumnClass(columnDef, elementRef.nativeElement);
        return cell;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyFooterCell, deps: [{ token: i1.CdkColumnDef }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyFooterCell, isStandalone: false, selector: "mat-footer-cell, td[mat-footer-cell]", host: { attributes: { "role": "gridcell" }, classAttribute: "mat-footer-cell" }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyFooterCell, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: 'mat-footer-cell, td[mat-footer-cell]',
                    host: {
                        'class': 'mat-footer-cell',
                        'role': 'gridcell',
                    },
                }]
        }], ctorParameters: () => [{ type: i1.CdkColumnDef }, { type: i0.ElementRef }] });
/**
 * Cell template container that adds the right classes and role.
 */
class MatLegacyCell extends CdkCell {
    // @ts-expect-error TS2377: valid derived object return preserves manual arguments.
    constructor(columnDef, elementRef) {
        const cell = constructWithPublicDependencies(CdkCell, new.target, [
            { provide: CdkColumnDef, useValue: columnDef },
            { provide: ElementRef, useValue: elementRef },
        ]);
        addLegacyColumnClass(columnDef, elementRef.nativeElement);
        return cell;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyCell, deps: [{ token: i1.CdkColumnDef }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyCell, isStandalone: false, selector: "mat-cell, td[mat-cell]", host: { attributes: { "role": "gridcell" }, classAttribute: "mat-cell" }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyCell, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: 'mat-cell, td[mat-cell]',
                    host: {
                        'class': 'mat-cell',
                        'role': 'gridcell',
                    },
                }]
        }], ctorParameters: () => [{ type: i1.CdkColumnDef }, { type: i0.ElementRef }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Header row definition for the mat-table.
 * Captures the header row's template and other header properties such as the columns to display.
 */
class MatLegacyHeaderRowDef extends CdkHeaderRowDef {
    // @ts-expect-error TS2377: derived constructor deliberately returns its object.
    constructor(template, differs, table) {
        const definition = constructWithPublicDependencies(CdkHeaderRowDef, new.target, [
            { provide: TemplateRef, useValue: template },
            { provide: IterableDiffers, useValue: differs },
        ]);
        definition._table = table;
        return definition;
    }
    get sticky() { return super.sticky; }
    set sticky(value) {
        this.resetStickyChanged();
        super.sticky = coerceBooleanProperty(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyHeaderRowDef, deps: [{ token: i0.TemplateRef }, { token: i0.IterableDiffers }, { token: CdkTable, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyHeaderRowDef, isStandalone: false, selector: "[matHeaderRowDef]", inputs: { columns: ["matHeaderRowDef", "columns"], sticky: ["matHeaderRowDefSticky", "sticky"] }, providers: [{ provide: CdkHeaderRowDef, useExisting: MatLegacyHeaderRowDef }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyHeaderRowDef, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[matHeaderRowDef]',
                    providers: [{ provide: CdkHeaderRowDef, useExisting: MatLegacyHeaderRowDef }],
                    inputs: ['columns: matHeaderRowDef', 'sticky: matHeaderRowDefSticky'],
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }, { type: i0.IterableDiffers }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CdkTable]
                }] }] });
/**
 * Footer row definition for the mat-table.
 * Captures the footer row's template and other footer properties such as the columns to display.
 */
class MatLegacyFooterRowDef extends CdkFooterRowDef {
    // @ts-expect-error TS2377: derived constructor deliberately returns its object.
    constructor(template, differs, table) {
        const definition = constructWithPublicDependencies(CdkFooterRowDef, new.target, [
            { provide: TemplateRef, useValue: template },
            { provide: IterableDiffers, useValue: differs },
        ]);
        definition._table = table;
        return definition;
    }
    get sticky() { return super.sticky; }
    set sticky(value) {
        this.resetStickyChanged();
        super.sticky = coerceBooleanProperty(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyFooterRowDef, deps: [{ token: i0.TemplateRef }, { token: i0.IterableDiffers }, { token: CdkTable, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyFooterRowDef, isStandalone: false, selector: "[matFooterRowDef]", inputs: { columns: ["matFooterRowDef", "columns"], sticky: ["matFooterRowDefSticky", "sticky"] }, providers: [{ provide: CdkFooterRowDef, useExisting: MatLegacyFooterRowDef }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyFooterRowDef, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[matFooterRowDef]',
                    providers: [{ provide: CdkFooterRowDef, useExisting: MatLegacyFooterRowDef }],
                    inputs: ['columns: matFooterRowDef', 'sticky: matFooterRowDefSticky'],
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }, { type: i0.IterableDiffers }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CdkTable]
                }] }] });
/**
 * Data row definition for the mat-table.
 * Captures the data row's template and other properties such as the columns to display and
 * a when predicate that describes when this row should be used.
 */
class MatLegacyRowDef extends CdkRowDef {
    // @ts-expect-error TS2377: derived constructor deliberately returns its object.
    constructor(template, differs, table) {
        const definition = constructWithPublicDependencies(CdkRowDef, new.target, [
            { provide: TemplateRef, useValue: template },
            { provide: IterableDiffers, useValue: differs },
        ]);
        definition._table = table;
        return definition;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyRowDef, deps: [{ token: i0.TemplateRef }, { token: i0.IterableDiffers }, { token: CdkTable, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyRowDef, isStandalone: false, selector: "[matRowDef]", inputs: { columns: ["matRowDefColumns", "columns"], when: ["matRowDefWhen", "when"] }, providers: [{ provide: CdkRowDef, useExisting: MatLegacyRowDef }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyRowDef, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[matRowDef]',
                    providers: [{ provide: CdkRowDef, useExisting: MatLegacyRowDef }],
                    inputs: ['columns: matRowDefColumns', 'when: matRowDefWhen'],
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }, { type: i0.IterableDiffers }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CdkTable]
                }] }] });
/**
 * Header template container that contains the cell outlet. Adds the right class and role.
 */
class MatLegacyHeaderRow extends CdkHeaderRow {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyHeaderRow, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyHeaderRow, isStandalone: false, selector: "mat-header-row, tr[mat-header-row]", host: { attributes: { "role": "row" }, classAttribute: "mat-header-row" }, providers: [{ provide: CdkHeaderRow, useExisting: MatLegacyHeaderRow }], exportAs: ["matHeaderRow"], usesInheritance: true, ngImport: i0, template: "<ng-container cdkCellOutlet></ng-container>", isInline: true, dependencies: [{ kind: "directive", type: i1.CdkCellOutlet, selector: "[cdkCellOutlet]" }], changeDetection: i0.ChangeDetectionStrategy.Eager, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyHeaderRow, decorators: [{
            type: Component,
            args: [{
                    standalone: false,
                    selector: 'mat-header-row, tr[mat-header-row]',
                    template: CDK_ROW_TEMPLATE,
                    host: {
                        'class': 'mat-header-row',
                        'role': 'row',
                    },
                    // See note on CdkTable for explanation on why this uses the default change detection strategy.
                    // tslint:disable-next-line:validate-decorators
                    changeDetection: ChangeDetectionStrategy.Eager,
                    encapsulation: ViewEncapsulation.None,
                    exportAs: 'matHeaderRow',
                    providers: [{ provide: CdkHeaderRow, useExisting: MatLegacyHeaderRow }],
                }]
        }] });
/**
 * Footer template container that contains the cell outlet. Adds the right class and role.
 */
class MatLegacyFooterRow extends CdkFooterRow {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyFooterRow, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyFooterRow, isStandalone: false, selector: "mat-footer-row, tr[mat-footer-row]", host: { attributes: { "role": "row" }, classAttribute: "mat-footer-row" }, providers: [{ provide: CdkFooterRow, useExisting: MatLegacyFooterRow }], exportAs: ["matFooterRow"], usesInheritance: true, ngImport: i0, template: "<ng-container cdkCellOutlet></ng-container>", isInline: true, dependencies: [{ kind: "directive", type: i1.CdkCellOutlet, selector: "[cdkCellOutlet]" }], changeDetection: i0.ChangeDetectionStrategy.Eager, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyFooterRow, decorators: [{
            type: Component,
            args: [{
                    standalone: false,
                    selector: 'mat-footer-row, tr[mat-footer-row]',
                    template: CDK_ROW_TEMPLATE,
                    host: {
                        'class': 'mat-footer-row',
                        'role': 'row',
                    },
                    // See note on CdkTable for explanation on why this uses the default change detection strategy.
                    // tslint:disable-next-line:validate-decorators
                    changeDetection: ChangeDetectionStrategy.Eager,
                    encapsulation: ViewEncapsulation.None,
                    exportAs: 'matFooterRow',
                    providers: [{ provide: CdkFooterRow, useExisting: MatLegacyFooterRow }],
                }]
        }] });
/**
 * Data row template container that contains the cell outlet. Adds the right class and role.
 */
class MatLegacyRow extends CdkRow {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyRow, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyRow, isStandalone: false, selector: "mat-row, tr[mat-row]", host: { attributes: { "role": "row" }, classAttribute: "mat-row" }, providers: [{ provide: CdkRow, useExisting: MatLegacyRow }], exportAs: ["matRow"], usesInheritance: true, ngImport: i0, template: "<ng-container cdkCellOutlet></ng-container>", isInline: true, dependencies: [{ kind: "directive", type: i1.CdkCellOutlet, selector: "[cdkCellOutlet]" }], changeDetection: i0.ChangeDetectionStrategy.Eager, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyRow, decorators: [{
            type: Component,
            args: [{
                    standalone: false,
                    selector: 'mat-row, tr[mat-row]',
                    template: CDK_ROW_TEMPLATE,
                    host: {
                        'class': 'mat-row',
                        'role': 'row',
                    },
                    // See note on CdkTable for explanation on why this uses the default change detection strategy.
                    // tslint:disable-next-line:validate-decorators
                    changeDetection: ChangeDetectionStrategy.Eager,
                    encapsulation: ViewEncapsulation.None,
                    exportAs: 'matRow',
                    providers: [{ provide: CdkRow, useExisting: MatLegacyRow }],
                }]
        }] });
/**
 * Row that can be used to display a message when no data is shown in the table.
 */
class MatLegacyNoDataRow extends CdkNoDataRow {
    // Type-only declaration: initialization is explicit on the returned object.
    _contentClassNames;
    /** Historical16 public member, retained alongside the current CDK field. */
    _contentClassName;
    // @ts-expect-error TS2377: valid derived object return preserves manual arguments.
    constructor(templateRef) {
        const row = constructWithPublicDependencies(CdkNoDataRow, new.target, [
            { provide: TemplateRef, useValue: templateRef },
        ]);
        row._contentClassName = 'mat-no-data-row';
        row._contentClassNames = ['mat-no-data-row'];
        // Material 16 did not add classes to the cells inside a no-data row.
        row._cellClassNames = [];
        // Even an empty classList.add call creates a class attribute in the DOM.
        row._cellSelector = ':not(*)';
        return row;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyNoDataRow, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyNoDataRow, isStandalone: false, selector: "ng-template[matNoDataRow]", providers: [{ provide: CdkNoDataRow, useExisting: MatLegacyNoDataRow }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyNoDataRow, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: 'ng-template[matNoDataRow]',
                    providers: [{ provide: CdkNoDataRow, useExisting: MatLegacyNoDataRow }],
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Column that simply shows text content for the header and row cells. Assumes that the table
 * is using the native table implementation (`<table>`).
 *
 * By default, the name of this column will be the header text and data property accessor.
 * The header text can be overridden with the `headerText` input. Cell values can be overridden with
 * the `dataAccessor` input. Change the text justification to the start or end using the `justify`
 * input.
 *
 */
class MatLegacyTextColumn extends CdkTextColumn {
    // @ts-expect-error TS2377: valid derived object return preserves manual arguments.
    constructor(table, options) {
        return constructWithPublicDependencies((CdkTextColumn), new.target, [
            { provide: CdkTable, useValue: table },
            { provide: TEXT_COLUMN_OPTIONS, useValue: options },
        ]);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyTextColumn, deps: [{ token: i1.CdkTable, optional: true }, { token: TEXT_COLUMN_OPTIONS, optional: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MatLegacyTextColumn, isStandalone: false, selector: "mat-text-column", host: { properties: { "attr.mat-id-collision": "null" } }, usesInheritance: true, ngImport: i0, template: `
    <ng-container matColumnDef>
      <th mat-header-cell *matHeaderCellDef [style.text-align]="justify">
        {{headerText}}
      </th>
      <td mat-cell *matCellDef="let data" [style.text-align]="justify">
        {{dataAccessor(data, name)}}
      </td>
    </ng-container>
  `, isInline: true, dependencies: [{ kind: "directive", type: MatLegacyHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: MatLegacyColumnDef, selector: "[matColumnDef]", inputs: ["sticky", "matColumnDef"] }, { kind: "directive", type: MatLegacyCellDef, selector: "[matCellDef]" }, { kind: "directive", type: MatLegacyHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: MatLegacyCell, selector: "mat-cell, td[mat-cell]" }], changeDetection: i0.ChangeDetectionStrategy.Eager, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyTextColumn, decorators: [{
            type: Component,
            args: [{
                    standalone: false,
                    selector: 'mat-text-column',
                    template: `
    <ng-container matColumnDef>
      <th mat-header-cell *matHeaderCellDef [style.text-align]="justify">
        {{headerText}}
      </th>
      <td mat-cell *matCellDef="let data" [style.text-align]="justify">
        {{dataAccessor(data, name)}}
      </td>
    </ng-container>
  `,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        // This binding is used to ensure that the component ID doesn't clash with the `MatTextColumn`.
                        '[attr.mat-id-collision]': 'null',
                    },
                    // Change detection is intentionally not set to OnPush. This component's template will be provided
                    // to the table to be inserted into its view. This is problematic when change detection runs since
                    // the bindings in this template will be evaluated _after_ the table's view is evaluated, which
                    // mean's the template in the table's view will not have the updated value (and in fact will cause
                    // an ExpressionChangedAfterItHasBeenCheckedError).
                    // tslint:disable-next-line:validate-decorators
                    changeDetection: ChangeDetectionStrategy.Eager,
                }]
        }], ctorParameters: () => [{ type: i1.CdkTable, decorators: [{
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [TEXT_COLUMN_OPTIONS]
                }] }] });

/**
 * Minimal MatCommonModule stand-in for legacy NgModules.
 * Historical MatCommonModule is gone from current @angular/material/core;
 * export CDK Bidi for directionality consumers.
 */
class MatCommonModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, imports: [BidiModule], exports: [BidiModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, imports: [BidiModule, BidiModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [BidiModule],
                    exports: [BidiModule],
                }]
        }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Raw public CDK definitions can also be used in a legacy table. Bind them to
 * the nearest public table so nested tables cannot borrow each other's defs.
 * Current tables retain their own provider and are left to the peer.
 */
class _LegacyTableDefinitionOwner {
    constructor(table, column, header, footer, row) {
        if (table instanceof MatLegacyTable) {
            for (const definition of [column, header, footer, row]) {
                if (definition)
                    definition._table = table;
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _LegacyTableDefinitionOwner, deps: [{ token: CdkTable, optional: true }, { token: CdkColumnDef, optional: true, self: true }, { token: CdkHeaderRowDef, optional: true, self: true }, { token: CdkFooterRowDef, optional: true, self: true }, { token: CdkRowDef, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: _LegacyTableDefinitionOwner, isStandalone: false, selector: "[cdkColumnDef], [cdkHeaderRowDef], [cdkFooterRowDef], [cdkRowDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _LegacyTableDefinitionOwner, decorators: [{
            type: Directive,
            args: [{
                    standalone: false,
                    selector: '[cdkColumnDef], [cdkHeaderRowDef], [cdkFooterRowDef], [cdkRowDef]',
                }]
        }], ctorParameters: () => [{ type: i1.CdkTable, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CdkTable]
                }] }, { type: i1.CdkColumnDef, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }, {
                    type: Inject,
                    args: [CdkColumnDef]
                }] }, { type: i1.CdkHeaderRowDef, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }, {
                    type: Inject,
                    args: [CdkHeaderRowDef]
                }] }, { type: i1.CdkFooterRowDef, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }, {
                    type: Inject,
                    args: [CdkFooterRowDef]
                }] }, { type: i1.CdkRowDef, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }, {
                    type: Inject,
                    args: [CdkRowDef]
                }] }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
const EXPORTED_DECLARATIONS = [
    // Table
    MatLegacyTable,
    MatLegacyRecycleRows,
    // Template defs
    MatLegacyHeaderCellDef,
    MatLegacyHeaderRowDef,
    MatLegacyColumnDef,
    MatLegacyCellDef,
    MatLegacyRowDef,
    MatLegacyFooterCellDef,
    MatLegacyFooterRowDef,
    // Cell directives
    MatLegacyHeaderCell,
    MatLegacyCell,
    MatLegacyFooterCell,
    // Row directives
    MatLegacyHeaderRow,
    MatLegacyRow,
    MatLegacyFooterRow,
    MatLegacyNoDataRow,
    MatLegacyTextColumn,
];
class MatLegacyTableModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyTableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyTableModule, declarations: [
            // Table
            MatLegacyTable,
            MatLegacyRecycleRows,
            // Template defs
            MatLegacyHeaderCellDef,
            MatLegacyHeaderRowDef,
            MatLegacyColumnDef,
            MatLegacyCellDef,
            MatLegacyRowDef,
            MatLegacyFooterCellDef,
            MatLegacyFooterRowDef,
            // Cell directives
            MatLegacyHeaderCell,
            MatLegacyCell,
            MatLegacyFooterCell,
            // Row directives
            MatLegacyHeaderRow,
            MatLegacyRow,
            MatLegacyFooterRow,
            MatLegacyNoDataRow,
            MatLegacyTextColumn, _LegacyTableOutlet, _LegacyTableDefinitionOwner, _LegacyTableColumnClasses], imports: [CdkTableModule, MatCommonModule], exports: [MatCommonModule, 
            // Table
            MatLegacyTable,
            MatLegacyRecycleRows,
            // Template defs
            MatLegacyHeaderCellDef,
            MatLegacyHeaderRowDef,
            MatLegacyColumnDef,
            MatLegacyCellDef,
            MatLegacyRowDef,
            MatLegacyFooterCellDef,
            MatLegacyFooterRowDef,
            // Cell directives
            MatLegacyHeaderCell,
            MatLegacyCell,
            MatLegacyFooterCell,
            // Row directives
            MatLegacyHeaderRow,
            MatLegacyRow,
            MatLegacyFooterRow,
            MatLegacyNoDataRow,
            MatLegacyTextColumn, _LegacyTableDefinitionOwner, _LegacyTableColumnClasses] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyTableModule, imports: [CdkTableModule, MatCommonModule, MatCommonModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatLegacyTableModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CdkTableModule, MatCommonModule],
                    exports: [MatCommonModule, EXPORTED_DECLARATIONS, _LegacyTableDefinitionOwner, _LegacyTableColumnClasses],
                    declarations: [EXPORTED_DECLARATIONS, _LegacyTableOutlet, _LegacyTableDefinitionOwner, _LegacyTableColumnClasses],
                }]
        }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatTableDataSource` + paginator interfaces (removed from
 * Angular Material 22 public API; M22 MatTableDataSource is coupled to MatPaginator).
 */
/**
 * Corresponds to `Number.MAX_SAFE_INTEGER`. Moved out into a variable here due to
 * flaky browser support and the value not being defined in Closure's typings.
 */
const MAX_SAFE_INTEGER = 9007199254740991;
/** Shared base class with MDC-based implementation. */
class _MatTableDataSource extends DataSource {
    /** Stream that emits when a new data array is set on the data source. */
    _data;
    /** Stream emitting render data to the table (depends on ordered data changes). */
    _renderData = new BehaviorSubject([]);
    /** Stream that emits when a new filter string is set on the data source. */
    _filter = new BehaviorSubject('');
    /** Used to react to internal changes of the paginator that are made by the data source itself. */
    _internalPageChanges = new Subject();
    /**
     * Subscription to the changes that should trigger an update to the table's rendered rows, such
     * as filtering, sorting, pagination, or base data changes.
     */
    _renderChangesSubscription = null;
    /**
     * The filtered set of data that has been matched by the filter string, or all the data if there
     * is no filter. Useful for knowing the set of data the table represents.
     * For example, a 'selectAll()' function would likely want to select the set of filtered data
     * shown to the user rather than all the data.
     */
    filteredData;
    /** Array of data that should be rendered by the table, where each object represents one row. */
    get data() {
        return this._data.value;
    }
    set data(data) {
        data = Array.isArray(data) ? data : [];
        this._data.next(data);
        // Normally the `filteredData` is updated by the re-render
        // subscription, but that won't happen if it's inactive.
        if (!this._renderChangesSubscription) {
            this._filterData(data);
        }
    }
    /**
     * Filter term that should be used to filter out objects from the data array. To override how
     * data objects match to this filter string, provide a custom function for filterPredicate.
     */
    get filter() {
        return this._filter.value;
    }
    set filter(filter) {
        this._filter.next(filter);
        // Normally the `filteredData` is updated by the re-render
        // subscription, but that won't happen if it's inactive.
        if (!this._renderChangesSubscription) {
            this._filterData(this.data);
        }
    }
    /**
     * Instance of the MatSort directive used by the table to control its sorting. Sort changes
     * emitted by the MatSort will trigger an update to the table's rendered data.
     */
    get sort() {
        return this._sort;
    }
    set sort(sort) {
        this._sort = sort;
        this._updateChangeSubscription();
    }
    _sort;
    /**
     * Instance of the paginator component used by the table to control what page of the data is
     * displayed. Page changes emitted by the paginator will trigger an update to the
     * table's rendered data.
     *
     * Note that the data source uses the paginator's properties to calculate which page of data
     * should be displayed. If the paginator receives its properties as template inputs,
     * e.g. `[pageLength]=100` or `[pageIndex]=1`, then be sure that the paginator's view has been
     * initialized before assigning it to this data source.
     */
    get paginator() {
        return this._paginator;
    }
    set paginator(paginator) {
        this._paginator = paginator;
        this._updateChangeSubscription();
    }
    _paginator;
    /**
     * Data accessor function that is used for accessing data properties for sorting through
     * the default sortData function.
     * This default function assumes that the sort header IDs (which defaults to the column name)
     * matches the data's properties (e.g. column Xyz represents data['Xyz']).
     * May be set to a custom function for different behavior.
     * @param data Data object that is being accessed.
     * @param sortHeaderId The name of the column that represents the data.
     */
    sortingDataAccessor = (data, sortHeaderId) => {
        const value = data[sortHeaderId];
        if (legacyIsNumberValue(value)) {
            const numberValue = Number(value);
            // Numbers beyond `MAX_SAFE_INTEGER` can't be compared reliably so we
            // leave them as strings. For more info: https://goo.gl/y5vbSg
            return numberValue < MAX_SAFE_INTEGER ? numberValue : value;
        }
        return value;
    };
    /**
     * Gets a sorted copy of the data array based on the state of the MatSort. Called
     * after changes are made to the filtered data or when sort changes are emitted from MatSort.
     * By default, the function retrieves the active sort and its direction and compares data
     * by retrieving data using the sortingDataAccessor. May be overridden for a custom implementation
     * of data ordering.
     * @param data The array of data that should be sorted.
     * @param sort The connected MatSort that holds the current sort state.
     */
    sortData = (data, sort) => {
        const active = sort.active;
        const direction = sort.direction;
        if (!active || direction == '') {
            return data;
        }
        return data.sort((a, b) => {
            let valueA = this.sortingDataAccessor(a, active);
            let valueB = this.sortingDataAccessor(b, active);
            // If there are data in the column that can be converted to a number,
            // it must be ensured that the rest of the data
            // is of the same type so as not to order incorrectly.
            const valueAType = typeof valueA;
            const valueBType = typeof valueB;
            if (valueAType !== valueBType) {
                if (valueAType === 'number') {
                    valueA += '';
                }
                if (valueBType === 'number') {
                    valueB += '';
                }
            }
            // If both valueA and valueB exist (truthy), then compare the two. Otherwise, check if
            // one value exists while the other doesn't. In this case, existing value should come last.
            // This avoids inconsistent results when comparing values to undefined/null.
            // If neither value exists, return 0 (equal).
            let comparatorResult = 0;
            if (valueA != null && valueB != null) {
                // Check if one value is greater than the other; if equal, comparatorResult should remain 0.
                if (valueA > valueB) {
                    comparatorResult = 1;
                }
                else if (valueA < valueB) {
                    comparatorResult = -1;
                }
            }
            else if (valueA != null) {
                comparatorResult = 1;
            }
            else if (valueB != null) {
                comparatorResult = -1;
            }
            return comparatorResult * (direction == 'asc' ? 1 : -1);
        });
    };
    /**
     * Checks if a data object matches the data source's filter string. By default, each data object
     * is converted to a string of its properties and returns true if the filter has
     * at least one occurrence in that string. By default, the filter string has its whitespace
     * trimmed and the match is case-insensitive. May be overridden for a custom implementation of
     * filter matching.
     * @param data Data object used to check against the filter.
     * @param filter Filter string that has been set on the data source.
     * @returns Whether the filter matches against the data
     */
    filterPredicate = (data, filter) => {
        // Transform the data into a lowercase string of all property values.
        const dataStr = Object.keys(data)
            .reduce((currentTerm, key) => {
            // Use an obscure Unicode character to delimit the words in the concatenated string.
            // This avoids matches where the values of two columns combined will match the user's query
            // (e.g. `Flute` and `Stop` will match `Test`). The character is intended to be something
            // that has a very low chance of being typed in by somebody in a text field. This one in
            // particular is "White up-pointing triangle with dot" from
            // https://en.wikipedia.org/wiki/List_of_Unicode_characters
            return currentTerm + data[key] + '◬';
        }, '')
            .toLowerCase();
        // Transform the filter by converting it to lowercase and removing whitespace.
        const transformedFilter = filter.trim().toLowerCase();
        return dataStr.indexOf(transformedFilter) != -1;
    };
    constructor(initialData = []) {
        super();
        this._data = new BehaviorSubject(initialData);
        this._updateChangeSubscription();
    }
    /**
     * Subscribe to changes that should trigger an update to the table's rendered rows. When the
     * changes occur, process the current state of the filter, sort, and pagination along with
     * the provided base data and send it to the table for rendering.
     */
    _updateChangeSubscription() {
        // Sorting and/or pagination should be watched if sort and/or paginator are provided.
        // The events should emit whenever the component emits a change or initializes, or if no
        // component is provided, a stream with just a null event should be provided.
        // The `sortChange` and `pageChange` acts as a signal to the combineLatests below so that the
        // pipeline can progress to the next step. Note that the value from these streams are not used,
        // they purely act as a signal to progress in the pipeline.
        const sortChange = this._sort
            ? merge(this._sort.sortChange, this._sort.initialized)
            : of(null);
        const pageChange = this._paginator
            ? merge(this._paginator.page, this._internalPageChanges, this._paginator.initialized)
            : of(null);
        const dataStream = this._data;
        // Watch for base data or filter changes to provide a filtered set of data.
        const filteredData = combineLatest([dataStream, this._filter]).pipe(map(([data]) => this._filterData(data)));
        // Watch for filtered data or sort changes to provide an ordered set of data.
        const orderedData = combineLatest([filteredData, sortChange]).pipe(map(([data]) => this._orderData(data)));
        // Watch for ordered data or page changes to provide a paged set of data.
        const paginatedData = combineLatest([orderedData, pageChange]).pipe(map(([data]) => this._pageData(data)));
        // Watched for paged data changes and send the result to the table to render.
        this._renderChangesSubscription?.unsubscribe();
        this._renderChangesSubscription = paginatedData.subscribe(data => this._renderData.next(data));
    }
    /**
     * Returns a filtered data array where each filter object contains the filter string within
     * the result of the filterPredicate function. If no filter is set, returns the data array
     * as provided.
     */
    _filterData(data) {
        // If there is a filter string, filter out data that does not contain it.
        // Each data object is converted to a string using the function defined by filterPredicate.
        // May be overridden for customization.
        this.filteredData =
            this.filter == null || this.filter === ''
                ? data
                : data.filter(obj => this.filterPredicate(obj, this.filter));
        if (this.paginator) {
            this._updatePaginator(this.filteredData.length);
        }
        return this.filteredData;
    }
    /**
     * Returns a sorted copy of the data if MatSort has a sort applied, otherwise just returns the
     * data array as provided. Uses the default data accessor for data lookup, unless a
     * sortDataAccessor function is defined.
     */
    _orderData(data) {
        // If there is no active sort or direction, return the data without trying to sort.
        if (!this.sort) {
            return data;
        }
        return this.sortData(data.slice(), this.sort);
    }
    /**
     * Returns a paged slice of the provided data array according to the provided paginator's page
     * index and length. If there is no paginator provided, returns the data array as provided.
     */
    _pageData(data) {
        if (!this.paginator) {
            return data;
        }
        const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
        return data.slice(startIndex, startIndex + this.paginator.pageSize);
    }
    /**
     * Updates the paginator to reflect the length of the filtered data, and makes sure that the page
     * index does not exceed the paginator's last page. Values are changed in a resolved promise to
     * guard against making property changes within a round of change detection.
     */
    _updatePaginator(filteredDataLength) {
        Promise.resolve().then(() => {
            const paginator = this.paginator;
            if (!paginator) {
                return;
            }
            paginator.length = filteredDataLength;
            // If the page index is set beyond the page, reduce it to the last page.
            if (paginator.pageIndex > 0) {
                const lastPageIndex = Math.ceil(paginator.length / paginator.pageSize) - 1 || 0;
                const newPageIndex = Math.min(paginator.pageIndex, lastPageIndex);
                if (newPageIndex !== paginator.pageIndex) {
                    paginator.pageIndex = newPageIndex;
                    // Since the paginator only emits after user-generated changes,
                    // we need our own stream so we know to should re-render the data.
                    this._internalPageChanges.next();
                }
            }
        });
    }
    /**
     * Used by the MatTable. Called when it connects to the data source.
     * @docs-private
     */
    connect() {
        if (!this._renderChangesSubscription) {
            this._updateChangeSubscription();
        }
        return this._renderData;
    }
    /**
     * Used by the MatTable. Called when it disconnects from the data source.
     * @docs-private
     */
    disconnect() {
        this._renderChangesSubscription?.unsubscribe();
        this._renderChangesSubscription = null;
    }
}
/**
 * Data source that accepts a client-side data array and includes native support of filtering,
 * sorting (using MatSort), and pagination (using MatPaginator).
 *
 * Allows for sort customization by overriding sortingDataAccessor, which defines how data
 * properties are accessed. Also allows for filter customization by overriding filterPredicate,
 * which defines how row data is converted to a string for filter matching.
 *
 * **Note:** This class is meant to be a simple data source to help you get started. As such
 * it isn't equipped to handle some more advanced cases like robust i18n support or server-side
 * interactions. If your app needs to support more advanced use cases, consider implementing your
 * own `DataSource`.
 */

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Data source that accepts a client-side data array and includes native support of filtering,
 * sorting (using MatSort), and pagination (using paginator).
 *
 * Allows for sort customization by overriding sortingDataAccessor, which defines how data
 * properties are accessed. Also allows for filter customization by overriding filterPredicate,
 * which defines how row data is converted to a string for filter matching.
 *
 * **Note:** This class is meant to be a simple data source to help you get started. As such
 * it isn't equipped to handle some more advanced cases like robust i18n support or server-side
 * interactions. If your app needs to support more advanced use cases, consider implementing your
 * own `DataSource`.
 *
 */
class MatLegacyTableDataSource extends _MatTableDataSource {
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MatCommonModule, MatLegacyCell, MatLegacyCellDef, MatLegacyColumnDef, MatLegacyFooterCell, MatLegacyFooterCellDef, MatLegacyFooterRow, MatLegacyFooterRowDef, MatLegacyHeaderCell, MatLegacyHeaderCellDef, MatLegacyHeaderRow, MatLegacyHeaderRowDef, MatLegacyNoDataRow, MatLegacyRecycleRows, MatLegacyRow, MatLegacyRowDef, MatLegacyTable, MatLegacyTableDataSource, MatLegacyTableModule, MatLegacyTextColumn, _LegacyTableDefinitionOwner, _MatTableDataSource as _MatLegacyTableDataSource, _LegacyTableColumnClasses as ɵLegacyTableColumnClasses };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-table.mjs.map
