import * as _angular_cdk_testing from '@angular/cdk/testing';
import { ContentContainerComponentHarness, HarnessPredicate } from '@angular/cdk/testing';
import { DialogHarnessFilters } from '@angular/material/dialog/testing';
export { DialogHarnessFilters as LegacyDialogHarnessFilters } from '@angular/material/dialog/testing';
import { DialogRole } from '@angular/material/dialog';
import { ComponentType } from '@angular/cdk/overlay';
import * as i1 from '@ngx-compat/material-legacy/legacy-dialog';
import { MatLegacyDialogContainer, MatLegacyDialog, MatLegacyDialogConfig, MatLegacyDialogRef } from '@ngx-compat/material-legacy/legacy-dialog';
import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';

/** Selectors for different sections of the mat-dialog that can contain user content. */
declare enum MatDialogSection {
    TITLE = ".mat-dialog-title",
    CONTENT = ".mat-dialog-content",
    ACTIONS = ".mat-dialog-actions"
}
/** Base class for the `MatDialogHarness` implementation. */
declare class _MatDialogHarnessBase extends ContentContainerComponentHarness<MatDialogSection | string> {
    protected _title: () => Promise<_angular_cdk_testing.TestElement | null>;
    protected _content: () => Promise<_angular_cdk_testing.TestElement | null>;
    protected _actions: () => Promise<_angular_cdk_testing.TestElement | null>;
    /** Gets the id of the dialog. */
    getId(): Promise<string | null>;
    /** Gets the role of the dialog. */
    getRole(): Promise<DialogRole | null>;
    /** Gets the value of the dialog's "aria-label" attribute. */
    getAriaLabel(): Promise<string | null>;
    /** Gets the value of the dialog's "aria-labelledby" attribute. */
    getAriaLabelledby(): Promise<string | null>;
    /** Gets the value of the dialog's "aria-describedby" attribute. */
    getAriaDescribedby(): Promise<string | null>;
    /** Closes the dialog by pressing Escape. */
    close(): Promise<void>;
    /** Gets the dialog's full text content. */
    getText(): Promise<string>;
    /** Gets the text of the dialog's title section. */
    getTitleText(): Promise<string>;
    /** Gets the text of the dialog's content section. */
    getContentText(): Promise<string>;
    /** Gets the text of the dialog's actions section. */
    getActionsText(): Promise<string>;
}

/**
 * Selectors for different sections of the mat-dialog that can contain user content.
 */
declare enum MatLegacyDialogSection {
    TITLE = ".mat-dialog-title",
    CONTENT = ".mat-dialog-content",
    ACTIONS = ".mat-dialog-actions"
}
/**
 * Harness for interacting with a standard `MatDialog` in tests.
 */
declare class MatLegacyDialogHarness extends _MatDialogHarnessBase {
    static hostSelector: string;
    static with(options?: DialogHarnessFilters): HarnessPredicate<MatLegacyDialogHarness>;
    protected _title: () => Promise<_angular_cdk_testing.TestElement | null>;
    protected _content: () => Promise<_angular_cdk_testing.TestElement | null>;
    protected _actions: () => Promise<_angular_cdk_testing.TestElement | null>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatTestDialogOpenerBase` (removed from Angular Material 22).
 */

/** Base class for a component that immediately opens a dialog when created. */
declare class _MatTestDialogOpenerBase<C extends MatLegacyDialogContainer = MatLegacyDialogContainer, T = unknown, R = unknown> implements OnDestroy {
    dialog: MatLegacyDialog;
    protected static component: ComponentType<unknown> | undefined;
    protected static config: MatLegacyDialogConfig | undefined;
    dialogRef: MatLegacyDialogRef<T, R>;
    closedResult: R | undefined;
    private readonly _afterClosedSubscription;
    constructor(dialog: MatLegacyDialog);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatTestDialogOpenerBase<any, any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_MatTestDialogOpenerBase<any, any, any>, never, never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Test component that immediately opens a dialog when created.
 */
declare class MatTestLegacyDialogOpener<T = unknown, R = unknown> extends _MatTestDialogOpenerBase<MatLegacyDialogContainer, T, R> {
    constructor(dialog: MatLegacyDialog);
    /** Static method that prepares this class to open the provided component. */
    static withComponent<T = unknown, R = unknown>(component: ComponentType<T>, config?: MatLegacyDialogConfig): typeof MatTestLegacyDialogOpener;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatTestLegacyDialogOpener<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatTestLegacyDialogOpener<any, any>, "mat-test-dialog-opener", never, {}, {}, never, never, false, never>;
}
/**
 * Testing module that opens a dialog immediately and disables Material motion via the
 * public MATERIAL_ANIMATIONS token (engine-free; no NoopAnimationsModule).
 */
declare class MatTestLegacyDialogOpenerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatTestLegacyDialogOpenerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatTestLegacyDialogOpenerModule, [typeof MatTestLegacyDialogOpener], [typeof i1.MatLegacyDialogModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatTestLegacyDialogOpenerModule>;
}

export { MatLegacyDialogHarness, MatLegacyDialogSection, MatTestLegacyDialogOpener, MatTestLegacyDialogOpenerModule };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-dialog-testing.d.ts.map
