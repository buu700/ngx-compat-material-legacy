import * as i0 from '@angular/core';
import * as i1 from '@angular/cdk/bidi';

/**
 * Content of a card, needed as it's used as a selector in the API.
 * @docs-private
 */
declare class MatLegacyCardContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCardContent, "mat-card-content, [mat-card-content], [matCardContent]", never, {}, {}, never, never, false, never>;
}
/**
 * Title of a card, needed as it's used as a selector in the API.
 * @docs-private
 */
declare class MatLegacyCardTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardTitle, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCardTitle, "mat-card-title, [mat-card-title], [matCardTitle]", never, {}, {}, never, never, false, never>;
}
/**
 * Sub-title of a card, needed as it's used as a selector in the API.
 * @docs-private
 */
declare class MatLegacyCardSubtitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardSubtitle, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCardSubtitle, "mat-card-subtitle, [mat-card-subtitle], [matCardSubtitle]", never, {}, {}, never, never, false, never>;
}
/**
 * Action section of a card, needed as it's used as a selector in the API.
 * @docs-private
 */
declare class MatLegacyCardActions {
    /** Position of the actions inside the card. */
    align: 'start' | 'end';
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardActions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCardActions, "mat-card-actions", ["matCardActions"], { "align": { "alias": "align"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Footer of a card, needed as it's used as a selector in the API.
 * @docs-private
 */
declare class MatLegacyCardFooter {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardFooter, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCardFooter, "mat-card-footer", never, {}, {}, never, never, false, never>;
}
/**
 * Image used in a card, needed to add the mat- CSS styling.
 * @docs-private
 */
declare class MatLegacyCardImage {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardImage, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCardImage, "[mat-card-image], [matCardImage]", never, {}, {}, never, never, false, never>;
}
/**
 * Image used in a card, needed to add the mat- CSS styling.
 * @docs-private
 */
declare class MatLegacyCardSmImage {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardSmImage, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCardSmImage, "[mat-card-sm-image], [matCardImageSmall]", never, {}, {}, never, never, false, never>;
}
/**
 * Image used in a card, needed to add the mat- CSS styling.
 * @docs-private
 */
declare class MatLegacyCardMdImage {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardMdImage, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCardMdImage, "[mat-card-md-image], [matCardImageMedium]", never, {}, {}, never, never, false, never>;
}
/**
 * Image used in a card, needed to add the mat- CSS styling.
 * @docs-private
 */
declare class MatLegacyCardLgImage {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardLgImage, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCardLgImage, "[mat-card-lg-image], [matCardImageLarge]", never, {}, {}, never, never, false, never>;
}
/**
 * Large image used in a card, needed to add the mat- CSS styling.
 * @docs-private
 */
declare class MatLegacyCardXlImage {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardXlImage, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCardXlImage, "[mat-card-xl-image], [matCardImageXLarge]", never, {}, {}, never, never, false, never>;
}
/**
 * Avatar image used in a card, needed to add the mat- CSS styling.
 * @docs-private
 */
declare class MatLegacyCardAvatar {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardAvatar, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyCardAvatar, "[mat-card-avatar], [matCardAvatar]", never, {}, {}, never, never, false, never>;
}
/**
 * A basic content container component that adds the styles of a Material design card.
 *
 * While this component can be used alone, it also provides a number
 * of preset styles for common card sections, including:
 * - mat-card-title
 * - mat-card-subtitle
 * - mat-card-content
 * - mat-card-actions
 * - mat-card-footer
 *
 */
declare class MatLegacyCard {
    _animationMode?: string | undefined;
    constructor(_animationMode?: string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCard, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyCard, "mat-card", ["matCard"], {}, {}, never, ["*", "mat-card-footer"], false, never>;
}
/**
 * Component intended to be used within the `<mat-card>` component. It adds styles for a
 * preset header section (i.e. a title, subtitle, and avatar layout).
 * @docs-private
 */
declare class MatLegacyCardHeader {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardHeader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyCardHeader, "mat-card-header", never, {}, {}, never, ["[mat-card-avatar], [matCardAvatar]", "mat-card-title, mat-card-subtitle,\n      [mat-card-title], [mat-card-subtitle],\n      [matCardTitle], [matCardSubtitle]", "*"], false, never>;
}
/**
 * Component intended to be used within the `<mat-card>` component. It adds styles for a preset
 * layout that groups an image with a title section.
 * @docs-private
 */
declare class MatLegacyCardTitleGroup {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardTitleGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyCardTitleGroup, "mat-card-title-group", never, {}, {}, never, ["mat-card-title, mat-card-subtitle,\n      [mat-card-title], [mat-card-subtitle],\n      [matCardTitle], [matCardSubtitle]", "img", "*"], false, never>;
}

declare class MatCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatCommonModule, never, [typeof i1.BidiModule], [typeof i1.BidiModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatCommonModule>;
}

declare class MatLegacyCardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyCardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacyCardModule, [typeof MatLegacyCard, typeof MatLegacyCardHeader, typeof MatLegacyCardTitleGroup, typeof MatLegacyCardContent, typeof MatLegacyCardTitle, typeof MatLegacyCardSubtitle, typeof MatLegacyCardActions, typeof MatLegacyCardFooter, typeof MatLegacyCardSmImage, typeof MatLegacyCardMdImage, typeof MatLegacyCardLgImage, typeof MatLegacyCardImage, typeof MatLegacyCardXlImage, typeof MatLegacyCardAvatar], [typeof MatCommonModule], [typeof MatLegacyCard, typeof MatLegacyCardHeader, typeof MatLegacyCardTitleGroup, typeof MatLegacyCardContent, typeof MatLegacyCardTitle, typeof MatLegacyCardSubtitle, typeof MatLegacyCardActions, typeof MatLegacyCardFooter, typeof MatLegacyCardSmImage, typeof MatLegacyCardMdImage, typeof MatLegacyCardLgImage, typeof MatLegacyCardImage, typeof MatLegacyCardXlImage, typeof MatLegacyCardAvatar, typeof MatCommonModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacyCardModule>;
}

export { MatCommonModule, MatLegacyCard, MatLegacyCardActions, MatLegacyCardAvatar, MatLegacyCardContent, MatLegacyCardFooter, MatLegacyCardHeader, MatLegacyCardImage, MatLegacyCardLgImage, MatLegacyCardMdImage, MatLegacyCardModule, MatLegacyCardSmImage, MatLegacyCardSubtitle, MatLegacyCardTitle, MatLegacyCardTitleGroup, MatLegacyCardXlImage };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-card.d.ts.map
