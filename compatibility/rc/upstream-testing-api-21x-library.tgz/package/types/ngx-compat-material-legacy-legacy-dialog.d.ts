import * as i0 from '@angular/core';
import { OnDestroy, ElementRef, NgZone, EventEmitter, ComponentRef, EmbeddedViewRef, ChangeDetectorRef, Injector, Type, InjectionToken, TemplateRef, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { FocusTrapFactory, FocusOrigin, InteractivityChecker, FocusMonitor } from '@angular/cdk/a11y';
import * as i4 from '@angular/cdk/overlay';
import { OverlayRef, Overlay, ScrollStrategy, OverlayContainer, ComponentType } from '@angular/cdk/overlay';
import * as i5 from '@angular/cdk/portal';
import { BasePortalOutlet, CdkPortalOutlet, ComponentPortal, TemplatePortal, DomPortal } from '@angular/cdk/portal';
import { MatDialogConfig, DialogPosition, MatDialogState } from '@angular/material/dialog';
export { AutoFocusTarget as LegacyAutoFocusTarget, DialogPosition as LegacyDialogPosition, DialogRole as LegacyDialogRole, MatDialogState as MatLegacyDialogState } from '@angular/material/dialog';
import { Location } from '@angular/common';
import { Observable, Subject } from 'rxjs';
import * as i3 from '@angular/cdk/dialog';
import { DialogRef } from '@angular/cdk/dialog';
import * as i1 from '@angular/cdk/bidi';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Historical focus and animation values are interpreted by the owned legacy
 * container. Keep their contract independent of upstream removal annotations.
 * All other configuration fields retain the public peer contract.
 */
type LegacyDialogRuntimeConfig<D = any> = Omit<MatDialogConfig<D>, 'autoFocus' | 'enterAnimationDuration' | 'exitAnimationDuration'> & {
    autoFocus?: string | boolean;
    enterAnimationDuration?: string | number;
    exitAnimationDuration?: string | number;
};
declare class MatLegacyDialogConfig<D = any> extends MatDialogConfig<D> {
    /**
     * Whether the dialog should set `aria-modal`. Current Material defaults this
     * to false; the legacy dialog set it to true.
     */
    ariaModal: boolean;
    /** Max-width of the dialog. Current Material leaves this unset; legacy defaults to 80vw. */
    maxWidth?: number | string;
    /** Historical autofocus policy, including boolean values handled by the owned container. */
    autoFocus?: string | boolean;
    /** Duration of the enter animation. Has to be a valid CSS value (e.g. 100ms). */
    enterAnimationDuration?: string;
    /** Duration of the exit animation. Has to be a valid CSS value (e.g. 50ms). */
    exitAnimationDuration?: string;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 dialog base, composed from public portal and focus APIs.
 */

/** Event that captures the state of dialog container animations. */
interface LegacyDialogAnimationEvent {
    state: 'opened' | 'opening' | 'closing' | 'closed';
    totalTime: number;
}
/**
 * Base class for the legacy dialog container. Portal rendering, keyboard trapping
 * and focus monitoring remain owned by the current public peer primitives.
 */
declare abstract class _MatDialogContainerBase extends BasePortalOutlet implements OnDestroy {
    protected _elementRef: ElementRef;
    protected _focusTrapFactory: FocusTrapFactory;
    readonly _config: LegacyDialogRuntimeConfig;
    private _legacyFocusChecker;
    protected _ngZone: NgZone;
    private _legacyOverlayRef;
    private _legacyFocusMonitor?;
    /** Emits when an animation state changes. */
    _animationStateChanged: EventEmitter<LegacyDialogAnimationEvent>;
    _portalOutlet: CdkPortalOutlet;
    _closeInteractionType: FocusOrigin | null;
    _ariaLabelledByQueue: string[];
    protected _document: Document;
    private readonly _legacyFocusNotifications;
    private readonly _legacyFocusStableSubscriptions;
    private readonly _legacyChangeDetector;
    private readonly _legacyDialogRef;
    private readonly _legacyFocusPlatform;
    private readonly _legacyFocusRenderer;
    private _legacyFocusTrap;
    private _legacyPreviousFocus;
    private _legacyBackdropSubscription;
    private _legacyFocusDestroyed;
    private _legacyFocusCleanup;
    constructor(_elementRef: ElementRef, _focusTrapFactory: FocusTrapFactory, _document: any, _config: LegacyDialogRuntimeConfig, _legacyFocusChecker: InteractivityChecker, _ngZone: NgZone, _legacyOverlayRef: OverlayRef, _legacyFocusMonitor?: FocusMonitor | undefined);
    /** Starts the dialog exit animation. */
    abstract _startExitAnimation(): void;
    attachComponentPortal<T>(portal: ComponentPortal<T>): ComponentRef<T>;
    attachTemplatePortal<T>(portal: TemplatePortal<T>): EmbeddedViewRef<T>;
    /** Historical DOM-portal entry, delegated through the public generic protocol. */
    attachDomPortal: (portal: DomPortal) => void;
    hasAttached(): boolean;
    detach(): void;
    dispose(): void;
    protected _contentAttached(): void;
    _recaptureFocus(): void;
    /** Preserve the original direct-focus and public NgZone stability timing. */
    protected _trapFocus(): void;
    ngOnDestroy(): void;
    protected _captureInitialFocus(): void;
    protected _openAnimationDone(totalTime: number): void;
    private _assertContentAvailable;
    private _isBrowser;
    private _restoreLegacyFocus;
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatDialogContainerBase, [null, null, { optional: true; }, null, null, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<_MatDialogContainerBase, "ng-component", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Legacy dialog container motion follows Material 22's CSS + timer pattern
 * (no `@angular/animations` engine on the primary entry). Historical
 * `matDialogAnimations` / `matLegacyDialogAnimations` recipes live under
 * native CSS motion (historical `/animations` recipe secondary removed in F04).
 */

/**
 * Internal component that wraps user-provided dialog content.
 * Animation is based on https://material.io/guidelines/motion/choreography.html.
 * @docs-private
 */
declare class MatLegacyDialogContainer extends _MatDialogContainerBase implements OnDestroy {
    private _changeDetectorRef;
    private readonly _legacyAnimationsDisabled;
    /** Whether CSS transitions should run (MATERIAL_ANIMATIONS / reduced-motion / Noop). */
    readonly _animationsEnabled: boolean;
    private _enterAnimationDuration;
    private _exitAnimationDuration;
    private _animationTimer;
    private _animationFrame;
    private _animationRevision;
    private _animationDestroyed;
    private _animationCompleted;
    private _hostElement;
    /**
     * Animation phase string kept for historical specs that asserted the
     * engine trigger state. Mapped onto CSS enter/exit lifecycle.
     * @docs-private
     */
    _state: 'void' | 'enter' | 'exit';
    constructor(elementRef: ElementRef, focusTrapFactory: FocusTrapFactory, document: any, dialogConfig: MatLegacyDialogConfig, checker: InteractivityChecker, ngZone: NgZone, overlayRef: OverlayRef, _changeDetectorRef: ChangeDetectorRef, focusMonitor?: FocusMonitor);
    protected _contentAttached(): void;
    private _startOpenAnimation;
    /** Starts the dialog exit animation. */
    _startExitAnimation(): void;
    private _finishDialogOpen;
    private _finishDialogClose;
    private _clearAnimationClasses;
    private _waitForAnimationToComplete;
    private _requestAnimationFrame;
    private _cancelAnimationWork;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogContainer, [null, null, { optional: true; }, null, null, null, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyDialogContainer, "mat-dialog-container", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 dialog ref adapted for Angular 22 peers. Uses shared
 * `MatDialogState` / `DialogPosition` from `@angular/material/dialog`.
 */

/**
 * Reference to a dialog opened via the MatDialog service.
 */
declare class MatLegacyDialogRef<T, R = any> {
    private _ref;
    _containerInstance: _MatDialogContainerBase;
    /** The instance of component opened into the dialog. */
    componentInstance: T;
    /**
     * `ComponentRef` of the component opened into the dialog. Will be
     * undefined when the dialog is opened using a `TemplateRef`.
     */
    readonly componentRef: ComponentRef<T> | null | undefined;
    /** Whether the user is allowed to close the dialog. */
    disableClose: boolean | undefined;
    /** Unique ID for the dialog. */
    id: string;
    /** Subject for notifying the user that the dialog has finished opening. */
    private readonly _afterOpened;
    /** Subject for notifying the user that the dialog has started closing. */
    private readonly _beforeClosed;
    /** Result to be passed to afterClosed. */
    private _result;
    /** Handle to the timeout that's running as a fallback in case the exit animation doesn't fire. */
    private _closeFallbackTimeout;
    /** Subscriptions owned by this ref, including the pending animation phases. */
    private readonly _subscriptions;
    /** Prevent synchronous close observers from notifying beforeClosed twice. */
    private _beforeClosedEmitted;
    /** Current state of the dialog. */
    private _state;
    /** Interaction that caused the dialog to close. */
    private _closeInteractionType;
    constructor(_ref: DialogRef<R, T>, config: MatDialogConfig, _containerInstance: _MatDialogContainerBase);
    /** Close the dialog. */
    close(dialogResult?: R): void;
    /** Gets an observable that is notified when the dialog is finished opening. */
    afterOpened(): Observable<void>;
    /** Gets an observable that is notified when the dialog is finished closing. */
    afterClosed(): Observable<R | undefined>;
    /** Gets an observable that is notified when the dialog has started closing. */
    beforeClosed(): Observable<R | undefined>;
    /** Gets an observable that emits when the overlay's backdrop has been clicked. */
    backdropClick(): Observable<MouseEvent>;
    /** Gets an observable that emits when keydown events are targeted on the overlay. */
    keydownEvents(): Observable<KeyboardEvent>;
    /** Updates the dialog's position. */
    updatePosition(position?: DialogPosition): this;
    /** Updates the dialog's width and height. */
    updateSize(width?: string, height?: string): this;
    /** Add a CSS class or an array of classes to the overlay pane. */
    addPanelClass(classes: string | string[]): this;
    /** Remove a CSS class or an array of classes from the overlay pane. */
    removePanelClass(classes: string | string[]): this;
    /** Gets the current state of the dialog's lifecycle. */
    getState(): MatDialogState;
    private _notifyBeforeClosed;
    private _scheduleCloseFallback;
    private _finishDialogClose;
}
/**
 * Closes the dialog with the specified interaction type.
 * @docs-private
 */
declare function _closeDialogVia<R>(ref: MatLegacyDialogRef<R>, interactionType: FocusOrigin, result?: R): void;

/** @docs-private */
declare function MAT_DIALOG_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy;
/**
 * Base class for dialog services. The base dialog service allows
 * for arbitrary dialog refs and dialog container components.
 */
declare abstract class _MatDialogBase<C extends _MatDialogContainerBase> implements OnDestroy {
    private _overlay;
    private _defaultOptions;
    private _parentDialog;
    private _dialogRefConstructor;
    private _dialogContainerType;
    private _dialogDataToken;
    private readonly _openDialogsAtThisLevel;
    private readonly _afterAllClosedAtThisLevel;
    private readonly _afterOpenedAtThisLevel;
    private _scrollStrategy;
    protected _idPrefix: string;
    private _dialog;
    protected dialogConfigClass: typeof MatDialogConfig;
    /** Keeps track of the currently-open dialogs. */
    get openDialogs(): MatLegacyDialogRef<any>[];
    /** Stream that emits when a dialog has been opened. */
    get afterOpened(): Subject<MatLegacyDialogRef<any>>;
    private _getAfterAllClosed;
    /**
     * Stream that emits when all open dialog have finished closing.
     * Will emit on subscribe if there are no open dialogs to begin with.
     */
    readonly afterAllClosed: Observable<void>;
    constructor(_overlay: Overlay, injector: Injector, _defaultOptions: MatDialogConfig | undefined, _parentDialog: _MatDialogBase<C> | undefined, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 15.0.0
     */
    _overlayContainer: OverlayContainer, scrollStrategy: any, _dialogRefConstructor: Type<MatLegacyDialogRef<any>>, _dialogContainerType: Type<C>, _dialogDataToken: InjectionToken<any>, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 14.0.0
     */
    _animationMode?: 'NoopAnimations' | 'BrowserAnimations');
    open<T, D = any, R = any>(component: ComponentType<T>, config?: MatDialogConfig<D>): MatLegacyDialogRef<T, R>;
    open<T, D = any, R = any>(template: TemplateRef<T>, config?: MatDialogConfig<D>): MatLegacyDialogRef<T, R>;
    open<T, D = any, R = any>(template: ComponentType<T> | TemplateRef<T>, config?: MatDialogConfig<D>): MatLegacyDialogRef<T, R>;
    /** Closes all of the currently-open dialogs. */
    closeAll(): void;
    /**
     * Finds an open dialog by its id.
     * @param id ID to use when looking up the dialog.
     */
    getDialogById(id: string): MatLegacyDialogRef<any> | undefined;
    ngOnDestroy(): void;
    private _closeDialogs;
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatDialogBase<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<_MatDialogBase<any>>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Injection token that can be used to access the data that was passed in to a dialog.
 */
declare const MAT_LEGACY_DIALOG_DATA: InjectionToken<any>;
/**
 * Injection token that can be used to specify default dialog options.
 */
declare const MAT_LEGACY_DIALOG_DEFAULT_OPTIONS: InjectionToken<MatLegacyDialogConfig<any>>;
/**
 * Injection token that determines the scroll handling while the dialog is open.
 */
declare const MAT_LEGACY_DIALOG_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
/**
 * @docs-private
 */
declare function MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY(overlay: Overlay): () => ScrollStrategy;
/**
 * @docs-private
 */
declare const MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER: {
    provide: InjectionToken<() => ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY;
};
/**
 * Service to open Material Design modal dialogs.
 */
declare class MatLegacyDialog extends _MatDialogBase<MatLegacyDialogContainer> {
    protected dialogConfigClass: typeof MatLegacyDialogConfig;
    constructor(overlay: Overlay, injector: Injector, 
    /**
     * @deprecated `_location` parameter to be removed.
     * @breaking-change 10.0.0
     */
    _location: Location, defaultOptions: MatLegacyDialogConfig, scrollStrategy: any, parentDialog: MatLegacyDialog, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 15.0.0
     */
    overlayContainer: OverlayContainer, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 14.0.0
     */
    animationMode?: 'NoopAnimations' | 'BrowserAnimations');
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialog, [null, null, { optional: true; }, { optional: true; }, null, { optional: true; skipSelf: true; }, null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MatLegacyDialog>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Button that will close the current dialog.
 */
declare class MatLegacyDialogClose implements OnInit, OnChanges {
    /**
     * Reference to the containing dialog.
     * @deprecated `dialogRef` property to become private.
     * @breaking-change 13.0.0
     */
    dialogRef: MatLegacyDialogRef<any>;
    private _elementRef;
    private _dialog;
    /** Screen reader label for the button. */
    ariaLabel: string;
    /** Default to "button" to prevents accidental form submits. */
    type: 'submit' | 'button' | 'reset';
    /** Dialog close input. */
    dialogResult: any;
    _matDialogClose: any;
    constructor(
    /**
     * Reference to the containing dialog.
     * @deprecated `dialogRef` property to become private.
     * @breaking-change 13.0.0
     */
    dialogRef: MatLegacyDialogRef<any>, _elementRef: ElementRef<HTMLElement>, _dialog: MatLegacyDialog);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    _onButtonClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogClose, [{ optional: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyDialogClose, "[mat-dialog-close], [matDialogClose]", ["matDialogClose"], { "ariaLabel": { "alias": "aria-label"; "required": false; }; "type": { "alias": "type"; "required": false; }; "dialogResult": { "alias": "mat-dialog-close"; "required": false; }; "_matDialogClose": { "alias": "matDialogClose"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Title of a dialog element. Stays fixed to the top of the dialog when scrolling.
 */
declare class MatLegacyDialogTitle implements OnInit, OnDestroy {
    private _dialogRef;
    private _elementRef;
    private _dialog;
    /** Unique id for the dialog title. If none is supplied, it will be auto-generated. */
    id: string;
    constructor(_dialogRef: MatLegacyDialogRef<any>, _elementRef: ElementRef<HTMLElement>, _dialog: MatLegacyDialog);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogTitle, [{ optional: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyDialogTitle, "[mat-dialog-title], [matDialogTitle]", ["matDialogTitle"], { "id": { "alias": "id"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Scrollable content container of a dialog.
 */
declare class MatLegacyDialogContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyDialogContent, "[mat-dialog-content], mat-dialog-content, [matDialogContent]", never, {}, {}, never, never, false, never>;
}
/**
 * Container for the bottom action buttons in a dialog.
 * Stays fixed to the bottom when scrolling.
 */
declare class MatLegacyDialogActions {
    /**
     * Horizontal alignment of action buttons.
     */
    align?: 'start' | 'center' | 'end';
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogActions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyDialogActions, "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", never, { "align": { "alias": "align"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MatCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatCommonModule, never, [typeof i1.BidiModule], [typeof i1.BidiModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatCommonModule>;
}

declare class MatLegacyDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacyDialogModule, [typeof MatLegacyDialogContainer, typeof MatLegacyDialogClose, typeof MatLegacyDialogTitle, typeof MatLegacyDialogActions, typeof MatLegacyDialogContent], [typeof i3.DialogModule, typeof i4.OverlayModule, typeof i5.PortalModule, typeof MatCommonModule], [typeof MatLegacyDialogContainer, typeof MatLegacyDialogClose, typeof MatLegacyDialogTitle, typeof MatLegacyDialogContent, typeof MatLegacyDialogActions, typeof MatCommonModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacyDialogModule>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Duration defaults for legacy dialog open/close (CSS or recipe path).
 * Kept free of `@angular/animations` so the primary dialog entry can omit that peer.
 */
/**
 * Default parameters for the animation for backwards compatibility.
 * @docs-private
 */
declare const _defaultParams: {
    params: {
        enterAnimationDuration: string;
        exitAnimationDuration: string;
    };
};
/**
 * Alias used by the legacy dialog container template binding.
 * @docs-private
 * @deprecated Use `_defaultParams` instead.
 * @breaking-change 17.0.0
 */
declare const defaultParams: {
    params: {
        enterAnimationDuration: string;
        exitAnimationDuration: string;
    };
};

export { MAT_LEGACY_DIALOG_DATA, MAT_LEGACY_DIALOG_DEFAULT_OPTIONS, MAT_LEGACY_DIALOG_SCROLL_STRATEGY, MAT_DIALOG_SCROLL_STRATEGY_FACTORY as MAT_LEGACY_DIALOG_SCROLL_STRATEGY_FACTORY, MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER, MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY, MatCommonModule, MatLegacyDialog, MatLegacyDialogActions, MatLegacyDialogClose, MatLegacyDialogConfig, MatLegacyDialogContainer, MatLegacyDialogContent, MatLegacyDialogModule, MatLegacyDialogRef, MatLegacyDialogTitle, _MatDialogBase as _MatLegacyDialogBase, _MatDialogContainerBase as _MatLegacyDialogContainerBase, _closeDialogVia as _closeLegacyDialogVia, _defaultParams, defaultParams };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-dialog.d.ts.map
