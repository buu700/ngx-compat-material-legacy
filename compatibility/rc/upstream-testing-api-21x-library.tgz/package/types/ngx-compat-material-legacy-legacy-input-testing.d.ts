import { HarnessPredicate } from '@angular/cdk/testing';
import { MatInputHarness, InputHarnessFilters } from '@angular/material/input/testing';
export { InputHarnessFilters as LegacyInputHarnessFilters, NativeOptionHarnessFilters as LegacyNativeOptionHarnessFilters, NativeSelectHarnessFilters as LegacyNativeSelectHarnessFilters, MatNativeOptionHarness as MatLegacyNativeOptionHarness, MatNativeSelectHarness as MatLegacyNativeSelectHarness } from '@angular/material/input/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Harness for a legacy native input or textarea. */
declare class MatLegacyInputHarness extends MatInputHarness {
    static hostSelector: string;
    /** Keeps predicates bound to the legacy harness's native-property behavior. */
    static with(options?: InputHarnessFilters): HarnessPredicate<MatLegacyInputHarness>;
    /** Reads the native property, as the Material 16 legacy alias did. */
    isDisabled(): Promise<boolean>;
}

export { MatLegacyInputHarness };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-input-testing.d.ts.map
