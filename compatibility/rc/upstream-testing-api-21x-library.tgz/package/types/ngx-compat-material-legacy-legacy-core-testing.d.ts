import { BaseHarnessFilters, ComponentHarness, HarnessPredicate } from '@angular/cdk/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

interface LegacyOptionHarnessFilters extends BaseHarnessFilters {
    text?: string | RegExp;
    isSelected?: boolean;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a legacy `mat-option` in tests.
 */
declare class MatLegacyOptionHarness extends ComponentHarness {
    static hostSelector: string;
    private _text;
    static with(options?: LegacyOptionHarnessFilters): HarnessPredicate<MatLegacyOptionHarness>;
    click(): Promise<void>;
    getText(): Promise<string>;
    isDisabled(): Promise<boolean>;
    isSelected(): Promise<boolean>;
    isActive(): Promise<boolean>;
    isMultiple(): Promise<boolean>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

interface LegacyOptgroupHarnessFilters extends BaseHarnessFilters {
    labelText?: string | RegExp;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a legacy `mat-optgroup` in tests.
 */
declare class MatLegacyOptgroupHarness extends ComponentHarness {
    static hostSelector: string;
    private _label;
    static with(options?: LegacyOptgroupHarnessFilters): HarnessPredicate<MatLegacyOptgroupHarness>;
    getLabelText(): Promise<string>;
    isDisabled(): Promise<boolean>;
    getOptions(filter?: LegacyOptionHarnessFilters): Promise<MatLegacyOptionHarness[]>;
}

export { MatLegacyOptgroupHarness, MatLegacyOptionHarness };
export type { LegacyOptgroupHarnessFilters, LegacyOptionHarnessFilters };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-core-testing.d.ts.map
