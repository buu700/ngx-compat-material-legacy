import { BaseHarnessFilters, ContentContainerComponentHarness, HarnessPredicate } from '@angular/cdk/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * A set of criteria that can be used to filter a list of `MatCardHarness` instances.
 */
interface LegacyCardHarnessFilters extends BaseHarnessFilters {
    /** Only find instances whose text matches the given value. */
    text?: string | RegExp;
    /** Only find instances whose title matches the given value. */
    title?: string | RegExp;
    /** Only find instances whose subtitle matches the given value. */
    subtitle?: string | RegExp;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Selectors for different sections of the mat-card that can container user content.
 */
declare enum MatLegacyCardSection {
    HEADER = ".mat-card-header",
    CONTENT = ".mat-card-content",
    ACTIONS = ".mat-card-actions",
    FOOTER = ".mat-card-footer"
}
/**
 * Harness for interacting with a standard mat-card in tests.
 */
declare class MatLegacyCardHarness extends ContentContainerComponentHarness<MatLegacyCardSection> {
    /** The selector for the host element of a `MatCard` instance. */
    static hostSelector: string;
    /**
     * Gets a `HarnessPredicate` that can be used to search for a `MatCardHarness` that meets
     * certain criteria.
     * @param options Options for filtering which card instances are considered a match.
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: LegacyCardHarnessFilters): HarnessPredicate<MatLegacyCardHarness>;
    private _title;
    private _subtitle;
    /** Gets all of the card's content as text. */
    getText(): Promise<string>;
    /** Gets the cards's title text. */
    getTitleText(): Promise<string>;
    /** Gets the cards's subtitle text. */
    getSubtitleText(): Promise<string>;
}

export { MatLegacyCardHarness, MatLegacyCardSection };
export type { LegacyCardHarnessFilters };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-card-testing.d.ts.map
