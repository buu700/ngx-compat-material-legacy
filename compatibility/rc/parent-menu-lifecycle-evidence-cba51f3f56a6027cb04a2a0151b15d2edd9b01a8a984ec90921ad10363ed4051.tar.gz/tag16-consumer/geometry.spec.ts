import '@angular/compiler';
import 'zone.js'; import 'zone.js/testing';
import {Component, ElementRef, ViewChild, NgModule} from '@angular/core';
import {CommonModule, DOCUMENT} from '@angular/common';
import {TestBed} from '@angular/core/testing';
import {BrowserDynamicTestingModule, platformBrowserDynamicTesting} from '@angular/platform-browser-dynamic/testing';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {OverlayContainer} from '@angular/cdk/overlay';
import {ViewportRuler} from '@angular/cdk/scrolling';
import {MatLegacyMenuModule, MatLegacyMenuTrigger} from '@angular/material/legacy-menu';
import overlayCss from '@angular/cdk/overlay-prebuilt.css';
getTestBedInit();
function getTestBedInit() { TestBed.initTestEnvironment(BrowserDynamicTestingModule, platformBrowserDynamicTesting()); }
@Component({selector:'mat-icon',template:'<ng-content></ng-content>'}) class FakeIcon {}
@Component({template:`<button [matMenuTriggerFor]="menu" #triggerEl>Toggle menu</button><mat-menu #menu="matMenu"><button mat-menu-item>Item</button><button mat-menu-item disabled>Disabled</button><button mat-menu-item disableRipple><mat-icon>unicorn</mat-icon>Item with an icon</button><button mat-menu-item><span>Item with text inside span</span></button><button *ngFor="let item of extraItems" mat-menu-item>{{item}}</button></mat-menu>`})
class Host { @ViewChild(MatLegacyMenuTrigger) trigger!: MatLegacyMenuTrigger; @ViewChild('triggerEl') triggerEl!:ElementRef<HTMLElement>; extraItems:string[]=[]; }
for (const addCss of [false,true]) describe('tag16 geometry overlay css '+addCss,()=>{
 it('records tagged test geometry',()=>{
  let style: HTMLStyleElement|undefined; if(addCss){style=document.createElement('style');style.textContent=overlayCss;document.head.appendChild(style);}
  TestBed.configureTestingModule({imports:[CommonModule,MatLegacyMenuModule,NoopAnimationsModule],declarations:[Host,FakeIcon],providers:[{provide:DOCUMENT,useValue:document}]}).compileComponents();
  const fixture=TestBed.createComponent(Host);fixture.detectChanges();const triggerEl=fixture.componentInstance.triggerEl.nativeElement;triggerEl.style.position='absolute';triggerEl.style.left='200px';triggerEl.style.bottom='300px';triggerEl.click();fixture.detectChanges();
  const overlay=TestBed.inject(OverlayContainer).getContainerElement();const panel=overlay.querySelector('.mat-menu-panel') as HTMLElement;const height=TestBed.inject(ViewportRuler).getViewportSize().height;const before=panel.getBoundingClientRect();fixture.componentInstance.extraItems=new Array(50).fill('Hello there');fixture.detectChanges();const after=panel.getBoundingClientRect();
  fixture.componentInstance.trigger.updatePosition();fixture.detectChanges();const afterUpdate=panel.getBoundingClientRect();console.log('C04_TAG16_GEOMETRY '+JSON.stringify({addCss,height,innerHeight:window.innerHeight,clientHeight:document.documentElement.clientHeight,before:{top:before.top,bottom:before.bottom,height:before.height},after:{top:after.top,bottom:after.bottom,height:after.height},afterUpdate:{top:afterUpdate.top,bottom:afterUpdate.bottom,height:afterUpdate.height},scrollHeight:panel.scrollHeight,maxHeight:getComputedStyle(panel).maxHeight,bodyMargin:getComputedStyle(document.body).margin}));expect(panel).toBeTruthy();fixture.destroy();style?.remove();
 });
});
