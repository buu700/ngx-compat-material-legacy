"""Actual maintained lifecycle controls and helper CI census, no product gate."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
line=sys.argv[1];suffix='21' if line=='21.x' else 'main'
root=Path('/home/parallels/.codex/worktrees/codex-closeout-'+suffix+'/ngx-compat-material-legacy')
out=Path('/tmp/parent-lifecycle-maintained-integration-'+suffix+'-v1.json')
plan=Path('/tmp/parent-lifecycle-helper-plan-'+suffix+'-v1.json')
node=Path('/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node')
python=Path('/nix/store/lfh101cfjj8p8npcari9hk0lbqi33yvh-python3-3.14.7/bin/python3')
assert line in ['21.x','main'] and not out.exists() and not plan.exists()
env={k:v for k,v in os.environ.items() if not k.startswith(('RC_','GIT_')) and k not in ['NODE_OPTIONS','NODE_PATH','PYTHONPATH','PYTHONHOME','PYTHONOPTIMIZE']}
env.update(PYTHONDONTWRITEBYTECODE='1',PATH=str(node.parent)+':'+str(python.parent)+':'+env['PATH'])
paths=['scripts/check-companion-computed-styles.mjs','tests/chromium-lifecycle-process-controls.mjs','tests/test_chromium_lifecycle_process_controls.py','.node-version','scripts/helper_ci.py']
def sha(b):return hashlib.sha256(b).hexdigest()
def snapshot():
 return [dict(path=p,sha256=sha((root/p).read_bytes()),bytes=len((root/p).read_bytes())) for p in paths]
before=snapshot();commands=[]
for name,command in [('controls',[str(python),'-B','-m','unittest','discover','-s','tests','-p','test_chromium_lifecycle_process_controls.py','-v']),('census',[str(python),'-B','scripts/helper_ci.py','plan','--out',str(plan)])]:
 start=time.monotonic();child=subprocess.Popen(command,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 print(json.dumps(dict(line=line,stage=name,state='started',pid=child.pid)),flush=True)
 expired=False
 try:stdout,stderr=child.communicate(timeout=150)
 except subprocess.TimeoutExpired:
  expired=True
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  stdout,stderr=child.communicate()
 commands.append(dict(stage=name,command=command,seconds=time.monotonic()-start,exit_code=child.returncode,timed_out=expired,stdout=stdout,stderr=stderr))
 if child.returncode or expired:break
after=snapshot();census=None
if plan.exists():
 p=json.loads(plan.read_bytes());rows=[r for r in p['modules'] if r['path']=='tests/test_chromium_lifecycle_process_controls.py'];assert len(rows)==1
 census=dict(plan_path=str(plan),sha256=sha(plan.read_bytes()),module=rows[0])
passed=len(commands)==2 and all(r['exit_code']==0 and not r['timed_out'] for r in commands) and before==after and census is not None
record=dict(scope='Actual maintained eleven-process-control Python wrapper and real helper CI census only; no product, source regression, owner or G11 qualification',line=line,before=before,after=after,source_unchanged=before==after,commands=commands,census=census,passed=passed,g11_claim='not-passed')
with out.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(dict(line=line,passed=passed,receipt=str(out))),flush=True)
if not passed:raise SystemExit(1)
