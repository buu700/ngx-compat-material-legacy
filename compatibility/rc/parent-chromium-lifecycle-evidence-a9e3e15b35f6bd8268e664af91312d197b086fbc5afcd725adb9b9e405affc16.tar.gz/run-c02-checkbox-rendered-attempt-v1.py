"""One isolated packed mixed-checkbox diagnostic, never publication."""
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import time

ROOT=Path('/home/parallels/.codex/worktrees/c02-checkbox-rendered/ngx-compat-material-legacy')
HEAD='1fb34a5b54b89e443522d8ca2c7d7afb981f428b'
ARTIFACT=Path('/tmp/c02-checkbox-artifact-1fb34a5b-v1')
OUT=Path('/tmp/c02-checkbox-rendered-attempt-v1.json')
NODE=Path('/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node')
PNPM=Path('/nix/store/kihdwpai73bk2z942hwkr9gildyxkrww-pnpm-12.4.2/bin/pnpm')
PROBE=Path('/tmp/c02-checkbox-rendered-draft-v1/probe-isolated-v1.mjs')
assert not OUT.exists() and not ARTIFACT.exists()
assert NODE.is_file() and PNPM.is_file()
env={k:v for k,v in os.environ.items() if not k.startswith(('RC_','GIT_')) and k not in ('NODE_OPTIONS','NODE_PATH','NODE_V8_COVERAGE')}
env.update(C02_SOURCE_ROOT=str(ROOT),npm_config_offline='true',npm_config_update_notifier='false',npm_config_manage_package_manager_versions='false',GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
env['PATH']=str(NODE.parent)+':'+str(PNPM.parent)+':'+env['PATH']
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-c','gc.auto=0','-c','maintenance.auto=0',*args],cwd=ROOT,env=env)
def snapshot():
 assert git('rev-parse','HEAD').decode().strip()==HEAD
 files=[]
 for raw in sorted(filter(None,git('ls-files','-z').split(b'\0'))):
  path=raw.decode();file=ROOT/path;st=file.lstat();assert stat.S_ISREG(st.st_mode)
  b=file.read_bytes();files.append(dict(path=path,sha256=sha(b),bytes=len(b),mode=stat.S_IMODE(st.st_mode)))
 return dict(head=HEAD,status=git('status','--porcelain','--untracked-files=all').decode(),files=files)
before=snapshot();assert before['status']==''
versions={name:subprocess.check_output([str(tool),'--version'],cwd=ROOT,env=env,text=True,timeout=30).strip() for name,tool in [('node',NODE),('pnpm',PNPM),('npm',NODE.parent/'npm')]}
assert versions=={'node':'v24.21.0','pnpm':'12.4.2','npm':'11.19.0'},versions
record=dict(scope='One actual packed 21.x mixed-checkbox diagnostic; no full coexistence, floor, G11 or release qualification',source_root=str(ROOT),head=HEAD,tool_versions=versions,execution='Declared maintained pack-draft Node entry with existing pinned dependencies; no setup or dependency refresh while maintained source gates are live',before=before,commands=[],g11_claim='not-passed')
for name,command,timeout in [('pack',[str(NODE),'scripts/pack-draft-run.mjs','--line','21.x','--out',str(ARTIFACT)],600),('render',[str(NODE),str(PROBE),str(ARTIFACT/'run.json'),HEAD],900)]:
 started=time.monotonic();child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 print(json.dumps(dict(stage=name,state='started',pid=child.pid,timeout_seconds=timeout)),flush=True)
 expired=False
 try:stdout,stderr=child.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  expired=True
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  stdout,stderr=child.communicate()
 result=dict(stage=name,command=command,seconds=time.monotonic()-started,exit_code=child.returncode,timed_out=expired,stdout=stdout,stderr=stderr)
 record['commands'].append(result)
 print(json.dumps({k:v for k,v in result.items() if k not in ('stdout','stderr','command')}),flush=True)
 if child.returncode or expired:break
after=snapshot();record.update(after=after,source_unchanged=before==after)
record['all_commands_succeeded']=len(record['commands'])==2 and all(r['exit_code']==0 and not r['timed_out'] for r in record['commands'])
for path in [PROBE,PROBE.with_name('main.ts'),PROBE.with_name('theme.scss'),PROBE.with_name('WORKSHEET.md')]:
 b=path.read_bytes();record.setdefault('diagnostic_inputs',[]).append(dict(path=str(path),sha256=sha(b),bytes=len(b)))
with OUT.open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(dict(state='terminal',receipt=str(OUT),all_commands_succeeded=record['all_commands_succeeded'],source_unchanged=record['source_unchanged'])),flush=True)
if not record['all_commands_succeeded'] or not record['source_unchanged']:raise SystemExit(1)
