"""One actual artifact-bound rendering with reviewed lifecycle prototype; no gate credit."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import time

ROOT=Path('/home/parallels/.codex/worktrees/c02-checkbox-rendered/ngx-compat-material-legacy')
HEAD='1fb34a5b54b89e443522d8ca2c7d7afb981f428b'
RUN=Path('/tmp/c02-checkbox-artifact-1fb34a5b-v1/run.json')
OUT=Path('/tmp/c02-checkbox-rendered-attempt-v3.json')
NODE=Path('/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node')
PROBE=Path('/tmp/c02-checkbox-rendered-draft-v1/probe-isolated-v1.mjs')
assert not OUT.exists() and RUN.is_file() and NODE.is_file()
env={k:v for k,v in os.environ.items() if not k.startswith(('RC_','GIT_')) and k not in ('NODE_OPTIONS','NODE_PATH','NODE_V8_COVERAGE')}
env.update(C02_SOURCE_ROOT=str(ROOT),npm_config_offline='true',npm_config_update_notifier='false',npm_config_manage_package_manager_versions='false',GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
env['PATH']=str(NODE.parent)+':'+env['PATH']
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-c','gc.auto=0','-c','maintenance.auto=0',*args],cwd=ROOT,env=env)
def snapshot():
 assert git('rev-parse','HEAD').decode().strip()==HEAD
 files=[]
 for raw in sorted(filter(None,git('ls-files','-z').split(b'\0'))):
  path=raw.decode();file=ROOT/path;st=file.lstat();assert stat.S_ISREG(st.st_mode)
  b=file.read_bytes();files.append(dict(path=path,sha256=sha(b),bytes=len(b),mode=stat.S_IMODE(st.st_mode)))
 inputs=[]
 for p in [RUN,PROBE,PROBE.with_name('main.ts'),PROBE.with_name('theme.scss'),PROBE.with_name('WORKSHEET.md')]:
  b=p.read_bytes();inputs.append(dict(path=str(p),sha256=sha(b),bytes=len(b)))
 return dict(head=HEAD,status=git('status','--porcelain','--untracked-files=all').decode(),files=files,inputs=inputs)
before=snapshot();assert before['status']==' M scripts/check-companion-computed-styles.mjs\n'
assert next(x for x in before['files'] if x['path']=='scripts/check-companion-computed-styles.mjs')['sha256']=='33b978d346ff4891ab5b338b5ca2004ca2ed4d667ff18b6843f34c9743fc9559'
command=[str(NODE),str(PROBE),str(RUN),HEAD]
start=time.monotonic();child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
print(json.dumps(dict(stage='render',state='started',pid=child.pid,timeout_seconds=900)),flush=True)
expired=False
try:stdout,stderr=child.communicate(timeout=900)
except subprocess.TimeoutExpired:
 expired=True
 try:os.killpg(child.pid,signal.SIGKILL)
 except ProcessLookupError:pass
 stdout,stderr=child.communicate()
after=snapshot()
scope_path=OUT.with_suffix('.source.json.gz')
scope=gzip.compress((json.dumps(dict(before=before,after=after),sort_keys=True)+'\n').encode(),mtime=0)
with scope_path.open('xb') as f:f.write(scope)
record=dict(scope='One real packed 21.x mixed-checkbox observation with reviewed dirty lifecycle helper; no complete C02/C03, floor, owner, G11 or release qualification',source_root=str(ROOT),head=HEAD,command=command,seconds=time.monotonic()-start,exit_code=child.returncode,timed_out=expired,stdout=stdout,stderr=stderr,source_unchanged=before==after,source_snapshot=dict(path=str(scope_path),sha256=sha(scope),bytes=len(scope)),g11_claim='not-passed')
with OUT.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('stdout','stderr','command')}),flush=True)
if child.returncode or expired or before!=after:raise SystemExit(1)
