// Disposable diagnostic only: no gate credit, no changes to maintained sources.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {readFileSync, writeFileSync, realpathSync, mkdtempSync} from 'node:fs';
import {join, resolve, relative} from 'node:path';
import {tmpdir} from 'node:os';
import {pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';
const root='/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy';
const draft='/tmp/c02-checkbox-rendered-draft-v1';
const {resolveLibraryFromRun,sha256File}=await import(pathToFileURL(join(root,'scripts/resolve-run-library.mjs')));
const {readPackedPackage,versionsFor,buildLab,withChromium}=await import(pathToFileURL(join(root,'scripts/check-companion-computed-styles.mjs')));
const [runArg, expectedHead]=process.argv.slice(2);assert.ok(runArg&&/^[a-f0-9]{40}$/.test(expectedHead||''),'supply run.json and exact source head');
const head=()=>{const p=spawnSync('git',['--no-replace-objects','rev-parse','HEAD'],{cwd:root,encoding:'utf8'});assert.equal(p.status,0);return p.stdout.trim();};
assert.equal(head(),expectedHead);
const sha=b=>createHash('sha256').update(b).digest('hex');
for(const [path,expected] of [['src/material/core/theming/_palette.scss','86fcb97f4fe3c1c005edc4840c48ebe7a677d35fa558988db62fb268b0aef300'],['src/material/legacy-checkbox/_checkbox-theme.scss','f50e3f7ec838c204e1ef92c4ceed4b6b4f4aae38602fc3a69b58e5e5c796d3f1'],['src/material/checkbox/_checkbox-theme.scss','856a480f6fd480f5b720dba992fa0eb630ea8a2c004476a91e3795f0cb514c80'],['src/material/core/tokens/m2/mdc/_checkbox.scss','8a51236695e9db931bbc315ded26bdb855b9a44b77a14e8a71b3420cc9d11c1b'],['src/material/checkbox/checkbox.scss','76b1e1991b12dd28d2f1df602c5f3cb1de75da93154ea381e30b0ce1818db5ac']]){const p=spawnSync('git',['--no-replace-objects','show','df60e733c60e572ba538f6ad0ceff3e63e527b53:'+path],{cwd:root,maxBuffer:16*1024*1024});assert.equal(p.status,0);assert.equal(sha(p.stdout),expected,'tagged16 reference mismatch '+path);}
assert.equal(sha(readFileSync('/tmp/closeout-configurable-sort-tree-20261015-m02wodg4/reference16/node_modules/@material/checkbox/_checkbox-theme.scss')),'90823b9219a5d38d6c57f9294fbc720e650c7ffd13d8f9b64a57228499200abf','tagged16 original MDC checkbox source missing or changed');
assert.equal(sha(readFileSync(join(root,'projects/ngx-material-legacy/styles/core/tokens/m2/mdc/_checkbox.scss'))),'5b3924089e17121d456084ff1b0eaaa20a6c301bd88c28503cd058a888944819','owned M2 input changed');
const run=resolveLibraryFromRun(resolve(runArg));assert.equal(run.line,'21.x');assert.equal(run.draft.source.commit,expectedHead,'artifact source commit mismatch');assert.equal(run.draft.source.clean,true,'artifact source not clean');
const pkg=readPackedPackage(run.tarball),versions=versionsFor(pkg);
assert.equal(pkg.peerDependencies['@angular/core'],'^21.2.23');assert.equal(pkg.peerDependencies['@angular/material'],'^21.2.14');assert.equal(pkg.peerDependencies['@angular/cdk'],'^21.2.14');
assert.equal(versions.core,'21.2.23');assert.equal(versions.material,'21.2.14');assert.equal(versions.cdk,'21.2.14');
assert.equal(process.env.npm_config_offline,'true','require offline cached exact peer packages');
const started=Date.now(),consumer=mkdtempSync(join(tmpdir(),'checkbox-mixed-')),nm=join(consumer,'node_modules'),localTar=join(consumer,'library.tgz');
writeFileSync(localTar,readFileSync(run.tarball));assert.equal(sha256File(localTar),run.digest);
const deps={'@angular/cdk':versions.cdk,'@angular/common':versions.core,'@angular/compiler':versions.core,'@angular/compiler-cli':versions.core,'@angular/core':versions.core,'@angular/forms':versions.core,'@angular/material':versions.material,'@angular/platform-browser':versions.core,'@angular/platform-browser-dynamic':versions.core,'@ngx-compat/material-legacy':'file:'+localTar,rxjs:versions.rxjs,tslib:versions.tslib,typescript:versions.typescript,'zone.js':versions.zone};
writeFileSync(join(consumer,'package.json'),JSON.stringify({name:'checkbox-mixed-diagnostic',private:true,dependencies:deps},null,2));
const env={...process.env,NODE_OPTIONS:'',npm_config_offline:'true',npm_config_update_notifier:'false'};delete env.NODE_PATH;
const install=spawnSync('npm',['install','--offline','--ignore-scripts','--no-audit','--no-fund','--package-lock'],{cwd:consumer,env,encoding:'utf8',timeout:600000});
assert.equal(install.status,0,'offline install failed: '+String(install.stderr||install.stdout).slice(-3000));
const installed=realpathSync(join(nm,'@ngx-compat/material-legacy'));assert.ok(!relative(consumer,installed).startsWith('..'));
for(const [name,v] of [['@angular/core',versions.core],['@angular/material',versions.material],['@angular/cdk',versions.cdk]])assert.equal(JSON.parse(readFileSync(join(nm,name,'package.json'))).version,v);
const sass=createRequire(join(root,'package.json'))('sass'),source=readFileSync(join(draft,'main.ts'),'utf8'),scss=readFileSync(join(draft,'theme.scss'),'utf8');
const compiled=sass.compileString(scss,{loadPaths:[nm],url:pathToFileURL(join(consumer,'checkbox-probe.scss')),style:'expanded',silenceDeprecations:['if-function','global-builtin','color-functions','import']});
const allowed=[realpathSync(installed),realpathSync(join(nm,'@angular/material')),realpathSync(join(nm,'@angular/cdk'))];
const loaded=compiled.loadedUrls.filter(x=>x.protocol==='file:'&&x.pathname!==join(consumer,'checkbox-probe.scss')).map(x=>realpathSync(x.pathname));
for(const p of loaded)assert.ok(allowed.some(a=>p.startsWith(a+'/')),'unexpected Sass source '+p);
await buildLab(consumer,env,versions,source);const dist=join(consumer,'dist');writeFileSync(join(dist,'theme.css'),compiled.css);
writeFileSync(join(dist,'index.html'),'<!doctype html><html><head><link rel="stylesheet" href="/theme.css"><style>body{margin:20px}section{display:flex;gap:20px;margin:30px}label{cursor:pointer}</style></head><body><lab-root></lab-root><script src="/app.js"></script></body></html>');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const rendered=await withChromium(dist,async ({evaluate,send,browser})=>{
 for(let i=0;i<200;i++){if(await evaluate('window.__checkboxReady === true || !!document.querySelector("#bootstrap-error")'))break;await sleep(100);}
 assert.equal(await evaluate('document.querySelector("#bootstrap-error")?.textContent || null'),null);assert.equal(await evaluate('window.__checkboxReady'),true);
 const read=async id=>await evaluate(`(()=>{const h=document.getElementById(${JSON.stringify(id)}),i=h?.querySelector('input[type=checkbox]'),current=h?.tagName.toLowerCase()==='current-box',box=h?.querySelector(current?'.mdc-checkbox__background':'.mat-checkbox-background'),frame=h?.querySelector(current?'.mdc-checkbox__background':'.mat-checkbox-frame');if(!h||!i||!box||!frame)throw Error('missing fixture nodes '+${JSON.stringify(id)});const s=getComputedStyle(box),f=getComputedStyle(frame),r=box.getBoundingClientRect();return {checked:i.checked,disabled:i.disabled,background:s.backgroundColor,border:f.borderTopColor,visible:r.width>0&&r.height>0,box:{x:r.x,y:r.y,width:r.width,height:r.height}}})()`);
 const ids=['pink-current','pink-legacy','blue-current','blue-legacy','pink-current-disabled-selected','pink-current-disabled-empty','pink-legacy-disabled-selected','pink-legacy-disabled-empty'];
 const before={};for(const id of ids)before[id]=await read(id);
 for(const id of ids.slice(0,4)){const row=before[id];assert.ok(row.visible&&!row.checked&&!row.disabled);const x=row.box.x+row.box.width/2,y=row.box.y+row.box.height/2;await send('Input.dispatchMouseEvent',{type:'mouseMoved',x,y});await send('Input.dispatchMouseEvent',{type:'mousePressed',x,y,button:'left',buttons:1,clickCount:1});await send('Input.dispatchMouseEvent',{type:'mouseReleased',x,y,button:'left',buttons:0,clickCount:1});await sleep(500);assert.equal((await read(id)).checked,true,'real pointer click did not check '+id);}
 await send('Input.dispatchMouseEvent',{type:'mouseMoved',x:1200,y:900});await sleep(500);
 const after={};for(const id of ids)after[id]=await read(id);
 const failures=[];const eq=(actual,expected,label)=>{if(actual!==expected)failures.push({label,actual,expected});};
 for(const kind of ['current','legacy']){eq(before['pink-'+kind].border,'rgba(0, 0, 0, 0.54)',kind+' unselected border');eq(after['pink-'+kind].background,'rgb(255, 64, 129)',kind+' pink A200 selected fill');eq(after['blue-'+kind].background,'rgb(68, 138, 255)',kind+' blue A200 selected fill');if(after['pink-'+kind].background===after['blue-'+kind].background)failures.push({label:kind+' changed accent negative',actual:after['pink-'+kind].background});}
 for(const kind of ['current','legacy'])for(const state of ['selected','empty']){const d=after['pink-'+kind+'-disabled-'+state];assert.ok(d.visible&&d.disabled);assert.equal(d.checked,state==='selected');}
 eq(after['pink-legacy-disabled-selected'].background,'rgb(176, 176, 176)','legacy disabled selected fill');eq(after['pink-legacy-disabled-empty'].border,'rgb(176, 176, 176)','legacy disabled empty border');
 eq(after['pink-current-disabled-selected'].background,'rgba(0, 0, 0, 0.38)','current disabled selected fill');eq(after['pink-current-disabled-empty'].border,'rgba(0, 0, 0, 0.38)','current disabled empty border');
 return {browser,before,after,failures};
},{debugPort:9347});
assert.equal(head(),expectedHead);assert.equal(sha256File(run.tarball),run.digest,'packed bytes changed');
const hash=s=>createHash('sha256').update(s).digest('hex');
console.log(JSON.stringify({scope:'diagnostic one mixed checkbox observation, no gate credit',result:rendered.failures.length?'fail':'pass',head:expectedHead,artifact:{path:run.tarball,sha256:run.digest,bytes:run.bytes},versions,node:process.version,npm_lock_sha256:sha(readFileSync(join(consumer,'package-lock.json'))),browser:rendered.browser,fixture_sha256:hash(source),scss_sha256:hash(scss),compiled_css_sha256:hash(compiled.css),loaded,seconds:(Date.now()-started)/1000,observations:rendered}));
if(rendered.failures.length)process.exitCode=1;
