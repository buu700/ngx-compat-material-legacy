import 'zone.js';
import {AfterViewInit, Component, Input, provideZoneChangeDetection} from '@angular/core';
import {bootstrapApplication} from '@angular/platform-browser';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatLegacyCheckboxModule} from '@ngx-compat/material-legacy/legacy-checkbox';
import {MATERIAL_ANIMATIONS} from '@angular/material/core';
// The two implementations share the mat-checkbox selector. Separate standalone
// template scopes prevent Angular from matching both components to one node.
@Component({standalone:true, selector:'current-box', imports:[MatCheckboxModule], template:`<mat-checkbox color="accent" [disabled]="disabled" [checked]="checked">Current</mat-checkbox>`})
class CurrentBox { @Input() disabled=false; @Input() checked=false; }
@Component({standalone:true, selector:'legacy-box', imports:[MatLegacyCheckboxModule], template:`<mat-checkbox color="accent" [disabled]="disabled" [checked]="checked">Legacy</mat-checkbox>`})
class LegacyBox { @Input() disabled=false; @Input() checked=false; }
@Component({standalone: true, selector: 'lab-root', imports: [CurrentBox, LegacyBox], template: `
  <section class="pink" id="pink">
    <current-box id="pink-current"></current-box>
    <current-box id="pink-current-disabled-selected" [checked]="true" [disabled]="true"></current-box>
    <current-box id="pink-current-disabled-empty" [disabled]="true"></current-box>
    <legacy-box id="pink-legacy"></legacy-box>
    <legacy-box id="pink-legacy-disabled-selected" [checked]="true" [disabled]="true"></legacy-box>
    <legacy-box id="pink-legacy-disabled-empty" [disabled]="true"></legacy-box>
  </section>
  <section class="blue" id="blue">
    <current-box id="blue-current"></current-box>
    <legacy-box id="blue-legacy"></legacy-box>
  </section>`})
class Lab implements AfterViewInit { ngAfterViewInit() { (window as any).__checkboxReady = true; } }
bootstrapApplication(Lab, {providers: [provideZoneChangeDetection(), {provide: MATERIAL_ANIMATIONS, useValue: {animationsDisabled: true}}]}).catch(err => {
 const n=document.createElement('pre'); n.id='bootstrap-error'; n.textContent=String(err?.stack || err); document.body.appendChild(n);
});
