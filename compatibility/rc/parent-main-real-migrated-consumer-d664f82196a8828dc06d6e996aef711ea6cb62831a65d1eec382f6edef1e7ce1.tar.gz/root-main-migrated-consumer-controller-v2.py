from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,traceback,tarfile
ROOT=Path('/tmp/root-main-migrated-consumer-v2')
RUN=Path('/tmp/root-main-migrated-consumer-v2-run')
OLD=Path('/tmp/main-real-migrated-consumer-sol6-v1/run')
NODE='/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node'
STATE=Path('/tmp/root-main-migrated-consumer-state-v2.json')
LOG=Path('/tmp/root-main-migrated-consumer-execution-v2.log')
REPORT=RUN/'old-workspace-cli.json'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s={'schema_version':1,'role':'durable-main-real-packaged-migrated-consumer-iteration','controller_pid':os.getpid(),'source_parent':'0da0a92934ffae20098de762d78c329dc932c04c','source_root':str(ROOT),'candidate_path':'scripts/migrated-consumer-proof.mjs','candidate_sha256':sha(ROOT/'scripts/migrated-consumer-proof.mjs'),'started_at':now(),'status':'preflight','log':str(LOG),'limits':['Standalone unsealed diagnostic run, no coordinator invocation or G gate pass.','Migration browser callsite is a proposed source change in disposable clone.','Exact tarballs retain original build provenance; current product and CLI source have not changed.']}
def save():
 tmp=STATE.with_suffix('.new');tmp.write_text(json.dumps(s,indent=2)+'\n');tmp.replace(STATE)
def wait_sass():
 st=Path('/tmp/root-main-sass-after-select-dialog-v5-state-v2.json')
 while True:
  x=json.loads(st.read_bytes());pid=x.get('child_pid');p=Path('/proc')/str(pid)
  live=False
  if p.exists():
   try:
    args=(p/'cmdline').read_bytes().rstrip(b'\0').decode().split('\0')
    live=len(args)>1 and args[0]==NODE and args[1]=='scripts/sass-seal.mjs' and (p/'stat').read_text().split()[2]!='Z'
   except OSError:pass
  if not live:
   s['prior_sass_observed_status']=x.get('status');save();return
  s.update(status='waiting-for-owned-sass-process',waiting_pid=pid,last_observed_at=now());save();time.sleep(10)
try:
 assert not RUN.exists();RUN.mkdir();(RUN/'inputs').mkdir()
 old=json.loads((OLD/'run.json').read_bytes());manifest=dict(old)
 manifest.update(run_id='main-real-migrated-consumer-v2',created_at=now())
 manifest['execution_source']={'git_parent':s['source_parent'],'candidate_changes':[{'path':s['candidate_path'],'sha256':s['candidate_sha256']}],'scope':'standalone browser acquisition repair; no release qualification'}
 for a in manifest['artifacts']:
  original=OLD/a['path'];assert sha(original)==a['sha256'];assert original.stat().st_size==a['bytes'];shutil.copyfile(original,RUN/a['path'])
 with tarfile.open(RUN/'inputs/migrate-cli.tgz','r:gz') as tf:
  s['exact_cli_members']=[{'path':m.name,'bytes':m.size} for m in tf.getmembers() if m.isfile()]
 (RUN/'run.json').write_text(json.dumps(manifest,indent=2)+'\n')
 s['manifest_sha256']=sha(RUN/'run.json');save();wait_sass()
 assert sha(ROOT/s['candidate_path'])==s['candidate_sha256']
 env=dict(os.environ)
 env['PATH']='/tmp/root-main-sass-runtime-v1/bin:'+str(Path(NODE).parent)+':'+env['PATH']
 env['CHROME_BIN']='/nix/store/cfr0bikmf9nz75lsx095xacnmis6drgb-playwright-chromium/chrome-linux/chrome-wrapper'
 env['NODE_OPTIONS']='--max-old-space-size=1024'
 for name in list(env):
  if name.startswith('RC_'):del env[name]
 args=[NODE,'scripts/check-old-workspace-cli.mjs','--run',str(RUN/'run.json'),'--out',str(REPORT)]
 with LOG.open('xb') as log:
  child=subprocess.Popen(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  s.update(status='running',child_pid=child.pid,command=args,execution_started_at=now());save()
  while child.poll() is None:
   s.update(last_observed_at=now(),log_bytes=LOG.stat().st_size);save();time.sleep(10)
  s.update(status='passed' if child.returncode==0 else 'failed',exit_code=child.returncode,finished_at=now(),log_sha256=sha(LOG),log_bytes=LOG.stat().st_size)
 if REPORT.exists():s.update(report=str(REPORT),report_sha256=sha(REPORT))
 save()
except BaseException as e:
 s.update(status='controller-error',error=repr(e),traceback=traceback.format_exc(),finished_at=now());save();raise
