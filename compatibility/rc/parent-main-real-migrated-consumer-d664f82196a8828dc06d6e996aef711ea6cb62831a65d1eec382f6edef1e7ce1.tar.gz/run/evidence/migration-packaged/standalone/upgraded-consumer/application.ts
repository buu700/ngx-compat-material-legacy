
import 'zone.js';
import {AfterViewInit, Component, ViewChild, provideZoneChangeDetection} from '@angular/core';
import {bootstrapApplication} from '@angular/platform-browser';
import {FormControl, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatLegacyButtonModule} from '@ngx-compat/material-legacy/legacy-button';
import {MatLegacySelect, MatLegacySelectModule} from '@ngx-compat/material-legacy/legacy-select';
import {MatLegacyOptionModule} from '@ngx-compat/material-legacy/legacy-core';
@Component({standalone: true, selector: 'migrated-app', imports: [MatLegacyButtonModule, MatLegacySelectModule, MatLegacyOptionModule, ReactiveFormsModule],
 template: '<button mat-raised-button id="migrated-button">Migrated</button><mat-select [formControl]="control"><mat-option value="yes">Yes</mat-option></mat-select>'})
export class MigratedApplication implements AfterViewInit {
 control = new FormControl('', {nonNullable: true, validators: Validators.required});
 @ViewChild(MatLegacySelect) select!: MatLegacySelect;
 ngAfterViewInit() { (window as any).__migratedApp = this; }
}
bootstrapApplication(MigratedApplication, {providers: [provideZoneChangeDetection()]}).catch(error => {
 (window as any).__migrationError = String(error);
});
