# @license
# Copyright Google LLC All Rights Reserved.
# Copyright (c) 2026 Ryan Lester.
# Use of this source code is governed by an MIT-style license that can be
# found in the LICENSE file at https://angular.io/license
"""Public, read-only source recovery authenticated against the complete original census."""
import difflib, gzip, hashlib, json, os, pathlib, subprocess, tempfile, urllib.request

root = pathlib.Path('/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy')
cache = pathlib.Path('/home/parallels/.cache/ngx-material-legacy-upstream-blobs')
cache.mkdir(parents=True, exist_ok=True)
shas = ['4de7c0fb2d033bd81074764a52cc46edd02e6774', '54d514df66b9a1ea544df0aacc7069defcd78dcd',
        '3619903fa26910a784f01bee627e30d922b9b525', '85f596b3c32d22541c3825da3479b67832a2f4da',
        '9cf15019d9d82bcb7460df5febd898a1b1eec59b', '3ef56a682fa797563d3269f18769ddceda05f760']
census_path = 'compatibility/rc/upstream-complete-patch-census.json.gz'
census_bytes = (root/census_path).read_bytes()
census = json.loads(gzip.decompress(census_bytes))
digest = lambda raw: hashlib.sha256(raw).hexdigest()
def git_object(kind, raw):
    return hashlib.sha1(f'{kind} {len(raw)}\0'.encode()+raw).hexdigest()

subjects, errors = [], []
for sha in shas:
    row = next(r for r in census['commits'] if r['sha'] == sha)
    assert git_object('commit', row['raw_commit'].encode()) == sha
    assert len(row['parents']) == 1
    parent, members = row['parents'][0], []
    try:
        for member in row['complete_changed_files']:
            sides = {}
            for side, commit in [('before', parent), ('after', sha)]:
                blob = member[side+'_blob']
                if blob == '0'*40:
                    sides[side] = {'text': '', 'git_blob': blob, 'absent': True}
                    continue
                stored = cache/blob
                url = 'https://raw.githubusercontent.com/angular/components/'+commit+'/'+member['path']
                if stored.exists():
                    raw = stored.read_bytes()
                else:
                    request = urllib.request.Request(url, headers={'User-Agent': 'ngx-compat-closeout-source-review'})
                    with urllib.request.urlopen(request, timeout=20) as response:
                        assert response.status == 200
                        raw = response.read(4*1024*1024+1)
                    assert len(raw) <= 4*1024*1024
                    assert git_object('blob', raw) == blob, 'public source bytes differ from authenticated original blob'
                    with stored.open('xb') as output:
                        output.write(raw)
                assert git_object('blob', raw) == blob, 'cached source identity mismatch'
                sides[side] = {'text': raw.decode('utf-8'), 'git_blob': blob, 'sha256': digest(raw), 'bytes': len(raw), 'url': url}
            members.append({**member, **sides})
        pieces = []
        for member in members:
            path = member['path']
            a, b = member['before'], member['after']
            assert not a['text'] or a['text'].endswith('\n')
            assert not b['text'] or b['text'].endswith('\n')
            header = f'diff --git a/{path} b/{path}\n'
            if a.get('absent'):
                header += 'new file mode '+member['after_mode']+'\n'
            elif b.get('absent'):
                header += 'deleted file mode '+member['before_mode']+'\n'
            else:
                assert member['before_mode'] == member['after_mode']
            header += 'index '+a['git_blob']+'..'+b['git_blob']
            if not a.get('absent') and not b.get('absent'):
                header += ' '+member['after_mode']
            header += '\n'
            lines = difflib.unified_diff(a['text'].splitlines(keepends=True), b['text'].splitlines(keepends=True),
                        fromfile='/dev/null' if a.get('absent') else 'a/'+path,
                        tofile='/dev/null' if b.get('absent') else 'b/'+path, n=3)
            pieces.append(header+''.join(lines))
        diff = ''.join(pieces)
        # A diff is useful review evidence only if it reproduces every complete
        # authenticated after-image, including added files and API snapshots.
        with tempfile.TemporaryDirectory(prefix='ngx-upstream-patch-recovery-') as directory:
            temporary = pathlib.Path(directory)
            for member in members:
                path = pathlib.PurePosixPath(member['path'])
                assert not path.is_absolute() and '..' not in path.parts
                assert member['before_mode'] in ['000000', '100644']
                assert member['after_mode'] in ['000000', '100644']
                if not member['before'].get('absent'):
                    file = temporary/member['path']
                    file.parent.mkdir(parents=True, exist_ok=True)
                    file.write_text(member['before']['text'])
            env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
            env.update(GIT_NO_REPLACE_OBJECTS='1', GIT_NO_LAZY_FETCH='1')
            for command in [['git', 'apply', '--check', '--whitespace=nowarn'], ['git', 'apply', '--whitespace=nowarn']]:
                applied = subprocess.run(command, cwd=temporary, input=diff.encode(), capture_output=True, env=env)
                assert applied.returncode == 0, applied.stderr.decode()
            for member in members:
                file = temporary/member['path']
                if member['after'].get('absent'):
                    assert not file.exists()
                else:
                    assert file.read_text() == member['after']['text']
            assert sorted(str(p.relative_to(temporary)) for p in temporary.rglob('*') if p.is_file()) == sorted(
                m['path'] for m in members if not m['after'].get('absent'))
        subjects.append({'sha': sha, 'raw_commit': row['raw_commit'], 'parent': parent, 'subject': row['seed_subject'],
                         'members': members, 'diff': diff, 'diff_sha256': digest(diff.encode()),
                         'complete_patch_roundtrip_verified': True,
                         'diff_construction': 'Deterministic full-index unified diff from every authenticated before/after blob; no selected-path filtering.'})
        print(json.dumps({'sha': sha, 'status': 'captured', 'complete_files': len(members)}), flush=True)
    except Exception as error:
        errors.append({'sha': sha, 'error': str(error)})
        print(json.dumps({'sha': sha, 'status': 'source-recovery-failed', 'error': str(error)}), flush=True)
out = pathlib.Path('/tmp/ngx-testing-api-21x-recovered-subjects.json.gz')
packet = {'schema_version': 1, 'role': 'Source recovery only; no individual-review or disposition credit',
          'source_census': {'path': census_path, 'sha256': digest(census_bytes)},
          'producer': {'path': 'compatibility/rc/upstream-testing-api-21x-acquisition-producer.py.gz',
                       'raw_sha256': digest(pathlib.Path(__file__).read_bytes())},
          'selected_SHA_ids': shas, 'subjects': subjects, 'errors': errors,
          'complete': not errors and len(subjects) == len(shas),
          'credentials_used': False, 'upstream_code_executed': False,
          'git_repository_or_remote_modified': False}
raw = (json.dumps(packet, indent=2)+'\n').encode()
out.write_bytes(gzip.compress(raw, compresslevel=9, mtime=0))
print(json.dumps({'path': str(out), 'subjects': len(subjects), 'errors': len(errors), 'sha256': digest(out.read_bytes())}), flush=True)
raise SystemExit(bool(errors))
