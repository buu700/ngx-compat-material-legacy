from pathlib import Path
import tempfile,hashlib,json,importlib.util
root=Path('/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy')
spec=importlib.util.spec_from_file_location('dependency_checker',root/'scripts/check-dependency-eligibility.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
manifest=json.loads((root/'compatibility/vendored-sass-manifest.json').read_text());row=manifest['files'][0]
with tempfile.TemporaryDirectory(prefix='root-vendor-requested-root-v1-') as t:
 r=Path(t);dest=r/row['dest'];dest.parent.mkdir(parents=True);dest.write_bytes((root/row['dest']).read_bytes()+b'\n/* wrong requested-root bytes */\n')
 manifest['files']=[row];manifest['packages']=[];path=r/'compatibility/vendored-sass-manifest.json';path.parent.mkdir(parents=True);path.write_text(json.dumps(manifest))
 observed=mod.vendor_observations(path)
 actual=hashlib.sha256(dest.read_bytes()).hexdigest()
 assert actual!=row['rewritten_sha256'];assert observed['hash_mismatches']==[]
 report={'scope':'Ordinary two-root vendor-observation regression; no network or security clearance claim','checker_source_sha256':hashlib.sha256((root/'scripts/check-dependency-eligibility.py').read_bytes()).hexdigest(),'requested_root_has_mismatched_vendor_bytes':True,'expected_hash_mismatch_path':row['dest'],'observed':observed,'result':'Reproduced: asked-root file mismatch incorrectly passes because function reads global module root.'}
 Path('/tmp/root-vendor-requested-root-regression-v1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
