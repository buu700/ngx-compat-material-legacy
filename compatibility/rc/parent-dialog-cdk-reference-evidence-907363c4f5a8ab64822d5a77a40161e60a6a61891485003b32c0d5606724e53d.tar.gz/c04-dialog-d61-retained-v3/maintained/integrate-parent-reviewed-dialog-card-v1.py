import hashlib,json,pathlib,subprocess

OUT=pathlib.Path('/tmp/parent-reviewed-dialog-card-controlled-integration-v1.json')
DIALOG_OUT=pathlib.Path('/tmp/parent-dialog-cdk-ref-controlled-integration-v1.json')
assert not OUT.exists() and not DIALOG_OUT.exists()
ROOTS={k:pathlib.Path('/home/parallels/.codex/worktrees/codex-closeout-'+k+'/ngx-compat-material-legacy') for k in ['21','main']}
HEADS={'21':'e45dca2982c8c8569c77fed9375b70e6675b2fe3','main':'79b1f0f7e28230df02c784eb11e1b15f1263d0e3'}
PRODUCT='projects/ngx-material-legacy/legacy-dialog/internal/dialog-base.ts'
SPEC='projects/ngx-material-legacy/legacy-dialog/dialog.spec.ts'
PATCHES=[('/tmp/c04-dialog003-review-v1/d61-product.patch','cbd431a17958161248fc58968721ee3d827a52254fffd095b6cb3820b1b4db0f'),('/tmp/c04-dialog003-review-v1/d61-tests.patch','2967cc3dcc5a133a96579ab956ed6cb873cb5372b0c58842776c2f29a47f8a51')]
CARD_HASH={'21':'f824ee768883e03926fbb78cb5acdac7ab0a96dacf54cd6355d8546c353679e4','main':'2dd19ac46115ed9bc95ac4dbf6b293356b733ddf55a0c8f0237d61d571a93b26'}
def sha(b):return hashlib.sha256(b).hexdigest()
def image(b):return {'sha256':sha(b),'bytes':len(b)}
def git(r,*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=0',*a],cwd=r)
def other(r,targets):
 names=git(r,'diff','--name-only','-z').split(b'\0')+git(r,'ls-files','--others','--exclude-standard','-z').split(b'\0')
 return {p.decode():image((r/p.decode()).read_bytes()) for p in names if p and p.decode() not in targets}
for p,h in PATCHES:assert sha(pathlib.Path(p).read_bytes())==h
reviews={}
for name,p,h in [('dialog','/tmp/c04-dialog003-d61-independent-review-v1.json','52ac82bd031caee7feff73b0f6907c4fe668c652016ddf1d744fa8eb0b4f7ca3'),('card','/tmp/c02-private-card-wiring-independent-review-v1.json','63695163b6d6785d9babaf8db600ee11f0e87e702b5dd67738c2512f936157fb')]:
 data=pathlib.Path(p).read_bytes();assert sha(data)==h;reviews[name]={'path':p,**image(data)}
receipt={'schema':'parent-reviewed-dialog-card-controlled-integration-v1','reviews':reviews,'branches':{},'limits':'Exact reviewed source integration only. Dialog prior diagnostic bundles and card prior authentic artifacts/simulated admission are not fresh current artifact, full source, Sass seal, browser matrix or release qualification.','remote_actions':'none'}
ledgers={}
for line,root in ROOTS.items():
 assert git(root,'rev-parse','HEAD').decode().strip()==HEADS[line]
 assert not git(root,'diff','--name-only').strip() and not git(root,'diff','--cached','--name-only').strip()
 ledger=pathlib.Path('/tmp/c02-private-card-'+line+'-v3-ledger.json');body=json.loads(ledger.read_text());ledgers[line]=body
 assert sha(pathlib.Path(body['patch']).read_bytes())==CARD_HASH[line]==body['patch_sha256']
 paths={r['path'] for r in body['rows']};assert len(paths)==14 and not paths.intersection({PRODUCT,SPEC})
 for row in body['rows']:
  p=root/row['path'];actual=sha(p.read_bytes()) if p.exists() else None
  assert actual==row['base_sha256']==row['current_sha256'],(line,row['path'],actual)
 targets=paths|{PRODUCT,SPEC}
 receipt['branches'][line]={'root':str(root),'head':HEADS[line],'dialog_before':{p:image((root/p).read_bytes()) for p in [PRODUCT,SPEC]},'card_ledger':{'path':str(ledger),**image(ledger.read_bytes())},'card_before':{row['path']:image((root/row['path']).read_bytes()) if (root/row['path']).exists() else None for row in body['rows']},'unrelated_before':other(root,targets)}
 for p,_ in PATCHES:subprocess.run(['git','apply','--check',p],cwd=root,check=True)
 subprocess.run(['git','apply','--check',body['patch']],cwd=root,check=True)

for line,root in ROOTS.items():
 row=receipt['branches'][line];before=(root/PRODUCT).read_bytes();spec_before=(root/SPEC).read_bytes()
 assert before.count(b'import {Dialog, DialogConfig, DialogRef}')==1
 block=b'          // Prevent content from resolving the CDK DialogRef accidentally.\n          {provide: DialogRef, useValue: null},\n';assert before.count(block)==1
 expected=before.replace(b'import {Dialog, DialogConfig, DialogRef}',b'import {Dialog, DialogConfig}').replace(block,b'')
 for p,_ in PATCHES:subprocess.run(['git','apply',p],cwd=root,check=True)
 assert (root/PRODUCT).read_bytes()==expected
 after=(root/SPEC).read_bytes();assert after.count(b'  inject as injectToken,')==1
 tail=after[len(spec_before.replace(b'  createNgModule,\n',b'  createNgModule,\n  inject as injectToken,\n')):]
 assert after==spec_before.replace(b'  createNgModule,\n',b'  createNgModule,\n  inject as injectToken,\n')+tail
 assert tail.count(b"describe('legacy dialog content reference injection'")==1 and tail.count(b'it(')==2
 row['dialog_after']={p:image((root/p).read_bytes()) for p in [PRODUCT,SPEC]}
 body=ledgers[line];subprocess.run(['git','apply',body['patch']],cwd=root,check=True)
 for r in body['rows']:assert sha((root/r['path']).read_bytes())==r['proposed_sha256'],(line,r['path'])
 row['card_after']={r['path']:image((root/r['path']).read_bytes()) for r in body['rows']}
 targets=set(row['card_after'])|{PRODUCT,SPEC};row['unrelated_after']=other(root,targets)
 assert row['unrelated_before']==row['unrelated_after']
 subprocess.run(['git','diff','--check','--',*sorted(targets)],cwd=root,check=True)
OUT.write_text(json.dumps(receipt,indent=2)+'\n')
DIALOG_OUT.write_text(json.dumps({'schema':'parent-dialog-cdk-ref-controlled-integration-v1','application':{'path':str(OUT),**image(OUT.read_bytes())},'review':reviews['dialog'],'branches':{k:{x:v[x] for x in ['root','head','dialog_before','dialog_after']} for k,v in receipt['branches'].items()},'limits':receipt['limits'],'remote_actions':'none'},indent=2)+'\n')
print(json.dumps({'receipt':str(OUT),'dialog_receipt':str(DIALOG_OUT),'paths_per_line':16}))
