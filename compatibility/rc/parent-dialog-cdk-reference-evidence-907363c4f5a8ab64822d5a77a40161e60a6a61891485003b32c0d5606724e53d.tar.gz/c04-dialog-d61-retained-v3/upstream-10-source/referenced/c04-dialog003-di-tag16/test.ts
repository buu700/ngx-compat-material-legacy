import '@angular/compiler'; import 'zone.js'; import 'zone.js/testing';
import {Component, Directive, TemplateRef, ViewChild, inject} from '@angular/core';
import {TestBed, fakeAsync, tick} from '@angular/core/testing';
import {BrowserDynamicTestingModule, platformBrowserDynamicTesting} from '@angular/platform-browser-dynamic/testing';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {DialogRef} from '@angular/cdk/dialog';
import {MatLegacyDialog, MatLegacyDialogModule, MatLegacyDialogRef} from '@angular/material/legacy-dialog';
TestBed.initTestEnvironment(BrowserDynamicTestingModule, platformBrowserDynamicTesting());
let observations:any[]=[];
@Directive({selector:'[probe]'}) class Probe { constructor(){const optional=inject(DialogRef,{optional:true});const required=inject(DialogRef); const legacy=inject(MatLegacyDialogRef);observations.push({optional:!!optional,required:!!required,same:optional===required,legacy:!!legacy});} }
@Component({template:'<div probe>component</div>'}) class Content {}
@Component({template:'<ng-template><div probe>template</div></ng-template>'}) class Host { @ViewChild(TemplateRef) tmpl!:TemplateRef<any>; }
describe('tag16 legacy DI',()=>{it('checks component and template',fakeAsync(()=>{TestBed.configureTestingModule({declarations:[Probe,Content,Host],imports:[MatLegacyDialogModule,NoopAnimationsModule]});const host=TestBed.createComponent(Host);host.detectChanges();const service=TestBed.inject(MatLegacyDialog);const a=service.open(Content);host.detectChanges();tick(250);const b=service.open(host.componentInstance.tmpl);host.detectChanges();tick(250);console.log('C04_DIALOG_DI_TAG16 '+JSON.stringify(observations));expect(observations.length).toBe(2);for(const x of observations){expect(x.optional).toBeTrue();expect(x.required).toBeTrue();expect(x.same).toBeTrue();expect(x.legacy).toBeTrue();}a.close();b.close();host.detectChanges();tick(500);host.destroy();}));});
