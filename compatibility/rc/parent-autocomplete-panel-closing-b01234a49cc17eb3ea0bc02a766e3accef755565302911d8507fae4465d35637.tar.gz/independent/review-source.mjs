/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 * Use of this source code is governed by the MIT license in LICENSE.
 */
/** Exact two-file autocomplete successor AST/API review. */
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {resolve} from 'node:path';
const root=resolve(process.argv[2]),line=process.argv[3],commit=line==='main'?'0ca6505896139dab0643f91f4179c3b351b5c068':'fe45d079195f02d12071d73f2cf3d4804a47ef1a';
assert.ok(root&&['21.x','main'].includes(line));
const require=createRequire(resolve(root,'package.json')),ts=require('typescript'),ops=require('rxjs/operators');
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const path='projects/ngx-material-legacy/legacy-autocomplete/internal/autocomplete-trigger-base.ts';
const current=readFileSync(resolve(root,path),'utf8'),prior=execFileSync('git',['show',commit+':'+path],{cwd:root,encoding:'utf8'});
assert.equal(hash(current),'19f6b4cbd1710ee1a33f3d4d7a68e790f484acde462373e7edc2e2538c380b83');
const parse=text=>{const file=ts.createSourceFile(path,text,ts.ScriptTarget.Latest,true);assert.equal(file.parseDiagnostics.length,0);return file;};
const a=parse(prior),b=parse(current),owner=file=>file.statements.find(node=>ts.isClassDeclaration(node)&&node.name?.text==='_MatAutocompleteTriggerBase');
const old=owner(a),now=owner(b);assert.ok(old&&now);
const ctor=(cls,file)=>{const found=cls.members.filter(ts.isConstructorDeclaration);assert.equal(found.length,1);return found[0];};
assert.equal(ctor(old,a).getText(a),ctor(now,b).getText(b));assert.equal(ctor(now,b).parameters.length,11);
const key=(node,file)=>node.name?.getText(file)||'<constructor>';
const before=new Map(old.members.map(node=>[key(node,a),node])),after=new Map(now.members.map(node=>[key(node,b),node]));
const added=[...after.keys()].filter(name=>!before.has(name)).sort(),removed=[...before.keys()].filter(name=>!after.has(name));
const changed=[...before.keys()].filter(name=>after.has(name)&&before.get(name).getText(a)!==after.get(name).getText(b)).sort();
assert.deepEqual(added,['_overlayRefChanges','_panelClosingActions']);assert.deepEqual(removed,[]);
assert.deepEqual(changed,['_attachOverlay','ngOnDestroy','panelClosingActions']);
for(const name of added){const field=after.get(name);assert.ok(ts.isPropertyDeclaration(field));assert.ok(field.modifiers.some(mod=>mod.kind===ts.SyntaxKind.PrivateKeyword));assert.ok(field.modifiers.some(mod=>mod.kind===ts.SyntaxKind.ReadonlyKeyword));}
assert.match(after.get('_overlayRefChanges').initializer.getText(b),/^new Subject<OverlayRef>\(\)$/);
assert.match(after.get('_panelClosingActions').initializer.getText(b),/^defer\(/);
const getter=after.get('panelClosingActions'),oldGetter=before.get('panelClosingActions');
assert.ok(ts.isGetAccessorDeclaration(getter)&&ts.isGetAccessorDeclaration(oldGetter));
assert.equal(getter.type.getText(b),oldGetter.type.getText(a));assert.equal(getter.name.getText(b),oldGetter.name.getText(a));
assert.equal(typeof ops.share,'function');assert.equal(require('rxjs/package.json').version,'7.8.2');
assert.match(current,/this\._overlayRef = overlayRef;\s*this\._overlayRefChanges\.next\(overlayRef\);/);
assert.match(current,/this\._overlayRefChanges\.complete\(\);\s*this\._closingActionsSubscription\?\.unsubscribe\(\);/);
console.log(JSON.stringify({line,source_sha256:hash(current),constructor_parameters:11,constructor_text_unchanged:true,added_private_fields:added,changed_members:changed,public_getter_type:getter.type.getText(b),rxjs_version:'7.8.2',public_share_export:true,source_only:true}));
