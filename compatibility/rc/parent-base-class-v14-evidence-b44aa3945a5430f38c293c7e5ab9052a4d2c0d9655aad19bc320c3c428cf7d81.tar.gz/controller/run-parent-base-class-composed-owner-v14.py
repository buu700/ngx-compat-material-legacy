from pathlib import Path
import hashlib,json,os,signal,stat,subprocess,time,sys
if sys.flags.optimize or not sys.dont_write_bytecode:
 raise SystemExit('controller requires unoptimized Python with -B')
if Path(sys.executable).resolve()!=Path('/nix/store/lfh101cfjj8p8npcari9hk0lbqi33yvh-python3-3.14.7/bin/python3').resolve():
 raise SystemExit('controller requires pinned Python 3.14.7')
roots={k:Path('/home/parallels/.codex/worktrees/codex-closeout-'+v+'/ngx-compat-material-legacy') for k,v in [('21.x','21'),('main','main')]}
expected_program_heads={'21.x':'2f5201af2294a1c99552fb1876583b4e8d11b5f2','main':'9734b4a9ada49cdfe3dc8b4dfe44d1e04664a2ed'}
# Reviewed launch pins are deliberately absent in the draft. No command may run
# until a separately reviewed pin file replaces every null value.
pins_path=Path('/tmp/parent-base-class-owner-v14-launch-pins-v1.json')
pins_raw=pins_path.read_bytes();pins=json.loads(pins_raw)
expected_launch_heads=pins['expected_launch_heads'];expected_gate_refs=pins['expected_gate_refs']
assert pins['status']=='REVIEWED_V14_LAUNCH_PINS', 'draft pins do not authorize execution'
for line in roots:
 assert isinstance(expected_launch_heads[line],str) and len(expected_launch_heads[line])==40
 ref=expected_gate_refs[line];assert isinstance(ref,dict) and set(ref)=={'path','sha256','bytes'}
 assert isinstance(ref['sha256'],str) and len(ref['sha256'])==64 and type(ref['bytes']) is int and ref['bytes']>0
assert sys.argv[1:] in ([],['--preflight']),'unsupported arguments'
preflight_only=sys.argv[1:]==['--preflight']
root=roots['21.x'];node='/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node'
python='/nix/store/lfh101cfjj8p8npcari9hk0lbqi33yvh-python3-3.14.7/bin/python3'
receipt=Path('/tmp/parent-base-class-composed-owner-attempt-v14.json')
snapshot_path=Path('/tmp/parent-base-class-owner-v14-source-snapshots.json.gz')
out='compatibility/rc/snack-current-owner-repair-base-class-preapplication-v14.json'
for p in [receipt,snapshot_path,root/out]:assert not p.exists() and not p.is_symlink(),str(p)
env={k:v for k,v in os.environ.items() if not k.startswith(('RC_','GIT_'))};env.update(GIT_NO_LAZY_FETCH='1',GIT_NO_REPLACE_OBJECTS='1',GIT_TERMINAL_PROMPT='0')
for name in ['NODE_OPTIONS','NODE_PATH','NODE_V8_COVERAGE','PYTHONPATH','PYTHONHOME','PYTHONOPTIMIZE']:env.pop(name,None)
env['PYTHONDONTWRITEBYTECODE']='1'
env['PATH']=str(Path(node).parent)+':'+str(Path(python).parent)+':'+env['PATH']
assert Path(node).is_file() and Path(python).is_file()
def git(where,*args):return subprocess.check_output(['git','--no-replace-objects','-c','gc.auto=0','-c','maintenance.auto=0',*args],cwd=where,env=env)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def identity(path,raw):return dict(path=path,sha256=digest(raw),bytes=len(raw))
profile_raw=(root/'compatibility/rc/parent-base-class-tool-successor-inputs-v3.json').read_bytes()
assert digest(profile_raw)=='f25d474e8022f226623b27093a47659c02bbc88a1e9b43ed9e8f209f3c246044' and len(profile_raw)==367807
profile=json.loads(profile_raw)
assert {line:(len(branch['updates']),len(branch['additional_inputs'])) for line,branch in profile['branches'].items()}=={'21.x':(56,106),'main':(23,47)}
expected_scope=set()
for line,branch in profile['branches'].items():
 paths={r['path'] for r in [*branch['updates'],*branch['additional_inputs']]}
 paths.update(['scripts/check-source-contract-regressions.py','compatibility/rc/parent-base-class-tool-successor-inputs-v3.json','scripts/current-sass-tool-references.mjs','scripts/current_sass_tool_references.py'])
 expected_scope.update((line,path) for path in paths)
assert all(any(item[0]==line for item in expected_scope) for line in roots)
assert type(expected_launch_heads) is dict and set(expected_launch_heads)==set(roots),'launch heads not independently pinned'
assert type(expected_gate_refs) is dict and set(expected_gate_refs)==set(roots),'genuine gate bytes not pinned'
gates={};gate_refs={};gate_scopes={};qualified_regression_refs={}
def register_regression_ref(line,ref):
 key=(line,ref['path']);actual=dict(line=line,**{k:ref[k] for k in ['path','sha256','bytes']})
 if key in qualified_regression_refs:assert qualified_regression_refs[key]==actual,'conflicting current regression judgment '+str(key)
 else:qualified_regression_refs[key]=actual
for line,suffix in [('21.x','21'),('main','main')]:
 path=expected_gate_refs[line]['path'];assert path=='/tmp/parent-source-contract-regressions-'+suffix+'-v14.json';raw=Path(path).read_bytes();gate=json.loads(raw)
 assert identity(path,raw)==expected_gate_refs[line],'wrong genuine V14 receipt bytes'
 assert gate['line']==line and gate['exit_code']==0 and gate['source_unchanged'] is True and gate['stdout_report']['result']=='pass' and gate['stdout_report']['line']==line and gate['child_command_budgets_changed'] is True and gate['current_child_budgets_seconds']=={'checker':180,'browser':300} and gate['budget_policy_origin_profile']=='b08ed6163f798dc7c2463a330d29ba1622fdc9ee9fd8b1f9c1c741bf44ee2ed9' and gate['current_profile_sha256']=='f25d474e8022f226623b27093a47659c02bbc88a1e9b43ed9e8f209f3c246044'
 assert gate['source_heads']==expected_program_heads and gate['source_head']==expected_program_heads[line],'wrong committed source cut'
 assert gate['outer_capture_expired'] is False
 scope_ref=gate['source_snapshot'];scope_raw=Path(scope_ref['path']).read_bytes();assert identity(scope_ref['path'],scope_raw)==scope_ref
 import gzip
 scope=json.loads(gzip.decompress(scope_raw));assert scope['before']==scope['after'] and scope['before']['heads']==expected_program_heads
 assert scope['before']['finite']==gate['source_inputs'];gate_scopes[line]={**scope['before'],'_scope_path':scope_ref['path']}
 full=gate['stdout_report'];assert full['source_commit']==expected_program_heads[line] and full['g11_claim']=='not-passed'
 assert full['cases']==[{'case_id':'source-contract-regressions/'+kind+'-source/full-fault-lifetimes','result':'pass'} for kind in ['checker','browser']],'incomplete source regression cases'
 assert set(full['observations'])=={'checker','browser'}
 for kind in ['checker','browser']:
  observation=full['observations'][kind];facts=observation['report'];count=facts['bound_current_paths']
  assert facts['result']=='pass' and isinstance(count,int) and count>0 and len(observation['bound'])==count
  assert facts['cold_source_faults_rejected']==count and facts['late_source_faults_rejected']==count,'incomplete source fault lifetimes'
  paths=[ref['path'] for ref in observation['bound']]
  assert len(set(paths))==count,'duplicate current fault population'
  assert facts['cold_source_fault_paths_rejected']==paths and facts['late_source_fault_paths_rejected']==paths,'substituted fault path population'
  assert facts['source_execution_mode']=='complete-regression' and facts['full_source_fault_lifetimes_executed'] is True
  for ref in observation['bound']:register_regression_ref(line,ref)
 assert len(gate['source_inputs'])==len(expected_scope) and {(r['line'],r['path']) for r in gate['source_inputs']}==expected_scope,'wrong V14 source input roster'
 for row in gate['source_inputs']:
  register_regression_ref(row['line'],row)
  body=(roots[row['line']]/row['path']).read_bytes();assert digest(body)==row['sha256'] and len(body)==row['bytes'],row['path']
 gates[line]=gate;gate_refs[line]=identity(path,raw)
assert gates['21.x']['source_heads']==gates['main']['source_heads']
for ref in qualified_regression_refs.values():
 raw=(roots[ref['line']]/ref['path']).read_bytes();assert digest(raw)==ref['sha256'] and len(raw)==ref['bytes'],'stale factual bound '+str((ref['line'],ref['path']))
assert expected_launch_heads==expected_program_heads,'launch must use exact gate HEADs'
for line,where in roots.items():
 assert git(where,'rev-parse','HEAD').decode().strip()==expected_program_heads[line]
 git(where,'diff','--quiet');git(where,'diff','--cached','--quiet')
gate=gates['21.x']
# Prior V12 was a terminal 1800-second timeout. Its scope can locate files,
# but no prior byte identity is promoted to a current success or gold standard.
prior_raw=Path('/tmp/parent-base-class-composed-owner-attempt-v12.json').read_bytes()
assert digest(prior_raw)=='3be316b1645ae5db6ac2a57eac4a4c22accd962e6135fbcfe99f4ffa487400b3'
prior=json.loads(prior_raw)
assert prior['timed_out'] is True and prior['exit_code']!=0 and prior['complete_owner_success'] is False
extra_paths=set(canonical for canonical in ['compatibility/f10/disposition-ledger/ledger.json','scripts/upstream-source-contract-registry.mjs','compatibility/rc/21x-remaining-disposition-worksheet.json'])
extra_paths.update(r['path'] for r in gate['source_inputs'] if r['line']=='21.x')
extra_paths.update(['compatibility/rc/snack-current-owner-repair-owner-probe.mjs'])
for row in [*profile['branches']['21.x']['updates'],*profile['branches']['21.x']['additional_inputs']]:extra_paths.add(row['path'])
canonical=['compatibility/f10/disposition-ledger/ledger.json','scripts/upstream-source-contract-registry.mjs','compatibility/rc/21x-remaining-disposition-worksheet.json']
canonical_pins={
 'compatibility/f10/disposition-ledger/ledger.json':('e9ef5c0bf543977809134c3367cf9a33bdda62233ab6b944dc3c4e4ac101585e',4191043),
 'scripts/upstream-source-contract-registry.mjs':('be50b37d181b43960361860dd7cb3bb24d0f2d1b0a2ecfaa5a85a791e4869399',15548),
 'compatibility/rc/21x-remaining-disposition-worksheet.json':('0459559a90a64ee02fafce8421c1108b112f67a697932ec51128c9f40c4601f8',269780),
}
for path in canonical:
 program_bytes=git(root,'show',expected_program_heads['21.x']+':'+path)
 assert (digest(program_bytes),len(program_bytes))==canonical_pins[path], 'unexpected program cut canonical preimage '+path
 assert (root/path).read_bytes()==program_bytes, 'canonical preimage differs from program cut '+path
allowed_external={'../../../../cyph/shared/js/cyph/services/material-dialog.service.ts','../../../../cyph/shared/js/cyph/modules/cyph-web.module.ts'}
for path in [*extra_paths,*(ref['path'] for ref in qualified_regression_refs.values())]:assert path in allowed_external or path and not path.startswith('/') and all(p not in ('','.','..') for p in path.split('/'))
def snapshot():
 rows=[];heads={};statuses={}
 for line,where in roots.items():
  heads[line]=git(where,'rev-parse','HEAD').decode().strip()
  status=git(where,'status','--porcelain','--untracked-files=all').decode().splitlines()
  allowed='?? '+out
  statuses[line]=[entry for entry in status if not (line=='21.x' and entry==allowed and (root/out).is_file() and not (root/out).is_symlink())]
  paths=git(where,'ls-files','-z').split(b'\0');assert paths.pop()==b''
  for encoded in sorted(paths):
   path=encoded.decode();cursor=where
   for part in path.split('/'):
    assert part not in ('','.','..');cursor/=part;assert not cursor.is_symlink(),str(cursor)
   assert stat.S_ISREG(cursor.stat().st_mode);raw=cursor.read_bytes();rows.append(dict(line=line,**identity(path,raw),mode=stat.S_IMODE(cursor.stat().st_mode)))
 qualified=[identity(path,(root/path).read_bytes()) for path in sorted(extra_paths)]
 factual=[dict(line=line,**identity(path,(roots[line]/path).read_bytes())) for line,path in sorted(qualified_regression_refs)]
 gate_current={line:identity(ref['path'],Path(ref['path']).read_bytes()) for line,ref in expected_gate_refs.items()}
 assert gate_current==expected_gate_refs,'V14 receipt bytes changed'
 physical_paths=[]
 for line,path in sorted(set(qualified_regression_refs)|{('21.x',path) for path in extra_paths}):
  file=roots[line]/path;target=file.resolve(strict=True);st=target.stat();assert stat.S_ISREG(st.st_mode)
  physical_paths.append(dict(line=line,path=path,realpath=str(target),mode=stat.S_IMODE(st.st_mode)))
 gate_scope_files={line:identity(gate_scopes[line]['_scope_path'],Path(gate_scopes[line]['_scope_path']).read_bytes()) for line in roots}
 assert gate_scope_files=={line:gates[line]['source_snapshot'] for line in roots},'gate source snapshots changed'
 controller=Path(__file__).resolve();controller_ref=identity(str(controller),controller.read_bytes())
 return dict(heads=heads,statuses=statuses,rows=rows,qualified_source_inputs=qualified,regression_source_inputs=factual,qualified_realpaths=physical_paths,source_gates=gate_current,gate_scope_files=gate_scope_files,controller=controller_ref,pin_file_sha256=digest(pins_path.read_bytes()))
def summary(s):
 raw=(json.dumps(s,sort_keys=True,separators=(',',':'))+'\n').encode();return dict(heads=s['heads'],tracked_files=len(s['rows']),qualified_inputs=len(s['qualified_source_inputs']),both_branch_regression_inputs=len(s['regression_source_inputs']),sha256=digest(raw),serialized_bytes=len(raw))
before=snapshot();assert before['heads']==expected_launch_heads and before['pin_file_sha256']==digest(pins_raw)
for line in roots:
 assert gate_scopes[line]['tracked']==before['rows'],'tracked source differs from actual gate snapshot'
 assert {key:val.splitlines() for key,val in gate_scopes[line]['statuses'].items()}==before['statuses'],'untracked status differs from actual gate snapshot'

assert before['regression_source_inputs']==[qualified_regression_refs[key] for key in sorted(qualified_regression_refs)],'entry factual scope differs from genuine regressions'
if preflight_only:
 preflight_archive=Path('/tmp/parent-base-class-owner-v14-preflight-source.json.gz')
 preflight_receipt=Path('/tmp/parent-base-class-owner-v14-preflight.json')
 assert not preflight_archive.exists() and not preflight_receipt.exists()
 raw=gzip.compress((json.dumps(before,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with preflight_archive.open('xb') as f:f.write(raw)
 result=dict(status='pass',scope='read-only preflight; owner not executed',snapshot=summary(before),source_archive=identity(str(preflight_archive),raw),source_gates=gate_refs,controller=before['controller'],node=node,python=python,admission_granted=False)
 with preflight_receipt.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps(result),flush=True);raise SystemExit(0)
command=[node,'--max-old-space-size=4096','compatibility/rc/snack-current-owner-repair-owner-probe.mjs',out]
start=time.monotonic();child=subprocess.Popen(command,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
print(json.dumps(dict(state='started',pid=child.pid,command=command,source_snapshot=summary(before))),flush=True)
expired=False
try:stdout,stderr=child.communicate(timeout=1800)
except subprocess.TimeoutExpired:
 expired=True
 try:os.killpg(child.pid,signal.SIGKILL)
 except ProcessLookupError:pass
 stdout,stderr=child.communicate()
seconds=time.monotonic()-start
try:after=snapshot();snapshot_error=None
except Exception as error:after=None;snapshot_error=type(error).__name__+': '+str(error)
report=None;report_error=None;output_reference=None
if (root/out).exists() or (root/out).is_symlink():
 try:
  target=root/out;assert not target.is_symlink() and stat.S_ISREG(target.stat().st_mode),'nonregular owner output'
  raw=target.read_bytes();output_reference=identity(out,raw);value=json.loads(raw)
  assert type(value) is dict and value.get('status') in ('pass','rejected'),'invalid owner report shape'
  assert value.get('current_native_packed_browser_floor_or_full_audit_qualified') is False and value.get('g11_claim')=='not-passed','invalid owner scope'
  if value['status']=='pass':assert value.get('actual_full_source_owner_executed') is True and value.get('line')=='21.x' and value.get('native_test_before_image_exposed') is False,'invalid successful owner report'
  report=value
 except Exception as error:report_error=type(error).__name__+': '+str(error)
unchanged=after is not None and before==after
snapshot_archive=gzip.compress((json.dumps({'before':before,'after':after},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with snapshot_path.open('xb') as f:f.write(snapshot_archive)
snapshot_ref=identity(str(snapshot_path),snapshot_archive)
passed=child.returncode==0 and not expired and unchanged and report_error is None and report is not None and report['status']=='pass'
record=dict(schema_version=14,scope='One genuine unprofiled complete current owner attempt at original1800s on exact committed V14 source gate HEADs; not G11 or product qualification',source_head=before['heads']['21.x'],source_heads=before['heads'],source_inputs=before['qualified_source_inputs'],both_branch_regression_inputs=before['regression_source_inputs'],source_before=summary(before),source_after=summary(after) if after is not None else None,full_source_snapshot_archive=snapshot_ref,source_snapshot_error=snapshot_error,source_unchanged=unchanged,source_snapshot_limits='Tracked regular file contents/modes/HEADs bothroots plus enumerated qualified21input byte hashes and every current checker/browser factual bound from both branches, including inherited ignored peer/Cyph input paths. Metadata snapshot does not replace actual owner physical policies, bound freshness, runtime identity or provide atomic hostile-filesystem protection.',source_gates=gate_refs,source_regression_program_cut=gate['source_heads'],source_regression_program_input_count=len(expected_scope),current_program_refs_identical_to_successful_regression_cut=True,command=command,wall_seconds=seconds,deadline_seconds=1800,node_heap_MiB=4096,timed_out=expired,exit_code=child.returncode,owner_report=report,owner_report_error=report_error,owner_output_reference=output_reference,stdout=stdout,stderr=stderr,complete_owner_success=passed,canonical_transaction_applied=False if unchanged else None,child_command_budgets_changed=True,current_child_budgets_seconds={'checker':180,'browser':300},g11_claim='not-passed')
with receipt.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({k:record[k] for k in ['exit_code','wall_seconds','timed_out','source_unchanged','owner_report','owner_report_error','complete_owner_success']}),flush=True)
if not passed:raise SystemExit(1)
