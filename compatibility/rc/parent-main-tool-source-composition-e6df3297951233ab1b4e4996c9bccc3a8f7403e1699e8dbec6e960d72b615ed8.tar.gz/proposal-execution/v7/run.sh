#!/bin/bash
set +e
cd /tmp/root-main-tool-reference-v4 || exit 1
export PATH=/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin:/nix/store/lfh101cfjj8p8npcari9hk0lbqi33yvh-python3-3.14.7/bin:/usr/bin:/bin
export GIT_NO_LAZY_FETCH=1 GIT_NO_REPLACE_OBJECTS=1
echo $$ > /tmp/tool-v4-controller-v7/pid
aggregate=0
phase() {
 name="$1"; shift
 printf 'running\n' > "/tmp/tool-v4-controller-v7/$name.state"
 "$@" > "/tmp/tool-v4-controller-v7/$name.log" 2>&1
 rc=$?
 printf '%s\n' "$rc" > "/tmp/tool-v4-controller-v7/$name.exit"
 printf 'finished\n' > "/tmp/tool-v4-controller-v7/$name.state"
 if [ "$rc" -ne 0 ]; then aggregate=1; fi
}
phase probe node tests/current_sass_tool_reference_v4_probe.mjs "$PWD"
phase python python3 -m unittest tests.test_current_sass_tool_references
phase outer node tests/.tool-v4-outer-capture.mjs --source
phase guard node tests/current_tool_guard_graph_probe.mjs "$PWD"
sha256sum compatibility/rc/parent-base-class-tool-successor-inputs-v4.json > /tmp/tool-v4-controller-v7/final-hashes.txt
printf '%s\n' "$aggregate" > /tmp/tool-v4-controller-v7/aggregate.exit
printf 'finished\n' > /tmp/tool-v4-controller-v7/controller.state
exit "$aggregate"
