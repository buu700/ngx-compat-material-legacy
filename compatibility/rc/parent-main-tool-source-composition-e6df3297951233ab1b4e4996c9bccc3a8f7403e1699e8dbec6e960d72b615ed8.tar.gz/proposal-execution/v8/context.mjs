import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {inventoryReferenceOwnerContext} from '/tmp/root-main-tool-reference-v4/scripts/inventory-reference-owner.mjs';
const root='/tmp/root-main-tool-reference-v4',ledger='compatibility/f10/disposition-ledger/ledger.json',path=root+'/'+ledger;
const hash=x=>createHash('sha256').update(x).digest('hex'),original=readFileSync(path),unknown=Buffer.concat([original,Buffer.from(' ')]);
const source=inventoryReferenceOwnerContext({root});source.assertCurrent();writeFileSync('/tmp/tool-v4-controller-v8/bound.json',JSON.stringify(source.bound,null,2));
const read=p=>{const raw=readFileSync(root+'/'+p);return p===ledger?Buffer.concat([raw,Buffer.from(' ')]):raw;};
assert.throws(()=>inventoryReferenceOwnerContext({root,read}),/nonphysical inventory owner input/);
try {writeFileSync(path,unknown);const value=inventoryReferenceOwnerContext({root});assert.equal(value.applied,false);assert.ok(value.metadataRead(ledger).equals(unknown));value.assertCurrent();}
finally {writeFileSync(path,original);}
assert.ok(readFileSync(path).equals(original));source.assertCurrent();
console.log(JSON.stringify({result:'pass',bound:source.bound.length,nonphysical_ledger_rejected:true,physical_unknown_frame_applied:false,physical_unknown_metadata_preserved:true,ledger_restored_sha256:hash(original),g11_claim:'not-passed'}));
