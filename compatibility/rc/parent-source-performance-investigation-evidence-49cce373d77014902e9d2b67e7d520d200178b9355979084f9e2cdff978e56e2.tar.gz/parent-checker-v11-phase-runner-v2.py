import subprocess,os,time,json,signal,hashlib
roots={'21':'/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy','main':'/home/parallels/.codex/worktrees/codex-closeout-main/ngx-compat-material-legacy'}
def snap():
 out={}
 for k,p in roots.items():
  def git(*a):return subprocess.check_output(['git',*a],cwd=p,text=True).strip()
  out[k]={'head':git('rev-parse','HEAD'),'status_porcelain':git('status','--porcelain=v1'),'checker_probe_sha256':hashlib.sha256(open(p+'/tests/checker_reference_source_probe.mjs','rb').read()).hexdigest(),'checker_owner_sha256':hashlib.sha256(open(p+'/scripts/checker-owner-source.mjs','rb').read()).hexdigest()}
 return out
node='/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node'
assert subprocess.check_output([node,'--version'],text=True).strip()=='v24.21.0'
before=snap(); log='/tmp/parent-checker-v11-phase-diagnostic-v2.jsonl';started=time.monotonic()
with open(log,'w') as f:
 env={k:v for k,v in os.environ.items() if not k.startswith('RC_')};env['PATH']='/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin:'+env['PATH']
 child=subprocess.Popen(['/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node','/tmp/parent-checker-v11-phase-driver-v1.mjs'],stdout=f,stderr=subprocess.STDOUT,start_new_session=True,cwd=roots['21'],env=env)
 print(json.dumps({'pid':child.pid,'pgid':os.getpgid(child.pid),'log':log}),flush=True)
 try: child.wait(timeout=55); timed=False
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(child.pid,signal.SIGTERM)
  try: child.wait(timeout=2)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
after=snap();events=[]
for line in open(log):
 try:events.append(json.loads(line))
 except json.JSONDecodeError:events.append({'unparsed':line.rstrip()})
result={'scope':'bounded diagnostic only; incomplete progress is not a gate or pass','pid':child.pid,'process_group':child.pid,'timeout_seconds':55,'timed_out':timed,'exit_code':child.returncode,'elapsed_seconds':round(time.monotonic()-started,3),'before':before,'after':after,'events':events,'log':log,'driver':'/tmp/parent-checker-v11-phase-driver-v1.mjs'}
result['node_executable']=node;result['node_version']='v24.21.0';result['driver_sha256']=hashlib.sha256(open('/tmp/parent-checker-v11-phase-driver-v1.mjs','rb').read()).hexdigest();result['source_and_status_unchanged']=before==after
with open('/tmp/parent-checker-v11-phase-diagnostic-v2.json','w') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'exit_code':child.returncode,'timed_out':timed,'events':events}),flush=True)
