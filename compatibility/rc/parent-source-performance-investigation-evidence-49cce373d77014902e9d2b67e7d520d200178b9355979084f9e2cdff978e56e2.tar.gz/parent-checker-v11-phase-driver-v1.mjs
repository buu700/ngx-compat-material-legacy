import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {inspectCheckerSourceMetadata as inspect} from '/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy/tests/checker_reference_source_probe.mjs';
import {readCheckerOwnerMember} from '/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy/scripts/checker-owner-source.mjs';
const root='/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy';
const start=performance.now();const log=(event,extra={})=>console.log(JSON.stringify({event,elapsed_ms:Math.round(performance.now()-start),...extra}));
let tamper=null;const read=path=>{const raw=readCheckerOwnerMember(root,path);return path===tamper?Buffer.concat([raw,Buffer.from(' ')]):raw;};
try {
 log('baseline_start');const subject=await inspect({read});log('baseline_complete',{population:subject.bound.length});
 let count=0;log('late_start');for(const ref of subject.bound){tamper=ref.path;assert.throws(()=>subject.assertCurrent(),undefined,'late '+tamper);tamper=null;count++;if(count%25===0)log('late_progress',{count});}log('late_complete',{count});
 count=0;log('cold_start');for(const ref of subject.bound){tamper=ref.path;await assert.rejects(inspect({read}),undefined,'cold '+tamper);tamper=null;count++;if(count%25===0)log('cold_progress',{count});}log('cold_complete',{count});
 subject.assertCurrent();log('diagnostic_complete',{population:subject.bound.length});
}catch(error){log('error',{name:error?.name,message:error?.message,stack:error?.stack});process.exitCode=1;}
