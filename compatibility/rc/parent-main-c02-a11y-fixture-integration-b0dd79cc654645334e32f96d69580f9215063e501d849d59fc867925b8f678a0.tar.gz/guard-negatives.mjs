import assert from 'node:assert/strict';
import {legacyCoreHighContrastOkay} from './scripts/legacy-core-high-contrast-contract.mjs';
const life={lifecycle:['FADING_IN','VISIBLE','FADING_OUT','HIDDEN'],connected:[true,true,true,false]};
const fallback={initial_state:'FADING_IN',initial_connected:true,final_state:'HIDDEN',final_connected:false,wait_completed:true};
const persistent={initial_state:'FADING_IN',initial_connected:true,visible_state:'VISIBLE',visible_connected:true,visible_wait_completed:true,dismissed_state:'FADING_OUT',dismissed_connected:true,final_state:'HIDDEN',final_connected:false,hidden_wait_completed:true};
const positive={found:true,ripple_display:'none',focus_display:'block',submenu_fill:'rgb(0, 0, 0)',canvas_color:'rgb(0, 0, 0)',negative:{found:true,ripple_display:'block',focus_display:'none',submenu_fill:'rgb(8, 9, 10)'},...life,fallback,persistent};
const body={normal:{found:true,media_active:false,class_active:false,ripple_display:'block',focus_display:'none',submenu_fill:'rgb(1, 2, 3)',...life},historical_class:{...structuredClone(positive),media_active:false,class_active:true},forced_colors:{...structuredClone(positive),media_active:true,class_active:false}};
assert.equal(legacyCoreHighContrastOkay(body),true);let n=0;
for(const mode of ['historical_class','forced_colors'])for(const section of ['fallback','persistent'])for(const [key,value] of Object.entries(body[mode][section])){const b=structuredClone(body);b[mode][section][key]=typeof value==='boolean'?!value:'INVALID';assert.equal(legacyCoreHighContrastOkay(b),false,`${mode}.${section}.${key}`);n++;}
console.log(JSON.stringify({result:'pass',independent_field_negatives:n}));
