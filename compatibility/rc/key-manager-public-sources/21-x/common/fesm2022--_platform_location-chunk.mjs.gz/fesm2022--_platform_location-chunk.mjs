/**
 * @license Angular v21.2.23
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */

import * as i0 from '@angular/core';
import { InjectionToken, inject, DOCUMENT, Injectable } from '@angular/core';

let _DOM = null;
function getDOM() {
  return _DOM;
}
function setRootDomAdapter(adapter) {
  _DOM ??= adapter;
}
class DomAdapter {}

class PlatformLocation {
  historyGo(relativePosition) {
    throw new Error(ngDevMode ? 'Not implemented' : '');
  }
  static ɵfac = i0.ɵɵngDeclareFactory({
    minVersion: "12.0.0",
    version: "21.2.23",
    ngImport: i0,
    type: PlatformLocation,
    deps: [],
    target: i0.ɵɵFactoryTarget.Injectable
  });
  static ɵprov = i0.ɵɵngDeclareInjectable({
    minVersion: "12.0.0",
    version: "21.2.23",
    ngImport: i0,
    type: PlatformLocation,
    providedIn: 'platform',
    useFactory: () => inject(BrowserPlatformLocation)
  });
}
i0.ɵɵngDeclareClassMetadata({
  minVersion: "12.0.0",
  version: "21.2.23",
  ngImport: i0,
  type: PlatformLocation,
  decorators: [{
    type: Injectable,
    args: [{
      providedIn: 'platform',
      useFactory: () => inject(BrowserPlatformLocation)
    }]
  }]
});
const LOCATION_INITIALIZED = new InjectionToken(typeof ngDevMode !== 'undefined' && ngDevMode ? 'Location Initialized' : '');
class BrowserPlatformLocation extends PlatformLocation {
  _location;
  _history;
  _doc = inject(DOCUMENT);
  constructor() {
    super();
    this._location = window.location;
    this._history = window.history;
  }
  getBaseHrefFromDOM() {
    return getDOM().getBaseHref(this._doc);
  }
  onPopState(fn) {
    const window = getDOM().getGlobalEventTarget(this._doc, 'window');
    window.addEventListener('popstate', fn, false);
    return () => window.removeEventListener('popstate', fn);
  }
  onHashChange(fn) {
    const window = getDOM().getGlobalEventTarget(this._doc, 'window');
    window.addEventListener('hashchange', fn, false);
    return () => window.removeEventListener('hashchange', fn);
  }
  get href() {
    return this._location.href;
  }
  get protocol() {
    return this._location.protocol;
  }
  get hostname() {
    return this._location.hostname;
  }
  get port() {
    return this._location.port;
  }
  get pathname() {
    return this._location.pathname;
  }
  get search() {
    return this._location.search;
  }
  get hash() {
    return this._location.hash;
  }
  set pathname(newPath) {
    this._location.pathname = newPath;
  }
  pushState(state, title, url) {
    this._history.pushState(state, title, url);
  }
  replaceState(state, title, url) {
    this._history.replaceState(state, title, url);
  }
  forward() {
    this._history.forward();
  }
  back() {
    this._history.back();
  }
  historyGo(relativePosition = 0) {
    this._history.go(relativePosition);
  }
  getState() {
    return this._history.state;
  }
  static ɵfac = i0.ɵɵngDeclareFactory({
    minVersion: "12.0.0",
    version: "21.2.23",
    ngImport: i0,
    type: BrowserPlatformLocation,
    deps: [],
    target: i0.ɵɵFactoryTarget.Injectable
  });
  static ɵprov = i0.ɵɵngDeclareInjectable({
    minVersion: "12.0.0",
    version: "21.2.23",
    ngImport: i0,
    type: BrowserPlatformLocation,
    providedIn: 'platform',
    useFactory: () => new BrowserPlatformLocation()
  });
}
i0.ɵɵngDeclareClassMetadata({
  minVersion: "12.0.0",
  version: "21.2.23",
  ngImport: i0,
  type: BrowserPlatformLocation,
  decorators: [{
    type: Injectable,
    args: [{
      providedIn: 'platform',
      useFactory: () => new BrowserPlatformLocation()
    }]
  }],
  ctorParameters: () => []
});

export { BrowserPlatformLocation, DomAdapter, LOCATION_INITIALIZED, PlatformLocation, getDOM, setRootDomAdapter };
//# sourceMappingURL=_platform_location-chunk.mjs.map
