from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time,traceback
ROOT=Path('/home/parallels/.codex/worktrees/codex-closeout-main/ngx-compat-material-legacy')
NODE='/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node'
TAR=Path('/tmp/root-radio-packed-main-v3/ngx-compat-material-legacy-22.0.0-rc.0.tgz')
STATE=Path('/tmp/root-main-sass-after-select-dialog-v5-state-v2.json')
LOG=Path('/tmp/root-main-sass-after-select-dialog-v5-v2.log')
REPORT=ROOT/'compatibility/rc/reports/sass-seal.json'
HEAD='0da0a92934ffae20098de762d78c329dc932c04c'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
s={'schema_version':1,'role':'durable-main-sass-iteration','controller_pid':os.getpid(),'source_head':HEAD,'root':str(ROOT),'tarball':str(TAR),'tarball_sha256':sha(TAR),'started_at':now(),'status':'preflight','log':str(LOG),'limits':['Standalone exact tarball iteration, no coordinator/G gate pass.','Prior process305292/session31722 missing with no fresh report; reason unknown.']}
def save():
 tmp=STATE.with_suffix('.new');tmp.write_text(json.dumps(s,indent=2)+'\n');tmp.replace(STATE)
try:
 assert s['tarball_sha256']=='eab8ee40771e47406dab34272879fd510f63da94b3936a81bcff2fc9f033a801'
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
 assert subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True)==''
 assert not LOG.exists()
 s['prior_report_sha256']=sha(REPORT) if REPORT.exists() else None
 env=dict(os.environ)
 env['PATH']='/tmp/root-main-sass-runtime-v1/bin:'+str(Path(NODE).parent)+':'+env['PATH']
 env['CHROME_BIN']='/nix/store/cfr0bikmf9nz75lsx095xacnmis6drgb-playwright-chromium/chrome-linux/chrome-wrapper'
 env['NODE_OPTIONS']='--max-old-space-size=1024'
 args=[NODE,'scripts/sass-seal.mjs','--tarball',str(TAR)]
 with LOG.open('wb') as log:
  child=subprocess.Popen(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  s.update(status='running',child_pid=child.pid,command=args,heap_limit_mb=1024)
  save()
  while child.poll() is None:
   s['last_observed_at']=now();s['log_bytes']=LOG.stat().st_size;save();time.sleep(10)
  s.update(status='passed' if child.returncode==0 else 'failed',exit_code=child.returncode,finished_at=now(),log_bytes=LOG.stat().st_size,log_sha256=sha(LOG))
 if REPORT.exists():
  s['report_sha256']=sha(REPORT);s['fresh_report']=s['report_sha256']!=s['prior_report_sha256']
  if s['fresh_report']:
   out=Path('/tmp/root-main-sass-after-select-dialog-v5-report-v2.json');out.write_bytes(REPORT.read_bytes());s['report_copy']=str(out)
 save()
except BaseException as e:
 s.update(status='controller-error',error=repr(e),traceback=traceback.format_exc(),finished_at=now());save();raise
