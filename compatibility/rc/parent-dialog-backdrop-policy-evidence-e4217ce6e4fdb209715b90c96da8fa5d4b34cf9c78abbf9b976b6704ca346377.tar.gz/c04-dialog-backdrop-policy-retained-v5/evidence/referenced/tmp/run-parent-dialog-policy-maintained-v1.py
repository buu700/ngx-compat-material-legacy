import pathlib,subprocess,hashlib,json,time,datetime,os,concurrent.futures
NODE='/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin'
PYTHON='/nix/store/lfh101cfjj8p8npcari9hk0lbqi33yvh-python3-3.14.7/bin/python3'
PATHS=['projects/ngx-material-legacy/legacy-dialog/internal/dialog-base.ts','projects/ngx-material-legacy/legacy-core/internal/legacy-animations.ts','tests/dialog_backdrop_policy_runtime_probe.mjs','tests/test_dialog_backdrop_policy_runtime.py','tests/test_dialog_motion_runtime.py','tests/dialog_motion_runtime_probe.mjs']
def run(line):
 root=pathlib.Path('/home/parallels/.codex/worktrees/codex-closeout-'+line+'/ngx-compat-material-legacy')
 def watch():return {p:{'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest(),'bytes':(root/p).stat().st_size} for p in PATHS}
 before=watch();start=time.monotonic();env={**os.environ,'PATH':NODE+':'+os.environ['PATH']}
 command=[PYTHON,'-m','unittest','tests.test_dialog_backdrop_policy_runtime','tests.test_dialog_motion_runtime','-v']
 child=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,timeout=180)
 after=watch();r={'schema':'parent-dialog-policy-maintained-v1','time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'line':line,'root':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'command':command,'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'returncode':child.returncode,'duration_seconds':time.monotonic()-start,'stdout':child.stdout,'stderr':child.stderr,'before':before,'after':after,'source_unchanged':before==after,'scope':'Actual maintained source with real Angular injector/fake CDK policy lifecycle plus existing motion runtime; no native/packed/G11/release gate.'}
 p=pathlib.Path('/tmp/parent-dialog-policy-maintained-'+line+'-v1.json');p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'path':str(p),'returncode':child.returncode,'duration_seconds':r['duration_seconds'],'source_unchanged':r['source_unchanged'],'stderr':child.stderr}),flush=True)
 assert child.returncode==0 and before==after and 'skipped' not in child.stderr
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:list(executor.map(run,['21','main']))
