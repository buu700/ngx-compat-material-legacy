/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * CSS keyframe motion (Material 22-style). Recipe metadata lives under
 * native CSS motion (historical `/animations` recipe secondary removed in F04).
 */

import {ChangeDetectionStrategy, Component, ViewEncapsulation} from '@angular/core';
import {_MatSnackBarContainerBase} from './internal/snack-bar-container-base';
import {legacyAnimationsDisabled, legacyHostMotionEvent} from '@ngx-compat/material-legacy/legacy-core';

const ENTER_MS = 150;
const EXIT_MS = 75;

/**
 * Internal component that wraps user-provided snack bar content.
 * @docs-private
 */
@Component({
  standalone: false,
  selector: 'snack-bar-container',
  templateUrl: 'snack-bar-container.html',
  styleUrls: ['snack-bar-container.scss'],
  // In Ivy embedded views will be change detected from their declaration place, rather than
  // where they were stamped out. This means that we can't have the snack bar container be OnPush,
  // because it might cause snack bars that were opened from a template not to be out of date.
  // tslint:disable-next-line:validate-decorators
  changeDetection: ChangeDetectionStrategy.Eager,
  encapsulation: ViewEncapsulation.None,
  host: {
    'class': 'mat-snack-bar-container',
    '[class.mat-snack-bar-container-enter]': "_animationsEnabled && _animationState === 'visible'",
    '[class.mat-snack-bar-container-exit]': "_animationsEnabled && _animationState === 'hidden'",
    '[class.mat-snack-bar-container-animations-enabled]': '_animationsEnabled',
    '(animationend)': 'onAnimationEnd($event)',
  },
})
export class MatLegacySnackBarContainer extends _MatSnackBarContainerBase {
  private readonly _legacyAnimationsDisabled = legacyAnimationsDisabled();
  readonly _animationsEnabled = !this._legacyAnimationsDisabled;

  private _legacyMotionDestroyed = false;
  private _enterFallback: ReturnType<typeof setTimeout> | null = null;
  private _exitFallback: ReturnType<typeof setTimeout> | null = null;

  protected override _afterEnterMotionStarted(): void {
    if (!this._animationsEnabled) {
      // Let callers subscribe after open() returns, as with the historical no-op animation.
      queueMicrotask(() => {
        if (!this._legacyMotionDestroyed && this._animationState === 'visible') {
          this._notifyEnter();
        }
      });
      return;
    }
    if (this._enterFallback !== null) {
      clearTimeout(this._enterFallback);
    }
    this._enterFallback = setTimeout(() => {
      this.onAnimationEnd('mat-legacy-snack-bar-enter');
    }, ENTER_MS + 50);
  }

  protected override _afterExitMotionStarted(): void {
    if (!this._animationsEnabled) {
      // Keep the container in the DOM for the current turn so callers can see
      // the mat-exit attribute, then finish on a microtask. queueMicrotask
      // runs under fakeAsync flush and in a zoneless app, unlike
      // NgZone.onMicrotaskEmpty.
      queueMicrotask(() => {
        if (!this._onExit.closed) {
          this._onExit.next();
          this._onExit.complete();
        }
      });
      return;
    }
    if (this._exitFallback !== null) {
      clearTimeout(this._exitFallback);
    }
    this._exitFallback = setTimeout(() => {
      this.onAnimationEnd('mat-legacy-snack-bar-exit');
    }, EXIT_MS + 50);
  }

  override onAnimationEnd(
    event: string | Event | {fromState?: string; toState?: string; animationName?: string},
  ) {
    if (typeof event !== 'string' && event instanceof Event) {
      if (!legacyHostMotionEvent(event)) {
        return;
      }
      const animationName = (event as AnimationEvent).animationName;
      if (animationName) {
        this.onAnimationEnd(animationName);
      }
      return;
    }
    if (typeof event === 'string') {
      if (event === 'mat-legacy-snack-bar-enter' && this._enterFallback !== null) {
        clearTimeout(this._enterFallback);
        this._enterFallback = null;
      }
      if (event === 'mat-legacy-snack-bar-exit' && this._exitFallback !== null) {
        clearTimeout(this._exitFallback);
        this._exitFallback = null;
      }
    }
    super.onAnimationEnd(event);
  }

  override ngOnDestroy() {
    this._legacyMotionDestroyed = true;
    if (this._enterFallback !== null) {
      clearTimeout(this._enterFallback);
    }
    if (this._exitFallback !== null) {
      clearTimeout(this._exitFallback);
    }
    super.ngOnDestroy();
  }

  protected override _afterPortalAttached() {
    super._afterPortalAttached();

    if (this.snackBarConfig.horizontalPosition === 'center') {
      this._elementRef.nativeElement.classList.add('mat-snack-bar-center');
    }

    if (this.snackBarConfig.verticalPosition === 'top') {
      this._elementRef.nativeElement.classList.add('mat-snack-bar-top');
    }
  }
}
