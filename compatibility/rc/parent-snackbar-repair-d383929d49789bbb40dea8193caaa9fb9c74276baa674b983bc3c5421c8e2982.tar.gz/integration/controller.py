import hashlib
import json
import pathlib
import subprocess

BASE = pathlib.Path('/home/parallels/.codex/worktrees')
OUT = pathlib.Path('/tmp/parent-snack-lifecycle-controlled-integration-v1.json')
PATCHES = {
    '/tmp/c04-snackbar-batch/prototype.patch': 'b9d63f4fac9c89ba653d43ad23f669e6b3d5fb207a433c25076d44aad7b0db04',
    '/tmp/c04-snackbar-batch/comment.patch': 'dca3d03411e4d57456bdce7f738a7142c5f55f8edb8dac4825c32b2461104b12',
    '/tmp/c04-snackbar-batch/tests-v3.patch': '93ecac77cbcf15f6f0c407184f0f4986b992f2a4639812cd867fb10daa75c7e6',
}
REVIEWS = {
    '/tmp/c04-snackbar-independent-review-v1.json': '19747c821b56e23cd5823edc8541c724fd4f4fc43dc0d6a98de5e57cd6063ea4',
    '/tmp/c04-snackbar-microtask-independent-review-v1.json': '9531a853cad5cd1860a79cb6d7158cdb265fd9df2c4642d934b247aa3d5d149e',
}
TARGETS = [
    'projects/ngx-material-legacy/legacy-snack-bar/snack-bar-container.ts',
    'projects/ngx-material-legacy/legacy-snack-bar/internal/snack-bar-base.ts',
    'projects/ngx-material-legacy/legacy-snack-bar/snack-bar.spec.ts',
]

def image(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def git(root, *args):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=0', *args], cwd=root)

def dirty(root):
    names = git(root, 'diff', '--name-only', '-z').split(b'\0')
    names += git(root, 'ls-files', '--others', '--exclude-standard', '-z').split(b'\0')
    return {p.decode(): image((root / p.decode()).read_bytes()) for p in names if p and p.decode() not in TARGETS}

assert not OUT.exists(), 'Do not overwrite a cited receipt'
for name, wanted in {**PATCHES, **REVIEWS}.items():
    assert image(pathlib.Path(name).read_bytes())['sha256'] == wanted, name
receipt = {'schema': 'parent-snack-lifecycle-controlled-integration-v1', 'patches': PATCHES, 'reviews': REVIEWS, 'branches': {}, 'remote_actions': 'none'}
for line in ['21', 'main']:
    root = BASE / ('codex-closeout-' + line) / 'ngx-compat-material-legacy'
    assert not git(root, 'diff', '--cached', '--name-only').strip(), 'Unrelated staged changes'
    before = {p: image((root / p).read_bytes()) for p in TARGETS}
    for p in TARGETS:
        assert (root / p).read_bytes() == git(root, 'show', 'HEAD:' + p), p
    subprocess.run(['git', 'apply', '--check', *PATCHES], cwd=root, check=True)
    receipt['branches'][line] = {'root': str(root), 'before_head': git(root, 'rev-parse', 'HEAD').decode().strip(), 'before': before, 'unrelated_before': dirty(root)}
for line, row in receipt['branches'].items():
    root = pathlib.Path(row['root'])
    subprocess.run(['git', 'apply', *PATCHES], cwd=root, check=True)
    # afterOpened's next notification, rather than RxJS completion alone, arms duration.
    service = root / TARGETS[1]
    content = service.read_text()
    old = '// Subscribe before enter() so completion always arms the duration timer.'
    assert content.count(old) == 1
    service.write_text(content.replace(old, '// Subscribe before enter() so the opening notification arms the duration timer.'))
    row['after'] = {p: image((root / p).read_bytes()) for p in TARGETS}
    row['unrelated_after'] = dirty(root)
    assert row['unrelated_after'] == row['unrelated_before'], 'Unrelated dirty bytes changed'
    row['diff'] = git(root, 'diff', '--', *TARGETS).decode()
    subprocess.run(['git', 'diff', '--check', '--', *TARGETS], cwd=root, check=True)
receipt['root_review_delta'] = 'Only the service comment differs from the reviewed comment patch: opening notification accurately describes the next handler; runtime and regression code exactly match the reviewed patches.'
receipt['qualification_limit'] = '66/66 per floor belongs to independently tested prior prototype tarballs, not the current maintained graph or final RC artifact. No new browser/full source/RC gate is claimed.'
OUT.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': str(OUT), 'branches': {k: {'before_head': v['before_head'], 'after': v['after']} for k,v in receipt['branches'].items()}}))
