import subprocess,hashlib,json
from pathlib import Path
node='/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node';p=Path('/tmp/c04-chip-tdz-independent-v1');script=(p/'check.mjs').read_text();entries=['./scripts/tab-portal-explicit-container-review.mjs','./scripts/tab-adapter-product-inventory-context.mjs','./scripts/upstream-historical-behavior-evidence.mjs'];records=[]
for line,root in [('main',Path('/home/parallels/.codex/worktrees/codex-closeout-main/ngx-compat-material-legacy')),('21.x',Path('/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy')),('old-control',p)]:
 f=root/'scripts/upstream-chip-lifecycle-admission.mjs';before=hashlib.sha256(f.read_bytes()).hexdigest()
 for entry in entries:
  r=subprocess.run([node,'--input-type=module','-e',script.replace('process.argv[2]','process.argv[1]'),entry],cwd=root,text=True,capture_output=True,timeout=60);records.append({'line':line,'entry':entry,'source_sha256':before,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 after=hashlib.sha256(f.read_bytes()).hexdigest();assert before==after
 if line!='old-control':assert all(x['exit_code']==0 for x in records[-3:])
 else:assert any(x['exit_code']!=0 and 'before initialization' in x['stderr'] for x in records[-3:])
out=p/'results.json';out.write_text(json.dumps(records,indent=2)+'\n');print(json.dumps([{'line':x['line'],'entry':x['entry'],'exit':x['exit_code'],'stderr':x['stderr'][:150]} for x in records]))
