import assert from 'node:assert/strict';
await import(process.argv[2]);
const admission=await import('./scripts/upstream-chip-lifecycle-admission.mjs');
const context=await import('./scripts/tab-adapter-product-inventory-context.mjs');
const required=['compatibility/rc/tab-adapter-product-inventory-inputs.json','compatibility/rc/tab-adapter-product-inventory-focus-inputs.json'];
assert.deepEqual([context.TAB_ADAPTER_INVENTORY_INPUTS,context.CURRENT_CHIP_FOCUS_INPUTS],required);
const scopes=admission.chipLifecycleHistoricalScopes(['independent-sentinel',required[0]],(...args)=>args);
assert.equal(scopes.length,3);
for(const [sha,scope] of scopes){assert.ok(admission.CHIP_LIFECYCLE_NATIVE_SHAS.includes(sha));assert.equal(scope.members.filter(x=>x===required[0]).length,1);assert.equal(scope.members.filter(x=>x===required[1]).length,1);assert.ok(scope.members.includes('independent-sentinel'));assert.equal(scope.source_contract,'owned-chip-lifecycle-current');assert.ok(scope.cases.length>0);}
console.log(JSON.stringify({entry:process.argv[2],scopes:scopes.length,required}));
