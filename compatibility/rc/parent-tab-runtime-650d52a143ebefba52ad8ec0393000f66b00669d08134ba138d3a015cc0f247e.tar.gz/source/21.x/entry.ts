import "/home/parallels/.codex/worktrees/source-profile-v11-21/ngx-compat-material-legacy/testing/legacy-runner/init-test-env.ts";
import "/home/parallels/.codex/worktrees/source-profile-v11-21/ngx-compat-material-legacy/projects/ngx-material-legacy/legacy-tabs/tab-body-reversal.spec.ts";
