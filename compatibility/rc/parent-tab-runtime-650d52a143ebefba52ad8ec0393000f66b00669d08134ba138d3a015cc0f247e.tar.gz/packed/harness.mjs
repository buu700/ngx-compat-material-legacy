import {readFileSync,writeFileSync,mkdirSync,realpathSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import {dirname,join} from 'node:path';
import {pathToFileURL} from 'node:url';

const [lineArg,runtime]=process.argv.slice(2);
if(!['21','main'].includes(lineArg)||!['zoneful','zoneless'].includes(runtime))throw Error('usage: node script 21|main zoneful|zoneless');
const line=lineArg==='21'?'21.x':'main';
const profile=`/home/parallels/.codex/worktrees/source-profile-v11-${lineArg}/ngx-compat-material-legacy`;
const setup=JSON.parse(readFileSync(`/tmp/fresh-sass-sol6-${lineArg}-v1/setup.json`));
const outDir=`/tmp/native-tabs-rapid-sol6-v1/${lineArg}`;
mkdirSync(outDir,{recursive:true});
const out=join(outDir,`${runtime}.json`);
const h=bytes=>createHash('sha256').update(bytes).digest('hex');
const stamp=(stage,extra={})=>{const row={line,runtime,stage,time:new Date().toISOString(),...extra};console.error(JSON.stringify(row));return row;};
const sourcePaths=['scripts/native-motion-run.mjs','scripts/native-motion-consumer.ts','scripts/native-motion-page.mjs','scripts/native-motion-roster.mjs','scripts/browser-required-cells.mjs'];
const report={schema_version:1,scope:'packed native tabs rapid reversal Chromium focused runtime',line,runtime,started_at:new Date().toISOString(),status:'started',command:{execPath:process.execPath,args:process.argv.slice(1),cwd:process.cwd(),chromeBin:process.env.CHROME_BIN||null},artifact:{path:setup.artifact,expected_sha256:setup.artifact_sha256,actual_sha256:h(readFileSync(setup.artifact)),bytes:readFileSync(setup.artifact).length},tool_source:Object.fromEntries(sourcePaths.map(path=>[path,h(readFileSync(join(profile,path)))]))};
const save=()=>writeFileSync(out,JSON.stringify(report,null,2)+'\n');
save();
let server;
try{
 if(report.artifact.actual_sha256!==report.artifact.expected_sha256)throw Error('artifact SHA mismatch');
 const [{buildConsumer},{withChromium},{assertCase}]=await Promise.all([
  import(pathToFileURL(join(profile,'scripts/native-motion-run.mjs'))),
  import(pathToFileURL(join(profile,'scripts/browser-required-cells.mjs'))),
  import(pathToFileURL(join(profile,'scripts/native-motion-roster.mjs'))),
 ]);
 stamp('building');
 const built=await buildConsumer(setup.artifact,runtime==='zoneless');
 report.consumer={path:built.consumer,bundleHasZone:built.bundleHasZone,app_sha256:h(readFileSync(join(built.consumer,'dist/app.js'))),theme_sha256:h(readFileSync(join(built.consumer,'dist/theme.css'))),cache_ready_sha256:h(readFileSync(join(built.consumer,'dist/cache-ready.json')))};
 if(runtime==='zoneless'&&built.bundleHasZone)throw Error('zoneless bundle contains Zone');
 save();stamp('built',{consumer:built.consumer,app_sha256:report.consumer.app_sha256});
 server=createServer((req,res)=>{
  const path=(req.url||'/').split('?')[0];
  const name=path==='/'?'index.html':path.replace(/^\//,'');
  if(!['index.html','app.js','theme.css'].includes(name)){res.writeHead(404);res.end();return;}
  try{const body=readFileSync(join(built.consumer,'dist',name));res.writeHead(200,{'content-type':name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':'text/html'});res.end(body);}catch{res.writeHead(404);res.end();}
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const origin=`http://127.0.0.1:${server.address().port}`;
 const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 await withChromium(origin,async driver=>{
  report.browser=driver.browser;save();stamp('browser',{browser:driver.browser});
  let readiness=null;
  for(let i=0;i<90;i++){
   const status=JSON.parse(await driver.evaluate('JSON.stringify({ready: document.documentElement.dataset.labReady || "", error: (document.getElementById("bootstrap-error") || {}).textContent || "", angularZoneEntered: window.__closeoutAngularZoneEntered})'));
   if(status.error)throw Error('bootstrap failed '+status.error);
   if(status.ready==='1'){readiness=status;break;}
   await sleep(100);
  }
  if(!readiness)throw Error('page did not bootstrap');
  report.readiness=readiness;save();stamp('ready',readiness);
  if(readiness.angularZoneEntered!==(runtime==='zoneful'))throw Error('Angular zone mode mismatch');
  await driver.evaluate("document.documentElement.dataset.stepState='running'; document.getElementById('interrupt-tabs').click();");
  let step=null,last=null;
  for(let i=0;i<240;i++){
   const current=JSON.parse(await driver.evaluate('JSON.stringify({step: document.documentElement.dataset.step || "", state: document.documentElement.dataset.stepState || "", value: window.__step || null, error: (document.getElementById("bootstrap-error") || {}).textContent || ""})'));
   last=current;
   if(current.error)throw Error('probe error '+current.error);
   if(current.state==='done'&&current.step==='interrupt-tabs'){step=current.value;break;}
   await sleep(50);
  }
  if(!step)throw Error('probe timed out '+JSON.stringify(last).slice(0,1000));
  report.raw_step=step;
  report.dom_after=JSON.parse(await driver.evaluate('JSON.stringify({activeText:(document.querySelector(".mat-tab-body-active .mat-tab-body-content")||{}).textContent||"",animating:!!document.querySelector(".mat-tab-body-animating"),activeLabels:[...document.querySelectorAll(".mat-tab-label-active")].map(x=>x.textContent.trim())})'));
  const caseId=`native-motion/${line}/chromium/${runtime}/interruption-destruction/tabs/rapid-reversal`;
  const observation=step?.observation?{...step.observation,angularZoneEntered:readiness.angularZoneEntered}:null;
  const problems=step?.key==='tabs/rapid-reversal'?assertCase(caseId,observation):['wrong probe key'];
  if(!report.dom_after.activeText.includes('Three')||report.dom_after.animating)problems.push('DOM did not settle on Three');
  report.assertion={case_id:caseId,observation,problems,pass:problems.length===0};
  stamp('asserted',{case_id:caseId,pass:problems.length===0,problems});
 },{startPath:'/?mode=enabled&scene=interrupt'});
 report.artifact.after_sha256=h(readFileSync(setup.artifact));
 if(report.artifact.after_sha256!==report.artifact.expected_sha256)throw Error('artifact changed during run');
 report.status=report.assertion.pass?'pass':'fail';
}catch(error){report.status='error';report.error=String(error?.stack||error);stamp('error',{error:report.error});}
finally{if(server)await new Promise(resolve=>server.close(resolve));report.finished_at=new Date().toISOString();save();stamp('done',{status:report.status,report:out,report_sha256:h(readFileSync(out))});}
if(report.status!=='pass')process.exitCode=1;
