import hashlib,json,pathlib,re,subprocess,datetime
cyph=pathlib.Path('/home/parallels/cyph')
roots={line:pathlib.Path('/home/parallels/.codex/worktrees')/name/'ngx-compat-material-legacy' for line,name in [('21','codex-closeout-21'),('main','codex-closeout-main')]}
components=['account-wallets','account-contacts','account-register','account-pgp','help']
files=[]
for name in components:
    files.extend(sorted((cyph/'shared/js/cyph/components'/name).glob('*')))
files=[p for p in files if p.is_file() and p.suffix in {'.html','.scss','.ts'}]
files.extend(cyph/p for p in ['shared/css/cyph.base.scss','shared/css/mixins.scss','shared/js/cyph/modules/cyph-web.module.ts','shared/js/cyph/modules/cyph-shared.module.ts'])
def row(p,base):
    b=p.read_bytes();return {'path':str(p.relative_to(base)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
pattern=re.compile(r'matTabContent|animationDone|preserveContent|animationDuration|selectedIndexChange|mat-tab-body|mat-tab-label|MatLegacyTabsModule|BrowserAnimationsModule')
hits=[]
for p in files:
    for n,s in enumerate(p.read_text().splitlines(),1):
        if pattern.search(s): hits.append({'path':str(p.relative_to(cyph)),'line':n,'text':s.strip()})
product=[]
for line,root in roots.items():
    source=[root/'projects/ngx-material-legacy/legacy-tabs'/p for p in ['tab-body.html','tab-body.scss','tab-group.html','tab-group.scss']]
    rows=[]
    for p in source:
        current=p.read_bytes(); old=subprocess.check_output(['git','show','HEAD:'+str(p.relative_to(root))],cwd=root)
        assert current==old
        rows.append(row(p,root)|{'equals_committed_HEAD':True})
    product.append({'line':line,'HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'unchanged_style_template_sources':rows})
report={'schema':'c04-tabs-cyph-static-sanity-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only static sanity of five known Cyph tab consumers and shared selectors; not whole-app compatibility or execution proof.','cyph_HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=cyph,text=True).strip(),'source_members':[row(p,cyph) for p in files],'matching_observations':hits,'product_styles_templates':product,'findings':['Scanned five HTML templates have no explicit matTabContent, animationDone, preserveContent or animationDuration use.','selectedIndexChange handlers occur in account-contacts and account-register; scanned source does not establish whole-app lifecycle timing independence.','Existing selectors include mat-tab-body, mat-tab-body.mat-tab-body-active > div, .mat-tab-body-wrapper and .mat-tab-label; tabs changes retain these structures/selectors and require no CSS/SCSS edit in the inspected consumers.','Account-contacts intentionally hides .mat-tab-body-wrapper with display:none!important; account-register overrides active body/direct-child overflow.','No .mat-tab-body-content transform/transition override found in these component styles or shared/css sources.'],'limitations':['No Cyph file modified.','No Cyph build/runtime/integration executed. Final upgraded-consumer and release gates remain required.','Product TypeScript is undergoing a further stale-end correction; this report qualifies unchanged templates/styles at the listed HEADs only, not final motion source.']}
for p in files:
    if p.suffix=='.html':
        assert not re.search(r'matTabContent|animationDone|preserveContent|animationDuration',p.read_text())
# Broader shared-css scan only establishes the stated selector absence, not arbitrary Sass expansion behavior.
css=[p for p in (cyph/'shared/css').rglob('*') if p.is_file() and p.suffix in {'.css','.scss'}]
report['shared_css_scan_members']=[row(p,cyph) for p in sorted(css)]
report['body_content_selector_hits']=[str(p.relative_to(cyph)) for p in css if '.mat-tab-body-content' in p.read_text()]
assert not report['body_content_selector_hits']
out=pathlib.Path('/tmp/parent-c04-tabs-cyph-static-sanity-v1.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_members':len(files),'shared_css_members':len(css),'observations':len(hits)}))
