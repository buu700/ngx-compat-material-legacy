from pathlib import Path
import hashlib,json,difflib,shutil
root=Path('/tmp/parent-c04-tabs-candidate-lifecycle-trace-v2');root.mkdir();header=Path('/tmp/parent-c04-tabs-reference-lifecycle-trace-v3/public/bundle.mjs').read_text().split('var __defProp = Object.defineProperty;',1)[0]
for name in ['candidate21','candidate22']:
 source=Path('/tmp/parent-c04-tabs-three-comparison-v3')/name/'ltr/bundle.mjs';original=source.read_text();s=header+original
 for marker,tag in [('  _startTransition(fromOverride) {','candidate-start'),('  _finishTransition(transition) {','candidate-finish'),('  _onContentTransitionEnd(event) {','candidate-native-end')]:
  assert s.count(marker)==1,(name,marker,s.count(marker));extra=",transition:transition?{...transition}:null" if 'finishTransition' in marker else ",property:event.propertyName,elapsed:event.elapsedTime" if 'TransitionEnd' in marker else ",fromOverride:fromOverride??null"
  s=s.replace(marker,marker+"\n    window.__log('"+tag+"',{id:this._elementRef.nativeElement.id,position:this._position,pending:this._pendingTransition?{...this._pendingTransition}:null"+extra+"});",1)
 start=s.index('var MatLegacyTabBodyPortal = class _MatLegacyTabBodyPortal');idx=s.index('  ngOnInit() {',start)
 code='''  detach() {
    const ref=this.attachedRef;const roots=Array.isArray(ref?.rootNodes)?[...ref.rootNodes]:[];const id=this._host._elementRef.nativeElement.id;
    if(ref)window.__trackedViews.push({id,ref,roots});
    window.__log('portal-detach-before',{id,position:this._host._position,preserve:this._host.preserveContent,attached:this.hasAttached(),destroyed:ref?.destroyed??null,roots:roots.map(window.__nodeInfo)});
    try{return super.detach()}finally{window.__log('portal-detach-after',{id,position:this._host._position,attached:this.hasAttached(),destroyed:ref?.destroyed??null,roots:roots.map(window.__nodeInfo)});}
  }
''';s=s[:idx]+code+s[idx:]
 for kind in ['create','destroy']:
  needle=f'    lifecycle.push({{ type: "{kind}", panel: this.panel, instance: this.instance }});';assert s.count(needle)==1;s=s.replace(needle,needle+f"window.__log('consumer-{kind}',{{panel:this.panel,instance:this.instance}});")
 needle='var record = (type, details = {}) => events.push({ type, ...details, time: performance.now(), actionId });';assert s.count(needle)==1;s=s.replace(needle,"var record = (type, details = {}) => {window.__log('public-'+type,{...details});events.push({type,...details,time:performance.now(),actionId});};")
 needle='  const host = app.components[0].instance;';assert s.count(needle)==1;s=s.replace(needle,needle+"\n  window.__destroyC04=()=>{window.__log('application-destroy-start');app.destroy();window.__log('application-destroy-end');};")
 needle='''      const id = ++actionId;
      host.zone.run(() => {
        host.selected = index;''';assert s.count(needle)==1;s=s.replace(needle,needle.replace('      host.zone.run',"      window.__currentActionId=id;window.__log('select-request',{index});\n      host.zone.run"))
 dest=root/name;dest.mkdir();(dest/'instrumentation.diff').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='actual-candidate',tofile='instrumented-copy')))
 for direction in ['ltr','rtl']:
  out=dest/direction;out.mkdir();(out/'public').mkdir();shutil.copyfile(source.parent.parent/direction/'index.html',out/'public/index.html');shutil.copyfile(source.parent.parent/direction/'theme.css',out/'public/theme.css');(out/'public/bundle.mjs').write_text(s)
  script=Path('/tmp/parent-c04-tabs-reference-lifecycle-trace-v3',direction,'run.mjs').read_text();lines=script.splitlines(keepends=True);lines[1]='const root='+json.dumps(str(out/'public'))+', result='+json.dumps(str(out/'observations.json'))+';\n';(out/'run.mjs').write_text(''.join(lines))
 h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(dest/'identity.json').write_text(json.dumps({'original':str(source),'original_sha256':h(source),'instrumented_sha256':h(dest/'ltr/public/bundle.mjs'),'diff_sha256':h(dest/'instrumentation.diff'),'scope':'diagnostic recording only; not golden or qualification'},indent=2)+'\n')
