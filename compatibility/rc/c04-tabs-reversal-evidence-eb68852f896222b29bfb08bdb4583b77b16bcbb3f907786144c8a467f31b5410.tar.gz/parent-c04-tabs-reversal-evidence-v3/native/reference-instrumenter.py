from pathlib import Path
import hashlib,json,shutil,difflib
source=Path('/tmp/parent-c04-tabs-three-comparison-v2/reference/ltr/bundle.mjs');dest=Path('/tmp/parent-c04-tabs-reference-lifecycle-trace-v3');dest.mkdir();(dest/'public').mkdir();shutil.copyfile('/tmp/parent-c04-tabs-three-comparison-v2/reference/ltr/index.html',dest/'public/index.html');shutil.copyfile('/tmp/parent-c04-tabs-three-comparison-v2/reference/ltr/theme.css',dest/'public/theme.css')
original=source.read_text();s=original
header='''window.__lifecycleTrace=[];window.__trackedViews=[];window.__trackedNodes=[];window.__nodeIds=new WeakMap();window.__nextNodeId=0;
window.__nodeInfo=(n)=>{if(!n)return null;if(!window.__nodeIds.has(n))window.__nodeIds.set(n,++window.__nextNodeId);return {id:window.__nodeIds.get(n),type:n.nodeType,tag:n.tagName||null,panel:n.getAttribute?.('data-panel-probe')||null,connected:n.isConnected,focus:n===document.activeElement}};
window.__log=(kind,data={})=>window.__lifecycleTrace.push({kind,time:performance.now(),actionId:window.__currentActionId||0,...data});
window.__state=()=>({time:performance.now(),focus:window.__nodeInfo(document.activeElement),views:window.__trackedViews.map(v=>({id:v.id,destroyed:v.ref.destroyed,roots:v.roots.map(window.__nodeInfo)})),nodes:window.__trackedNodes.map(window.__nodeInfo)});
new MutationObserver(records=>{for(const r of records)for(const [kind,nodes] of [['added',r.addedNodes],['removed',r.removedNodes]])for(const n of nodes){const found=[];if(n.nodeType===1&&n.matches?.('[data-panel-probe]'))found.push(n);if(n.nodeType===1)found.push(...n.querySelectorAll('[data-panel-probe]'));for(const z of found){if(!window.__trackedNodes.includes(z))window.__trackedNodes.push(z);window.__log('mutation-'+kind,{node:window.__nodeInfo(z)});}}}).observe(document.documentElement,{subtree:true,childList:true});
'''
s=header+s
needle='''    this._translateTabComplete = new Subject();
    this._onCentering = new EventEmitter();''';assert s.count(needle)==1
s=s.replace(needle,'''    this._translateTabComplete = new Subject();
    const originalTranslateNext = this._translateTabComplete.next.bind(this._translateTabComplete);
    this._translateTabComplete.next = event => {window.__log('translate-done',{id:this._elementRef.nativeElement.id,position:this._position,fromState:event.fromState,toState:event.toState,phaseName:event.phaseName,totalTime:event.totalTime});return originalTranslateNext(event);};
    this._onCentering = new EventEmitter();''',1)
needle='''  _onTranslateTabStarted(event) {
    const isCentering = this._isCenterPosition(event.toState);''';assert s.count(needle)==1
s=s.replace(needle,'''  _onTranslateTabStarted(event) {
    window.__log('translate-start',{id:this._elementRef.nativeElement.id,position:this._position,fromState:event.fromState,toState:event.toState,phaseName:event.phaseName,totalTime:event.totalTime});
    const isCentering = this._isCenterPosition(event.toState);''',1)
needle='''      if (this._isCenterPosition(event.fromState) && !this._isCenterPosition(this._position)) {
        this._afterLeavingCenter.emit();''';assert s.count(needle)==1
s=s.replace(needle,'''      if (this._isCenterPosition(event.fromState) && !this._isCenterPosition(this._position)) {
        window.__log('after-leaving-center',{id:this._elementRef.nativeElement.id,position:this._position,fromState:event.fromState,toState:event.toState});
        this._afterLeavingCenter.emit();''',1)
needle='''  /** Set initial visibility or set up subscription for changing visibility. */
  ngOnInit() {''';assert s.count(needle)==1
s=s.replace(needle,'''  detach() {
    const ref = this.attachedRef;const roots = Array.isArray(ref?.rootNodes) ? [...ref.rootNodes] : [];
    const id=this._host._elementRef.nativeElement.id;
    if (ref) window.__trackedViews.push({id,ref,roots});
    for (const n of roots) {if (n.nodeType===1 && n.matches?.('[data-panel-probe]') && !window.__trackedNodes.includes(n)) window.__trackedNodes.push(n);}
    window.__log('portal-detach-before',{id,position:this._host._position,preserve:this._host.preserveContent,attached:this.hasAttached(),destroyed:ref?.destroyed??null,roots:roots.map(window.__nodeInfo)});
    try{return super.detach();}finally{window.__log('portal-detach-after',{id,position:this._host._position,attached:this.hasAttached(),destroyed:ref?.destroyed??null,roots:roots.map(window.__nodeInfo)});}
  }
  /** Set initial visibility or set up subscription for changing visibility. */
  ngOnInit() {''',1)
needle='    lifecycle.push({ type: "create", panel: this.panel, instance: this.instance });';assert s.count(needle)==1;s=s.replace(needle,needle+"window.__log('consumer-create',{panel:this.panel,instance:this.instance});")
needle='    lifecycle.push({ type: "destroy", panel: this.panel, instance: this.instance });';assert s.count(needle)==1;s=s.replace(needle,needle+"window.__log('consumer-destroy',{panel:this.panel,instance:this.instance});")
needle='var record = (type, details = {}) => events.push({ type, ...details, time: performance.now(), actionId });';assert s.count(needle)==1;s=s.replace(needle,"var record = (type, details = {}) => {window.__log('public-'+type,{...details});events.push({type,...details,time:performance.now(),actionId});};")
needle='  const host = app.components[0].instance;';assert s.count(needle)==1;s=s.replace(needle,needle+"\n  window.__destroyC04=()=>{window.__log('application-destroy-start');app.destroy();window.__log('application-destroy-end');};")
needle='''      const id = ++actionId;
      host.zone.run(() => {
        host.selected = index;''';assert s.count(needle)==1;s=s.replace(needle,needle.replace('      host.zone.run',"      window.__currentActionId=id;window.__log('select-request',{index});\n      host.zone.run"))
(dest/'public/bundle.mjs').write_text(s)
(dest/'instrumentation.diff').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='authenticated-fixture-bundle',tofile='instrumented-copy')))
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(dest/'identity.json').write_text(json.dumps({'original':str(source),'original_sha256':h(source),'instrumented_sha256':h(dest/'public/bundle.mjs'),'diff_sha256':h(dest/'instrumentation.diff'),'scope':'diagnostic instrumented bundle only; not golden, qualification or product implementation'},indent=2)+'\n')
