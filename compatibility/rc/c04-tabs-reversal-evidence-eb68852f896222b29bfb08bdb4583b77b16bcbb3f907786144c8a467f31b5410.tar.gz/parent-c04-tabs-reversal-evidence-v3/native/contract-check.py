from pathlib import Path
import json,hashlib
root=Path('/tmp/parent-c04-tabs-candidate-lifecycle-trace-v2');rows=[]
for name in ['candidate21','candidate22']:
 for direction in ['ltr','rtl']:
  p=root/name/direction/'observations.json';d=json.loads(p.read_text());assert not d['errors']
  for r in d['cases']:
   tests={};preserve=r['preserve'];ph={x['name']:x for x in r['phases']};trace=r['trace'];host='mat-tab-content-0-1';beta=lambda phase:[n for n in ph[phase]['state']['nodes'] if n.get('panel')=='beta'];connected=lambda phase:[n for n in beta(phase) if n['connected']];destroy=lambda e:e['kind']=='consumer-destroy' and e.get('panel')=='beta' and e.get('instance')==1
   tests['observed_without_exceptions']=r['status']=='observed' and not r.get('exceptions')
   tests['initial_focus_inside_original_beta']=ph['initial-focused-beta']['state']['focus']['tag']=='BUTTON' and len(connected('initial-focused-beta'))==1
   tests['canceled_phases_do_not_destroy_current_view']=not any(destroy(e) for e in trace if e.get('actionId',0)<5)
   tests['latest_completion_present']=any(e['kind']=='candidate-finish' and e.get('id')==host and e.get('actionId')==5 and e.get('transition',{}).get('fromState')=='center' for e in trace)
   tests['only_one_beta_node_after_reselect']=len(connected('reselect-settled'))==1
   tests['all_beta_nodes_disconnected_after_destroy']=all(not n['connected'] for n in beta('after-application-destroy'))
   if preserve:
    tests['preserved_view_not_destroyed_before_app_teardown']=not any(destroy(e) for e in trace if e['kind']!='application-destroy-start' and e['time']<next(x['time'] for x in trace if x['kind']=='application-destroy-start'))
    tests['same_beta_node_after_reselect']=connected('initial-focused-beta')[0]['id']==connected('reselect-settled')[0]['id']
   else:
    done=next((i for i,e in enumerate(trace) if e['kind']=='candidate-finish' and e.get('id')==host and e.get('actionId')==5 and e.get('transition',{}).get('fromState')=='center'),-1)
    deaths=[i for i,e in enumerate(trace) if destroy(e)]
    tests['old_beta_destroyed_once_after_latest_completion']=done>=0 and len(deaths)==1 and deaths[0]>done
    tests['old_beta_disconnected_after_settlement']=len(connected('final-settled'))==0
    tests['reselect_created_distinct_beta_node']=len(connected('reselect-settled'))==1 and connected('reselect-settled')[0]['id']!=beta('initial-focused-beta')[0]['id']
    tests['focus_not_left_on_detached_beta']=ph['final-settled']['state']['focus']['id']!=ph['initial-focused-beta']['state']['focus']['id']
   rows.append({'candidate':name,'direction':direction,'preserve':preserve,'checks':tests,'status':'pass' if all(tests.values()) else 'failed','trace_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
report={'scope':'Focused scratch native lifecycle controls on instrumented copies, not C04 parity qualification. Synthetic stale-end rejection is separately covered by the actual-class Jasmine spec.','cases':rows,'status':'pass' if all(r['status']=='pass' for r in rows) else 'failed','limitations':['The tagged reference destroys the view earlier and retains its original DOM nodes; this proposed owned-lifecycle disposition differs in timing and physical node behavior.','Deadlines cannot associate a native event with a particular transition; the public animationDone event carries no cycle identity.','Browser callback scheduling may extend beyond configured animation and fallback timers.','Instrumentation adds recording wrappers; original packed artifacts are unchanged.']};out=root/'contract-check.json';out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'cases':[(r['candidate'],r['direction'],r['preserve'],r['status'],[k for k,v in r['checks'].items() if not v]) for r in rows]}))
