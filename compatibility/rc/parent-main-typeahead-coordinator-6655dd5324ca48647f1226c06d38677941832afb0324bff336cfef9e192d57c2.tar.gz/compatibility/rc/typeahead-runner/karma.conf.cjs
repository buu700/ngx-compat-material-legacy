/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 * Use of this source code is governed by the MIT license in LICENSE.
 */
const path = require('path');

module.exports = function (config) {
  const expectFail = process.env.LEGACY_TESTS_EXPECT_FAIL === '1';
  config.set({
    basePath: path.resolve(__dirname, '../..'),
    frameworks: ['jasmine'],
    files: [
      {pattern: 'testing/legacy-runner/out/legacy-tests.iife.js', watched: false},
    ],
    reporters: ['progress', 'legacy-json'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('./karma-legacy-json-reporter.cjs'),
    ],
    legacyJsonReporter: {
      outputFile: process.env.LEGACY_RESULTS_PATH
        ? path.resolve(process.env.LEGACY_RESULTS_PATH)
        : path.resolve(__dirname, '../../compatibility/f08/legacy-test-results.json'),
      expectFail,
    },
    hostname: '127.0.0.1',
    // Fixed off the default so a leftover browser tab cannot join the run.
    port: 9887,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: false,
    singleRun: true,
    captureTimeout: 180000,
    browserNoActivityTimeout: 600000,
    browserDisconnectTimeout: 180000,
    pingTimeout: 120000,
    browsers: ['ChromeHeadlessNoSandbox'],
    customLaunchers: {
      ChromeHeadlessNoSandbox: {
        base: 'ChromeHeadless',
        flags: [
          '--no-sandbox',
          '--disable-gpu',
          '--disable-dev-shm-usage',
          // Historical layout specs place a 500px trigger and read the tooltip
          // below it. The default headless viewport clips that trigger.
          '--window-size=1400,1200',
        ],
      },
    },
    client: {
      jasmine: {random: false},
      args: process.env.LEGACY_TYPEAHEAD_GREP ? ['--grep', process.env.LEGACY_TYPEAHEAD_GREP] : [],
      captureConsole: true,
    },
    browserConsoleLogOptions: {level: 'log', terminal: true},
  });
};
