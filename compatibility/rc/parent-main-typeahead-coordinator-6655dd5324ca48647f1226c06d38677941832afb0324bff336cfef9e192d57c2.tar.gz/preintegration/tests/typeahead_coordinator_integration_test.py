import copy
import hashlib
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from rc_acceptance import (EvidenceError, EvidenceSnapshot, TYPEAHEAD_CASES,
                           validate_matrix, validate_typeahead_observation)
spec = importlib.util.spec_from_file_location('rc_verify', ROOT / 'scripts/rc-verify.py')
coordinator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(coordinator)

class TypeaheadIntegration(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.prefix = 'evidence/typeahead-execution/inv1'
        self.out = self.root / self.prefix
        self.out.mkdir(parents=True)
        self.binding = {'run_id': 'run1', 'source_line': 'main'}
        self.run = {'run_id': 'run1', 'artifacts': [{'id': 'library', 'sha256': 'a'*64, 'bytes': 123}]}
        selected = [{'full_name': name, 'skipped': False, 'success': True} for name in TYPEAHEAD_CASES]
        specs = selected + [{'full_name': f'other {i}', 'skipped': True} for i in range(487)]
        self.raw = {'subject_mode':'artifact', 'mode':'normal', 'run_id':'run1', 'artifact_sha256':'a'*64,
                    'totals':{'executed':496,'passed':9,'failed':0,'skipped':487}, 'failures':[], 'specs':specs}
        self.files = {}
        for name in ('raw-report.json','commands.json','inputs-before.json','metafile.json','bundle.js','bundle-inputs.json','entry.generated.ts'):
            data = (json.dumps(self.raw) if name == 'raw-report.json' else name).encode()
            (self.out / name).write_bytes(data)
            self.files[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes':len(data)}
        self.obs = {'schema_version':1, 'kind':'typeahead-execution', 'sha':'ff36c80f9c7a14f0e9f36eafc3e1423d34e7c916', 'run_id':'run1', 'line':'main', 'invocation_id':'inv1', 'binding':self.binding, 'library':{'sha256':'a'*64,'bytes':123}, 'inputs_unchanged':True, 'files':self.files, 'selected_cases':selected, 'counts':self.raw['totals']}
        self.write_obs()
    def tearDown(self): self.temp.cleanup()
    def write_obs(self): (self.out/'observation.json').write_text(json.dumps(self.obs))
    def validate(self):
        paths = {f'{self.prefix}/{name}' for name in (*self.files, 'observation.json')}
        return validate_typeahead_observation(EvidenceSnapshot(ROOT,self.root), self.run,self.binding,'inv1',paths)
    def test_positive_and_binding_negatives(self):
        self.assertEqual(len(self.validate()['selected_cases']),9)
        for key, value in [('invocation_id','other'),('binding',{'run_id':'other'}),('library',{'sha256':'b'*64,'bytes':123}),('inputs_unchanged',False)]:
            original = copy.deepcopy(self.obs)
            self.obs[key] = value; self.write_obs()
            with self.assertRaises(EvidenceError): self.validate()
            self.obs = original; self.write_obs()
    def test_tampering_and_failed_case(self):
        (self.out/'bundle.js').write_text('tampered')
        with self.assertRaises(EvidenceError): self.validate()
        (self.out/'bundle.js').write_text('bundle.js')
        self.obs['selected_cases'][0]['success'] = False; self.write_obs()
        with self.assertRaises(EvidenceError): self.validate()
    def test_matrix_and_actual_attestation(self):
        matrix = json.loads((ROOT/'compatibility/rc/matrices/full-verify.json').read_text())
        validate_matrix(matrix)
        row = next(x for x in matrix['checks'] if x['check_id']=='typeahead-execution')
        row['acceptance']['cases_by_line']['main']['focused-typeahead'].pop()
        with self.assertRaises(EvidenceError): validate_matrix(matrix)
        class Active: pass
        active=Active(); active.manifest={'run_id':'run1'}; active.invocations={'typeahead-execution':'inv1'}
        active.exit_codes={'typeahead-execution':1}; active.outputs={'typeahead-execution':[{'path':f'{self.prefix}/observation.json','sha256':'c'*64,'bytes':5}]}
        att = coordinator.typeahead_execution_attestation(active)
        self.assertEqual(att['exit_code'],1); self.assertEqual(att['invocation_id'],'inv1')
        active.invocations['typeahead-execution']='inv2'
        self.assertIsNone(coordinator.typeahead_execution_attestation(active)['output'])

if __name__ == '__main__': unittest.main()
