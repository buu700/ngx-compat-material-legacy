#!/usr/bin/env python3
"""Finite RC automatic product gate (RC-02.04 incremental orchestration).

Packs once into --out, runs every currently implemented automatic check against
that artifact, and fails closed for any required check that is missing,
unknown, unimplemented, or red. Does not publish, does not run private Cyph,
and does not claim G01–G13 while required cells remain open.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
import tempfile
import shutil
import uuid
from contextlib import contextmanager
from functools import lru_cache

# Script and unittest/importlib execution both resolve this local helper.
if str(Path(__file__).resolve().parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
from rc_acceptance import (
    CHECK_CONTRACT, EvidenceError, binding_for, evaluate_run, read_json,
    validate_matrix, checked_file, sha256_file as evidence_sha256,
    assertion_directory, expected_cases, prepack_binding_for, EvidenceSnapshot,
    TYPEAHEAD_CASES, validate_typeahead_observation,
)
from archive_run_closure import ClosureError, write_closure
from historical_inventory_source import check_inventory_source_bindings
from owned_rendered_admission import owned_rendered_ok
from migration_workspace_admission import old_workspace_assertion_ok, workspace_support_records
from migration_transaction_admission import transaction_assertion_ok
from migration_frontend_admission import frontend_assertion_ok
from sass_function_admission import function_assertion_ok
from sass_private_card_gate import private_card_assertion_ok
from sass_mixin_argument_admission import mixin_argument_assertion_ok
from sass_ordinary_control_gate import ORDINARY_CONTROL_GATE_CASES, ordinary_control_gate_assertion_ok
from sass_ordinary_card_gate import ORDINARY_CARD_GATE_CASES, ordinary_card_gate_assertion_ok
from sass_spinner_snack_gate_integration import SPINNER_SNACK_GATE_CASES, spinner_snack_gate_assertion_ok
from sass_default_core_cdk_admission import DEFAULT_CORE_CDK_CASES, default_core_cdk_envelope_ok
from sass_ordered_core_admission import ORDERED_CORE_CASES, ordered_core_envelope_ok
from sass_ordered_legacy_button_admission import ORDERED_LEGACY_BUTTON_CASES, ordered_legacy_button_envelope_ok
from sass_ordered_aggregate_admission import ORDERED_AGGREGATE_CASES, ordered_aggregate_envelope_ok
from sass_default_companion_admission import DEFAULT_COMPANION_CASES, default_companion_envelope_ok
from sass_default_mapped_companion_admission import DEFAULT_MAPPED_COMPANION_CASES, default_mapped_companion_envelope_ok
from sass_default_aggregate_admission import DEFAULT_AGGREGATE_CASES, default_aggregate_envelope_ok
from sass_stepper_historical_oracle import TOKENS as HISTORICAL_STEPPER_TOKENS, SCENARIOS as HISTORICAL_STEPPER_SCENARIOS, PROOF as HISTORICAL_STEPPER_PROOF, stepper_historical_value
from sass_form_field_state_admission import FORM_FIELD_STATE_DEFAULT_CASES, form_field_state_default_envelope_ok
from sass_ripple_color_admission import RIPPLE_COLOR_DEFAULT_CASES, RIPPLE_COLOR_ORDERED_CASES, ripple_color_envelope_ok
from m3_rendered_admission import complete_rendered_checks
from consumer_floor_admission import floor_assertion_ok, floor_support_records

ROOT = Path(__file__).resolve().parents[1]
MATRIX_PATH = ROOT / "compatibility/rc/matrices/full-verify.json"
ACTIVE_RUN = None

# Explicit legacy output locations. Capturing these preserves existing domain
# runners while preventing any old fixed-path report from becoming fresh proof.
FIXED_DETAILS = {
    "scripts/engine-free-consumer.mjs": ("engine-free-consumer", "compatibility/rc/reports/engine-free-consumer.json"),
    "scripts/sass-seal.mjs": ("sass-seal", "compatibility/rc/reports/sass-seal.json"),
    "scripts/check-companion-bridges.mjs": ("companion-bridge-tokens", "compatibility/rc/reports/companion-bridge-tokens.json"),
    "scripts/check-companion-computed-styles.mjs": ("companion-computed-styles", "compatibility/rc/reports/companion-computed-styles.json"),
    "scripts/run-browser-matrix-slice.mjs": ("browser-matrix", "compatibility/rc/reports/browser-matrix-slice.json"),
    "scripts/api-completeness.mjs": ("api-completeness", "compatibility/rc/reports/api-completeness.json"),
}
SCRIPT_CHECKS = {
    **{script: item[0] for script, item in FIXED_DETAILS.items()},
    "scripts/pack-draft-run.mjs": "pack-library",
    "scripts/check-pack-library.mjs": "pack-library",
    "scripts/check-packed-exports.mjs": "packed-exports",
    "scripts/check-source-contract-regressions.py": "source-contract-regressions",
    "scripts/run-typeahead-execution.py": "typeahead-execution",
    "scripts/check-upstream-audit-disposition.mjs": "upstream-audit-disposition",
    "scripts/check-source-policy.py": "source-policy",
    "scripts/check-dependency-eligibility.py": "dependency-eligibility",
    "scripts/packed-consumer-aot-smoke.mjs": "packed-consumer",
    "scripts/motion-lifecycle-smoke.mjs": "motion-smoke",
    "scripts/native-motion-acceptance.mjs": "native-motion",
    "scripts/csp-ssr-acceptance.mjs": "csp-ssr",
    "scripts/build-migrate-legacy-cli.mjs": "migration-packaged",
    "scripts/migration-cli-isolation.mjs": "migration-packaged",
    "scripts/check-old-workspace-cli.mjs": "migration-packaged",
    "scripts/migration-transaction.mjs": "migration-packaged",
    "scripts/check-frontend-parity.mjs": "migration-packaged",
    "scripts/check-packaged-schematic.mjs": "migration-packaged",
    "scripts/rc-test-legacy-family.mjs": "historical-legacy-artifact",
    "scripts/check-m3-inclusion-order.mjs": "m3-coexistence",
    "scripts/check-consumer-floors.mjs": "consumer-floors",
    "scripts/run-consumer-floor-configurations.mjs": "consumer-floors",
    "scripts/check-release-metadata.mjs": "release-metadata",
}


class RunEvidence:
    """One coordinator's captured identities and actual child outcomes."""
    def __init__(self, manifest, run_dir, matrix_digest, *, pack_execution=None):
        self.manifest = manifest
        self.run_dir = run_dir
        self.matrix_digest = matrix_digest
        self.binding = binding_for(manifest, matrix_digest)
        self.invocations = {}
        self.exit_codes = {}
        self.outputs = {}
        self.pack_execution = pack_execution
        if pack_execution is not None:
            expected = prepack_binding_for(manifest['run_id'], manifest['execution_inputs'],
                                           manifest['environment'], manifest['oracles'], matrix_digest)
            if pack_execution.get('binding') != expected or pack_execution.get('status') != 'completed':
                raise EvidenceError('pack invocation does not match the frozen prepack inputs')
            self.invocations['pack-library'] = pack_execution['invocation_id']
            self.record_exit('pack-library', pack_execution['exit_code'])

    def invocation(self, check_id):
        return self.invocations.setdefault(check_id, uuid.uuid4().hex)

    def record_exit(self, check_id, code):
        previous = self.exit_codes.get(check_id, 0)
        self.exit_codes[check_id] = previous if previous != 0 else code

    def subject(self, check_id):
        _, kind, ids, _ = CHECK_CONTRACT[check_id]
        artifacts = {
            item['id']: {'sha256': item['sha256'], 'bytes': item['bytes']}
            for item in self.manifest.get('artifacts', []) if item['id'] in ids
        }
        return {'subject_kind': kind, 'subject_ids': list(ids), 'artifacts': artifacts}


@contextmanager
def capture_fixed_report(root, run_dir, relative_path, check_id):
    """Temporarily remove the old file; never use mtime as freshness evidence.

    Preserve the original in a unique backup and restore it even if the child
    fails. Only a newly created regular JSON file is retained as this invocation's
    supplemental detail. Full acceptance still validates its case-level report.
    """
    source = root / relative_path
    if any(p.is_symlink() for p in [source, *source.parents] if p != root.parent):
        raise EvidenceError(f'symlink in fixed report path: {relative_path}')
    source.parent.mkdir(parents=True, exist_ok=True)
    details = run_dir / 'reports/details'
    details.mkdir(parents=True, exist_ok=True)
    dest = details / f'{check_id}.json'
    if dest.exists():
        raise EvidenceError(f'output already exists for {check_id}: {dest}')
    # Keep rename/restore on the source filesystem even when --out is on /tmp.
    backup = source.with_name(f'.saved-{check_id}-{uuid.uuid4().hex}.json')
    had_original = source.exists()
    if had_original:
        if not source.is_file():
            raise EvidenceError(f'fixed report is not a file: {relative_path}')
        source.rename(backup)
    try:
        yield dest
        if source.is_symlink() or not source.is_file():
            raise EvidenceError(f'{check_id}: child did not produce a new regular detail report')
        read_json(source)  # Malformed or duplicate-key JSON is not evidence.
        shutil.copyfile(source, dest)
    finally:
        if source.is_symlink() or source.is_file():
            source.unlink()
        elif source.exists():
            # Do not recursively delete an unexpected child-created directory.
            raise EvidenceError(f'unsafe child output at {source}; recovery file: {backup}')
        if had_original:
            backup.rename(source)


@contextmanager
def verifier_lock(root):
    """Serialize full verifiers while legacy children still have fixed outputs."""
    import fcntl
    lock_dir = root / 'artifacts'
    if lock_dir.is_symlink() or (lock_dir / '.full-verify.lock').is_symlink():
        raise EvidenceError('refuse symlinked verifier lock path')
    lock_dir.mkdir(parents=True, exist_ok=True)
    with (lock_dir / '.full-verify.lock').open('a') as stream:
        try:
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise EvidenceError('another full verifier owns the fixed report paths') from error
        try:
            yield
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def classify_input(path):
    """Role of a fingerprinted path. Reports stay excluded; this does not ignore locks or checkers."""
    name = path.replace('\\', '/')
    if name.startswith('compatibility/rc/reports/') or name == 'compatibility/pack-proof/motion-lifecycle-smoke.json':
        return 'derived-diagnostic'
    if name in {'pnpm-lock.yaml', 'toolchain-lock.json', 'chainman.lock', '.npm-version', '.node-version'}:
        return 'lock'
    if name.startswith('compatibility/rc/matrices/'):
        return 'matrix'
    if name == 'compatibility/provenance.json' or name.startswith('compatibility/pack-proof/historical-unbound/'):
        return 'oracle'
    if name.startswith('projects/'):
        return 'product-source'
    if name.startswith('scripts/') or name.startswith('tests/') or name == 'justfile':
        return 'checker'
    return 'consumed-input'


def _file_record(path, role):
    if path.is_symlink():
        payload = b'link:' + os.readlink(path).encode()
        return {'sha256': hashlib.sha256(payload).hexdigest(), 'role': role, 'payload': payload, 'missing': False}
    if not path.exists():
        return {'sha256': None, 'role': role, 'payload': b'missing', 'missing': True}
    if path.is_dir():
        return {'sha256': None, 'role': role, 'payload': b'directory', 'missing': False}
    payload = str(path.stat().st_mode).encode() + b'\0' + path.read_bytes()
    return {'sha256': hashlib.sha256(payload).hexdigest(), 'role': role, 'payload': payload, 'missing': False}


def source_line_for_library_version(version):
    """Map an advertised library version to the checkout line this verifier accepts.

    Major 21 is the 21.x line. Major 22 is main. Any other major is not a
    supported checkout line. A synthetic version string is not a checkout.
    """
    major = version.split('.', 1)[0] if isinstance(version, str) else ''
    if major not in ('21', '22'):
        raise EvidenceError('cannot determine the supported source line from library version')
    return '21.x' if major == '21' else 'main'


def require_line_matches_checkout(requested_line, checkout_line):
    """Reject --line when it disagrees with the checkout library version's line."""
    if checkout_line != requested_line:
        fail('--line does not match this checkout library version')


def observe_inputs(root):
    """Fingerprint plus per-path hashes. The aggregate digest matches the historical tracked-file loop."""
    def git(*args):
        result = subprocess.run(['git', *args], cwd=root, capture_output=True, check=True)
        return result.stdout
    commit = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    names = git('ls-files', '-z').decode().split('\0')
    digest = hashlib.sha256()
    files = {}
    for name in sorted(filter(None, names)):
        if name.startswith('compatibility/rc/reports/'):
            continue  # Legacy generated outputs, not the contract/runner inputs.
        record = _file_record(root / name, classify_input(name))
        digest.update(name.encode() + b'\0')
        digest.update(record['payload'])
        files[name] = {'sha256': record['sha256'], 'role': record['role'], 'missing': record['missing']}
    status = git('status', '--porcelain', '--untracked-files=all', '--', '.', ':(exclude)compatibility/rc/reports')
    digest.update(status)
    status_lines = [line for line in status.decode().splitlines() if line]
    for line in status_lines:
        if not line.startswith('?? '):
            continue
        name = line[3:]
        if name in files or name.startswith('compatibility/rc/reports/'):
            continue
        record = _file_record(root / name, classify_input(name))
        files[name] = {'sha256': record['sha256'], 'role': record['role'], 'missing': record['missing']}
    package = read_json(root / 'projects/ngx-material-legacy/package.json')
    version = package.get('version', '')
    checkout_line = source_line_for_library_version(version)
    locks = {}
    for name in ('chainman.lock', 'pnpm-lock.yaml', 'toolchain-lock.json', '.node-version', '.npm-version'):
        candidate = root / name
        if candidate.is_file() and not candidate.is_symlink():
            locks[name] = hashlib.sha256(candidate.read_bytes()).hexdigest()
    fingerprint = {'commit': commit, 'tree': tree, 'inputs_sha256': digest.hexdigest(),
                   'clean': not status.strip(), 'line': checkout_line}
    return {'fingerprint': fingerprint, 'files': files, 'status_lines': status_lines, 'locks': locks}


def source_fingerprint(root):
    """Detect source/tool/test changes during execution; no synthetic Git fallback."""
    return observe_inputs(root)['fingerprint']


def describe_input_drift(before, after):
    """Changed, missing, and new input paths with before/after hashes. No file contents."""
    changes = []
    for path in sorted(set(before['files']) | set(after['files'])):
        left = before['files'].get(path)
        right = after['files'].get(path)
        if left == right:
            continue
        if left is None:
            change = 'new'
        elif right is None or right.get('missing') is True:
            change = 'missing'
        else:
            change = 'changed'
        role = (right or left).get('role') or classify_input(path)
        changes.append({
            'path': path,
            'change': change,
            'role': role,
            'before_sha256': None if left is None else left.get('sha256'),
            'after_sha256': None if right is None else right.get('sha256'),
        })
    explained = {item['path'] for item in changes}
    for line in sorted(set(after.get('status_lines') or []) - set(before.get('status_lines') or [])):
        path = line[3:] if len(line) > 3 else line
        if path in explained:
            continue
        changes.append({
            'path': path,
            'change': 'status',
            'role': classify_input(path),
            'before_sha256': None,
            'after_sha256': None,
        })
    if not changes and before['fingerprint'] != after['fingerprint']:
        changes.append({
            'path': '(aggregate)',
            'change': 'changed',
            'role': 'consumed-input',
            'before_sha256': before['fingerprint'].get('inputs_sha256'),
            'after_sha256': after['fingerprint'].get('inputs_sha256'),
        })
    return changes


def format_input_drift(changes):
    return [
        f"{item['change']} {item['role']} {item['path']} before={item['before_sha256']} after={item['after_sha256']}"
        for item in changes
    ]



def pack_environment(root):
    """Freeze the same declared environment/oracle fields as the run writer.

    No output artifact identity is knowable here. The coordinator checks these
    fields against the writer's post-build manifest before it runs consumers.
    """
    def version(command):
        child = subprocess.run([command, '-v'], cwd=root, capture_output=True, text=True, check=True)
        return (child.stdout or child.stderr).strip().splitlines()[0]
    pkg = read_json(root / 'package.json')
    provenance = read_json(root / 'compatibility/provenance.json')
    node_platform = subprocess.run(['node', '-p', 'process.platform + "-" + process.arch'],
                                  cwd=root, capture_output=True, text=True, check=True).stdout.strip()
    environment = {
        'chainman_revision': (root / 'chainman.lock').read_text().strip(),
        'lock_sha256': evidence_sha256(root / 'pnpm-lock.yaml'),
        'install_policy_sha256': evidence_sha256(root / 'toolchain-lock.json'),
        'tool_versions': {name: version(name) for name in ('node', 'pnpm', 'npm')},
        'mode': os.environ.get('CHAINMAN_MODE') or 'unqualified-host',
        'platform': node_platform,
    }
    oracles = {
        'historical': [{'id': 'angular-components', 'tag': provenance['baseline_tag'],
                        'commit': provenance['baseline_full_commit']}],
        'current_peer': [{'id': name, 'version': pkg.get('devDependencies', {}).get(name)}
                         for name in ('@angular/core', '@angular/cdk', '@angular/material')],
    }
    return environment, oracles


def execute_pack(out_dir, line, source_inputs, matrix_digest):
    """Assign and persist the input-only invocation BEFORE starting the pack.

    pack-library is coordinator-owned: its final report binds resulting bytes,
    but never claims that a subprocess received hashes that did not yet exist.
    Failure/interrupt records are retained even when no run.json is produced.
    """
    environment, oracles = pack_environment(ROOT)
    run_id = f"verify-{line.replace('.', '')}-{source_inputs['commit'][:12]}-{uuid.uuid4().hex}"
    invocation_id = uuid.uuid4().hex
    binding = prepack_binding_for(run_id, source_inputs, environment, oracles, matrix_digest)
    record = {
        'schema_version': 1, 'check_id': 'pack-library', 'run_id': run_id,
        'invocation_id': invocation_id, 'binding': binding, 'status': 'running',
        'command': ['node', str(ROOT / 'scripts/pack-draft-run.mjs'), '--line', line, '--out', str(out_dir)],
        'started_at': datetime.now(timezone.utc).isoformat(), 'finished_at': None, 'exit_code': None,
    }
    record_path = out_dir / 'pack-execution.json'
    with record_path.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    output_dir = out_dir / assertion_directory('pack-library', invocation_id)
    output_dir.mkdir(parents=True, exist_ok=False)
    env = {**os.environ, 'RC_CHECK_ID': 'pack-library', 'RC_RUN_ID': run_id,
           'RC_INVOCATION_ID': invocation_id, 'RC_EVIDENCE_BINDING': json.dumps(binding, sort_keys=True),
           'RC_ASSERTION_OUTPUT_DIR': str(output_dir)}
    code = 1
    try:
        code = subprocess.run(record['command'], cwd=ROOT, env=env).returncode
        record['status'] = 'completed'
    except KeyboardInterrupt:
        record['status'] = 'interrupted'
        code = 130
        raise
    except OSError as error:
        record['status'] = 'launch-failed'
        record['error'] = str(error)
        raise
    finally:
        record['exit_code'] = code
        record['finished_at'] = datetime.now(timezone.utc).isoformat()
        temporary = record_path.with_suffix('.writing')
        with temporary.open('x') as stream:
            json.dump(record, stream, indent=2)
            stream.write('\n')
        temporary.replace(record_path)
    return record

def check_existing_run(argv):
    """Read-only recheck for the sealer. The expected matrix hash is caller-pinned.

    A hash is an identity, not approval: use this only with reviewed source and
    a trusted execution record. This command never authenticates a reviewer.
    """
    values = {}
    if len(argv) != 4:
        fail('usage: --check-run --run <run.json> --expected-matrix-sha256 <reviewed-hash>')
    for flag, value in zip(argv[::2], argv[1::2]):
        if flag not in ('--run', '--expected-matrix-sha256') or flag in values or not value or value.startswith('--'):
            fail('invalid or duplicate --check-run option')
        values[flag] = value
    if set(values) != {'--run', '--expected-matrix-sha256'}:
        fail('--check-run needs the run and caller-pinned matrix identity')
    run_path = Path(values['--run']).resolve()
    run = read_json(run_path)
    record_path = checked_file(run_path.parent, run.get('execution_record'), 'coordinator execution record')
    record = read_json(record_path)
    if record.get('run_id') != run.get('run_id'):
        fail('coordinator record belongs to another run')
    recorded_inputs = run.get('execution_inputs') or {}
    current_inputs = source_fingerprint(ROOT)
    if current_inputs != recorded_inputs:
        bits = []
        for key in ('commit', 'tree', 'inputs_sha256', 'clean', 'line'):
            if current_inputs.get(key) != recorded_inputs.get(key):
                bits.append(f"{key} recorded={recorded_inputs.get(key)} current={current_inputs.get(key)}")
        fail('source/checker inputs differ from the recorded execution: ' + '; '.join(bits))
    result = evaluate_run(ROOT, run_path, matrix_sha256=values['--expected-matrix-sha256'],
        binding=record.get('binding', {}), process_results=record.get('process_results', {}),
        invocation_ids=record.get('invocation_ids', {}))
    print(json.dumps(result, indent=2))
    return 0 if result['automatic_product_result'] == 'pass' else 2


def fail(message: str, code: int = 2) -> None:
    print(f"verify: {message}", file=sys.stderr)
    raise SystemExit(code)


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_args(argv: list[str]) -> tuple[Path, str]:
    out: Path | None = None
    line = "main"
    i = 0
    seen = set()
    while i < len(argv):
        arg = argv[i]
        if arg in seen:
            fail(f'duplicate argument: {arg}')
        seen.add(arg)
        if arg in ("--out", "--line"):
            if i + 1 >= len(argv) or argv[i + 1].startswith("-"):
                fail(f"{arg} requires a value")
            if arg == "--out":
                out = (ROOT / argv[i + 1]).resolve() if not Path(argv[i + 1]).is_absolute() else Path(argv[i + 1])
            else:
                line = argv[i + 1]
            i += 2
            continue
        fail(f"Unknown argument: {arg}")
    if out is None:
        print("usage: just verify --out <run-directory> [--line main|21.x]", file=sys.stderr)
        fail("full product gate requires --out")
    if line not in ("main", "21.x"):
        fail("--line must be main or 21.x")
    return out, line


def typeahead_execution_attestation(active):
    """Forward only the actual coordinator child result and captured output identity."""
    outputs = active.outputs.get('typeahead-execution', [])
    invocation = active.invocations.get('typeahead-execution')
    expected = f'evidence/typeahead-execution/{invocation}/observation.json'
    output = next((item for item in outputs if item.get('path') == expected), None)
    return {'run_id': active.manifest['run_id'], 'invocation_id': invocation,
            'exit_code': active.exit_codes.get('typeahead-execution'), 'output': output}


def write_typeahead_report(run_dir, run_id, line, exit_code):
    """Create a complete roster only from this child's retained selected results."""
    check_id = 'typeahead-execution'
    try:
        if exit_code != 0 or line != 'main':
            raise EvidenceError('typeahead child did not pass on main')
        invocation = ACTIVE_RUN.invocation(check_id)
        prefix = assertion_directory(check_id, invocation)
        names = ['observation.json', 'raw-report.json', 'commands.json', 'inputs-before.json',
                 'metafile.json', 'bundle.js', 'bundle-inputs.json', 'entry.generated.ts']
        outputs = []
        for name in names:
            path = run_dir / prefix / name
            if path.is_symlink() or not path.is_file() or path.stat().st_nlink != 1:
                raise EvidenceError('missing or unsafe typeahead output')
            outputs.append({'path': f'{prefix}/{name}', 'sha256': evidence_sha256(path), 'bytes': path.stat().st_size})
        snapshot = EvidenceSnapshot(ROOT, run_dir)
        validate_typeahead_observation(snapshot, ACTIVE_RUN.manifest, ACTIVE_RUN.binding, invocation,
                                       {item['path'] for item in outputs})
        snapshot.revalidate()
        ACTIVE_RUN.outputs[check_id] = outputs
        row = validate_matrix(read_json(MATRIX_PATH))[check_id]
        artifacts = _contract_artifacts(row)
        if artifacts is None:
            raise EvidenceError('typeahead artifact unavailable')
        cases = list(TYPEAHEAD_CASES)
        report = {'schema_version': 1, 'template': False, 'run_id': run_id, 'check_id': check_id,
                  'line': line, 'invocation_id': invocation, 'binding': ACTIVE_RUN.binding,
                  'coverage': 'complete', 'result': 'pass', 'exit_code': 0,
                  'subject_kind': 'artifact', 'subject_ids': ['library'], 'artifacts': artifacts,
                  'expected_case_ids': cases, 'discovered_case_ids': cases, 'executed_case_ids': cases,
                  'passed_case_ids': cases, 'failed_case_ids': [], 'skipped_case_ids': [],
                  'unresolved_case_ids': [], 'exceptions': [], 'passed': len(cases), 'failed': 0, 'skipped': 0,
                  'outputs': outputs, 'case_results': [{'case_id': case, 'result': 'pass', 'kind': 'assertion',
                  'output_paths': [f'{prefix}/observation.json']} for case in cases],
                  'command': ['rc-verify.py', check_id], 'limitations': ['Focused execution only; no G11 claim.']}
        path = run_dir / 'reports' / f'{check_id}.json'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, indent=2) + '\n')
        return True
    except (EvidenceError, OSError, ValueError, KeyError, TypeError) as error:
        print(f'verify: typeahead evidence incomplete: {error}', file=sys.stderr)
        write_check_report(run_dir, run_id, line, check_id, exit_code=exit_code or 1,
                           limitations=['Focused typeahead execution did not produce complete bound evidence.'])
        return False


def run_node(script: str, args: list[str], *, record: bool = True) -> int:
    if script.endswith(".py"):
        cmd = [sys.executable, str(ROOT / script), *args]
    else:
        cmd = ["node", str(ROOT / script), *args]
    print("verify:", " ".join(cmd), flush=True)
    if ACTIVE_RUN is None:
        return subprocess.run(cmd, cwd=ROOT).returncode
    check_id = SCRIPT_CHECKS[script]
    invocation = ACTIVE_RUN.invocation(check_id)
    output_dir = ACTIVE_RUN.run_dir / assertion_directory(check_id, invocation)
    output_dir.mkdir(parents=True, exist_ok=True)
    env = {**os.environ, 'RC_INVOCATION_ID': invocation, 'RC_CHECK_ID': check_id,
           'RC_ASSERTION_OUTPUT_DIR': str(output_dir),
           'RC_EVIDENCE_BINDING': json.dumps(ACTIVE_RUN.binding, sort_keys=True),
           'RC_RUN_ID': ACTIVE_RUN.manifest['run_id']}
    if check_id == 'upstream-audit-disposition':
        # Capture the actual earlier child outcome; a self-written report cannot
        # stand in for the coordinator's invocation. Final sealing checks both.
        env['RC_UPSTREAM_PACKED_CONSUMER'] = json.dumps({
            'run_id': ACTIVE_RUN.manifest['run_id'],
            'invocation_id': ACTIVE_RUN.invocations.get('packed-consumer'),
            'exit_code': ACTIVE_RUN.exit_codes.get('packed-consumer'),
        }, sort_keys=True)
        env['RC_UPSTREAM_HISTORICAL'] = json.dumps({
            'run_id': ACTIVE_RUN.manifest['run_id'],
            'invocation_id': ACTIVE_RUN.invocations.get('historical-legacy-artifact'),
            'exit_code': ACTIVE_RUN.exit_codes.get('historical-legacy-artifact'),
        }, sort_keys=True)
        env['RC_UPSTREAM_SASS_SEAL'] = json.dumps({
            'run_id': ACTIVE_RUN.manifest['run_id'],
            'invocation_id': ACTIVE_RUN.invocations.get('sass-seal'),
            'exit_code': ACTIVE_RUN.exit_codes.get('sass-seal'),
        }, sort_keys=True)
        env['RC_UPSTREAM_BROWSER_MATRIX'] = json.dumps({
            'run_id': ACTIVE_RUN.manifest['run_id'],
            'invocation_id': ACTIVE_RUN.invocations.get('browser-matrix'),
            'exit_code': ACTIVE_RUN.exit_codes.get('browser-matrix'),
        }, sort_keys=True)
        env['RC_UPSTREAM_TYPEAHEAD'] = json.dumps(typeahead_execution_attestation(ACTIVE_RUN), sort_keys=True)
        env['RC_UPSTREAM_NATIVE_MOTION'] = json.dumps({
            'run_id': ACTIVE_RUN.manifest['run_id'],
            'invocation_id': ACTIVE_RUN.invocations.get('native-motion'),
            'exit_code': ACTIVE_RUN.exit_codes.get('native-motion'),
        }, sort_keys=True)
    code = 1
    try:
        if script in FIXED_DETAILS:
            _, fixed_path = FIXED_DETAILS[script]
            with capture_fixed_report(ROOT, ACTIVE_RUN.run_dir, fixed_path, check_id) as output:
                code = subprocess.run(cmd, cwd=ROOT, env=env).returncode
            ACTIVE_RUN.outputs[check_id] = [{
                'path': output.relative_to(ACTIVE_RUN.run_dir).as_posix(),
                'sha256': evidence_sha256(output), 'bytes': output.stat().st_size,
            }]
        else:
            code = subprocess.run(cmd, cwd=ROOT, env=env).returncode
    except (EvidenceError, OSError) as error:
        print(f'verify: {error}', file=sys.stderr)
        code = code or 1
    if record:
        ACTIVE_RUN.record_exit(check_id, code)
    return code


def run_source_contract_regressions(out_dir, run_id, line, results, implemented_ran):
    """Run complete source fault suites once for this RC invocation."""
    code = run_node("scripts/check-source-contract-regressions.py", [])
    write_check_report(
        out_dir, run_id, line, "source-contract-regressions", exit_code=code,
        limitations=["Source fault controls do not qualify product, browser, security, or full G11 acceptance."],
    )
    results["source-contract-regressions"] = "pass" if code == 0 else "fail"
    implemented_ran.append("source-contract-regressions")


def write_missing_report(run_dir: Path, run_id: str, line: str, check_id: str, reason: str) -> None:
    reports = run_dir / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": 1,
        "template": False,
        "run_id": run_id,
        "check_id": check_id,
        "line": line,
        "subject_kind": "artifact",
        "subject_ids": ["library"],
        "command": ["rc-verify.py", "--missing", check_id],
        "exit_code": 1,
        "result": "fail",
        "expected_case_ids": [check_id],
        "executed_case_ids": [],
        "passed": 0,
        "failed": 1,
        "skipped": 0,
        "skip_reasons": [],
        "outputs": [],
        "limitations": [reason],
    }
    if ACTIVE_RUN is not None:
        payload.update(ACTIVE_RUN.subject(check_id))
        payload.update(coverage='slice', binding=ACTIVE_RUN.binding,
                       invocation_id=ACTIVE_RUN.invocation(check_id))
        payload['outputs'] = ACTIVE_RUN.outputs.get(check_id, [])
        if check_id == 'pack-library' and ACTIVE_RUN.pack_execution is not None:
            payload.update(evidence_origin='coordinator', prepack_binding=ACTIVE_RUN.pack_execution['binding'])
    else:
        payload['coverage'] = 'slice'
    report_path = reports / f"{check_id}.json"
    if report_path.is_file():
        # Do not overwrite an actual full child report with a process wrapper.
        # The evaluator checks the captured process exit independently.
        child = read_json(report_path)
        if child.get('coverage') == 'complete':
            return
        details = reports / 'details'
        details.mkdir(exist_ok=True)
        original = details / f'{check_id}-child.json'
        if original.exists():
            raise EvidenceError(f'duplicate child output for {check_id}')
        original.write_bytes(report_path.read_bytes())
        payload['outputs'] = [*payload.get('outputs', []), {
            'path': original.relative_to(run_dir).as_posix(),
            'sha256': evidence_sha256(original), 'bytes': original.stat().st_size,
        }]
    report_path.write_text(json.dumps(payload, indent=2) + "\n")


def write_check_report(
    run_dir: Path,
    run_id: str,
    line: str,
    check_id: str,
    *,
    exit_code: int,
    limitations: list[str] | None = None,
) -> None:
    reports = run_dir / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    ok = exit_code == 0
    payload = {
        "schema_version": 1,
        "template": False,
        "run_id": run_id,
        "check_id": check_id,
        "line": line,
        "subject_kind": "artifact",
        "subject_ids": ["library"],
        "command": ["rc-verify.py", check_id],
        "exit_code": exit_code,
        "result": "pass" if ok else "fail",
        "expected_case_ids": [check_id],
        "executed_case_ids": [check_id],
        "passed": 1 if ok else 0,
        "failed": 0 if ok else 1,
        "skipped": 0,
        "skip_reasons": [],
        "outputs": [],
        "limitations": limitations or [],
    }
    if ACTIVE_RUN is not None:
        payload.update(ACTIVE_RUN.subject(check_id))
        payload.update(coverage='slice', binding=ACTIVE_RUN.binding,
                       invocation_id=ACTIVE_RUN.invocation(check_id))
        payload['outputs'] = ACTIVE_RUN.outputs.get(check_id, [])
        if check_id == 'pack-library' and ACTIVE_RUN.pack_execution is not None:
            payload.update(evidence_origin='coordinator', prepack_binding=ACTIVE_RUN.pack_execution['binding'])
    else:
        payload['coverage'] = 'slice'
    report_path = reports / f"{check_id}.json"
    if report_path.is_file():
        # Do not overwrite an actual full child report with a process wrapper.
        # The evaluator checks the captured process exit independently.
        child = read_json(report_path)
        if child.get('coverage') == 'complete':
            return
        details = reports / 'details'
        details.mkdir(exist_ok=True)
        original = details / f'{check_id}-child.json'
        if original.exists():
            raise EvidenceError(f'duplicate child output for {check_id}')
        original.write_bytes(report_path.read_bytes())
        payload['outputs'] = [*payload.get('outputs', []), {
            'path': original.relative_to(run_dir).as_posix(),
            'sha256': evidence_sha256(original), 'bytes': original.stat().st_size,
        }]
    report_path.write_text(json.dumps(payload, indent=2) + "\n")



_MIGRATION_RESERVED_NAMES = {
    "run.json", "execution-record.json", "pack-execution.json", "pack-meta.json", "full-verify.json",
}


def _reserved_evidence(run_dir: Path) -> set[tuple[str, int]]:
    found: set[tuple[str, int]] = set()
    for name in _MIGRATION_RESERVED_NAMES:
        path = run_dir / name
        if path.is_file() and not path.is_symlink():
            found.add((evidence_sha256(path), path.stat().st_size))
    return found


def _migration_contract_artifacts(row: dict) -> dict | None:
    wanted = row["acceptance"]["subject_ids"]
    if wanted != ["library", "migrate-cli"]:
        return None
    by_id: dict = {}
    for item in ACTIVE_RUN.manifest.get("artifacts", []):
        aid = item.get("id")
        if aid not in wanted:
            continue
        if aid in by_id:
            return None
        digest = item.get("sha256")
        size = item.get("bytes")
        if not isinstance(digest, str) or type(size) is not int or size <= 0:
            return None
        by_id[aid] = {"sha256": digest, "bytes": size}
    if set(by_id) != set(wanted):
        return None
    return {aid: by_id[aid] for aid in wanted}


def _migration_assertion_records(run_dir: Path, invocation: str, expected: list[str]) -> dict | None:
    """Map rostered case ids to assertion files this run wrote.

    Copies of the manifest or other control files are not assertion evidence.
    """
    prefix = assertion_directory("migration-packaged", invocation)
    directory = run_dir / prefix
    if not directory.is_dir() or directory.is_symlink():
        return None
    reserved = _reserved_evidence(run_dir)
    allowed = set(expected)
    found: dict = {}
    for path in sorted(directory.iterdir()):
        if not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1:
            continue
        if path.name in _MIGRATION_RESERVED_NAMES or path.suffix != ".json":
            continue
        if path.name.endswith((".sha256", ".sha512", ".sha1")):
            continue
        identity = (evidence_sha256(path), path.stat().st_size)
        if identity in reserved:
            continue
        try:
            body = read_json(path)
        except EvidenceError:
            continue
        case_id = body.get("case_id")
        if body.get("result") != "pass" or body.get("kind") != "assertion":
            continue
        if not isinstance(case_id, str) or case_id not in allowed or case_id in found:
            if isinstance(case_id, str) and case_id in found:
                return None
            continue
        if not old_workspace_assertion_ok(ROOT, ACTIVE_RUN, body, invocation) or not transaction_assertion_ok(ROOT, ACTIVE_RUN, body, invocation) or not frontend_assertion_ok(ROOT, ACTIVE_RUN, body, invocation):
            continue
        relative = path.relative_to(run_dir).as_posix()
        if not relative.startswith(prefix + "/"):
            continue
        found[case_id] = {"path": relative, "sha256": identity[0], "bytes": identity[1]}
    if set(found) != allowed:
        return None
    return found


def _complete_migration_report(run_dir: Path, run_id: str) -> dict | None:
    """Coverage complete only for main, and only from the matrix roster.

    A main run calls expected_cases for main. Null 21.x groups are not filled
    and are not passed to expected_cases.
    """
    if ACTIVE_RUN is None:
        return None
    matrix = read_json(MATRIX_PATH)
    row = validate_matrix(matrix)["migration-packaged"]
    groups = row["acceptance"]["cases_by_line"].get("main")
    if not isinstance(groups, dict) or any(ids is None for ids in groups.values()):
        return None
    expected = expected_cases(row, "main")
    invocation = ACTIVE_RUN.invocation("migration-packaged")
    records = _migration_assertion_records(run_dir, invocation, expected)
    artifacts = _migration_contract_artifacts(row)
    if records is None or artifacts is None:
        return None
    outputs = []
    seen: set[str] = set()
    case_results = []
    for case_id in expected:
        record = records[case_id]
        if record["path"] not in seen:
            outputs.append(record)
            seen.add(record["path"])
        body = read_json(run_dir / record["path"])
        for support in workspace_support_records(body):
            if support["path"] not in seen:
                outputs.append(support)
                seen.add(support["path"])
        case_results.append({
            "case_id": case_id,
            "result": "pass",
            "kind": "assertion",
            "output_paths": [record["path"]],
        })
    spec = row["acceptance"]
    return {
        "schema_version": 1,
        "template": False,
        "run_id": run_id,
        "check_id": "migration-packaged",
        "line": "main",
        "invocation_id": invocation,
        "binding": ACTIVE_RUN.binding,
        "coverage": "complete",
        "result": "pass",
        "exit_code": 0,
        "subject_kind": spec["subject_kind"],
        "subject_ids": list(spec["subject_ids"]),
        "artifacts": artifacts,
        "expected_case_ids": expected,
        "discovered_case_ids": list(expected),
        "executed_case_ids": list(expected),
        "passed_case_ids": list(expected),
        "failed_case_ids": [],
        "skipped_case_ids": [],
        "unresolved_case_ids": [],
        "exceptions": [],
        "passed": len(expected),
        "failed": 0,
        "skipped": 0,
        "outputs": outputs,
        "case_results": case_results,
        "command": ["rc-verify.py", "migration-packaged"],
        "limitations": [
            "Coordinator report for the line being verified. Each rostered main case has an assertion file written by this run.",
            "21.x migration groups stay null. A main run does not copy them and does not call expected_cases for 21.x.",
            "This report is the acceptance input. It does not add a G04 or G05 claim field.",
        ],
    }


def write_migration_packaged_report(
    run_dir: Path,
    run_id: str,
    line: str,
    *,
    exit_code: int,
    limitations: list[str] | None = None,
) -> None:
    """Write one migration-packaged report.

    Coverage is complete only when this main run's child exit is zero and every
    rostered main case has a passing assertion file in the check-owned
    invocation directory. Any other outcome stays the incomplete slice.
    write_check_report must not replace a complete report.
    """
    report_path = run_dir / "reports" / "migration-packaged.json"
    complete = _complete_migration_report(run_dir, run_id) if exit_code == 0 and line == "main" else None
    if complete is None:
        write_check_report(
            run_dir, run_id, line, "migration-packaged",
            exit_code=exit_code, limitations=limitations,
        )
        return
    reports = report_path.parent
    reports.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(complete, indent=2) + "\n")
    before = report_path.read_bytes()
    write_check_report(
        run_dir, run_id, line, "migration-packaged",
        exit_code=exit_code, limitations=limitations,
    )
    if report_path.read_bytes() != before:
        raise EvidenceError("write_check_report overwrote a complete migration-packaged report")


_LINE_COORDINATOR_LIMITATIONS = {
    "m3-coexistence": [
        "Coordinator report for the line being verified. Each rostered main case has a packed rendered assertion file written by this run against the run library tarball.",
        "Contamination fixtures are rejected and are not rostered. The report keeps the executed scope ids only.",
        "21.x m3 groups stay null. A main run does not copy them and does not call expected_cases for 21.x.",
        "This report is the acceptance input. It does not add a G07 claim field.",
    ],
    "consumer-floors": [
        "Complete coverage requires diagnostics plus every source-policy runtime case on the actual pinned Node executable.",
        "Each floor uses the run's packed artifacts in an isolated consumer with exact peers, strict declarations, AOT and real harness probes.",
        "CLI floors execute the extracted packed CLI, including Node 18, dry-run, apply and idempotence.",
        "Only this run's source line is admitted; the other line's roster is policy, not evidence.",
    ],
    "release-metadata": [
        "Coordinator report for the line being verified. Each rostered main case has an assertion file written by this run.",
        "instructions-provenance rosters only provenance fields that were compared. No instruction file was compared.",
        "21.x release-metadata groups stay null. A main run does not copy them and does not call expected_cases for 21.x.",
        "This report is the acceptance input. It does not add a G01 or G13 claim field.",
    ],
    "companion-bridge-tokens": [
        "Coordinator report for the line being verified. Each rostered main token has an assertion file written by this run.",
        "Each assertion compares the compiled public bridge custom property, root and accent/warn variant declarations, with the installed current @angular/material peer's own M2 theme output compiled in the same invocation. Historical v16 output is not the oracle.",
        "Compiled CSS custom properties only. No rendered computed styles; companion-computed-styles stays a separate check.",
        "21.x companion-bridge-tokens groups stay null. A main run does not copy them and does not call expected_cases for 21.x.",
        "This report is the acceptance input. It does not add a G06, G07 or G08 claim field.",
    ],
    "sass-seal": [
        "Every owned-rendered case requires a real packed control, tagged CSS identities, peer/source binding, exact computed property comparisons and an effective injected wrong-style negative.",
        "Coordinator report for the line being verified. Each rostered main case needs a passing assertion file written by this run against the run library tarball.",
        "sass-api-and-values is the predeclared Material 16.2.14 Sass inventory in compatibility/rc/oracles/material-16.2.14-sass-api.json: variable values, function and mixin signatures, invoked mixin CSS digests and aggregate membership/order.",
        "Cases matching a recorded pending decision in compatibility/rc/sass-pending-decisions.json write no assertion. Pending decisions are owner-visible blockers, so the report stays an incomplete slice until each is decided and resolved.",
        "21.x sass-seal groups stay null. A main run does not copy them and does not call expected_cases for 21.x.",
        "This report is the acceptance input. It does not add a G06 or G08 claim field.",
    ],
    "companion-computed-styles": [
        "Coordinator report for the line being verified. Each rostered main case has exactly one assertion file written by this run.",
        "Each assertion compares the candidate rendered computed value with the computed value from the installed current @angular/material peer oracle recorded for this run. Historical v16 output is not the oracle.",
        "21.x companion-computed-styles groups stay null. A main run does not copy them and does not call expected_cases for 21.x.",
        "This report is the acceptance input. It does not add a G06, G07 or G08 claim field.",
    ],
}


def _contract_artifacts(row: dict) -> dict | None:
    """Manifest artifacts for the row's subjects.

    ``source`` is not a manifest artifact. As in rc_acceptance, it is skipped,
    so a source-only check binds ``{}`` and needs no run-manifest artifact.
    """
    subjects = row["acceptance"]["subject_ids"]
    if not isinstance(subjects, list) or not subjects:
        return None
    wanted = [aid for aid in subjects if aid != "source"]
    by_id: dict = {}
    for item in ACTIVE_RUN.manifest.get("artifacts", []):
        aid = item.get("id")
        if aid not in wanted:
            continue
        if aid in by_id:
            return None
        digest = item.get("sha256")
        size = item.get("bytes")
        if not isinstance(digest, str) or type(size) is not int or size <= 0:
            return None
        by_id[aid] = {"sha256": digest, "bytes": size}
    if set(by_id) != set(wanted):
        return None
    return {aid: by_id[aid] for aid in wanted}


def _roster_assertion_records(run_dir: Path, check_id: str, invocation: str, expected: list[str]) -> dict | None:
    """Map rostered case ids to assertion files this run wrote.

    Copies of the manifest or other control files are not assertion evidence.
    """
    prefix = assertion_directory(check_id, invocation)
    directory = run_dir / prefix
    if not directory.is_dir() or directory.is_symlink():
        return None
    reserved = _reserved_evidence(run_dir)
    allowed = set(expected)
    found: dict = {}
    for path in sorted(directory.iterdir()):
        if not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1:
            continue
        if path.name in _MIGRATION_RESERVED_NAMES or path.suffix != ".json":
            continue
        if path.name.endswith((".sha256", ".sha512", ".sha1")):
            continue
        identity = (evidence_sha256(path), path.stat().st_size)
        if identity in reserved:
            continue
        try:
            body = read_json(path)
        except EvidenceError:
            continue
        case_id = body.get("case_id")
        if body.get("result") != "pass" or body.get("kind") != "assertion":
            continue
        if not isinstance(case_id, str) or case_id not in allowed or case_id in found:
            if isinstance(case_id, str) and case_id in found:
                return None
            continue
        body_check = _ASSERTION_BODY_CHECKS.get(check_id)
        if body_check is not None and not body_check(body, invocation):
            continue
        relative = path.relative_to(run_dir).as_posix()
        if not relative.startswith(prefix + "/"):
            continue
        found[case_id] = {"path": relative, "sha256": identity[0], "bytes": identity[1]}
    if set(found) != allowed:
        return None
    return found


_PEER_SOURCE_FILE = re.compile(r"^([a-z0-9-]+)/_m2-\1\.scss$")


def _current_peer_version(package: str) -> str | None:
    for item in (ACTIVE_RUN.manifest.get("oracles") or {}).get("current_peer") or []:
        if isinstance(item, dict) and item.get("id") == package:
            version = item.get("version")
            return version if isinstance(version, str) and version else None
    return None


def _bridge_token_assertion_ok(body: dict, invocation: str) -> bool:
    """A companion bridge token assertion from this run's in-run peer oracle.

    It must name this run and invocation, the run's frozen @angular/material
    peer version, the peer M2 token source for its component, and carry a
    non-empty candidate value equal to the peer value in every selector of
    every compared theme scenario, except the six pinned Material-16 Stepper
    values whose tagged-reference CSS and shape are independently checked.
    """
    case_id = body.get("case_id")
    component = body.get("component")
    key = body.get("allowed_key")
    if not all(isinstance(v, str) and v for v in (case_id, component, key)):
        return False
    if body.get("token") != case_id or case_id != f"--mat-{component}-{key}":
        return False
    if body.get("run_id") != ACTIVE_RUN.manifest.get("run_id") or body.get("invocation_id") != invocation:
        return False
    if body.get("peer_package") != "@angular/material":
        return False
    peer_version = _current_peer_version("@angular/material")
    if peer_version is None or body.get("peer_version") != peer_version:
        return False
    source = body.get("peer_source_file")
    match = _PEER_SOURCE_FILE.fullmatch(source) if isinstance(source, str) else None
    if match is None or match.group(1) != component:
        return False
    if not (isinstance(body.get("peer_source_sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", body["peer_source_sha256"])):
        return False
    expected, candidate = body.get("expected_peer"), body.get("candidate")
    if not (isinstance(expected, str) and expected):
        return False
    historical = case_id in HISTORICAL_STEPPER_TOKENS
    if historical:
        line = body.get("line")
        if (line not in ("main", "21.x") or
            peer_version != {"main": "22.1.7", "21.x": "21.2.14"}[line] or
            body.get("historical_oracle") != HISTORICAL_STEPPER_PROOF or
            body.get("expected_historical") != stepper_historical_value(line, "contract", case_id) or
            candidate != body["expected_historical"]):
            return False
    elif (candidate != expected or "historical_oracle" in body or "expected_historical" in body):
        return False
    scenarios = body.get("scenarios")
    if not isinstance(scenarios, list) or not scenarios:
        return False
    if historical and [s.get("id") if isinstance(s, dict) else None for s in scenarios] != list(HISTORICAL_STEPPER_SCENARIOS):
        return False
    for scenario in scenarios:
        checks = scenario.get("selector_checks") if isinstance(scenario, dict) else None
        if scenario.get("match") is not True or not isinstance(checks, list) or not checks:
            return False
        if historical and (len(checks) != 1 or not isinstance(checks[0], dict) or checks[0].get("selector") != ":root"):
            return False
        for check in checks:
            if not isinstance(check, dict) or check.get("match") is not True:
                return False
            value = check.get("expected_peer")
            if not (isinstance(value, str) and value):
                return False
            if historical:
                historical_value = stepper_historical_value(body["line"], scenario["id"], case_id)
                if check.get("expected_historical") != historical_value or check.get("candidate") != historical_value:
                    return False
            elif (check.get("candidate") != value or "expected_historical" in check):
                return False
    return True


_SHA256_HEX = re.compile(r"^[0-9a-f]{64}$")
_COMPUTED_GROUPS = ("thirteen-companion-dimensions", "independent-peer-oracle")
_COMPUTED_DIMENSIONS = ("base", "color", "typography", "density")
_CSS_WIDE_KEYWORDS = ("inherit", "initial", "unset", "revert", "revert-layer")
# The peer datepicker density mixin restyles its calendar controls through
# icon-button tokens, so those cases consume a token the companion does not own.
_COMPUTED_FOREIGN_TOKEN_PREFIXES = {("datepicker", "density"): ("--mat-icon-button-",)}


def _is_sha256(value) -> bool:
    return isinstance(value, str) and _SHA256_HEX.fullmatch(value) is not None


def _library_artifact_sha256() -> str | None:
    for item in ACTIVE_RUN.manifest.get("artifacts", []):
        if isinstance(item, dict) and item.get("id") == "library":
            digest = item.get("sha256")
            return digest if isinstance(digest, str) and digest else None
    return None


@lru_cache(maxsize=1)
def _computed_binding_roster() -> dict:
    """Canonical consuming elements and required contexts, independent of report input."""
    module = Path(__file__).resolve().with_name("companion-computed-cases.mjs").as_uri()
    result = subprocess.run(
        ["node", "--input-type=module", "-e",
         f"import {{BINDINGS}} from {json.dumps(module)}; console.log(JSON.stringify(BINDINGS));"],
        capture_output=True, text=True, check=True,
    )
    return {binding["id"]: binding for binding in json.loads(result.stdout)}


def _computed_rendered_case_ok(body: dict, case_id: str, component: str, dimension: str) -> bool:
    try:
        binding = _computed_binding_roster().get(case_id)
    except (OSError, ValueError, subprocess.SubprocessError):
        return False
    if binding is None or any(body.get(key) != binding.get(key) for key in
                              ("companion", "dimension", "element", "property", "token", "locate")):
        return False
    element, prop = body.get("element"), body.get("property")
    if not all(isinstance(v, str) and v for v in (element, prop)):
        return False
    if case_id != f"{component}/{dimension}/{element}/{prop}":
        return False
    token = body.get("token")
    prefixes = (f"--mat-{component}-", *_COMPUTED_FOREIGN_TOKEN_PREFIXES.get((component, dimension), ()))
    if not (isinstance(token, str) and token.startswith(prefixes)):
        return False
    keyword = body.get("peer_declared_keyword")
    if keyword is not None and keyword not in _CSS_WIDE_KEYWORDS:
        return False
    scenarios = body.get("scenarios")
    if not isinstance(scenarios, list) or not scenarios:
        return False
    if [row.get("scenario") if isinstance(row, dict) else None for row in scenarios] != binding["scenarios"]:
        return False
    seen = set()
    for scenario in scenarios:
        if not isinstance(scenario, dict) or scenario.get("match") is not True:
            return False
        name = scenario.get("scenario")
        if not isinstance(name, str) or not name or name in seen:
            return False
        seen.add(name)
        oracle = scenario.get("oracle")
        if not (isinstance(oracle, str) and oracle.strip() and scenario.get("candidate") == oracle and scenario.get("bridge") == oracle):
            return False
        # A token the peer declares with a CSS-wide keyword has no computed value of its own.
        if keyword is None and not (isinstance(scenario.get("oracle_token"), str) and scenario["oracle_token"].strip()):
            return False
    for key in ("negative", "bridge_negative"):
        negative = body.get(key)
        if not isinstance(negative, dict) or negative.get("scenario") != binding["negative_scenario"]:
            return False
        if negative.get("sentinel_consumed") is not True or negative.get("mismatch_detected") is not True:
            return False
        injected, observed = negative.get("injected"), negative.get("observed")
        if not (isinstance(injected, str) and injected and isinstance(observed, str) and observed):
            return False
        if observed == negative.get("oracle"):
            return False
    return True


def _computed_style_assertion_ok(body: dict, invocation: str) -> bool:
    """A companion computed-style assertion from this run's rendered peer oracle.

    Common: this run and invocation, the run's frozen @angular/material peer
    version and package.json digest, the run's library tarball, and the peer
    ``<companion>/_m2-<companion>.scss`` source. A rendered dimension case
    needs candidate == oracle (non-empty, peer token defined on the consuming
    element) in every scenario and a consumed wrong-but-nonempty negative. A
    not-applicable case needs the live peer dimension mixin to emit nothing.
    A peer-oracle case needs peer-only Sass and a sensitivity witness per
    applicable dimension.
    """
    case_id = body.get("case_id")
    component = body.get("companion")
    if not (isinstance(case_id, str) and case_id and isinstance(component, str) and component):
        return False
    if body.get("check_id") != "companion-computed-styles" or body.get("line") != "main":
        return False
    if body.get("run_id") != ACTIVE_RUN.manifest.get("run_id") or body.get("invocation_id") != invocation:
        return False
    if body.get("peer_package") != "@angular/material":
        return False
    peer_version = _current_peer_version("@angular/material")
    if peer_version is None or body.get("peer_version") != peer_version:
        return False
    if not _is_sha256(body.get("peer_package_json_sha256")):
        return False
    library = _library_artifact_sha256()
    if library is None or body.get("tarball_sha256") != library:
        return False
    source = body.get("peer_source_file")
    match = _PEER_SOURCE_FILE.fullmatch(source) if isinstance(source, str) else None
    if match is None or match.group(1) != component or not _is_sha256(body.get("peer_source_sha256")):
        return False
    if not (_is_sha256(body.get("oracle_css_sha256")) and _is_sha256(body.get("candidate_css_sha256"))):
        return False
    group = body.get("group")
    if group == "independent-peer-oracle":
        if case_id != f"{component}/peer-oracle":
            return False
        isolation = body.get("oracle_isolation")
        if not isinstance(isolation, dict) or isolation.get("peer_only") is not True:
            return False
        if isolation.get("legacy_package_loaded") is not False:
            return False
        applicable = body.get("applicable_dimensions")
        sensitivity = body.get("sensitivity")
        if not isinstance(applicable, list) or not applicable or not isinstance(sensitivity, dict):
            return False
        if set(sensitivity) != set(applicable):
            return False
        return all(isinstance(v, dict) and v.get("ok") is True for v in sensitivity.values())
    if group != "thirteen-companion-dimensions":
        return False
    dimension = body.get("dimension")
    if dimension not in _COMPUTED_DIMENSIONS:
        return False
    if body.get("not_applicable") is True:
        if case_id != f"{component}/{dimension}/not-applicable":
            return False
        if body.get("peer_mixin") != f"mat.{component}-{dimension}":
            return False
        return body.get("peer_emitted_tokens") == []
    return _computed_rendered_case_ok(body, case_id, component, dimension)


_M3_CASE_GROUPS = {
    "current-only": "inclusion-order",
    "legacy-only": "inclusion-order",
    "current-then-legacy": "inclusion-order",
    "legacy-then-current": "inclusion-order",
    "nested-theme-scope": "nested-lazy-overlay",
    "lazy-body-overlay": "nested-lazy-overlay",
    "current-shared-scope": "shared-style-boundary",
    "legacy-shared-scope": "shared-style-boundary",
}


def _m3_order_facts_ok(case_id: str, facts: dict) -> bool:
    m3, m2 = facts.get("m3_present"), facts.get("m2_present")
    if case_id == "current-only":
        return m3 is True and m2 is False
    if case_id == "legacy-only":
        return m2 is True and m3 is False
    i3, i2 = facts.get("m3_index"), facts.get("m2_index")
    if not (m3 is True and m2 is True and isinstance(i3, int) and isinstance(i2, int)):
        return False
    return i3 < i2 if case_id == "current-then-legacy" else i2 < i3


def _m3_rendered_check_ok(check) -> bool:
    if not isinstance(check, dict) or check.get("found") is not True or check.get("ok") is not True:
        return False
    if not all(isinstance(check.get(k), str) and check.get(k) for k in ("label", "probe", "observed", "reference")):
        return False
    props = check.get("properties")
    if not isinstance(props, list) or not props:
        return False
    for prop in props:
        if not isinstance(prop, dict) or not isinstance(prop.get("property"), str) or not prop.get("property"):
            return False
        if not all(isinstance(prop.get(k), str) and prop.get(k) for k in ("observed", "reference")):
            return False
    if check.get("expect") == "equal":
        return all(prop["observed"] == prop["reference"] for prop in props)
    if check.get("expect") == "differ":
        return any(prop["observed"] != prop["reference"] for prop in props)
    return False


def _m3_assertion_ok(body: dict, invocation: str) -> bool:
    """An m3-coexistence assertion from this run's packed library.

    It must name this run and invocation and the run's library tarball, carry
    a passing packed compile of its case, and a passing Chromium render of a
    fresh consumer install against the run's frozen @angular/material peer:
    every rendered check found its probes and holds on non-empty computed
    values. current-shared-scope also needs its contamination fixture
    detected and unrostered. A workspace compile is not accepted.
    """
    case_id = body.get("case_id")
    group = _M3_CASE_GROUPS.get(case_id) if isinstance(case_id, str) else None
    if group is None or body.get("group") != group:
        return False
    if body.get("check_id") != "m3-coexistence" or body.get("line") != "main":
        return False
    if body.get("result") != "pass" or body.get("kind") != "assertion" or body.get("source_kind") != "packed":
        return False
    if body.get("run_id") != ACTIVE_RUN.manifest.get("run_id") or body.get("invocation_id") != invocation:
        return False
    library = _library_artifact_sha256()
    if library is None or body.get("tarball_sha256") != library:
        return False
    peer_version = _current_peer_version("@angular/material")
    if peer_version is None or body.get("peer_version") != peer_version:
        return False
    facts = body.get("packed_compile")
    if not isinstance(facts, dict) or not facts:
        return False
    if group == "inclusion-order" and not _m3_order_facts_ok(case_id, facts):
        return False
    rendered = body.get("rendered")
    if not isinstance(rendered, dict) or rendered.get("result") != "pass":
        return False
    if not (isinstance(rendered.get("browser"), str) and rendered.get("browser")):
        return False
    versions = rendered.get("versions")
    if not isinstance(versions, dict) or versions.get("material") != peer_version:
        return False
    if not complete_rendered_checks(case_id, rendered):
        return False
    checks = rendered.get("checks")
    if not isinstance(checks, list) or not checks or not all(_m3_rendered_check_ok(c) for c in checks):
        return False
    if not any(c.get("expect") == "equal" for c in checks):
        return False
    if case_id == "current-shared-scope":
        negative = rendered.get("contamination_negative")
        if not isinstance(negative, dict) or negative.get("detected") is not True or negative.get("rostered") is not False:
            return False
    return True


SASS_API_ORACLE = ROOT / "compatibility/rc/oracles/material-16.2.14-sass-api.json"
_SASS_API_PREFIXES = ("variable/", "function/", "mixin/", "mixin-css/", "aggregate/")


def _sass_seal_assertion_ok(body: dict, invocation: str) -> bool:
    if body.get('case_id')=='mixin-css/private-check-duplicate-theme-styles':return private_card_assertion_ok(ROOT,ACTIVE_RUN,body,invocation)
    if 'current_private_card' in body:return False
    if body.get('case_id') in ORDINARY_CARD_GATE_CASES and str(body.get('case_id','')).startswith('mixin-css/'):
        return ordinary_card_gate_assertion_ok(ROOT,ACTIVE_RUN,body,invocation)
    if 'current_ordinary_card' in body and body.get('case_id') not in ORDINARY_CARD_GATE_CASES:return False
    if body.get('case_id') in ORDINARY_CONTROL_GATE_CASES and str(body.get('case_id','')).startswith('mixin-css/'):
        return ordinary_control_gate_assertion_ok(ROOT,ACTIVE_RUN,body,invocation)
    if 'current_ordinary_controls' in body and body.get('case_id') not in ORDINARY_CONTROL_GATE_CASES:return False
    if body.get('case_id') in SPINNER_SNACK_GATE_CASES and str(body.get('case_id','')).startswith('mixin-css/'):
        return spinner_snack_gate_assertion_ok(ROOT,ACTIVE_RUN,body,invocation)
    if 'current_spinner_snack_bridge' in body and body.get('case_id') not in SPINNER_SNACK_GATE_CASES:return False
    """sass-api-and-values assertions must bind this run, invocation, library and oracle.

    Root core and aggregate ids require their finite whole-CSS artifact contracts.
    Other ordered-CSS and isolation-negative ids keep their existing bodies.
    """
    if str(body.get('case_id', '')).startswith(('mixin-argument/', 'owned-aggregate/')):
        return mixin_argument_assertion_ok(ROOT, ACTIVE_RUN, body, invocation)
    if str(body.get('case_id', '')).startswith('function-value/'):
        return function_assertion_ok(ROOT, ACTIVE_RUN, body, invocation)
    if str(body.get('case_id', '')).startswith('owned-style/'):
        return owned_rendered_ok(ROOT, ACTIVE_RUN, body, invocation)
    if body.get('case_id') in RIPPLE_COLOR_DEFAULT_CASES:
        return ripple_color_envelope_ok(ACTIVE_RUN,body,invocation)
    if body.get('case_id') in RIPPLE_COLOR_ORDERED_CASES:
        return ripple_color_envelope_ok(ACTIVE_RUN,body,invocation,ordered=True)
    if body.get('case_id') in FORM_FIELD_STATE_DEFAULT_CASES:
        return form_field_state_default_envelope_ok(ACTIVE_RUN,body,invocation)
    if body.get('case_id') in DEFAULT_AGGREGATE_CASES:
        return default_aggregate_envelope_ok(ACTIVE_RUN,body,invocation)
    if body.get('case_id') in DEFAULT_MAPPED_COMPANION_CASES:
        return default_mapped_companion_envelope_ok(ACTIVE_RUN,body,invocation)
    if body.get('case_id') in DEFAULT_COMPANION_CASES:
        return default_companion_envelope_ok(ACTIVE_RUN,body,invocation)
    if body.get('case_id') in ORDERED_CORE_CASES:
        return 'current_companion' not in body and ordered_core_envelope_ok(ACTIVE_RUN,body,invocation)
    if body.get('case_id') in ORDERED_LEGACY_BUTTON_CASES:
        return 'current_companion' not in body and ordered_legacy_button_envelope_ok(ACTIVE_RUN,body,invocation)
    if body.get('case_id') in ORDERED_AGGREGATE_CASES:
        return ordered_aggregate_envelope_ok(ACTIVE_RUN,body,invocation)
    if body.get('case_id') in DEFAULT_CORE_CDK_CASES:
        return 'current_companion' not in body and default_core_cdk_envelope_ok(ACTIVE_RUN,body,invocation)
    if 'current_infrastructure' in body or 'current_companion' in body:return False
    case_id = body.get("case_id")
    if not isinstance(case_id, str) or not case_id.startswith(_SASS_API_PREFIXES):
        return True
    if body.get("group") != "sass-api-and-values" or body.get("check_id") != "sass-seal" or body.get("line") != "main":
        return False
    if body.get("run_id") != ACTIVE_RUN.manifest.get("run_id") or body.get("invocation_id") != invocation:
        return False
    library = [a for a in ACTIVE_RUN.manifest.get("artifacts", []) if a.get("id") == "library"]
    if len(library) != 1 or body.get("tarball_sha256") != library[0].get("sha256"):
        return False
    if not SASS_API_ORACLE.is_file() or body.get("oracle_sha256") != evidence_sha256(SASS_API_ORACLE):
        return False
    return True


def _consumer_floor_assertion_ok(body: dict, invocation: str) -> bool:
    return floor_assertion_ok(ROOT, ACTIVE_RUN, body, invocation)


_ASSERTION_BODY_CHECKS = {
    "consumer-floors": _consumer_floor_assertion_ok,
    "sass-seal": _sass_seal_assertion_ok,
    "companion-bridge-tokens": _bridge_token_assertion_ok,
    "companion-computed-styles": _computed_style_assertion_ok,
    "m3-coexistence": _m3_assertion_ok,
}


def _complete_line_report(run_dir: Path, run_id: str, check_id: str) -> dict | None:
    """Coverage complete only for main, and only from the matrix roster.

    A main run calls expected_cases for main. Null 21.x groups are not filled
    and are not passed to expected_cases.
    """
    if ACTIVE_RUN is None or check_id not in _LINE_COORDINATOR_LIMITATIONS:
        return None
    matrix = read_json(MATRIX_PATH)
    row = validate_matrix(matrix)[check_id]
    line = ACTIVE_RUN.binding.get("source_line") if check_id == "consumer-floors" else "main"
    groups = row["acceptance"]["cases_by_line"].get(line)
    if not isinstance(groups, dict) or any(ids is None for ids in groups.values()):
        return None
    other = row["acceptance"]["cases_by_line"].get("21.x")
    if not isinstance(other, dict) or (check_id != "consumer-floors" and any(ids is not None for ids in other.values())):
        return None
    expected = expected_cases(row, line)
    invocation = ACTIVE_RUN.invocation(check_id)
    records = _roster_assertion_records(run_dir, check_id, invocation, expected)
    artifacts = _contract_artifacts(row)
    if records is None or artifacts is None:
        return None
    outputs = []
    seen: set[str] = set()
    case_results = []
    for case_id in expected:
        record = records[case_id]
        if record["path"] not in seen:
            outputs.append(record)
            seen.add(record["path"])
        if check_id == "consumer-floors":
            body = read_json(run_dir / record["path"])
            for support in floor_support_records(body):
                if support["path"] not in seen:
                    outputs.append(support)
                    seen.add(support["path"])
        case_results.append({
            "case_id": case_id,
            "result": "pass",
            "kind": "assertion",
            "output_paths": [record["path"]],
        })
    spec = row["acceptance"]
    return {
        "schema_version": 1,
        "template": False,
        "run_id": run_id,
        "check_id": check_id,
        "line": line,
        "invocation_id": invocation,
        "binding": ACTIVE_RUN.binding,
        "coverage": "complete",
        "result": "pass",
        "exit_code": 0,
        "subject_kind": spec["subject_kind"],
        "subject_ids": list(spec["subject_ids"]),
        "artifacts": artifacts,
        "expected_case_ids": expected,
        "discovered_case_ids": list(expected),
        "executed_case_ids": list(expected),
        "passed_case_ids": list(expected),
        "failed_case_ids": [],
        "skipped_case_ids": [],
        "unresolved_case_ids": [],
        "exceptions": [],
        "passed": len(expected),
        "failed": 0,
        "skipped": 0,
        "outputs": outputs,
        "case_results": case_results,
        "command": ["rc-verify.py", check_id],
        "limitations": list(_LINE_COORDINATOR_LIMITATIONS[check_id]),
    }


def write_line_coordinator_report(
    run_dir: Path,
    run_id: str,
    line: str,
    check_id: str,
    *,
    exit_code: int,
    limitations: list[str] | None = None,
) -> None:
    """Write one main-line coordinator report for a check that already asserts.

    Coverage is complete only when this main run's child exit is zero and every
    rostered main case has a passing assertion file in the check-owned
    invocation directory. Any other outcome, including a 21.x line, stays the
    incomplete slice. write_check_report must not replace a complete report.
    """
    if check_id not in _LINE_COORDINATOR_LIMITATIONS:
        raise EvidenceError(f"no line coordinator report for {check_id}")
    report_path = run_dir / "reports" / f"{check_id}.json"
    complete = _complete_line_report(run_dir, run_id, check_id) if exit_code == 0 and line == "main" else None
    if complete is None:
        write_check_report(
            run_dir, run_id, line, check_id,
            exit_code=exit_code, limitations=limitations,
        )
        return
    reports = report_path.parent
    reports.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(complete, indent=2) + "\n")
    before = report_path.read_bytes()
    write_check_report(
        run_dir, run_id, line, check_id,
        exit_code=exit_code, limitations=limitations,
    )
    if report_path.read_bytes() != before:
        raise EvidenceError(f"write_check_report overwrote a complete {check_id} report")


def main() -> int:
    global ACTIVE_RUN
    ACTIVE_RUN = None
    if sys.argv[1:2] == ['--check-run']:
        return check_existing_run(sys.argv[2:])
    if sys.argv[1:] == ['--check-matrix']:
        validate_matrix(read_json(MATRIX_PATH))
        print('verify: matrix structure valid; no product checks executed')
        return 0
    out_dir, line = parse_args(sys.argv[1:])
    check_inventory_source_bindings(
        json.loads((ROOT / "testing/legacy-runner/historical-inventory.json").read_text()),
        json.loads((ROOT / "testing/legacy-runner/historical-specs.json").read_text()))
    out_dir = out_dir.resolve()
    allowed_bases = ((ROOT / "artifacts").resolve(), Path(tempfile.gettempdir()).resolve())
    allowed = False
    for base in allowed_bases:
        try:
            relative_out = out_dir.relative_to(base)
            if str(relative_out) == '.':
                continue
            allowed = True
            break
        except ValueError:
            continue
    if not allowed:
        fail("--out must be under artifacts/ or the process temp directory")
    if out_dir.exists() and any(out_dir.iterdir()):
        fail(f"--out must be an empty or nonexisting directory: {out_dir}")
    out_dir.mkdir(parents=True, exist_ok=True)

    if not MATRIX_PATH.is_file():
        fail(f"missing full-verify matrix: {MATRIX_PATH}")
    matrix = read_json(MATRIX_PATH)
    required = list(validate_matrix(matrix).values())
    expected_matrix_digest = evidence_sha256(MATRIX_PATH)
    source_before_obs = observe_inputs(ROOT)
    source_before = source_before_obs['fingerprint']
    require_line_matches_checkout(line, source_before['line'])

    print("verify: packing once into", out_dir)
    pack_execution = execute_pack(out_dir, line, source_before, expected_matrix_digest)
    pack_code = pack_execution['exit_code']
    if pack_code != 0:
        fail(f"pack-draft failed ({pack_code})", code=pack_code or 1)

    run_path = out_dir / "run.json"
    meta_path = out_dir / "pack-meta.json"
    if not run_path.is_file() or not meta_path.is_file():
        fail("pack-draft did not write run.json / pack-meta.json")

    draft = read_json(run_path)
    run_id = draft.get('run_id')
    if run_id != pack_execution['run_id']:
        fail('pack manifest did not preserve the coordinator run identity')
    meta = json.loads(meta_path.read_text())
    tarball_name = meta.get("tarball")
    if not isinstance(tarball_name, str):
        fail("pack-meta.json missing tarball")
    tarball = out_dir / tarball_name
    if not tarball.is_file():
        fail(f"packed tarball missing: {tarball}")

    if draft.get('source', {}).get('commit') != source_before['commit'] or draft.get('source', {}).get('git_tree_sha') != source_before['tree'] or draft.get('source', {}).get('line') != line:
        fail('pack manifest source/tree/line does not match the selected checkout')
    draft['expected_matrix'] = {'path': 'compatibility/rc/matrices/full-verify.json', 'sha256': expected_matrix_digest}
    draft['execution_inputs'] = source_before
    pack_record_path = out_dir / 'pack-execution.json'
    draft['pack_execution'] = {'path': pack_record_path.name, 'sha256': evidence_sha256(pack_record_path),
                               'bytes': pack_record_path.stat().st_size}
    draft['pack_metadata'] = {'path': meta_path.name, 'sha256': evidence_sha256(meta_path),
                              'bytes': meta_path.stat().st_size}
    packed_obs = observe_inputs(ROOT)
    packed_drift = describe_input_drift(source_before_obs, packed_obs)
    if packed_drift or packed_obs['fingerprint'] != source_before:
        fail('source/checker inputs changed during packing\n' + '\n'.join(format_input_drift(packed_drift)))
    run_path.write_text(json.dumps(draft, indent=2) + '\n')
    ACTIVE_RUN = RunEvidence(draft, out_dir, expected_matrix_digest, pack_execution=pack_execution)
    # The pack child's exit stays in the execution record. Observation failures
    # keep this check incomplete without claiming the pack itself did not finish.
    pack_report_code = run_node("scripts/check-pack-library.mjs", ["--run", str(run_path)], record=False)
    pack_report_path = out_dir / "reports" / "pack-library.json"
    if pack_report_code != 0 and pack_report_path.is_file():
        observed = read_json(pack_report_path)
        if observed.get("coverage") == "complete":
            observed["coverage"] = "incomplete"
            observed["result"] = "fail"
            observed["exit_code"] = pack_report_code
            pack_report_path.write_text(json.dumps(observed, indent=2) + "\n")
    write_check_report(out_dir, run_id, line, "pack-library", exit_code=pack_report_code)

    results: dict[str, str] = {"pack-library": "pass" if pack_report_code == 0 else "fail"}
    implemented_ran: list[str] = ["pack-library"]

    # packed-exports
    code = run_node("scripts/check-packed-exports.mjs", ["--tarball", str(tarball)])
    write_check_report(out_dir, run_id, line, "packed-exports", exit_code=code)
    results["packed-exports"] = "pass" if code == 0 else "fail"
    implemented_ran.append("packed-exports")

    # packed-consumer (rehashes via --run)
    code = run_node("scripts/packed-consumer-aot-smoke.mjs", ["--run", str(run_path)])
    # packed-consumer writes its own report when --run is used; ensure index name.
    consumer_report = out_dir / "reports" / "packed-consumer.json"
    write_check_report(out_dir, run_id, line, "packed-consumer", exit_code=code)
    results["packed-consumer"] = "pass" if code == 0 else "fail"
    implemented_ran.append("packed-consumer")

    # motion-smoke is source-level today; record as implemented automatic check.
    code = run_node("scripts/motion-lifecycle-smoke.mjs", [])
    write_check_report(
        out_dir,
        run_id,
        line,
        "motion-smoke",
        exit_code=code,
        limitations=["Source/host motion smoke; not yet rebound as a packed-artifact subject."],
    )
    results["motion-smoke"] = "pass" if code == 0 else "fail"
    implemented_ran.append("motion-smoke")

    # engine-free-consumer: required consumer of the packed library bytes.
    code = run_node("scripts/engine-free-consumer.mjs", ["--tarball", str(tarball)])
    write_check_report(
        out_dir,
        run_id,
        line,
        "engine-free-consumer",
        exit_code=code,
        limitations=[
            "Installs declared peers without @angular/animations.",
            "Does not compile templates; not a sealed release certificate by itself.",
        ],
    )
    results["engine-free-consumer"] = "pass" if code == 0 else "fail"
    implemented_ran.append("engine-free-consumer")

    # migration-packaged: exact artifact verification plus this line
    # old-workspace/transaction/frontend groups. A failed child or missing
    # source-rostered assertion keeps the report incomplete. Foreign line
    # groups remain separate. The report is the acceptance input; this comment does
    # not accept the check and does not add a G04 or G05 claim field.
    code_verify = run_node("scripts/build-migrate-legacy-cli.mjs", ["--verify"])
    code_iso = run_node("scripts/migration-cli-isolation.mjs", [])
    code_workspace = run_node(
        "scripts/check-old-workspace-cli.mjs",
        ["--run", str(run_path), "--out", str(out_dir / "old-workspace-cli.json")],
    )
    code_tx = run_node(
        "scripts/migration-transaction.mjs",
        ["--run", str(run_path), "--out", str(out_dir / "migration-transaction.json")],
    )
    code_parity = run_node(
        "scripts/check-frontend-parity.mjs",
        ["--run", str(run_path), "--out", str(out_dir / "frontend-parity.json")],
    )
    code_schematic = run_node(
        "scripts/check-packaged-schematic.mjs",
        ["--run", str(run_path), "--out", str(out_dir / "packaged-schematic.json")],
    )
    code = 0 if code_verify == 0 and code_iso == 0 and code_workspace == 0 and code_tx == 0 and code_parity == 0 and code_schematic == 0 else (code_verify or code_iso or code_workspace or code_tx or code_parity or code_schematic or 1)
    write_migration_packaged_report(
        out_dir,
        run_id,
        line,
        exit_code=code,
        limitations=[
            "Checks the committed migrate-legacy CLI tarball identity and isolation. That tarball is not old-workspace-cli acceptance.",
            "old-workspace-cli runs the exact run CLI on the authenticated Material 16.2.14 environment, then upgrades that workspace and strictly compiles/renders the migrated application.",
            "transaction-negatives runs node on package/bin/migrate-legacy.js extracted from that tarball. It does not import a transform function and does not run the schematic runner.",
            "Ten artifact-bound transaction cases include real mid-replacement EIO recovery, preservation of concurrent edits and retained backups after rollback failure; injected errors and before-write hooks are identified separately.",
            "Recoverable file application is not crash-atomic and does not exclude noncooperating writers between validation and rename.",
            "frontend-parity runs the extracted CLI bin and ng generate of the packed library collection on two copies of one temp fixture. It does not use an in-memory schematic host. That comparison stays a CLI byte match.",
            "packaged-schematic compares ng generate output with expected_after. It reuses the ng generate frontend from scripts/check-frontend-parity.mjs and does not define the roster as bytes matched the CLI. Foreign-line groups remain separate. Missing assertions keep coverage slice. Does not mark migration-packaged accepted. Does not claim G04 or G05.",
        ],
    )
    results["migration-packaged"] = "pass" if code == 0 else "fail"
    implemented_ran.append("migration-packaged")

    # sass-seal: packed Sass API inventory, ordered CSS and isolation negatives.
    # Recorded pending decisions write no assertion, so the coordinator report
    # stays an incomplete slice while any decision is open.
    code = run_node("scripts/sass-seal.mjs", ["--run", str(run_path)])
    write_line_coordinator_report(
        out_dir,
        run_id,
        line,
        "sass-seal",
        exit_code=code,
        limitations=[
            "Peer-aware packed facade compile, three sealed value fixtures, the 16.2.14 Sass API inventory (values, signatures, invoked mixin CSS digests, aggregate membership), 31 ordered-CSS fixtures, and archived-import, mutated-golden, hidden-resolution and api-drift negatives.",
            "Cases covered by a recorded pending decision in compatibility/rc/sass-pending-decisions.json have no assertion and keep coverage incomplete. Pending decisions are not passes and are not exceptions.",
            "Does not execute DOM or 21.x. Does not mark sass-seal accepted. Does not close companion bridge computed styles or G06-G08.",
        ],
    )
    results["sass-seal"] = "pass" if code == 0 else "fail"
    implemented_ran.append("sass-seal")

    # companion-bridge-tokens: compiled bridge tokens vs the in-run current-peer M2 oracle (not G07).
    code = run_node("scripts/check-companion-bridges.mjs", [])
    write_line_coordinator_report(
        out_dir,
        run_id,
        line,
        "companion-bridge-tokens",
        exit_code=code,
        limitations=[
            "Compiled token inventory plus the in-run current-peer M2 oracle comparison; no rendered computed styles.",
            "Complete only on main when every rostered token has a passing assertion from this run. 21.x stays a slice.",
            "Does not claim G06-G08.",
        ],
    )
    results["companion-bridge-tokens"] = "pass" if code == 0 else "fail"
    implemented_ran.append("companion-bridge-tokens")

    # companion-computed-styles: Chromium rendered computed properties of the
    # thirteen companions vs the in-page current-peer M2 oracle; not a G07 claim.
    # Complete only on main when every rostered case has a passing peer-oracle
    # assertion from this run; null rosters, a failed child or 21.x stay a slice.
    code = run_node("scripts/check-companion-computed-styles.mjs", ["--run", str(run_path)])
    write_line_coordinator_report(
        out_dir,
        run_id,
        line,
        "companion-computed-styles",
        exit_code=code,
        limitations=[
            "Rendered current-peer components in Chromium; candidate bridges vs the in-page peer M2 oracle on consuming computed properties.",
            "Complete only on main when every rostered case has a passing assertion from this run. 21.x stays a slice.",
            "Does not claim RC-05-A02 / G06-G08.",
        ],
    )
    results["companion-computed-styles"] = "pass" if code == 0 else "fail"
    implemented_ran.append("companion-computed-styles")

    # m3-coexistence: packed compile plus a Chromium render of a fresh consumer
    # install of the run library for the inclusion orders, nested/lazy/overlay
    # and shared-style cases; the workspace compile stays in the child report.
    # When every rostered main case has a packed rendered assertion from this
    # run, write one coordinator report. A failed child or a 21.x line stays an
    # incomplete slice. Contamination negatives stay unrostered. No G07 claim.
    code = run_node(
        "scripts/check-m3-inclusion-order.mjs",
        ["--run", str(run_path), "--out", str(out_dir / "m3-inclusion-order-workspace.json")],
    )
    write_line_coordinator_report(
        out_dir,
        run_id,
        line,
        "m3-coexistence",
        exit_code=code,
        limitations=[
            "Run library tarball: packed compile and Chromium-rendered computed styles of a fresh consumer install for the four inclusion orders, nested-theme-scope, lazy-body-overlay, and separate current/legacy shared-style scopes.",
            "The main workspace compile also runs and stays in the child report. Contamination fixtures are rejected or detected and are not rostered.",
            "21.x m3 groups stay null. A 21.x line stays an incomplete slice. Does not mark m3-coexistence accepted. Does not claim G07.",
        ],
    )
    results["m3-coexistence"] = "pass" if code == 0 else "fail"
    implemented_ran.append("m3-coexistence")

    # browser-matrix: Chromium dialog/select + overlay families (zoneful/zoneless) PR-slice; not the full matrix.
    code = run_node("scripts/run-browser-matrix-slice.mjs", ["--run", str(run_path)])
    write_check_report(
        out_dir,
        run_id,
        line,
        "browser-matrix",
        exit_code=code,
        limitations=[
            "Executes dialog/select (zoneful/zoneless/CSP/reduced-motion) plus menu/snack-bar/tooltip/autocomplete/tabs defaults; does not fan out to unexecuted cells.",
            "Firefox/WebKit, remaining families/states, SSR, enabled-motion, and other CSP remain not-executed.",
            "Does not claim G10.",
        ],
    )
    results["browser-matrix"] = "pass" if code == 0 else "fail"
    implemented_ran.append("browser-matrix")

    # native-motion: packed artifact on Chromium, Firefox, and WebKitGTK.
    # WebKitGTK is the webkit engine only. motion-smoke stays source-level.
    code = run_node("scripts/native-motion-acceptance.mjs", ["--run", str(run_path)])
    write_check_report(
        out_dir,
        run_id,
        line,
        "native-motion",
        exit_code=code,
        limitations=[
            "Artifact-native motion on Chromium, Firefox, and WebKitGTK. WebKitGTK is not Safari.",
            "Does not claim G04 or G10.",
        ],
    )
    results["native-motion"] = "pass" if code == 0 else "fail"
    implemented_ran.append("native-motion")

    # csp-ssr: Chromium nonce/hash policy and dom-free server renders.
    # WebKitGTK is not Safari and is not launched here. Hydration is unclaimed.
    code = run_node("scripts/csp-ssr-acceptance.mjs", ["--run", str(run_path)])
    write_check_report(
        out_dir,
        run_id,
        line,
        "csp-ssr",
        exit_code=code,
        limitations=[
            "Chromium CSP nonce and style hash. No unsafe-inline. WebKitGTK is not Safari and is not this check.",
            "Server imports and renders start without a document. Hydration is unclaimed.",
            "Does not claim G04 or G10.",
        ],
    )
    results["csp-ssr"] = "pass" if code == 0 else "fail"
    implemented_ran.append("csp-ssr")

    # api-completeness: packed vs 16.2.14 names + allowlist + structural signatures.
    code = run_node("scripts/api-completeness.mjs", ["--run", str(run_path)])
    write_check_report(
        out_dir,
        run_id,
        line,
        "api-completeness",
        exit_code=code,
        limitations=[
            "Export-name completeness vs Material 16.2.14 with reviewed allowlist.",
            "Structural member-name signatures for shared class/interface exports.",
            "Does not claim G02 (full overload/generics/protected/DI identity).",
        ],
    )
    results["api-completeness"] = "pass" if code == 0 else "fail"
    implemented_ran.append("api-completeness")

    # historical-legacy-artifact: all inventory families against the packed --run.
    code = run_node("scripts/rc-test-legacy-family.mjs", ["--run", str(run_path)])
    write_check_report(
        out_dir,
        run_id,
        line,
        "historical-legacy-artifact",
        exit_code=code,
        limitations=[
            "Runs the inventory family suite against the rehashed packed library.",
            "Requires a usable Chromium/Chrome (CHROME_BIN).",
            "Passing this cell alone is not G09 or G01 closure.",
        ],
    )
    results["historical-legacy-artifact"] = "pass" if code == 0 else "fail"
    implemented_ran.append("historical-legacy-artifact")

    # FRESH-03 producers. Nonzero means the admission gap is still open.
    # A structural ledger pass is not security clearance and is not copied forward.
    code = run_node(
        "scripts/check-source-policy.py",
        ["--root", "projects/ngx-material-legacy", "--tarball", str(tarball),
         "--report", str(out_dir / "source-policy-observation.json")],
    )
    write_check_report(
        out_dir, run_id, line, "source-policy", exit_code=code,
        limitations=[
            "Installed peer annotation comparison is unknown unless declaration files from node_modules/@angular are present.",
            "Owned helpers replace animations-module imports, deep private modules, and underscore platform imports. A packed digest is still scanned separately.",
        ],
    )
    results["source-policy"] = "pass" if code == 0 else "fail"
    implemented_ran.append("source-policy")

    code = run_node(
        "scripts/check-dependency-eligibility.py",
        ["--lookup", "--report", str(out_dir / "dependency-eligibility-observation.json")],
    )
    write_check_report(
        out_dir, run_id, line, "dependency-eligibility", exit_code=code,
        limitations=[
            "This run queries OSV and registry publish times. A non-200, stale, truncated, or missing-time result stays unknown.",
            "HTTP 200 metadata is not security clearance. Unresolved findings and packages younger than seven days block the check.",
            "Vendor hash and license-file observations do not clear G08, G11, or G13. g11_claim stays not-passed.",
        ],
    )
    results["dependency-eligibility"] = "pass" if code == 0 else "fail"
    implemented_ran.append("dependency-eligibility")

    run_source_contract_regressions(out_dir, run_id, line, results, implemented_ran)

    # Run the finite packed typeahead producer before the audit consumes its identity.
    if line == 'main':
        code = run_node('scripts/run-typeahead-execution.py', ['--run', str(run_path)])
        complete = write_typeahead_report(out_dir, run_id, line, code)
        results['typeahead-execution'] = 'pass' if code == 0 and complete else 'fail'
        implemented_ran.append('typeahead-execution')

    code = run_node(
        "scripts/check-upstream-audit-disposition.mjs",
        ["--admission", "--line", line, "--report", str(out_dir / "upstream-audit-structural.json")],
    )
    write_check_report(
        out_dir, run_id, line, "upstream-audit-disposition", exit_code=code,
        limitations=[
            "Structural seed coverage is not disposition admission or security clearance.",
            "Sensitive, inherited, and material behavior rows still lack individual proof; the symbol seed is open.",
            "Current advisory admission consumes this run’s complete, source-bound dependency producer; g11_claim stays not-passed.",
        ],
    )
    results["upstream-audit-disposition"] = "pass" if code == 0 else "fail"
    implemented_ran.append("upstream-audit-disposition")

    # Diagnostic ranges and actual artifact-bound runtime configurations share one invocation.
    diagnostic_code = run_node(
        "scripts/check-consumer-floors.mjs",
        ["--out", str(out_dir / "consumer-floors-workspace.json")],
    )
    runtime_code = run_node("scripts/run-consumer-floor-configurations.mjs", ["--run", str(out_dir / "run.json")])
    code = diagnostic_code or runtime_code
    write_line_coordinator_report(
        out_dir, run_id, line, "consumer-floors", exit_code=code,
        limitations=["Only this source line's reviewed configurations are executed against this run's artifacts."],
    )
    results["consumer-floors"] = "pass" if code == 0 else "fail"
    implemented_ran.append("consumer-floors")

    # release-metadata: declared name/version/license/provenance only.
    # When every rostered main case has an assertion file from this run, write one
    # coordinator report. A failed child or a 21.x line stays an incomplete slice.
    # No instruction file is compared. The report does not add a G01 or G13 claim field.
    code = run_node(
        "scripts/check-release-metadata.mjs",
        ["--out", str(out_dir / "release-metadata-workspace.json")],
    )
    write_line_coordinator_report(
        out_dir,
        run_id,
        line,
        "release-metadata",
        exit_code=code,
        limitations=[
            "Compares declared library and migrate-cli name, version, and license fields, plus the existing provenance file.",
            "instructions-provenance rosters only provenance fields that were compared. No instruction file was compared.",
            "21.x release-metadata groups stay null. A 21.x line stays an incomplete slice. Does not mark release-metadata accepted. Does not claim G01 or G13.",
        ],
    )
    results["release-metadata"] = "pass" if code == 0 else "fail"
    implemented_ran.append("release-metadata")

    missing: list[str] = []
    failed: list[str] = []
    for check in required:
        check_id = check.get("check_id")
        if not isinstance(check_id, str) or not check_id:
            fail("full-verify matrix has a check without check_id")
        if check_id in results:
            if results[check_id] != "pass":
                failed.append(check_id)
            continue
        if not check.get("implemented"):
            write_missing_report(
                out_dir,
                run_id,
                line,
                check_id,
                f"Required check {check_id} is not implemented in automatic verify yet.",
            )
            missing.append(check_id)
            results[check_id] = "missing"
            continue
        # Marked implemented but no runner wired here — still fail closed.
        write_missing_report(
            out_dir,
            run_id,
            line,
            check_id,
            f"Required check {check_id} is marked implemented but was not invoked.",
        )
        missing.append(check_id)
        results[check_id] = "missing"

    record = {
        'schema_version': 1, 'run_id': run_id, 'binding': ACTIVE_RUN.binding,
        'invocation_ids': ACTIVE_RUN.invocations, 'process_results': ACTIVE_RUN.exit_codes,
        'recorded_at': datetime.now(timezone.utc).isoformat(),
    }
    record_path = out_dir / 'execution-record.json'
    record_path.write_text(json.dumps(record, indent=2) + '\n')
    draft['execution_record'] = {'path': record_path.name, 'sha256': evidence_sha256(record_path), 'bytes': record_path.stat().st_size}
    run_path.write_text(json.dumps(draft, indent=2) + '\n')
    completeness = evaluate_run(ROOT, run_path, matrix_sha256=expected_matrix_digest,
        binding=ACTIVE_RUN.binding, process_results=ACTIVE_RUN.exit_codes,
        invocation_ids=ACTIVE_RUN.invocations)
    source_after_obs = observe_inputs(ROOT)
    source_drift = describe_input_drift(source_before_obs, source_after_obs)
    (out_dir / 'source-inputs.json').write_text(json.dumps({
        'schema_version': 1,
        'role': 'source input observation',
        'run_id': run_id,
        'before': {'fingerprint': source_before, 'locks': source_before_obs['locks']},
        'after': {'fingerprint': source_after_obs['fingerprint'], 'locks': source_after_obs['locks']},
        'changes': source_drift,
    }, indent=2) + '\n')
    if source_drift or source_after_obs['fingerprint'] != source_before:
        named = format_input_drift(source_drift) or ['source, checker or tool inputs changed during execution']
        completeness['incomplete_checks']['source-drift'] = named
        completeness['automatic_product_result'] = 'incomplete'
        print('verify: source drift\n' + '\n'.join(named), file=sys.stderr)
    summary = {
        "schema_version": 1,
        "role": "rc-verify-orchestration",
        "run_id": run_id,
        "line": line,
        "out": str(out_dir),
        "matrix": str(MATRIX_PATH.relative_to(ROOT)),
        "implemented_ran": implemented_ran,
        "results": results,
        "completeness": completeness,
        "missing_required": missing,
        "failed_required": failed,
        "g01_claimed": False,
        "g_gates_claimed": [],
        "finished_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "limitations": [
            "Incremental RC-02.04 orchestration only.",
            "Missing required matrix cells keep this gate failed.",
            "Does not claim G01-G13 or RC engineering ready.",
        ],
    }
    (out_dir / "verify-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    archive_error = ''
    try:
        write_closure(out_dir)
    except ClosureError as error:
        archive_error = str(error)
        print(f'verify: {archive_error}', file=sys.stderr)

    print("verify: implemented checks:", ", ".join(implemented_ran))
    if missing:
        print("verify: missing required checks:")
        for item in missing:
            print(f"  - {item}")
    if failed:
        print("verify: failed required checks:")
        for item in failed:
            print(f"  - {item}")
    print("verify: this command did not claim G01-G13")
    # Keep a stable phrase so older tooling can detect non-success subsets:
    print("verify: did not run verify-lite or any historical family as a stand-in for omitted product gates")

    for cid, reasons in completeness['incomplete_checks'].items():
        print(f"verify: incomplete {cid}: {reasons[0]}")
    if archive_error or missing or failed or completeness['automatic_product_result'] != 'pass':
        return 2
    print('verify: automatic prerequisites complete; independent review and release admission remain pending')
    return 0


if __name__ == "__main__":
    try:
        if '--out' in sys.argv[1:]:
            with verifier_lock(ROOT):
                raise SystemExit(main())
        raise SystemExit(main())
    except (EvidenceError, OSError, ValueError, subprocess.CalledProcessError) as error:
        print(f'verify: {error}', file=sys.stderr)
        raise SystemExit(2)
