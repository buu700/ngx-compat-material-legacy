/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {gzipSync} from 'node:zlib';
const [root,diagnostic,out]=process.argv.slice(2),start=performance.now(),hash=b=>createHash('sha256').update(b).digest('hex'),cache=new Map();
const read=p=>{if(!cache.has(p))cache.set(p,readFileSync(join(root,p)));return cache.get(p);};
const load=async name=>import(pathToFileURL(join(root,'scripts/'+name+'.mjs')));
const line=JSON.parse(read('projects/ngx-material-legacy/package.json')).version.startsWith('21.')?'21.x':'main';
const ledger=JSON.parse(read('compatibility/f10/disposition-ledger/ledger.json'));
const failures=JSON.parse(readFileSync(diagnostic)).evidence_failures;assert.equal(failures.length,85);
const selected=new Set(failures.map(f=>f.sha)),paths=[...new Set(failures.map(f=>f.evidence_report))];
const all=execFileSync('git',['ls-files','--','projects/ngx-material-legacy'],{cwd:root,encoding:'utf8'}).trim().split('\n');assert.equal(all.length,1142);
const {candidateProductSourcePaths}=await load('upstream-candidate-source-evidence'),sources=candidateProductSourcePaths(root).sort(),sourcePaths=()=>sources;
const input=await load('upstream-slider-input-scope'),range=await load('upstream-slider-range-followups'),destroy=await load('upstream-slider-thumb-destroy-scope'),bazel=await load('upstream-bazel-build-scope'),modern=await load('upstream-modern-chip-scope');
const edit=await load('upstream-chip-edit-scope'),api=await load('upstream-chip-input-api-scope'),modernize=await load('upstream-chip-modernization-scope'),life=await load('upstream-chip-lifecycle-admission');
const {historicalBehaviorRequirements}=await load('upstream-historical-behavior-evidence');
const {buildScopeEvidenceOk}=await load('upstream-build-scope-evidence'),consolidation=await load('upstream-test-consolidation-evidence'),comments=await load('upstream-comment-review');
const checkpoint=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const writes=new Map(),changes=[],entries=[];
for(const path of paths){
 console.error(JSON.stringify({phase:'construct',path,seconds:(performance.now()-start)/1000}));
 const old=JSON.parse(read(path));let family=path.includes('closeout-ten-comment')?'comment':path.slice('compatibility/rc/snack-dom-source-context-'.length,-5),body=structuredClone(old),proof;
 const target='compatibility/rc/packed-upstream-source-'+family+'.json';
 if(family==='build'){
  body.candidate_context.product_members=all.map(path=>({path,sha256:hash(read(path)),bytes:read(path).length}));
  body.candidate_context.files=body.candidate_context.files.map(m=>({...m,sha256:hash(read(m.path)),bytes:read(m.path).length}));
  body.candidate_context.source_commit=checkpoint;body.candidate_context.source_tree=execFileSync('git',['rev-parse',checkpoint+'^{tree}'],{cwd:root,encoding:'utf8'}).trim();
 }else if(family==='test-consolidation')body.candidate_context={path:'compatibility/rc/packed-upstream-source-build.json',sha256:hash(writes.get('compatibility/rc/packed-upstream-source-build.json'))};
 else if(family==='slider-input')body.source_scope=input.reviewSliderInputScope(read,sourcePaths,line);
 else if(family==='slider-range')body.source_scope=range.reviewSliderRangeScope(read,sourcePaths,line);
 else if(family==='slider-destroy')body.source_scope=destroy.reviewSliderThumbDestroyScope(read,sourcePaths,line);
 else if(family==='bazel'){body.candidate_context=bazel.reviewBazelBuildContext(read,()=>all,line);const actual=bazel.analyzeBazelBuildSubjects(read);const before=structuredClone(body.source_analysis),after=structuredClone(actual);let changed=0;function same(a,b,path=[]){if(a&&typeof a==='object'&&!Array.isArray(a)){assert.deepEqual(Object.keys(a),Object.keys(b));for(const key of Object.keys(a))same(a[key],b[key],[...path,key]);}else if(Array.isArray(a)){assert.equal(a.length,b.length);a.forEach((value,i)=>same(value,b[i],[...path,String(i)]));}else if(a!==b){assert.equal(path[0],'starlark');assert.ok(['before_ast_sha256','after_ast_sha256','ast_sha256'].includes(path.at(-1)));assert.match(a,/^[0-9a-f]{64}$/);assert.match(b,/^[0-9a-f]{64}$/);changed++;}}same(before,after);assert.equal(changed,1186);body.source_analysis=actual;}
 else if(family==='modern-chip'){body.candidate_context=modern.modernChipSourceContext(read,sources);proof=row=>modern.modernChipSourceProof(row.original_analysis,body.candidate_context,row.decision);}
 else if(family==='chip-edit'){body=edit.chipEditSourceBody(read,sources,line);proof=row=>edit.chipEditSourceProof(row.original_analysis,body.candidate_context,row.decision);}
 else if(family==='chip-input-api'){body=api.chipInputApiSourceBody(read,sources,line);proof=row=>api.chipInputApiSourceProof(row.original_analysis,body.candidate_context,row.decision);}
 else if(family==='chip-modernization'){body=modernize.chipModernizationSourceBody(read,sources,line);proof=row=>modernize.chipModernizationSourceProof(row.original_analysis,body.candidate_context,row.decision);}
 else if(family==='chip-lifecycle'){body=life.chipLifecycleSourceBody(read,root,line);proof=row=>life.chipLifecycleSourceProof(row.original_analysis,body.candidate_context,row.decision,historicalBehaviorRequirements(row.sha),read);}
 else if(family==='comment')body.context_members=body.context_members.map(m=>({...m,sha256:hash(read(m.path)),...(Object.hasOwn(m,'bytes')?{bytes:read(m.path).length}:{})}));
 else throw new Error('Unknown family '+family);
 assert.deepEqual(body.reviews,old.reviews,'Original hunk/decision rows changed '+family);
 const bytes=Buffer.from(JSON.stringify(body,null,2)+'\n');writes.set(target,bytes);
 const rows=ledger.entries.filter(e=>e.evidence_report===path&&selected.has(e.sha));
 for(const previous of rows){const entry=structuredClone(previous);entry.evidence_report=target;if(entry.source_check?.evidence_report_sha256)entry.source_check.evidence_report_sha256=hash(bytes);if(proof)entry.individual_proof=proof(body.reviews.find(r=>r.sha===entry.sha));entries.push({before:previous,after:entry,family});}
 changes.push({family,before:path,after:target,entries:rows.length});
}
writeFileSync(out+'.proposal.json.gz',gzipSync(Buffer.from(JSON.stringify({line,checkpoint,changes,entries,reports:[...writes].map(([path,bytes])=>({path,sha256:hash(bytes),text:bytes.toString()}))})+'\n')),{flag:'wx'});
const proposedLedger=structuredClone(ledger);for(const pair of entries)proposedLedger.entries[proposedLedger.entries.findIndex(e=>e.sha===pair.after.sha)]=pair.after;
writes.set('compatibility/f10/disposition-ledger/ledger.json',Buffer.from(JSON.stringify(proposedLedger,null,2)+'\n'));
const proposed=p=>writes.get(p)??read(p),results=[],batchResults=new Map();
for(const pair of entries){const e=pair.after,body=JSON.parse(writes.get(e.evidence_report));let valid;
 switch(pair.family){
 case 'build':valid=buildScopeEvidenceOk(body,e,proposed,all);break;
 case 'test-consolidation':if(!batchResults.has(e.evidence_report))batchResults.set(e.evidence_report,consolidation.testConsolidationBatchOk(body,proposed,all));valid=consolidation.testConsolidationEntryOk(body,e,proposed,batchResults.get(e.evidence_report));break;
 case 'slider-input':valid=input.sliderInputScopeEvidenceOk(body,e,proposed,sourcePaths,line);break;
 case 'slider-range':valid=range.sliderRangeEvidenceOk(body,e,proposed,sourcePaths,line);break;
 case 'slider-destroy':valid=destroy.sliderThumbDestroyEvidenceOk(body,e,proposed,sourcePaths,line);break;
 case 'bazel':valid=bazel.bazelBuildEvidenceOk(body,e,proposed,()=>all,line);break;
 case 'modern-chip':valid=modern.modernChipScopeEvidenceOk(body,e,proposed,sources,line);break;
 case 'chip-edit':valid=edit.chipEditScopeEvidenceOk(body,e,proposed,sources,line);break;
 case 'chip-input-api':valid=api.chipInputApiScopeEvidenceOk(body,e,proposed,sources,line);break;
 case 'chip-modernization':valid=modernize.chipModernizationScopeEvidenceOk(body,e,proposed,sources,line);break;
 case 'chip-lifecycle':valid=life.chipLifecycleScopeEvidenceOk(body,e,proposed,root,line,historicalBehaviorRequirements);break;
 case 'comment':valid=comments.commentScopeEvidenceOk(body,e,proposed,line);break;
 }
 results.push({sha:e.sha,family:pair.family,valid});
 if(!valid||results.length%10===0)console.error(JSON.stringify({phase:'validate',done:results.length,family:pair.family,valid,seconds:(performance.now()-start)/1000}));
}
const report={line,proposed:true,canonical_applied:false,changes,results,failed:results.filter(r=>!r.valid),seconds:(performance.now()-start)/1000};
writeFileSync(out,JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({...report,results:undefined,changes:undefined}));
