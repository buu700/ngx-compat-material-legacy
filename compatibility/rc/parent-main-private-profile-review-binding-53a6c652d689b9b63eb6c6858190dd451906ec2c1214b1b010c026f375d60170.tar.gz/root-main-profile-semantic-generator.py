#!/usr/bin/env python3
"""Prepare main-only profile candidate. Source identity census; no security verdict."""
import argparse, hashlib, json, os, re, subprocess, sys
from pathlib import Path, PurePosixPath

RC='compatibility/rc/'
SUFFIXES=['.cjs','.js','.mjs','.py','.sh','.ts']
ROOTS=['tests','compatibility/handoff/codex-closeout/tools']
CHECKER='scripts/check-dependency-eligibility.py'
CAP=3000000

def fail(msg): raise ValueError(msg)
def digest(b): return hashlib.sha256(b).hexdigest()
def canonical(v): return digest(json.dumps(v,sort_keys=True,separators=(',',':')).encode())
def pathcheck(s):
 if not isinstance(s,str) or not s or s.startswith('/') or any(x in ('','.','..') for x in s.split('/')): fail('unsafe path: '+repr(s))
 return s
def git(root,*args,input=None):
 p=subprocess.run(['git','--no-replace-objects','-c','gc.auto=0','-c','maintenance.auto=0',*args],cwd=root,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode: fail('git failed: '+p.stderr.decode(errors='replace'))
 return p.stdout
def safe_bytes(root,name):
 pathcheck(name); p=root
 for part in name.split('/'):
  p=p/part
  if p.is_symlink(): fail('symlink: '+name)
 if not p.is_file(): fail('missing file: '+name)
 b=p.read_bytes()
 if not 0<len(b)<=CAP: fail('invalid byte count: '+name)
 return b
def ref(root,name):
 b=safe_bytes(root,name); return {'path':name,'sha256':digest(b),'bytes':len(b)}
def verify_ref(root,r):
 if type(r)!=dict or set(r)!={'path','sha256','bytes'} or ref(root,r['path'])!=r: fail('reference mismatch: '+repr(r))
def load(root,name): return json.loads(safe_bytes(root,name))
def discover(root,directory,exts):
 parent=root/directory
 if parent.is_symlink() or not parent.is_dir(): fail('missing or linked discovery root: '+directory)
 found=set()
 for p in parent.rglob('*'):
  if p.is_symlink(): fail('symlink in discovery: '+str(p))
  if p.is_file() and p.suffix in exts: found.add(p.relative_to(root).as_posix())
 return found

def run(a):
 root=Path(a.root).resolve(strict=True); out=Path(a.out).resolve()
 if out==root or root in out.parents: fail('output must be outside worktree')
 if out.exists(): fail('output directory already exists')
 if not re.fullmatch('[0-9a-f]{40}',a.commit): fail('commit must be full SHA-1')
 if git(root,'rev-parse','HEAD').decode().strip()!=a.commit: fail('HEAD differs from frozen commit')
 if git(root,'status','--porcelain=v1','--untracked-files=no'): fail('tracked worktree or index is dirty')
 tree={}
 for rec in git(root,'ls-tree','-r','-z',a.commit).split(b'\0'):
  if rec:
   meta,n=rec.split(b'\t',1); mode,kind,oid=meta.decode().split(); name=n.decode(); pathcheck(name)
   if kind=='blob': tree[name]=(mode,oid)
 profile=load(root,RC+'parent-private-npm-current-profile-inputs-v1.json')
 verify_ref(root,profile['review']); review=load(root,profile['review']['path'])
 old=load(root,RC+'tool-advisory-triage/private-profile-source-manifests.json')
 evidence=load(root,RC+'tool-advisory-triage/private-profile-remaining-evidence.json')
 brace=load(root,RC+'tool-advisory-triage/brace-profile-validation/manifest.json')['lines']['main']['source_inputs']
 if set(profile['lines'])!={'main','21.x'} or set(review['lines'])!={'main','21.x'}: fail('unexpected line population')
 primary=discover(root,'scripts',SUFFIXES)|discover(root,'.github/workflows',['.yml','.yaml'])
 primary.discard(CHECKER)
 primary.update(['.npmrc','chainman.toml','chainman.lock','justfile','package.json','projects/ngx-material-legacy/package.json','pnpm-lock.yaml'])
 support={r['path'] for r in profile['lines']['main']['support_files']}
 groups=[]
 for directory in ROOTS:
  paths=discover(root,directory,SUFFIXES); support.update(paths)
  groups.append({'root':directory,'suffixes':SUFFIXES,'paths':sorted(paths)})
 # Recursively inspect relative literal imports/references to tracked files. This is
 # conservative finite discovery, not a proof that dynamic calls are absent.
 pending=list(primary|support); visited=set(); literals=re.compile(r'''["']((?:\.{1,2}/)[^"'\n\r]+)["']''')
 while pending:
  name=pending.pop()
  if name in visited: continue
  visited.add(name)
  if name not in tree: fail('untracked or missing relevant file: '+name)
  if Path(name).suffix not in SUFFIXES+['.json','.yaml','.yml']: continue
  try: content=safe_bytes(root,name).decode('utf-8')
  except UnicodeDecodeError: continue
  for m in literals.finditer(content):
   value=m.group(1)
   if any(c in value for c in '*?${}'): continue
   resolved=os.path.normpath(os.path.join(os.path.dirname(name),value)).replace(os.sep,'/')
   if resolved.startswith('../') or resolved in ('.','..'): continue
   candidates=[resolved]+[resolved+x for x in SUFFIXES+['.json','.yaml','.yml']]+[resolved+'/index'+x for x in SUFFIXES]
   for candidate in candidates:
    if candidate not in tree and (root/candidate).is_file(): fail('untracked literal reference: '+candidate)
    if candidate in tree and candidate!=CHECKER and candidate not in primary and candidate not in support:
     support.add(candidate); pending.append(candidate)
 # Include previously bound finite inputs and independently enumerated sources.
 inputs=({r['path'] for r in profile['lines']['main']['input_files']}|{r['path'] for r in brace}|set(evidence['roots']['main']['source_hashes'])|{'toolchain-lock.json','.node-version','.npm-version','SECURITY.md'})-primary-support
 if primary&support or CHECKER in primary|support|inputs: fail('overlapping rows or checker self-reference')
 # Reject untracked files inside both executable discovery roots, including ignored
 # files if their suffix would enter discovery; relevant names must be Git blobs.
 all_names=sorted(primary|support|inputs)
 for name in all_names:
  pathcheck(name)
  if name not in tree or tree[name][0] not in ('100644','100755'): fail('missing tracked regular blob: '+name)
 requests=''.join(tree[n][1]+'\n' for n in all_names).encode(); data=git(root,'cat-file','--batch',input=requests); pos=0; rows={}
 for name in all_names:
  end=data.index(b'\n',pos); oid,kind,size=data[pos:end].decode().split(); size=int(size)
  b=data[end+1:end+1+size]; pos=end+1+size+1
  if kind!='blob' or oid!=tree[name][1] or data[pos-1:pos]!=b'\n' or b!=safe_bytes(root,name): fail('physical/blob mismatch: '+name)
  if hashlib.sha1(b'blob '+str(size).encode()+b'\0'+b).hexdigest()!=oid: fail('blob hash mismatch: '+name)
  rows[name]={'path':name,'sha256':digest(b),'bytes':size,'git_blob':oid}
 if pos!=len(data): fail('trailing git batch data')
 # Review names the earlier source checkpoint X; the frozen commit Y must
 # preserve the complete physical census and discovery populations from X.
 sem=json.loads(Path(a.semantic_index).read_bytes())
 if set(sem)!={'schema_version','semantic_review_refs','current_source_reviews'} or sem['schema_version']!=2 or type(sem['semantic_review_refs'])!=list or not sem['semantic_review_refs'] or type(sem['current_source_reviews'])!=dict or set(sem['current_source_reviews'])!={'main'}: fail('invalid independently authored semantic index')
 new_refs=sem['semantic_review_refs']; old_refs=review.get('semantic_review_refs',[])
 refs=old_refs+new_refs; seen=set()
 for item in refs:
  verify_ref(root,item); n=item['path']
  if n in seen: fail('duplicate semantic review: '+n)
  if n not in tree or tree[n][0] not in ('100644','100755'): fail('untracked semantic review: '+n)
  if n in all_names: fail('semantic review inside source projection: '+n)
  seen.add(n)
  if git(root,'cat-file','blob',tree[n][1])!=safe_bytes(root,n): fail('semantic review physical/blob mismatch: '+n)
 refs=sorted(refs,key=lambda x:x['path'])
 current=sem['current_source_reviews']['main']
 if current not in new_refs: fail('current main review must be newly supplied')
 authored=json.loads(safe_bytes(root,current['path']))
 main={'source_parent':a.commit,'historical_source_parent':old['lines']['main']['source_parent'],'historical_source_files':len(old['lines']['main']['source_files']),'source_files':[rows[n] for n in sorted(primary)],'support_files':[rows[n] for n in sorted(support)],'input_files':[rows[n] for n in sorted(inputs)],'support_discovery':groups,'historical_source_hashes':{n:{'historical_sha256':d,'current_sha256':rows[n]['sha256']} for n,d in sorted(evidence['roots']['main']['source_hashes'].items())}}
 expected={'schema_version':1,'role':'current-source-semantic-review','line':'main','preconditions':'unchanged-maintained-tool-owned-npm',**{n+'_sha256':canonical(main[n]) for n in ('source_files','support_files','input_files')}}
 if type(authored)!=dict or set(authored)!=set(expected)|{'source_parent','evidence_refs'} or any(authored.get(k)!=v for k,v in expected.items()) or type(authored.get('source_parent'))!=str or not re.fullmatch('[0-9a-f]{40}',authored['source_parent']): fail('semantic review scope or source projection mismatch')
 if type(authored['evidence_refs'])!=list or not authored['evidence_refs'] or any(r not in refs or r==current for r in authored['evidence_refs']) or [r['path'] for r in authored['evidence_refs']]!=sorted(set(r['path'] for r in authored['evidence_refs'])): fail('semantic evidence references invalid')
 source=authored['source_parent']
 if source==a.commit: fail('semantic review must follow source checkpoint')
 git(root,'merge-base','--is-ancestor',source,a.commit)
 oldtree={}
 for rec in git(root,'ls-tree','-r','-z',source).split(b'\0'):
  if rec:
   meta,n=rec.split(b'\t',1); mode,kind,oid=meta.decode().split(); name=n.decode(); pathcheck(name)
   if kind=='blob': oldtree[name]=(mode,oid)
 if current['path'] in oldtree: fail('semantic marker must be authored after source checkpoint')
 changed=set(oldtree)^set(tree) | {n for n in set(oldtree)&set(tree) if oldtree[n]!=tree[n]}
 if any(Path(n).suffix in SUFFIXES or (n.startswith('.github/workflows/') and Path(n).suffix in ('.yml','.yaml')) for n in changed): fail('executable changes after source checkpoint')
 if any(oldtree.get(n)!=tree[n] for n in all_names): fail('source projection changed since reviewed checkpoint')
 def discovered(t,base,exts): return {n for n in t if n.startswith(base+'/') and Path(n).suffix in exts}
 for directory,exts in [('scripts',SUFFIXES),('.github/workflows',['.yml','.yaml'])]+[(r,SUFFIXES) for r in ROOTS]:
  if discovered(oldtree,directory,exts)!=discovered(tree,directory,exts): fail('discovered population changed since reviewed checkpoint')
 profile['lines']['main']=main
 review['lines']['main']={'source_parent':a.commit,'source_files_sha256':canonical(main['source_files']),'support_files_sha256':canonical(main['support_files']),'input_files_sha256':canonical(main['input_files']),'preconditions':'unchanged-maintained-tool-owned-npm'}
 profile['schema_version']=2
 review['semantic_review_refs']=refs
 review['current_source_reviews']={'main':current}
 review['method']=['Candidate finite source identity inventory; physical bytes compared to frozen Git blobs.','Relative literal tracked references recursively discovered; dynamic or computed references require independent semantic review.']
 review['limits']=['Census is not semantic or security clearance. Review references are separately authored and must be independently authenticated and assessed.']
 review_raw=(json.dumps(review,indent=2)+'\n').encode(); pathcheck(a.review_path); pathcheck(a.profile_path)
 if a.profile_path==a.review_path or a.profile_path==RC+'parent-private-npm-current-profile-inputs-v1.json' or a.review_path==profile['review']['path']: fail('successor paths must be distinct from existing paths')
 if len(review_raw)>CAP: fail('review exceeds cap')
 profile['review']={'path':a.review_path,'sha256':digest(review_raw),'bytes':len(review_raw)}
 profile_raw=(json.dumps(profile,indent=2)+'\n').encode()
 if len(profile_raw)>CAP: fail('profile exceeds cap')
 out.mkdir(parents=True,exist_ok=False)
 (out/'review.json').write_bytes(review_raw); (out/'profile.json').write_bytes(profile_raw)
 result={'status':'candidate only; no semantic or security clearance','commit':a.commit,'profile_target':a.profile_path,'profile_sha256':digest(profile_raw),'review_target':a.review_path,'review_sha256':digest(review_raw),'counts':{'source':len(primary),'support':len(support),'inputs':len(inputs)},'reviewed_source_checkpoint':source,'checker_changes_required':['Independently review checker proposal and then pin the exact schema 2 profile target and SHA256.']}
 (out/'report.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser(); p.add_argument('--root',required=True); p.add_argument('--commit',required=True); p.add_argument('--out',required=True); p.add_argument('--semantic-index',required=True); p.add_argument('--profile-path',required=True); p.add_argument('--review-path',required=True)
 try: run(p.parse_args())
 except Exception as e: print('ERROR: '+str(e),file=sys.stderr); sys.exit(1)
