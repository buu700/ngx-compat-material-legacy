import tempfile, pathlib, subprocess, json, hashlib, os
G='/tmp/root-main-profile-semantic-generator.py'
def cmd(*a,cwd=None): return subprocess.run(a,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
def put(r,p,data):
 x=r/p; x.parent.mkdir(parents=True,exist_ok=True); x.write_text(data if isinstance(data,str) else json.dumps(data))
def h(b): return hashlib.sha256(b).hexdigest()
with tempfile.TemporaryDirectory(prefix='profile-gen-test-') as t:
 root=pathlib.Path(t)/'repo';root.mkdir();rc='compatibility/rc/'
 cmd('git','init','-q',cwd=root);cmd('git','config','user.name','fixture',cwd=root);cmd('git','config','user.email','fixture@example.invalid',cwd=root)
 for p in ['scripts/a.js','.github/workflows/a.yml','tests/a.py','compatibility/handoff/codex-closeout/tools/a.py','.npmrc','chainman.toml','chainman.lock','justfile','package.json','projects/ngx-material-legacy/package.json','pnpm-lock.yaml','toolchain-lock.json','.node-version','.npm-version','SECURITY.md','old-input.json','semantic.json','support-extra.json']:
  put(root,p, 'import "../support-extra.json"\n' if p=='scripts/a.js' else '{}\n')
 oldbranch={'source_parent':'1'*40,'source_files':[{}]}; evidence={'roots':{'main':{'source_hashes':{'old-input.json':'2'*64}}}}
 review={'schema_version':1,'scope':'maintained-tool-owned-npm-invocations','lines':{'21.x':{'sentinel':'preserve'},'main':{}},'semantic_review_refs':[]}
 put(root,rc+'old-review.json',review); b=(root/(rc+'old-review.json')).read_bytes()
 profile={'schema_version':1,'scope':'maintained-tool-owned-npm-invocations','historical_artifacts':{'sentinel':'preserve'},'lines':{'21.x':{'sentinel':'preserve'},'main':{'support_files':[],'input_files':[]}},'review':{'path':rc+'old-review.json','sha256':h(b),'bytes':len(b)},'provenance_limits':['preserve']}
 put(root,rc+'parent-private-npm-current-profile-inputs-v1.json',profile)
 put(root,rc+'tool-advisory-triage/private-profile-source-manifests.json',{'lines':{'main':oldbranch}})
 put(root,rc+'tool-advisory-triage/private-profile-remaining-evidence.json',evidence)
 put(root,rc+'tool-advisory-triage/brace-profile-validation/manifest.json',{'lines':{'main':{'source_inputs':[{'path':'old-input.json'}]}}})
 cmd('git','add','.',cwd=root);assert cmd('git','commit','-qm','fixture',cwd=root).returncode==0
 checkpoint=cmd('git','rev-parse','HEAD',cwd=root).stdout.strip()
 def row(n):
  b=(root/n).read_bytes(); return {'path':n,'sha256':h(b),'bytes':len(b),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
 def roster(names): return h(json.dumps([row(n) for n in sorted(names)],sort_keys=True,separators=(',',':')).encode())
 primary=['.npmrc','chainman.toml','chainman.lock','justfile','package.json','projects/ngx-material-legacy/package.json','pnpm-lock.yaml','scripts/a.js','.github/workflows/a.yml']
 support=['tests/a.py','compatibility/handoff/codex-closeout/tools/a.py','support-extra.json']
 inputs=['old-input.json','toolchain-lock.json','.node-version','.npm-version','SECURITY.md']
 contextname=rc+'context-review.txt';put(root,contextname,'contextual authored evidence');contextbytes=(root/contextname).read_bytes();contextref={'path':contextname,'sha256':h(contextbytes),'bytes':len(contextbytes)}
 authored={'evidence_refs':[contextref],'schema_version':1,'role':'current-source-semantic-review','line':'main','source_parent':checkpoint,'preconditions':'unchanged-maintained-tool-owned-npm','source_files_sha256':roster(primary),'support_files_sha256':roster(support),'input_files_sha256':roster(inputs)}
 name=rc+'semantic-review.json';put(root,name,authored); b=(root/name).read_bytes();ref={'path':name,'sha256':h(b),'bytes':len(b)}
 index=pathlib.Path(t)/'index.json';index.write_text(json.dumps({'schema_version':2,'semantic_review_refs':[ref,contextref],'current_source_reviews':{'main':ref}}))
 cmd('git','add',name,contextname,cwd=root);assert cmd('git','commit','-qm','review',cwd=root).returncode==0
 head=cmd('git','rev-parse','HEAD',cwd=root).stdout.strip()
 def run(out,commit=head): return cmd('python3',G,'--root',str(root),'--commit',commit,'--out',str(pathlib.Path(t)/out),'--semantic-index',str(index),'--profile-path',rc+'next-profile.json','--review-path',rc+'next-review.json')
 x=run('bad-head','0'*40); assert x.returncode and 'HEAD differs' in x.stderr,x.stderr
 (root/'scripts/a.js').write_text('dirty\n');x=run('dirty');assert x.returncode and 'dirty' in x.stderr,x.stderr
 cmd('git','restore','scripts/a.js',cwd=root)
 put(root,'tests/new.py','x\n');x=run('untracked');assert x.returncode and 'untracked' in x.stderr,x.stderr;(root/'tests/new.py').unlink()
 x=run('valid');assert not x.returncode,x.stderr
 out=pathlib.Path(t)/'valid';p=json.loads((out/'profile.json').read_text()); r=json.loads((out/'review.json').read_text())
 assert p['schema_version']==2 and r['current_source_reviews']['main']==ref
 assert p['lines']['21.x']==profile['lines']['21.x'] and r['lines']['21.x']==review['lines']['21.x'] and p['historical_artifacts']==profile['historical_artifacts']
 assert 'support-extra.json' in [z['path'] for z in p['lines']['main']['support_files']]
 assert p['lines']['main']['historical_source_hashes']['old-input.json']['historical_sha256']=='2'*64
 assert run('valid').returncode
 put(root,'scripts/a.js','changed after review\n');cmd('git','add','scripts/a.js',cwd=root);cmd('git','commit','-qm','changed source',cwd=root); changed=cmd('git','rev-parse','HEAD',cwd=root).stdout.strip()
 x=run('changed-source',changed);assert x.returncode and ('projection mismatch' in x.stderr or 'projection changed' in x.stderr or 'executable changes' in x.stderr),x.stderr
 print('PASS wrong HEAD, tracked dirty, untracked discovery membership, recursive relative reference, other-line and historical preservation, fresh output')
