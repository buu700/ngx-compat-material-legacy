from pathlib import Path
import copy,hashlib,json,sys,tarfile
line=sys.argv[1];root=Path('/home/parallels/.codex/worktrees/source-profile-v11-'+line+'/ngx-compat-material-legacy');base=Path('/tmp/fresh-sass-sol6-report-v1')
sys.path.insert(0,str(root/'scripts'))
from sass_ordered_aggregate_admission import ordered_aggregate_assertion_ok
from sass_private_card_gate import PrivateCardGateContext,private_card_gate_match
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((base/'manifest.json').read_bytes());assert sha((base/'manifest.json').read_bytes())=='105127176febaa48b0e41b5a1ea5e598be861c4b281a9f0efb63cc7b72865b74'
data=m['lines'][line]
for path,row in data['files'].items():
 raw=(base/line/path).read_bytes();assert (sha(raw),len(raw))==(row['sha256'],row['bytes'])
tarball=Path(data['tarball']);assert sha(tarball.read_bytes())==data['tarball_sha256']
ordered=json.loads((base/line/'python-06-body.json').read_bytes())['body'];card=json.loads((base/line/'python-private-card-body.json').read_bytes())['body']
for measurement in [ordered['actual_measurement'],card['actual']]:
 assert sha(measurement['css'].encode())==measurement['css_sha256'] and len(measurement['css'].encode())==measurement['css_bytes']
 owned=[row for row in measurement['sources'] if row['root']==0];assert len(owned)==len({r['path'] for r in owned})==286
 with tarfile.open(tarball,'r:gz') as archive:
  for ref in owned:
   raw=archive.extractfile('package/'+ref['path']).read();assert (sha(raw),len(raw))==(ref['sha256'],ref['bytes'])
   assert raw==(root/'projects/ngx-material-legacy'/ref['path']).read_bytes()
assert ordered_aggregate_assertion_ok(ordered)
bad=copy.deepcopy(ordered);a=bad['actual_measurement'];a['css']+='\n.unrelated { color: red; }\n';a['css_sha256']=sha(a['css'].encode());a['css_bytes']=len(a['css'].encode());bad['candidate_sha256']=a['css_sha256'];assert not ordered_aggregate_assertion_ok(bad)
bad=copy.deepcopy(ordered);bad['actual_measurement']['sources'][0]['sha256']='0'*64;assert not ordered_aggregate_assertion_ok(bad)
ctx=PrivateCardGateContext(root);assert private_card_gate_match(ctx,card)
bad=copy.deepcopy(card);a=bad['actual'];a['css']+='\n.unrelated { color: red; }\n';a['css_sha256']=sha(a['css'].encode());a['css_bytes']=len(a['css'].encode());assert not private_card_gate_match(ctx,bad)
bad=copy.deepcopy(card);bad['actual']['sources'][0]['sha256']='0'*64;assert not private_card_gate_match(ctx,bad)
print(json.dumps(dict(line=line,tarball_sha256=data['tarball_sha256'],owned_tar_and_current_matches=572,ordered_assertion='pass',private_card_match='pass',fully_rehashed_css_and_source_forgery_controls='rejected',scope='actual current Python comparison routes over fresh packed measurements; no coordinator envelope or seal')))
