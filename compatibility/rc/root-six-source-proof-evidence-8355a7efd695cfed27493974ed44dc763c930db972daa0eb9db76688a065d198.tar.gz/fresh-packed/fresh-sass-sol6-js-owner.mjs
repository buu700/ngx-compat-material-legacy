import {readFileSync} from 'node:fs';
const line=process.argv[2],root='/tmp/fresh-sass-sol6-'+line+'-v1',source=root+'/source';
const {ORDERED_AGGREGATE_CASES,orderedAggregateResultMatches}=await import('file://'+source+'/scripts/sass-ordered-aggregate-contract.mjs');
const record=JSON.parse(readFileSync(root+'/compile/compile-report.json')).fixtures[0],entry=ORDERED_AGGREGATE_CASES['06-aggregate-and-companions'];
const row={status:'blocked',baseline_sha256:entry.reference_sha256,candidate_sha256:record.actual_measurement.css_sha256};
const ok=orderedAggregateResultMatches(row,record);
const wrong={...record,actual_measurement:{...record.actual_measurement,css:record.actual_measurement.css+'\n.forged { color: red; }\n'}};
const sourceWrong=structuredClone(record);sourceWrong.actual_measurement.sources[0].sha256='0'.repeat(64);
console.log(JSON.stringify({line,accepted:ok,forged_css_rejected:!orderedAggregateResultMatches(row,wrong),forged_source_rejected:!orderedAggregateResultMatches(row,sourceWrong),baseline:entry.reference_sha256,candidate:record.actual_measurement.css_sha256}));
