import hashlib,json,shutil,tarfile
from pathlib import Path

out=Path('/tmp/fresh-sass-sol6-report-v1')
out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
rows={}
for line in ('21','main'):
    base=Path('/tmp/fresh-sass-sol6-'+line+'-v1')
    dest=out/line;dest.mkdir(exist_ok=True)
    setup=json.loads((base/'setup.json').read_bytes())
    report=json.loads((base/'compile/compile-report.json').read_bytes())
    record=report['fixtures'][0]
    actual=record['actual_measurement']
    private=json.loads((base/'private-card-actual.json').read_bytes())
    py06=json.loads((base/'python-06-body.json').read_bytes())
    pycard=json.loads((base/'python-private-card-body.json').read_bytes())
    assert len(report['fixtures'])==1 and not report['failures']
    assert actual['css_sha256']==sha(actual['css'].encode())
    assert actual['css_bytes']==len(actual['css'].encode())
    assert py06['result']['accepted'] and py06['result']['forged_css_rejected'] and py06['result']['forged_source_rejected'] and py06['result']['prior_css_rejected']
    assert pycard['result']['accepted'] and pycard['result']['forged_css_rejected'] and pycard['result']['forged_source_rejected']
    assert private['result']['matched'] and private['result']['forged_css_rejected'] and private['result']['forged_source_rejected']
    archive=Path(setup['artifact']);assert sha(archive.read_bytes())==setup['artifact_sha256']
    members={}
    with tarfile.open(archive,'r:gz') as tf:
        for ref in actual['sources']:
            if ref['root']!=0:continue
            raw=tf.extractfile('package/'+ref['path']).read()
            assert sha(raw)==ref['sha256'] and len(raw)==ref['bytes']
            extracted=(base/'env/node_modules/@ngx-compat/material-legacy'/ref['path']).read_bytes()
            assert raw==extracted
            members[ref['path']]=ref['sha256']
    assert len(members)==286
    copies={
        'setup.json':base/'setup.json',
        'compile-report.json':base/'compile/compile-report.json',
        'compiled-ordered.css':base/'compile/06-aggregate-and-companions.css',
        'expected-ordered.css':base/'expected-ordered.css',
        'private-card-actual.json':base/'private-card-actual.json',
        'python-06-body.json':base/'python-06-body.json',
        'python-private-card-body.json':base/'python-private-card-body.json',
        'fixture.scss':base/'fixtures/06-aggregate-and-companions.scss',
        'fixture-manifest.json':base/'fixtures/manifest.json',
        'density-proof-inputs.json':base/'source/fixtures/sass/ordinary-density-proof-inputs.json',
        'expected-isolation-inputs.json':base/'source/fixtures/sass/expected-isolation-inputs.json',
    }
    files={}
    for name,path in copies.items():
        raw=path.read_bytes();(dest/name).write_bytes(raw)
        files[name]={'sha256':sha(raw),'bytes':len(raw)}
    assert files['compiled-ordered.css']['sha256']==actual['css_sha256']==files['expected-ordered.css']['sha256']
    rows[line]={
        'source_profile':setup['profile'],
        'tarball':setup['artifact'],'tarball_sha256':setup['artifact_sha256'],'tarball_bytes':setup['artifact_bytes'],
        'ordered_css_sha256':actual['css_sha256'],'ordered_css_bytes':actual['css_bytes'],
        'ordered_loaded_sources':len(actual['sources']),'ordered_owned_sources':len(members),
        'private_card_css_sha256':private['actual']['css_sha256'],'private_card_css_bytes':private['actual']['css_bytes'],
        'private_card_loaded_sources':len(private['actual']['sources']),
        'python_06':py06['result'],'python_private_card':pycard['result'],
        'js_06':{'accepted':True,'forged_css_rejected':True,'forged_source_rejected':True},
        'js_private_card':{k:private['result'][k] for k in ('matched','forged_css_rejected','forged_source_rejected')},
        'owned_tar_members_equal_extracted_and_measurement':True,
        'files':files,
    }
for name in ('fresh-sass-sol6-verify.mjs','fresh-sass-sol6-isolation.mjs','fresh-sass-sol6-js-owner.mjs','fresh-sass-sol6-private-card.mjs','fresh-sass-sol6-python-owner.py','fresh-sass-sol6-python-private-card.py','fresh-sass-sol6-freeze.py'):
    raw=(Path('/tmp')/name).read_bytes();(out/name).write_bytes(raw)
manifest={'schema_version':1,'scope':'fresh artifact 06 and private-card diagnostics only; no full seal or coordinator claim','lines':rows,'scripts':{p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in out.iterdir() if p.is_file()}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'packet':str(out/'manifest.json'),'sha256':sha((out/'manifest.json').read_bytes()),'lines':{k:{'ordered':v['ordered_css_sha256'],'private_card':v['private_card_css_sha256']} for k,v in rows.items()}}))
