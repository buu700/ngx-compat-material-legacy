import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
const line=process.argv[2],root='/tmp/fresh-sass-sol6-'+line+'-v1',source=root+'/source';
const {createCurrentSpinnerSnackContract}=await import('file://'+source+'/scripts/current-sass-spinner-snack-contract.mjs');
const x=createCurrentSpinnerSnackContract({root:source});assert.equal(x.line,line==='21'?'21.x':'main');
const r=JSON.parse(readFileSync(root+'/compile/compile-report.json')).fixtures[0],measured=r.actual_measurement,expected=Object.values(x.source_sets)[0];
assert.deepEqual(measured.sources,expected);
const h=b=>createHash('sha256').update(b).digest('hex');let owned=0;
for(const ref of measured.sources.filter(s=>s.root===0)){const raw=readFileSync(join(root,'env/node_modules/@ngx-compat/material-legacy',ref.path));assert.equal(h(raw),ref.sha256);assert.equal(raw.length,ref.bytes);owned++;}
assert.equal(owned,286);x.assertCurrent();console.log(JSON.stringify({line,owned,loaded:measured.sources.length,expected_source_set_equal:true,css_sha256:measured.css_sha256,css_bytes:measured.css_bytes}));
