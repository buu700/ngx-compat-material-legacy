import copy,json,sys
from pathlib import Path
line=sys.argv[1]
base=Path('/tmp/fresh-sass-sol6-'+line+'-v1')
root=base/'source'
sys.path.insert(0,str(root/'scripts'))
from sass_private_card_gate import PrivateCardGateContext,private_card_gate_match
data=json.loads((base/'private-card-actual.json').read_bytes())
ctx=PrivateCardGateContext(root)
body={'case_id':'mixin-css/private-check-duplicate-theme-styles','line':'21.x' if line=='21' else 'main','expected':data['original']['expected'],'actual':data['actual'],'identity':data['original']['identity'],'current_private_card':data['result']['descriptor']}
ok=private_card_gate_match(ctx,body)
bad=copy.deepcopy(body);bad['actual']['css']+='\n.forged { color: red; }\n';import hashlib;bad['actual']['css_sha256']=hashlib.sha256(bad['actual']['css'].encode()).hexdigest();bad['actual']['css_bytes']=len(bad['actual']['css'].encode())
source_bad=copy.deepcopy(body);source_bad['actual']['sources'][0]['sha256']='0'*64
result={'line':body['line'],'accepted':ok,'forged_css_rejected':not private_card_gate_match(ctx,bad),'forged_source_rejected':not private_card_gate_match(ctx,source_bad),'css_sha256':body['actual']['css_sha256']}
(base/'python-private-card-body.json').write_text(json.dumps({'body':body,'result':result},indent=2)+'\n')
print(json.dumps(result))
