import copy,hashlib,json,os,sys
from pathlib import Path

line=sys.argv[1]
base=Path('/tmp/fresh-sass-sol6-'+line+'-v1')
root=base/'source'
sys.path.insert(0,str(root/'scripts'))
sys.path.insert(0,str(root/'tests'))
from sass_ordered_aggregate_admission import ordered_aggregate_assertion_ok
from sass_ordered_aggregate_fixture import ordered_aggregate_receipt

source_line='21.x' if line=='21' else 'main'
class Active:
    manifest={'run_id':'fresh-sol6-'+line,'artifacts':[{'id':'library','sha256':'0'*64}]}
    binding={'source_line':source_line}
body=ordered_aggregate_receipt(Active(),'06-aggregate-and-companions','fresh')
fresh=json.loads((base/'compile/compile-report.json').read_bytes())['fixtures'][0]
body['actual_measurement']=fresh['actual_measurement']
body['current_companion']=fresh['current_companion']
body['candidate_sha256']=fresh['actual_measurement']['css_sha256']
ok=ordered_aggregate_assertion_ok(body)
bad=copy.deepcopy(body);bad['actual_measurement']['css']+='\n.forged { color: red; }\n';bad['actual_measurement']['css_sha256']=hashlib.sha256(bad['actual_measurement']['css'].encode()).hexdigest();bad['actual_measurement']['css_bytes']=len(bad['actual_measurement']['css'].encode());bad['candidate_sha256']=bad['actual_measurement']['css_sha256']
source_bad=copy.deepcopy(body);source_bad['actual_measurement']['sources'][0]['sha256']='0'*64
prior=ordered_aggregate_receipt(Active(),'06-aggregate-and-companions','prior')
result={'line':source_line,'accepted':ok,'forged_css_rejected':not ordered_aggregate_assertion_ok(bad),'forged_source_rejected':not ordered_aggregate_assertion_ok(source_bad),'prior_css_rejected':not ordered_aggregate_assertion_ok(prior),'prior_css_sha256':prior['actual_measurement']['css_sha256'],'fresh_css_sha256':body['actual_measurement']['css_sha256']}
(base/'python-06-body.json').write_text(json.dumps({'body':body,'result':result},indent=2)+'\n')
print(json.dumps(result))
