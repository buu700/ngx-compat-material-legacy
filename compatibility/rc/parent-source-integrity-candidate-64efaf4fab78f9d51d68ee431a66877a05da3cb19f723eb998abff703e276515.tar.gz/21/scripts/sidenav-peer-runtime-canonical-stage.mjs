/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 * Use of this source code is governed by the MIT license in LICENSE.
 */
/** Draft finite 10-row metadata stage; source subject must separately qualify. */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {replaceHistoricalConsumerEntries} from './historical-consumer-wrapper-metadata.mjs';
import admission from './upstream-sidenav-peer-runtime-admission.cjs';
const hash=raw=>createHash('sha256').update(raw).digest('hex');
const LEDGER_BEFORE='e9ef5c0bf543977809134c3367cf9a33bdda62233ab6b944dc3c4e4ac101585e';
const REGISTRY_BEFORE='be50b37d181b43960361860dd7cb3bb24d0f2d1b0a2ecfaa5a85a791e4869399';
const ADMISSION_HASH='1a618b21b3609dd0d71232989355d2ed605b144f10a9a2fe0135425142886a37';
const admissionPath=fileURLToPath(new URL('./upstream-sidenav-peer-runtime-admission.cjs',import.meta.url));
const authenticated={inspectWholeBody:admission.inspectWholeBody,metadataOk:admission.metadataOk,sidenavPeerRuntimeProof:admission.sidenavPeerRuntimeProof};
function assertAdmissionIdentity(){
 const raw=readFileSync(admissionPath);assert.equal(hash(raw),ADMISSION_HASH,'changed admission helper');const text=raw.toString();
 for(const [name,fn] of Object.entries(authenticated)){assert.equal(admission[name],fn,'changed admission function');const start=text.indexOf('function '+name+'('),end=text.indexOf('\nfunction ',start+1);assert.ok(start>=0&&end>start);assert.equal(Function.prototype.toString.call(fn),text.slice(start,end));}
}
const open=row=>['needs-individual-review','security-review'].includes(row.final_disposition);
export function sidenavPeerRuntimeRegistrySuccessor(before,body){
 assert.equal(hash(before),REGISTRY_BEFORE);assert.equal(hash(JSON.stringify(body,null,2)+'\n'),'27f4080ea7396546a27aa5b469aab4733ba496e852a949de20cb005f64ba2364');
 const text=before.toString(),marker='];\n';assert.equal(text.split(marker).length,2);
 const add=body.reviews.map(row=>`  {sha:'${row.sha}',proof_kind:'sidenav-peer-runtime-source-only',\n    scope_key:'sidenav_peer_runtime_source_scope',module:'upstream-sidenav-peer-runtime-admission.cjs'},\n`).join('');
 return Buffer.from(text.replace(marker,add+marker));
}
export function applySidenavPeerRuntimeCanonicalStage({before,body}={}){
 assert.equal(hash(before),LEDGER_BEFORE);assert.equal(hash(JSON.stringify(body,null,2)+'\n'),'27f4080ea7396546a27aa5b469aab4733ba496e852a949de20cb005f64ba2364');
 const data=JSON.parse(before),expected=structuredClone(data),ids=new Set(body.reviews.map(r=>r.sha));assert.equal(ids.size,10);assert.equal(data.entries.length,1697);assert.equal(new Set(data.entries.map(r=>r.sha)).size,1697);assert.equal(data.open_or_deferred,data.entries.filter(open).length);assert.equal(data.closed_dispositions,data.entries.length-data.open_or_deferred);
 const entries=body.reviews.map(row=>{const i=data.entries.findIndex(r=>r.sha===row.sha);assert.ok(i>=0);const prior=data.entries[i];assert.equal(prior.final_disposition,'needs-individual-review');assert.equal(prior.evidence_report,null);const entry={...prior,files:row.paths,final_disposition:'do-not-adopt',reason:row.decision,review_depth:'individual-compatibility',evidence_report:'compatibility/rc/c04-sidenav-peer-runtime-individual-review.json',individual_proof:admission.sidenavPeerRuntimeProof(row)};assert.equal(admission.metadataOk({entry,body,review:row,proof:entry.individual_proof}),true);expected.entries[i]=entry;return entry;});
 expected.open_or_deferred=expected.entries.filter(open).length;expected.closed_dispositions=expected.entries.length-expected.open_or_deferred;
 const text=replaceHistoricalConsumerEntries(before,entries.map(entry=>({sha:entry.sha,after_entry:entry}))).toString(),split=text.indexOf('"entries": [');assert.ok(split>=0);let header=text.slice(0,split);
 for(const key of ['closed_dispositions','open_or_deferred']){const old=`  "${key}": ${data[key]},`,replacement=`  "${key}": ${expected[key]},`;assert.equal(header.split(old).length,2);header=header.replace(old,replacement);}
 const after=Buffer.from(header+text.slice(split));assert.deepEqual(JSON.parse(after),expected);assert.deepEqual(expected.entries.filter(r=>!ids.has(r.sha)),data.entries.filter(r=>!ids.has(r.sha)));assert.deepEqual(expected.entries.filter(r=>r.final_disposition==='security-review'),data.entries.filter(r=>r.final_disposition==='security-review'));assert.equal(expected.entries.filter(r=>r.final_disposition==='security-review').length,1);
 return {before,after,entries,individual_decisions:entries.length,unselected_entries_preserved:data.entries.length-entries.length};
}

/** Source-qualified proposal only. This never writes a registry or ledger. */
export function qualifySidenavPeerRuntimeCanonicalStage({before,body,root,read}={}) {
 assertAdmissionIdentity();
 const inspect=authenticated.inspectWholeBody;
 const snapshot=Buffer.from(before),bodyText=JSON.stringify(body,null,2)+'\n';
 const subject=inspect({body,root,read});
 const result=applySidenavPeerRuntimeCanonicalStage({before:snapshot,body});
 subject.assertCurrent();assertAdmissionIdentity();
 assert.ok(Buffer.isBuffer(before)&&before.equals(snapshot),'ledger input changed');
 assert.equal(JSON.stringify(body,null,2)+'\n',bodyText,'review input changed');
 return {...result,source_scope_only:true,g11_claim:'not-passed'};
}
