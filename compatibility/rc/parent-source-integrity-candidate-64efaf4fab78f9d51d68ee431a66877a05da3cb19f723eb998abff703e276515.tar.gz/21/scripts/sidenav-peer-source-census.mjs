/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 * Use of this source code is governed by the MIT license in LICENSE.
 */
/** An exact current-product census only; callers must also use the authored roster owner. */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {candidateProductSourcePaths} from './upstream-candidate-source-evidence.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
const CENSUS='compatibility/rc/c04-sidenav-source-evidence/source-census.json';
const PIN='1ea6468c0947ba96282f1d51fa1ce5bc4c155550aca9af21784e790641437bec';
export function sidenavPeerSourceCensus({root,read=path=>readFileSync(join(root,path))}) {
 root=resolve(root);assert.equal(typeof read,'function');const refs=[];
 const member=(path,expected)=>{const physical=readFileSync(join(root,path)),supplied=read(path);assert.ok(Buffer.isBuffer(supplied)&&physical.equals(supplied),'nonphysical '+path);assert.ok(physical.equals(readFileSync(join(root,path))),'changed during callback '+path);const ref={path,sha256:hash(physical),bytes:physical.length};assert.equal(ref.sha256,expected.sha256,path);if(expected.bytes!==undefined)assert.equal(ref.bytes,expected.bytes,path);refs.push(ref);return physical;};
 const census=JSON.parse(member(CENSUS,{sha256:PIN}));assert.equal(census.line,'21.x');assert.equal(census.source_scope_only,true);const version=JSON.parse(readFileSync(join(root,'projects/ngx-material-legacy/package.json'))).version;assert.ok(version.startsWith('21.'));
 const successor=JSON.parse(member('compatibility/rc/c04-sidenav-source-evidence/census-finite-successor-v2.json',{sha256:'c2e814cf63e497a5ed6e1a1689c07c1213f0be3a90a13d7df2de732b5bf6ca25'}));
 const receipt=JSON.parse(member('compatibility/rc/c04-sidenav-source-evidence/dialog-menu-commits-v1.json',{sha256:'378e6e741e8709ee149e45386ebc071e0f166aa4efda6653cacf06a1fb9d3f11'}));
 const changes=successor.changes;assert.equal(Object.keys(changes).length,4);const after=Object.assign({},...Object.values(receipt.commits).map(c=>c['21'].source_after));assert.deepEqual(Object.keys(changes).sort(),Object.keys(after).sort());
 for(const [path,pair] of Object.entries(changes)){const i=census.files.findIndex(r=>r.path===path);assert.ok(i>=0);assert.deepEqual(census.files[i],pair.before);assert.deepEqual(pair.after,{path,...after[path]});census.files[i]=pair.after;}
 const focusSource=JSON.parse(member('compatibility/rc/parent-dialog-focus-finite-source-successor-v5.json',{sha256:'74890ca9a672ac9ce3114087447c7117eea0502bfac1a96d54b1ac4e327caa51'}));
 const focusRoster=JSON.parse(member('compatibility/rc/parent-dialog-focus-authored-use-successor-v5.json',{sha256:'9c967f9246bf68cc5e599e6a4fc12c3d8cce40018fe426f1d8db53127f01d956'}));
 assert.equal(focusSource.role,'finite-dialog-focus-current-source-successor');assert.equal(focusSource.source_scope_only,true);assert.equal(focusSource.g11_claim,'not-passed');
 assert.equal(focusRoster.role,'finite-dialog-focus-authored-use-successor');assert.equal(focusRoster.source_scope_only,true);assert.equal(focusRoster.g11_claim,'not-passed');
 const focus=focusSource.branches['21.x'].transitions,delta=focusRoster.branches['21.x'];
 assert.deepEqual(focus.map(r=>r.path),['projects/ngx-material-legacy/legacy-dialog/internal/dialog-container-base.ts','projects/ngx-material-legacy/legacy-dialog/dialog-container.ts']);
 assert.equal(delta.source_files,532);assert.equal(delta.previous_uses,1966);assert.equal(delta.current_uses,1970);assert.equal(delta.changed_uses.length,45);assert.equal(delta.added_uses.length,4);assert.deepEqual(delta.removed_uses,[]);
 const env={...process.env,GIT_NO_LAZY_FETCH:'1',GIT_NO_REPLACE_OBJECTS:'1',GIT_TERMINAL_PROMPT:'0'};for(const name of Object.keys(env))if(name.startsWith('GIT_')&&!['GIT_NO_LAZY_FETCH','GIT_NO_REPLACE_OBJECTS','GIT_TERMINAL_PROMPT'].includes(name))delete env[name];
 for(const row of focus){const i=census.files.findIndex(r=>r.path===row.path);assert.ok(i>=0);assert.deepEqual(census.files[i],{path:row.path,sha256:row.before.sha256,bytes:row.before.bytes});
  for(const [commit,ref] of [[row.source_parent,row.before],[row.source_commit,row.after]]){assert.match(commit,/^[0-9a-f]{40}$/);const raw=execFileSync('git',['--no-replace-objects','-c','gc.auto=0','-c','maintenance.auto=0','show',commit+':'+row.path],{cwd:root,env,maxBuffer:2*1024*1024});assert.equal(hash(raw),ref.sha256);assert.equal(raw.length,ref.bytes);assert.equal(createHash('sha1').update('blob '+raw.length+'\0').update(raw).digest('hex'),ref.git_blob);}
  census.files[i]={path:row.path,sha256:row.after.sha256,bytes:row.after.bytes};}
 const stepper=JSON.parse(member('compatibility/rc/current-sass-stepper-sixth-source-inputs-v1.json',{sha256:'1d566395c25e3569cee1031526ec05508e40cb866d7d5fda008cb6a325a9caec'}));
 assert.equal(stepper.role,'finite-sixth-Stepper-M2-bridge-current-source-successor');assert.equal(stepper.source_scope_only,true);assert.equal(stepper.css_or_artifact_admission_granted,false);
 const bridge='projects/ngx-material-legacy/styles/bridges/_companion-overrides.scss',branch=stepper.branches['21.x'],i=census.files.findIndex(r=>r.path===bridge);assert.equal(stepper.sixth_module_path,bridge);assert.ok(i>=0);
 assert.deepEqual(census.files[i],{path:bridge,sha256:branch.before_git.sha256,bytes:branch.before_git.bytes});assert.match(branch.source_parent,/^[0-9a-f]{40}$/);
 const original=execFileSync('git',['--no-replace-objects','-c','gc.auto=0','-c','maintenance.auto=0','show',branch.source_parent+':'+bridge],{cwd:root,env,maxBuffer:2*1024*1024});assert.equal(hash(original),branch.before_git.sha256);assert.equal(original.length,branch.before_git.bytes);assert.equal(createHash('sha1').update('blob '+original.length+'\0').update(original).digest('hex'),branch.before_git.git_blob);
 let cursor=0;const pieces=[];for(const edit of branch.literal_edits){assert.ok(Number.isSafeInteger(edit.offset)&&edit.offset>=cursor);const old=Buffer.from(edit.before);assert.ok(original.subarray(edit.offset,edit.offset+old.length).equals(old));pieces.push(original.subarray(cursor,edit.offset),Buffer.from(edit.after));cursor=edit.offset+old.length;}pieces.push(original.subarray(cursor));const current=Buffer.concat(pieces);assert.equal(hash(current),branch.reviewed_after.sha256);assert.equal(current.length,branch.reviewed_after.bytes);assert.equal(createHash('sha1').update('blob '+current.length+'\0').update(current).digest('hex'),branch.reviewed_after.git_blob);
 census.files[i]={path:bridge,sha256:branch.reviewed_after.sha256,bytes:branch.reviewed_after.bytes};
 const paths=candidateProductSourcePaths(root);assert.deepEqual(paths,census.files.map(r=>r.path));
 for(const ref of census.files){const raw=member(ref.path,ref);if(/\.(ts|html)$/.test(ref.path))assert.doesNotMatch(raw.toString(),/MatDrawer|MatSidenav|mat-sidenav|mat-drawer|@angular\/material\/sidenav|_drawerToggled|_isShowingBackdrop/i,'new owned sidenav runtime use '+ref.path);}
 const assertCurrent=()=>{assert.deepEqual(candidateProductSourcePaths(root),paths);for(const ref of refs){const raw=readFileSync(join(root,ref.path));assert.equal(hash(raw),ref.sha256,'changed physical source '+ref.path);assert.equal(raw.length,ref.bytes);}};
 assertCurrent();return {bound:refs,assertCurrent};
}
