/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 * Copyright (c) 2026 Ryan Lester.
 * Use of this source code is governed by the MIT license in LICENSE.
 */
/** Source-only proposal probe. Mutations require an explicit isolated scratch root. */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {readFileSync, writeFileSync, unlinkSync} from 'node:fs';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';

const root = resolve(process.argv[2] ?? process.cwd());
const mutate = process.argv.includes('--mutations');
if (mutate) assert.match(root, /\/\.codex\/worktrees\/c04-sidenav-[^/]+\/ngx-compat-material-legacy$/, 'mutations require an isolated C04 scratch checkout');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const read = path => readFileSync(join(root, path));
const reviewPath = 'compatibility/rc/c04-sidenav-peer-runtime-individual-review.json';
const evidencePath = 'compatibility/rc/c04-sidenav-source-evidence/';
const body = JSON.parse(read(reviewPath));
const {qualifySidenavPeerRuntimeCanonicalStage: qualify} = await import(pathToFileURL(join(root, 'scripts/sidenav-peer-runtime-canonical-stage.mjs')));
const {sidenavPeerSourceCensus} = await import(pathToFileURL(join(root, 'scripts/sidenav-peer-source-census.mjs')));
const admissionPath = join(root, 'scripts/upstream-sidenav-peer-runtime-admission.cjs');
const admission = createRequire(import.meta.url)(admissionPath);
const before = read('compatibility/f10/disposition-ledger/ledger.json');

assert.equal(hash(read(reviewPath)), '27f4080ea7396546a27aa5b469aab4733ba496e852a949de20cb005f64ba2364');
assert.equal(body.reviews.length, 10);
assert.equal(body.reviews.reduce((n, row) => n + row.paths.length, 0), 23);
const index = JSON.parse(read(evidencePath + 'packet-index-v1.json'));
const independent = JSON.parse(read(evidencePath + 'c04-sidenav-002-independent-second-review-v1.json'));
const inventory = JSON.parse(read(evidencePath + 'verified-inventory.json'));
assert.equal(hash(read(evidencePath + 'packet-index-v1.json')), body.author_index_sha256);
assert.equal(hash(read(evidencePath + 'c04-sidenav-002-independent-second-review-v1.json')), body.independent_review_sha256);
for (const [i, row] of body.reviews.entries()) {
  assert.equal(row.sha, inventory[i].sha);
  assert.equal(row.sha, independent.rows[i].sha);
  assert.deepEqual(row.paths, inventory[i].paths);
  assert.deepEqual(row.paths, independent.rows[i].paths);
  assert.equal(row.decision, independent.rows[i].judgment);
  assert.equal(row.diff_sha256, inventory[i].diff_sha256);
  assert.equal(row.diff_sha256, independent.rows[i].original_full_diff_sha256);
  const file = index.files.find(item => item.file === row.sha + '.diff');
  assert.equal(file.sha256, row.diff_sha256);
  assert.equal(hash(read(evidencePath + file.file)), row.diff_sha256);
  for (const key of ['files', 'reason', 'sha']) {
    const proof = admission.sidenavPeerRuntimeProof(row);
    const entry = {sha: row.sha, files: row.paths, final_disposition: 'do-not-adopt', reason: row.decision,
      review_depth: 'individual-compatibility', affected_branches: ['21.x'], evidence_report: reviewPath,
      g11_claim: 'not-passed', individual_proof: proof};
    assert.equal(admission.metadataOk({entry, body, review: row, proof}), true);
    const wrong = structuredClone(entry);
    wrong[key] = key === 'files' ? [] : 'tampered';
    assert.equal(admission.metadataOk({entry: wrong, body, review: row, proof}), false);
  }
}
const invoke = readCallback => qualify({before, body, root, ...(readCallback ? {read: readCallback} : {})});
const result = invoke();
const ledger = JSON.parse(result.after);
assert.equal(result.individual_decisions, 10);
assert.equal(result.unselected_entries_preserved, 1687);
assert.equal(ledger.closed_dispositions, 436);
assert.equal(ledger.open_or_deferred, 1261);
assert.equal(ledger.entries.filter(row => row.final_disposition === 'security-review').length, 1);
assert.equal(result.g11_claim, 'not-passed');
for (const packet of ['parent-dialog-focus-finite-source-successor-v5.json',
  'parent-dialog-focus-authored-use-successor-v5.json', 'current-sass-stepper-sixth-source-inputs-v1.json']) {
  const target = 'compatibility/rc/' + packet;
  assert.throws(() => sidenavPeerSourceCensus({root, read: path => {
    const bytes = read(path);
    if (path === target) bytes[0] ^= 1;
    return bytes;
  }}), undefined, 'accepted changed callback packet ' + packet);
}
console.log('PASS source-qualified ten-row Sidenav stage, preserved ledger metadata, original evidence and packet callback guards; G11 not passed');

if (mutate) {
  const target = 'projects/ngx-material-legacy/_index.scss';
  const runtime = 'projects/ngx-material-legacy/legacy-dialog/internal/dialog-base.ts';
  const extra = 'projects/ngx-material-legacy/c04-sidenav-unapproved-added.ts';
  const original = read(target);
  try {
    writeFileSync(join(root, target), Buffer.concat([original, Buffer.from('\n/* physical mutation */\n')]));
    assert.throws(() => invoke());
  } finally { writeFileSync(join(root, target), original); }
  assert.throws(() => invoke(path => { const bytes = read(path); if (path === target) bytes[0] ^= 1; return bytes; }));
  let changed = false;
  try {
    assert.throws(() => invoke(path => { const bytes = read(path); if (path === target && !changed) {
      changed = true; writeFileSync(join(root, target), Buffer.concat([original, Buffer.from('\n/* callback mutation */\n')]));
    } return bytes; }));
  } finally { writeFileSync(join(root, target), original); }
  assert.equal(changed, true);
  const runtimeOriginal = read(runtime);
  try {
    writeFileSync(join(root, runtime), Buffer.concat([runtimeOriginal, Buffer.from('\nconst C04_RUNTIME_PROBE = "MatSidenav";\n')]));
    assert.throws(() => invoke());
  } finally { writeFileSync(join(root, runtime), runtimeOriginal); }
  try {
    writeFileSync(join(root, extra), 'export const C04_UNAPPROVED_ADDED = true;\n');
    assert.throws(() => invoke());
  } finally { unlinkSync(join(root, extra)); }
  const originalFunction = admission.inspectWholeBody;
  const admissionBytes = readFileSync(admissionPath);
  try {
    admission.inspectWholeBody = () => ({assertCurrent(){}});
    assert.throws(() => invoke(), /changed admission function/);
    admission.inspectWholeBody = originalFunction;
    writeFileSync(admissionPath, Buffer.concat([admissionBytes, Buffer.from('\n// tampered\n')]));
    assert.throws(() => invoke(), /changed admission helper/);
  } finally { admission.inspectWholeBody = originalFunction; writeFileSync(admissionPath, admissionBytes); }
  assert.equal(hash(read(target)), hash(original));
  assert.equal(hash(read(runtime)), hash(runtimeOriginal));
  console.log('PASS physical, callback, runtime, extra-file and helper mutation controls; scratch files restored');
}
