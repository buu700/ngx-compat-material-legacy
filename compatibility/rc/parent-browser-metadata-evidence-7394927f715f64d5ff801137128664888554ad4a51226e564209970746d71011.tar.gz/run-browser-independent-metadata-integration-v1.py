"""Actual named metadata-wrapper test on both maintained working inputs."""
import hashlib,json,os
from pathlib import Path
import signal,subprocess,sys,time
ROOTS={line:Path('/home/parallels/.codex/worktrees/codex-closeout-'+suffix+'/ngx-compat-material-legacy') for line,suffix in [('21.x','21'),('main','main')]}
NODE=Path('/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node')
PY=Path('/nix/store/lfh101cfjj8p8npcari9hk0lbqi33yvh-python3-3.14.7/bin/python3')
PROFILE='compatibility/rc/parent-base-class-tool-successor-inputs-v3.json'
EXPECTED='f25d474e8022f226623b27093a47659c02bbc88a1e9b43ed9e8f209f3c246044'
line=sys.argv[1];root=ROOTS[line];suffix='21' if line=='21.x' else 'main'
OUT=Path('/tmp/parent-browser-independent-metadata-integration-'+suffix+'-v1.json')
INNER=Path('/tmp/parent-browser-independent-metadata-report-'+suffix+'-v1.json')
assert not OUT.exists() and not INNER.exists() and NODE.is_file() and PY.is_file()
env={k:v for k,v in os.environ.items() if not k.startswith(('RC_','GIT_')) and k not in ('NODE_OPTIONS','NODE_PATH','NODE_V8_COVERAGE','PYTHONPATH','PYTHONHOME')}
env.update(GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0',BROWSER_REFERENCE_INDEPENDENT_REPORT=str(INNER))
env['PATH']=str(NODE.parent)+':'+str(PY.parent)+':'+env['PATH']
def sha(b):return hashlib.sha256(b).hexdigest()
def git(r,*args):return subprocess.check_output(['git','--no-replace-objects','-c','gc.auto=0','-c','maintenance.auto=0',*args],cwd=r,env=env)
def snapshot():
 rows=[];heads={};statuses={}
 for name,r in ROOTS.items():
  p=(r/PROFILE).read_bytes();assert sha(p)==EXPECTED
  paths={x.decode() for x in git(r,'ls-files','-z').split(b'\0') if x}
  branch=json.loads(p)['branches'][name];paths.update(x['path'] for x in branch['updates']+branch['additional_inputs'])
  for path in sorted(paths):
   f=r/path;assert f.is_file() and not f.is_symlink();b=f.read_bytes();rows.append(dict(line=name,path=path,sha256=sha(b),bytes=len(b),mode=f.stat().st_mode&0o777))
  heads[name]=git(r,'rev-parse','HEAD').decode().strip();statuses[name]=git(r,'status','--porcelain','--untracked-files=all').decode()
 return dict(heads=heads,statuses=statuses,files=rows)
before=snapshot();command=[str(PY),'-B','-m','unittest','discover','-s','tests','-p','test_browser_reference_proposal.py','-k','test_independent_python_token_splice_and_protected_canonical','-v']
started=time.monotonic();child=subprocess.Popen(command,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
print(json.dumps(dict(line=line,state='started',pid=child.pid,profile=EXPECTED,wrapper_inner_deadline_seconds=300)),flush=True)
expired=False
try:stdout,stderr=child.communicate(timeout=360)
except subprocess.TimeoutExpired:
 expired=True
 try:os.killpg(child.pid,signal.SIGKILL)
 except ProcessLookupError:pass
 stdout,stderr=child.communicate()
seconds=time.monotonic()-started;after=snapshot();report=json.loads(INNER.read_bytes()) if INNER.exists() else None
passed=not expired and child.returncode==0 and report is not None
if passed:
 passed=report['source_execution_mode']=='source-metadata' and report['current_canonical_frame_verified'] is False and report['canonical_frame_admission_granted'] is False and report['g11_claim']=='not-passed'
record=dict(scope='Actual named Python metadata-wrapper integration; dirty reviewed working cut, no strict-default or full source producer/owner qualification',line=line,profile_sha256=EXPECTED,command=command,seconds=seconds,exit_code=child.returncode,timed_out=expired,stdout=stdout,stderr=stderr,report=report,source_before=before,source_after=after,source_unchanged=before==after,passed=passed and before==after,inner_full_node_report_emitted=False,limitation='The genuine Python implementation validates its fresh full Node fault report against actual baselines internally. The wrapper emits its independent reconstruction/source-only report, not that inner full report.',g11_claim='not-passed')
with OUT.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(dict(line=line,state='terminal',seconds=seconds,exit_code=child.returncode,passed=record['passed'],source_unchanged=record['source_unchanged'],receipt=str(OUT))),flush=True)
if not record['passed']:raise SystemExit(1)
