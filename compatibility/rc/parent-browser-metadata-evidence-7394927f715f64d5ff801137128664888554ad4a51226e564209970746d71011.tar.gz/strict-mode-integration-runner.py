import os,subprocess,pathlib,hashlib,json,time,concurrent.futures,signal
roots={'21.x':'/home/parallels/.codex/worktrees/codex-closeout-21/ngx-compat-material-legacy','main':'/home/parallels/.codex/worktrees/codex-closeout-main/ngx-compat-material-legacy'}
node='/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin'
py='/nix/store/lq2fsnmg0q3y0vlxn91w8s8wvj1m6fld-python3-3.14.8/bin'
env=dict(os.environ,PATH=node+':'+py+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_NO_REPLACE_OBJECTS='1')
def snap(root):
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,env=env,text=True).strip()
 raw=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root,env=env)
 paths=sorted(set(os.fsdecode(x) for x in raw.split(b'\0') if x)); rows={}
 for name in paths:
  p=pathlib.Path(root)/name
  if p.is_symlink(): rows[name]={'symlink':os.readlink(p)}
  elif p.is_file():
   b=p.read_bytes(); rows[name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
  else: rows[name]={'missing_or_other':True}
 return {'head':head,'files':rows}
def run(pair):
 line,root=pair; prefix=pathlib.Path('/tmp/strict-mode-integration-'+line.replace('.','_'))
 before=snap(root);prefix.with_suffix('.before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
 start=time.monotonic(); proc=subprocess.Popen([py+'/python3','-B','tests/browser_reference_independent.py'],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 timed=False
 try: out,err=proc.communicate(timeout=360)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(proc.pid,signal.SIGKILL);out,err=proc.communicate()
 elapsed=time.monotonic()-start
 prefix.with_suffix('.stdout').write_bytes(out);prefix.with_suffix('.stderr').write_bytes(err)
 after=snap(root);prefix.with_suffix('.after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
 expectation=(proc.returncode==0 and not timed and json.loads(out).get('current_canonical_frame_verified') is True and json.loads(out).get('source_execution_mode')=='strict-canonical-frame') if line=='main' and out else (proc.returncode!=0 and not timed and b'AssertionError: unregistered strict canonical frame' in err) if line=='21.x' else False
 receipt={'line':line,'root':root,'head_before':before['head'],'head_after':after['head'],'tracked_and_untracked_files_before':len(before['files']),'tracked_and_untracked_files_after':len(after['files']),'snapshot_identical':before==after,'command':[py+'/python3','-B','tests/browser_reference_independent.py'],'node':node+'/node','expected':'strict frame pass' if line=='main' else 'unregistered strict canonical frame rejection','expectation_met':expectation,'returncode':proc.returncode,'timeout':timed,'elapsed_seconds':elapsed,'stdout_path':str(prefix.with_suffix('.stdout')),'stderr_path':str(prefix.with_suffix('.stderr')),'no_full_source_producer_or_owner_qualification':True}
 prefix.with_suffix('.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:
 for r in e.map(run,roots.items()): print(json.dumps(r),flush=True)
