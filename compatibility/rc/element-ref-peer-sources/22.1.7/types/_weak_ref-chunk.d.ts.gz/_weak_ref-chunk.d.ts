/**
 * @license Angular v22.1.7
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */

declare function setAlternateWeakRefImpl(impl: unknown): void;

export { setAlternateWeakRefImpl };
