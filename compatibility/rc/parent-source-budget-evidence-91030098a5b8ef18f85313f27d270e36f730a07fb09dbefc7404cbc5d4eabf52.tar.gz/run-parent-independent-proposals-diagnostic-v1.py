"""Prepared diagnostic. No command is launched merely by creating this file.

Diagnostic of two exact independent Python commands, serial, no producer edits.
The independent Python processes internally capture their Node source reports;
that output is not available to this controller. A separately captured complete
measurement is independently authenticated and must not be confused with it.
"""
from pathlib import Path
import gzip,hashlib,json,os,runpy,signal,stat,subprocess,sys,time
ROOTS={line:Path('/home/parallels/.codex/worktrees/codex-closeout-'+suffix+'/ngx-compat-material-legacy') for line,suffix in [('21.x','21'),('main','main')]}
ROOT=ROOTS['21.x']; NODE=Path('/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node'); PYTHON=Path('/nix/store/lfh101cfjj8p8npcari9hk0lbqi33yvh-python3-3.14.7/bin/python3')
PINS=Path('/tmp/parent-independent-proposals-diagnostic-pins-v1.json'); rawpins=PINS.read_bytes(); pins=json.loads(rawpins)
assert pins['status']=='READY_FOR_DIAGNOSTIC', 'pins are not ready for diagnostic'
assert set(pins['source_heads'])==set(ROOTS) and all(isinstance(v,str) and len(v)==40 for v in pins['source_heads'].values())
ref=pins['completed_source_measurement'];assert isinstance(ref,dict) and set(ref)=={'path','sha256','bytes'}
assert ref['path']=='/tmp/parent-complete-source-command-measurement-v1.json' and len(ref['sha256'])==64 and type(ref['bytes']) is int and ref['bytes']>0
OUT=Path('/tmp/parent-independent-proposals-diagnostic-v1.json');BEFORE=Path('/tmp/parent-independent-proposals-diagnostic-v1-before.json.gz');AFTER=Path('/tmp/parent-independent-proposals-diagnostic-v1-after.json.gz')
for p in (OUT,BEFORE,AFTER): assert not p.exists() and not p.is_symlink(),str(p)
assert NODE.is_file() and PYTHON.is_file() and Path(sys.executable).resolve()==PYTHON.resolve()
assert subprocess.check_output([str(NODE),'--version'],text=True).strip()=='v24.21.0'
assert sys.version_info[:3]==(3,14,7)
env={k:v for k,v in os.environ.items() if not k.startswith(('RC_','GIT_')) and k not in ('NODE_OPTIONS','NODE_PATH','NODE_V8_COVERAGE','PYTHONPATH','PYTHONHOME')}
env.update(GIT_NO_LAZY_FETCH='1',GIT_NO_REPLACE_OBJECTS='1',GIT_TERMINAL_PROMPT='0');env['PATH']=str(NODE.parent)+':'+str(PYTHON.parent)+':'+env.get('PATH','')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(root,*args):return subprocess.check_output(['git','--no-replace-objects','-c','gc.auto=0','-c','maintenance.auto=0',*args],cwd=root,env=env)
def ident(path,raw):return {'path':str(path),'sha256':sha(raw),'bytes':len(raw)}
def heads():return {line:git(root,'rev-parse','HEAD').decode().strip() for line,root in ROOTS.items()}
def input_raw(path):
 p=Path(path);assert not p.is_symlink() and p.is_file();return p.read_bytes()
measurement_raw=input_raw(ref['path']);assert ident(ref['path'],measurement_raw)==ref
measurement=json.loads(measurement_raw);assert measurement['source_heads']==pins['source_heads'] and measurement['source_heads_after']==pins['source_heads'] and measurement['source_unchanged'] is True and measurement['all_full_assertions_completed'] is True
assert measurement['pinned_node']=='v24.21.0' and measurement['g11_claim']=='not-passed'
# Import validators without executing their command entry point.
api=runpy.run_path(str(ROOT/'scripts/check-source-contract-regressions.py')); observations=measurement['observations'];assert set(observations)=={'checker','browser'}
qualified={}
for kind in ('checker','browser'):
 item=observations[kind];assert item['completed_full_assertions'] is True and item['exit_code']==0 and item['baseline_and_final_physical_unchanged'] is True
 bound=item['bound'];report=item['full_report'];api['validate_report'](kind,report,bound,'21.x')
 assert all(report.get(k)==v for k,v in item['baseline_report'].items())
 for phase in ('cold','late'):assert report[phase+'_source_fault_paths_rejected']==[x['path'] for x in bound]
 for member in bound:
  path=member['path'];assert path and not path.startswith('/') and all(part not in ('','.','..') for part in path.split('/'))
  old=qualified.get(path);assert old is None or old==member;qualified[path]=member
profile_path='compatibility/rc/parent-base-class-tool-successor-inputs-v3.json';profiles={}
for line,root in ROOTS.items():
 raw=(root/profile_path).read_bytes();assert sha(raw)==pins['profile_sha256'];profiles[line]=json.loads(raw)
assert profiles['21.x']==profiles['main']
specific=['tests/checker_reference_independent.py','tests/browser_reference_independent.py','tests/test_checker_reference_proposal.py','tests/test_browser_reference_proposal.py','tests/checker_reference_source_probe.mjs','tests/browser_reference_source_probe.mjs','scripts/check-upstream-audit-disposition.mjs','compatibility/f10/disposition-ledger/ledger.json','compatibility/rc/c04-checker-reference-proposal.json','compatibility/rc/c04-checker-reference-proposal-after.json.gz','compatibility/rc/c04-browser-reference-proposal.json','compatibility/rc/c04-browser-reference-proposal-after.json.gz']
originals=[('7bae903e9a1309c6e226909ed8ee1bae5ad4eccf','compatibility/f10/disposition-ledger/ledger.json','558b6891e575422cdfcdaff2f59fa7611cf53246130da3afeec68571d1c77a1b'),('7378668ffa018b9cbf5498d84a5db32fa824cc26','compatibility/f10/disposition-ledger/ledger.json','8f311ad001bf2daa3152b878414bd010a621d31b76c118d19f4184e5bed0ef17')]
assert heads()==pins['source_heads']
def snapshot():
 tracked=[];finite=[]
 for line,root in ROOTS.items():
  files=git(root,'ls-files','-z').split(b'\0');assert files.pop()==b''
  for encoded in sorted(files):
   path=encoded.decode();cursor=root
   for part in path.split('/'):
    assert part not in ('','.','..');cursor/=part;assert not cursor.is_symlink(),str(cursor)
   st=cursor.stat();assert stat.S_ISREG(st.st_mode);tracked.append({'line':line,**ident(path,cursor.read_bytes()),'mode':stat.S_IMODE(st.st_mode)})
  b=profiles[line]['branches'][line];paths={row['path'] for row in b['updates']+b['additional_inputs']};paths.update([profile_path,'scripts/check-source-contract-regressions.py','scripts/current-sass-tool-references.mjs','scripts/current_sass_tool_references.py']);
  if line=='21.x':paths.update(specific)
  for path in sorted(paths):
   p=root/path;assert p.is_file() and not p.is_symlink();finite.append({'line':line,**ident(path,p.read_bytes()),'mode':stat.S_IMODE(p.stat().st_mode)})
 factual=[]
 for path,expected in sorted(qualified.items()):
  p=ROOT/path;raw=p.read_bytes();assert sha(raw)==expected['sha256'] and len(raw)==expected['bytes'],'changed measured source '+path
  factual.append({**ident(path,raw),'resolved':str(p.resolve()),'mode':stat.S_IMODE(p.stat().st_mode)})
 historical=[]
 for commit,path,digest in originals:
  raw=git(ROOT,'show',commit+':'+path);assert sha(raw)==digest;historical.append({'commit':commit,**ident(path,raw)})
 return {'heads':heads(),'tracked':tracked,'finite':finite,'measured_factual':factual,'historical_originals':historical,'measurement':ident(ref['path'],input_raw(ref['path'])),'pins_sha256':sha(input_raw(PINS))}
def encode(value):return (json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
def summary(value):
 raw=encode(value);return {'sha256':sha(raw),'bytes':len(raw),'heads':value['heads'],'tracked_count':len(value['tracked']),'finite_count':len(value['finite']),'measured_factual_count':len(value['measured_factual'])}
def save(path,data):
 with path.open('xb') as f:f.write(data)
before=snapshot();assert before['heads']==pins['source_heads'] and before['pins_sha256']==sha(rawpins) and before['measurement']==ref
assert measurement['source_inputs_before']==measurement['source_inputs_after']
finite_by_key={(row['line'],row['path']):row for row in before['finite']}
assert all(finite_by_key.get((row['line'],row['path']))==row for row in measurement['source_inputs_before']), 'source inputs changed since full measurement'
save(BEFORE,gzip.compress(encode(before),compresslevel=9,mtime=0))
results={};specs=[('checker','tests/checker_reference_independent.py'),('browser','tests/browser_reference_independent.py')]
for kind,path in specs:
 command=[str(PYTHON),'-B',path];start=time.monotonic();child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 print(json.dumps({'state':'started','kind':kind,'pid':child.pid,'command':command,'deadline_seconds':600}),flush=True);expired=False
 try:stdout,stderr=child.communicate(timeout=600)
 except subprocess.TimeoutExpired:
  expired=True
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  stdout,stderr=child.communicate()
 seconds=time.monotonic()-start;result={'command':command,'seconds':seconds,'deadline_seconds':600,'timed_out':expired,'exit_code':child.returncode,'stdout':stdout,'stderr':stderr,'wrapper_equivalent_validation':False}
 try:
  assert not expired and child.returncode==0;report=json.loads(stdout);assert report['schema_version']==1 and report['line']=='21.x' and report['canonical_ledger_unchanged'] is True and report['canonical_owner_integration_complete'] is False and report['actual_native_packed_browser_floor_or_full_audit_qualified'] is False and report['g11_claim']=='not-passed'
  packet=json.loads((ROOT/('compatibility/rc/c04-'+kind+'-reference-proposal.json')).read_bytes());assert report['independent_after_sha256']==packet['after_ledger']['sha256'] and report['independent_after_bytes']==packet['after_ledger']['bytes']
  assert report['hash_scalar_replacements']==packet['metadata_reference_updates']
  if kind=='checker':assert report['hash_scalar_replacements']==5 and report['already_current_checker_references_preserved']==14 and report['unselected_entry_bytes_preserved']==1692
  else:assert report['selected_entries']==packet['selected_entries']==8 and report['unselected_entry_bytes_preserved']==1689 and report['preserved_native_reference_count']==packet['preserved_native_reference_count']
  result['report']=report;result['wrapper_equivalent_validation']=True
 except (AssertionError,KeyError,ValueError,TypeError) as error:result['validation_error']=type(error).__name__+': '+str(error)
 try:
  step=snapshot();result['source_after_command']=summary(step);result['source_unchanged_after_command']=step==before
 except Exception as error:result['source_unchanged_after_command']=False;result['source_snapshot_error']=type(error).__name__+': '+str(error)
 results[kind]=result
 print(json.dumps({'state':'terminal','kind':kind,'seconds':seconds,'exit_code':child.returncode,'timed_out':expired,'wrapper_equivalent_validation':result['wrapper_equivalent_validation']}),flush=True)
 if not result['source_unchanged_after_command']:break
try:after=snapshot();after_error=None;save(AFTER,gzip.compress(encode(after),compresslevel=9,mtime=0))
except Exception as error:after=None;after_error=type(error).__name__+': '+str(error)
unchanged=after is not None and before==after
record={'schema_version':1,'scope':'Diagnostic of complete independent reconstruction commands; no timeout-policy change, canonical transaction, owner, native, G11 or release qualification','source_heads':pins['source_heads'],'pinned_node':str(NODE),'pinned_python':str(PYTHON),'source_measurement':ref,'source_measurement_limitation':'Separate complete source reports were authenticated. The independent Python commands internally consume their own fresh full Node reports; these inner reports are not emitted, and are not relabeled as the separately measured report.','original_wrapper_timeouts_seconds':{'checker':120,'browser':180},'diagnostic_timeout_seconds_per_command':600,'commands_serial':True,'results':results,'source_before':summary(before),'source_after':summary(after) if after is not None else None,'source_snapshot_error':after_error,'source_unchanged':unchanged,'snapshot_files':{'before':ident(BEFORE,input_raw(BEFORE)),'after':ident(AFTER,input_raw(AFTER)) if after is not None else None},'snapshot_limits':'All tracked regular file bytes/modes and both HEADs, profile-derived inputs, measured checker/browser factual bounds including peer realpaths, exact retained measurement and pins, canonical ledger/proposals and original Git ledger blobs. No atomic hostile-filesystem guarantee.','g11_claim':'not-passed'}
save(OUT,(json.dumps(record,indent=2)+'\n').encode());success=unchanged and len(results)==2 and all(v['wrapper_equivalent_validation'] and v['source_unchanged_after_command'] for v in results.values())
print(json.dumps({'state':'terminal','receipt':str(OUT),'all_reconstructions_pass':success,'source_unchanged':unchanged}),flush=True)
if not success:raise SystemExit(1)
