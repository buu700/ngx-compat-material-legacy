"""Diagnostic only: unchanged complete commands with a bounded observation cap."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import time

ROOTS = {line: Path('/home/parallels/.codex/worktrees/codex-closeout-' + suffix + '/ngx-compat-material-legacy') for line, suffix in [('21.x', '21'), ('main', 'main')]}
EXPECTED_HEADS = {'21.x': '805b25a5b6908626a611dab783b1fa4454b88bbf', 'main': '57458ce01f798e571dc354c26e204484308cae27'}
NODE_DIR = Path('/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin')
OUT = Path('/tmp/parent-complete-source-command-measurement-v1.json')
assert not OUT.exists()
assert (NODE_DIR / 'node').is_file()
os.environ['PATH'] = str(NODE_DIR) + ':' + os.environ['PATH']
api = runpy.run_path(str(ROOTS['21.x'] / 'scripts/check-source-contract-regressions.py'))
need, head, inspect = (api[k] for k in ['need', 'head', 'inspect'])
run_child, validate_report = (api[k] for k in ['run_child', 'validate_report'])

def heads():
    return {line: head(root)[0] for line, root in ROOTS.items()}

def finite_snapshot():
    records = []
    for line, root in ROOTS.items():
        profile = json.loads((root / 'compatibility/rc/parent-base-class-tool-successor-inputs-v3.json').read_bytes())
        branch = profile['branches'][line]
        paths = {row['path'] for row in branch['updates'] + branch['additional_inputs']}
        paths.update(['scripts/check-source-contract-regressions.py', 'compatibility/rc/parent-base-class-tool-successor-inputs-v3.json', 'scripts/current-sass-tool-references.mjs', 'scripts/current_sass_tool_references.py'])
        for relative in sorted(paths):
            row = api['local_row'](root, relative)
            row['line'] = line
            row['mode'] = (root / relative).stat().st_mode & 0o777
            records.append(row)
    return records

need(heads() == EXPECTED_HEADS, 'unexpected source heads')
before = finite_snapshot()
receipt = {'schema_version': 1, 'scope': 'Diagnostic only; unchanged full current commands, not a pass under original source-gate budgets or owner admission', 'source_heads': heads(), 'pinned_node': subprocess.check_output([str(NODE_DIR / 'node'), '--version'], text=True).strip(), 'diagnostic_timeout_seconds_per_command': 600, 'original_budgets_seconds': api['TIMEOUTS'], 'source_inputs_before': before, 'observations': {}, 'g11_claim': 'not-passed'}
for kind in ['checker', 'browser']:
    root = ROOTS['21.x']
    baseline = inspect(kind, root)
    api['rows_by_path'](baseline['bound'])
    command = api['COMMANDS'][kind]
    print(json.dumps({'kind': kind, 'state': 'started', 'command': command, 'bound_paths': len(baseline['bound']), 'cap_seconds': 600}), flush=True)
    started = time.monotonic()
    observation = {'command': command, 'bound': baseline['bound'], 'baseline_report': baseline['report']}
    try:
        child = run_child(command, root, 600)
        observation.update(exit_code=child.returncode, stdout=child.stdout, stderr=child.stderr, seconds=time.monotonic() - started)
        need(child.returncode == 0, 'full command failed')
        report = json.loads(child.stdout)
        validate_report(kind, report, baseline['bound'], '21.x')
        need(all(report.get(k) == v for k, v in baseline['report'].items()), 'semantic report changed')
        for prefix in ['cold', 'late']:
            need(report[prefix + '_source_fault_paths_rejected'] == [row['path'] for row in baseline['bound']], 'ordered fault roster changed')
        after = inspect(kind, root)
        need(after == baseline, 'baseline source or semantic report changed')
        physical = run_child(['node', '--input-type=module', '-e', api['PHYSICAL']], root, 120, input_text=json.dumps(baseline['bound']))
        need(physical.returncode == 0, 'final physical sweep failed: ' + physical.stderr[-2000:])
        observation.update(completed_full_assertions=True, full_report=report, baseline_and_final_physical_unchanged=True)
    except (ValueError, KeyError, TypeError, OSError, subprocess.SubprocessError) as error:
        observation.update(completed_full_assertions=False, error=str(error), seconds=time.monotonic() - started)
    observation['exceeded_original_budget'] = observation['seconds'] > api['TIMEOUTS'][kind]
    receipt['observations'][kind] = observation
    print(json.dumps({'kind': kind, 'state': 'terminal', 'seconds': observation['seconds'], 'exit_code': observation.get('exit_code'), 'completed_full_assertions': observation['completed_full_assertions'], 'error': observation.get('error')}), flush=True)
receipt['source_inputs_after'] = finite_snapshot()
receipt['source_heads_after'] = heads()
receipt['source_unchanged'] = receipt['source_inputs_before'] == receipt['source_inputs_after'] and receipt['source_heads_after'] == receipt['source_heads']
receipt['all_full_assertions_completed'] = all(row['completed_full_assertions'] for row in receipt['observations'].values())
with OUT.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({'state': 'terminal', 'receipt': str(OUT), 'all_full_assertions_completed': receipt['all_full_assertions_completed'], 'source_unchanged': receipt['source_unchanged'], 'gate_qualification': False}), flush=True)
raise SystemExit(0 if receipt['all_full_assertions_completed'] and receipt['source_unchanged'] else 1)
