import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const root=process.cwd();
const load=p=>import(pathToFileURL(resolve(root,p)));
const {currentSassToolReferenceSubject}=await load('scripts/current-sass-tool-references.mjs');
const {historicalContractRepairSourceSubject}=await load('scripts/historical-contract-repair-source.mjs');
const rows={};
for(const [name,make] of [['tool',currentSassToolReferenceSubject],['historical',historicalContractRepairSourceSubject]]){const s=make({root});s.assertCurrent();rows[name]={bound:s.bound.length};}
if(JSON.parse((await import('node:fs')).readFileSync(resolve(root,'projects/ngx-material-legacy/package.json'))).version.startsWith('21.')){for(const [name,path,key] of [['base','scripts/base-class-removal-owner-source.mjs','baseClassRemovalOwnerSourceSubject'],['legacy','scripts/upstream-legacy-removal-source.mjs','inspectLegacyRemovalSourceReview']]){const s=(await load(path))[key]({root});s.assertCurrent();rows[name]={bound:s.bound.length};}}
console.log(JSON.stringify(rows));
