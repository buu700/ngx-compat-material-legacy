import hashlib
import json
import pathlib
import subprocess

BASE = pathlib.Path('/home/parallels/.codex/worktrees')
PACKET = pathlib.Path('/tmp/c03-zone-modes-final-v4')
OUT = pathlib.Path('/tmp/parent-zone-modes-controlled-integration-v1.json')
REVIEW = pathlib.Path('/tmp/c03-zone-modes-independent-review-v4.json')

def image(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def git(root, *args):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=0', *args], cwd=root)

def unrelated(root, targets):
    names = git(root, 'diff', '--name-only', '-z').split(b'\0') + git(root, 'ls-files', '--others', '--exclude-standard', '-z').split(b'\0')
    return {p.decode(): image((root / p.decode()).read_bytes()) for p in names if p and p.decode() not in targets}

assert not OUT.exists()
assert image((PACKET / 'manifest.json').read_bytes())['sha256'] == 'e7550053b60038262485bc792c5caf589ad271b9783671563748a4734e39ec3f'
assert image(REVIEW.read_bytes())['sha256'] == '32aebf0c2bf39e47df2e6833ffaed4b90309944a8dc2cfff6f19c9f14dd2b106'
manifest = json.loads((PACKET / 'manifest.json').read_text())
receipt = {'schema': 'parent-zone-modes-controlled-integration-v1', 'manifest': image((PACKET / 'manifest.json').read_bytes()), 'review': image(REVIEW.read_bytes()), 'branches': {}, 'remote_actions': 'none'}
for line in ['21', 'main']:
    root = BASE / ('codex-closeout-' + line) / 'ngx-compat-material-legacy'
    patch = PACKET / (line + '.patch')
    data = manifest[line]
    targets = [f['path'] for f in data['files']]
    assert len(targets) == len(set(targets)) == 19
    assert not git(root, 'diff', '--cached', '--name-only').strip()
    assert image(patch.read_bytes())['sha256'] == data['patch_sha256']
    before = {}
    for f in data['files']:
        path = root / f['path']
        actual = image(path.read_bytes()) if path.exists() else None
        assert (actual['sha256'] if actual else None) == f['before_sha256'], (line, f['path'], actual)
        if actual:
            assert path.read_bytes() == git(root, 'show', 'HEAD:' + f['path']), f['path']
        before[f['path']] = actual
    subprocess.run(['git', 'apply', '--check', str(patch)], cwd=root, check=True)
    receipt['branches'][line] = {'root': str(root), 'before_head': git(root, 'rev-parse', 'HEAD').decode().strip(), 'patch': str(patch), 'targets': targets, 'before': before, 'unrelated_before': unrelated(root, targets)}
for line, row in receipt['branches'].items():
    root = pathlib.Path(row['root'])
    subprocess.run(['git', 'apply', row['patch']], cwd=root, check=True)
    row['after'] = {p: image((root / p).read_bytes()) for p in row['targets']}
    for f in manifest[line]['files']:
        assert row['after'][f['path']] == {'sha256': f['after_sha256'], 'bytes': f['bytes']}
    row['unrelated_after'] = unrelated(root, row['targets'])
    assert row['unrelated_after'] == row['unrelated_before']
    subprocess.run(['git', 'diff', '--check', '--', *row['targets']], cwd=root, check=True)
receipt['limits'] = 'Source integration only. Prior old-artifact dialog mode observations were bounded passes; form/overlay family failures remain failures. Native browser motion, hydration, full source/RC gates and current artifact qualification are not established.'
OUT.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': str(OUT), 'branches': {k: {'head':v['before_head'], 'targets':len(v['targets']), 'exact_reviewed_postimages':True} for k,v in receipt['branches'].items()}}))
