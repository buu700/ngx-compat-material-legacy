import concurrent.futures
import hashlib
import json
import os
import pathlib
import subprocess
import time

NODE = '/nix/store/w8jijs92barihdb0z54dsgq5szj2wd47-nodejs-24.21.0/bin/node'
PYTHON = '/nix/store/lfh101cfjj8p8npcari9hk0lbqi33yvh-python3-3.14.7/bin/python3'
APPLICATION = pathlib.Path('/tmp/parent-zone-modes-controlled-integration-v1.json')
INPUT = json.loads(APPLICATION.read_text())

def snapshot(root, paths):
    return {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}

def run_line(line):
    row = INPUT['branches'][line]
    root = pathlib.Path(row['root'])
    out = pathlib.Path('/tmp/parent-zone-modes-maintained-' + line + '-v1.json')
    assert not out.exists()
    before = snapshot(root, row['targets'])
    env = os.environ.copy()
    env['PATH'] = str(pathlib.Path(NODE).parent) + ':' + str(pathlib.Path(PYTHON).parent) + ':' + env['PATH']
    commands = [
        [NODE, 'scripts/native-motion-regressions.mjs'],
        [PYTHON, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_browser_zone_modes.py', '-v'],
        [PYTHON, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_ripple_hydration_application.py', '-v'],
        [NODE, 'tests/ripple_hydration_observer_probe.mjs'],
    ]
    results = []
    for i, command in enumerate(commands):
        log = pathlib.Path('/tmp/parent-zone-modes-maintained-' + line + '-v1-' + str(i) + '.log')
        assert not log.exists()
        started = time.monotonic()
        with log.open('w') as stream:
            try:
                completed = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=120)
                code = completed.returncode
            except subprocess.TimeoutExpired:
                code = 'timeout'
        results.append({'command': command, 'exit_code': code, 'seconds': round(time.monotonic()-started,3), 'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
    after = snapshot(root, row['targets'])
    report = {'schema':'parent-zone-modes-maintained-v1','line':line,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'application_receipt':str(APPLICATION),'application_sha256':hashlib.sha256(APPLICATION.read_bytes()).hexdigest(),'checks':results,'before':before,'after':after,'source_unchanged':before==after,'passed':before==after and all(r['exit_code']==0 for r in results),'limits':'Portable/source checks only. No browser execution, hydration run, current packed RC or full source/owner gates.'}
    out.write_text(json.dumps(report,indent=2)+'\n')
    return {'line':line,'passed':report['passed'],'receipt':str(out),'checks':[{'exit_code':r['exit_code'],'seconds':r['seconds']} for r in results]}

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(run_line,['21','main']):
        print(json.dumps(result),flush=True)
