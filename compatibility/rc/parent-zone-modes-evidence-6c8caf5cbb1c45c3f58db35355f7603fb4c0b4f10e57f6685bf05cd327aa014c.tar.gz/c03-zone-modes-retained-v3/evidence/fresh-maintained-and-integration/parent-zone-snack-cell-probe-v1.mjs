import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';

const root = process.argv[2];
assert.ok(root);
const source = join(root, 'scripts/native-motion-roster.mjs');
const hash = () => createHash('sha256').update(readFileSync(source)).digest('hex');
const before = hash();
const {deriveMainRoster, assertCase, samplePass, SOURCE_LINE} = await import(pathToFileURL(source));
const ids = deriveMainRoster().ids.filter(id => id.includes('/enabled-disabled-reduced/snack-bar/') || id.includes('/exactly-once-notification/snack-bar/afterOpened/'));
assert.equal(ids.length, 36);
const results = [];
for (const id of ids) {
  const good = samplePass(id);
  assert.deepEqual(assertCase(id, good), []);
  const mutations = {
    'completion-without-next': {...good, notifications: 0},
    'duplicate-next': {...good, notifications: 2},
    'next-without-completion': {...good, completions: 0},
    'duplicate-completion': {...good, completions: 2},
    'wrong-zone': {...good, angularZoneEntered: !good.angularZoneEntered},
    'missing-zone': Object.fromEntries(Object.entries(good).filter(([key]) => key !== 'angularZoneEntered')),
  };
  const rejected = {};
  for (const [name, value] of Object.entries(mutations)) {
    const problems = assertCase(id, value);
    assert.ok(problems.length, id + ': ' + name);
    rejected[name] = problems;
  }
  results.push({id, rejected});
}
assert.equal(hash(), before);
console.log(JSON.stringify({line:SOURCE_LINE, source, source_sha256:before, cells:ids.length, rejected_mutants:results.length*6, results, source_unchanged:true, browser_executed:false, limitation:'Fresh current-roster predicate checks; does not reconstruct the unlocated earlier 36-cell observation or establish native browser execution.'}));
