import hashlib
import io
import json
import pathlib
import shutil
import subprocess
import tarfile

OUT=pathlib.Path('/tmp/parent-density-v4-commits-v1.json')
PACK=pathlib.Path('/tmp/c02-density-license-v4-retained.tar.gz')
V3=pathlib.Path('/tmp/parent-density-v3-controlled-integration-v1.json')
V4=pathlib.Path('/tmp/parent-density-v4-controlled-integration-v1.json')
REVIEW=pathlib.Path('/tmp/c04-density-v3-independent-review-v1.json')
RETAIN=pathlib.Path('/tmp/parent-density-v4-unit-retained-v1')
assert not OUT.exists() and not RETAIN.exists()

def image(data):return {'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
def git(root,*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=0',*args],cwd=root)
def other(root,targets):
    names=git(root,'diff','--name-only','-z').split(b'\0')+git(root,'ls-files','--others','--exclude-standard','-z').split(b'\0')
    return {p.decode():image((root/p.decode()).read_bytes()) for p in names if p and p.decode() not in targets}

assert image(PACK.read_bytes())['sha256']=='8ba3995c2187fd27e80d1b513ad5c56ca9711dad114dd0a37763b384fbe35ea2'
assert image(REVIEW.read_bytes())['sha256']=='20df05f1e9de9e549af46b30a4a89bcb4b9a6b7da2b290fe28d3c89a6571712d'
with tarfile.open(PACK) as t:
    manifest=json.load(t.extractfile('manifest.json'))
    assert len(t.getmembers())==11
    assert {m.name for m in t.getmembers()}==set(manifest['files'])|{'manifest.json'}
    for m in t.getmembers():
        assert m.isfile()
        if m.name!='manifest.json':assert image(t.extractfile(m).read())==manifest['files'][m.name],m.name

v3=json.loads(V3.read_text());v4=json.loads(V4.read_text())
payload={
 'evidence/author-license-v4.tar.gz':PACK.read_bytes(),
 'evidence/independent-density-v3-review.json':REVIEW.read_bytes(),
 'root/controlled-v3-application.json':V3.read_bytes(),
 'root/controlled-v4-application-and-review.json':V4.read_bytes(),
 'root/integrate-v3.py':pathlib.Path('/tmp/integrate-parent-density-v3.py').read_bytes(),
 'root/integrate-license-v4.py':pathlib.Path('/tmp/integrate-parent-density-license-v4.py').read_bytes(),
 'root/retain-and-commit.py':pathlib.Path(__file__).read_bytes(),
}
for line,row in v4['branches'].items():
    root=pathlib.Path(row['root'])
    assert git(root,'rev-parse','HEAD').decode().strip()==row['head']
    assert not git(root,'diff','--cached','--name-only').strip()
    assert len(row['full_unit_after'])==18
    for p,wanted in row['full_unit_after'].items():
        data=(root/p).read_bytes();assert image(data)==wanted,(line,p)
        payload['after/'+line+'/'+p]=data
        if v3['branches'][line]['before'][p] is not None:
            old=git(root,'show',row['head']+':'+p)
            assert image(old)==v3['branches'][line]['before'][p]
            payload['before/'+line+'/'+p]=old
    payload['diff/'+line+'.patch']=git(root,'diff','--',*row['full_unit_after'])
    payload['status/'+line+'.txt']=git(root,'status','--short')
payload['CONTENTS.json']=(json.dumps({'schema':'parent-density-v4-unit-evidence-v1','files':{name:image(data) for name,data in payload.items()},'limits':manifest['scope'],'test_note':'v3 independent both-floor three-case tests; v4 author repeats identical output hashes; root independently proves v4 is notices and exact matching identity pins only. Final current source epoch and full Sass/coordinator remain pending.'},indent=2)+'\n').encode()
RETAIN.mkdir()
temporary=RETAIN/'unit.tar.gz'
with tarfile.open(temporary,'w:gz') as t:
    for name,data in sorted(payload.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        t.addfile(info,io.BytesIO(data))
archive_name='parent-density-v4-evidence-'+image(temporary.read_bytes())['sha256']+'.tar.gz'
archive=RETAIN/archive_name;temporary.rename(archive)
with tarfile.open(archive) as t:
    members=t.getmembers();assert len(members)==len(set(m.name for m in members))==len(payload)
    for m in members:assert m.isfile() and t.extractfile(m).read()==payload[m.name]

archive_target='compatibility/rc/'+archive_name
index_target='compatibility/rc/parent-density-composition-integration-v1.json'
unit={'schema':'parent-density-composition-integration-v1','change':'Authenticate the finite ordinary checkbox/button peer density composition for default density and two specified aggregate argument cases, retaining complete original CSS and source closure.','application_v3':v3,'application_v4':v4,'evidence':{'archive':{'path':archive_target,**image(archive.read_bytes())},'member_count':len(payload),'members':{name:image(data) for name,data in payload.items()}},'qualification':{'independent_v3_review':image(REVIEW.read_bytes()),'v4_author_portable_output_hashes':{'21':'465e255193bcce9dbd45a0394220d4427ab4a72f9e18348c84fc895deca7d3fb','main':'d43a28fddef75cf499b4a30b719122a1034bb93cb7041e1b92a806526624fcdb'},'v4_root_review':v4['root_review']},'limits':['Three specified cases only; argument producer execution is diagnostic and its body was tested under a simulated envelope, not the real coordinator.','Both prior artifact runs retain 286 original source tuples and exact peer/artifact/source tamper rejection; they do not establish a current-tree pass.','Current select.html differs from the maintained source profile; shared successor enrollment, deliberate density manifest rebinding, full Sass roster and actual coordinator qualification remain required.','No product Sass, consumer maps, selectors or historical goldens changed.'],'remote_actions':'none'}
commits={}
for line,row in v4['branches'].items():
    root=pathlib.Path(row['root']);targets=set(row['full_unit_after'])|{index_target,archive_target}
    before=other(root,targets)
    assert not (root/index_target).exists() and not (root/archive_target).exists()
    (root/index_target).write_text(json.dumps(unit,indent=2)+'\n')
    shutil.copyfile(archive,root/archive_target)
    subprocess.run(['git','add','--',*sorted(targets)],cwd=root,check=True)
    assert set(git(root,'diff','--cached','--name-only','-z').decode().rstrip('\0').split('\0'))==targets
    subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
    subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=0','commit','-m','fix(test): authenticate finite peer density compositions'],cwd=root,check=True)
    commit=git(root,'rev-parse','HEAD').decode().strip()
    assert set(git(root,'diff-tree','--no-commit-id','--name-only','-r',commit).decode().splitlines())==targets
    assert before==other(root,targets)
    for p,wanted in row['full_unit_after'].items():assert image((root/p).read_bytes())==wanted
    commits[line]={'before_head':row['head'],'commit':commit,'source_paths':18,'total_paths':len(targets)}
OUT.write_text(json.dumps({'schema':'parent-density-v4-commits-v1','commits':commits,'archive':{'path':str(archive),**image(archive.read_bytes()),'members':len(payload)},'remote_actions':'none'},indent=2)+'\n')
print(json.dumps({'receipt':str(OUT),'commits':commits,'archive':str(archive),'members':len(payload)}))
