import hashlib
import json
import pathlib
import subprocess

OUT=pathlib.Path('/tmp/parent-density-v4-controlled-integration-v1.json')
assert not OUT.exists()
V3=pathlib.Path('/tmp/parent-density-v3-controlled-integration-v1.json')
prior=json.loads(V3.read_text())
JS='/**\n * @license\n * Copyright Google LLC All Rights Reserved.\n * Copyright (c) 2026 Ryan Lester.\n *\n * Use of this source code is governed by the MIT license in LICENSE.\n */\n'
PY='# Copyright Google LLC All Rights Reserved.\n# Copyright (c) 2026 Ryan Lester.\n# Use of this source code is governed by the MIT license in LICENSE.\n'
CODE=[
 'scripts/sass-ordinary-aggregate-composition.mjs',
 'scripts/sass_ordinary_aggregate_composition.py',
 'scripts/sass-ordinary-density-peer.mjs',
 'scripts/sass_ordinary_density_peer.py',
 'scripts/sass-ordinary-density-gate.mjs',
 'scripts/sass_ordinary_density_gate.py',
 'tests/sass-ordinary-density-portable.mjs',
 'tests/sass-ordinary-density-tamper.mjs',
 'tests/sass-ordinary-density-artifact.mjs',
 'tests/sass_ordinary_density_portable.py',
]
MANIFEST='fixtures/sass/ordinary-density-proof-inputs.json'
CHANGED_ROWS={'scripts/sass-ordinary-aggregate-composition.mjs','scripts/sass_ordinary_aggregate_composition.py','scripts/sass-ordinary-density-peer.mjs','scripts/sass_ordinary_density_peer.py'}
OLD={'21':'01c9bc7276fcff994e4fe94f80265d8f2651bc80d6afeaa11d0ecf4a1470cc7e','main':'1b1131d3cc09f2070aecc50c5f80ef4f1f957a0c09ad1c3123d05e5700f4f521'}
PATCHES={line:pathlib.Path('/tmp/c02-density-'+line+'-v4-license-delta.patch') for line in ['21','main']}

def image(data):return {'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
def git(root,*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=0',*args],cwd=root)
def other(root,targets):
    names=git(root,'diff','--name-only','-z').split(b'\0')+git(root,'ls-files','--others','--exclude-standard','-z').split(b'\0')
    return {p.decode():image((root/p.decode()).read_bytes()) for p in names if p and p.decode() not in targets}

expected={}
manifests={}
for line,row in prior['branches'].items():
    root=pathlib.Path(row['root'])
    for p,wanted in row['after'].items():assert image((root/p).read_bytes())==wanted,(line,p)
    patch=PATCHES[line]
    assert image(patch.read_bytes())['sha256']=='3a6b2cd2cd5fbaef661cf371664fdce44951668550f8ec85767acc086a3840a9'
    expected[line]={p:((PY if p.endswith('.py') else JS)+(root/p).read_text()).encode() for p in CODE}
    manifest=json.loads((root/MANIFEST).read_text())
    assert image((root/MANIFEST).read_bytes())['sha256']==OLD[line]
    seen=set()
    for m in manifest['files']:
        if m['path'] in CHANGED_ROWS:
            m.update(image(expected[line][m['path']]))
            seen.add(m['path'])
    assert seen==CHANGED_ROWS
    manifests[line]=(json.dumps(manifest,indent=2)+'\n').encode()
    expected[line][MANIFEST]=manifests[line]

new={line:image(data)['sha256'] for line,data in manifests.items()}
receipt={'schema':'parent-density-license-v4-controlled-integration-v1','prior_application':{'path':str(V3),**image(V3.read_bytes())},'root_review':'Exact full-text transformation independently derived from current v3: ten prescribed MIT Google/Ryan prefixes, exactly four source manifest row updates and matching per-line manifest constants in JS/Python gates. No other executable text or peer Sass program changes permitted. This is a comment/identity-only update; current source epoch and full qualification remain pending.','branches':{},'remote_actions':'none'}
for line,row in prior['branches'].items():
    root=pathlib.Path(row['root'])
    for p in ['scripts/sass-ordinary-density-gate.mjs','scripts/sass_ordinary_density_gate.py']:
        text=expected[line][p].decode()
        for key in ['21','main']:
            assert text.count(OLD[key])==1
            text=text.replace(OLD[key],new[key])
        expected[line][p]=text.encode()
    subprocess.run(['git','apply','--check',str(PATCHES[line])],cwd=root,check=True)
    assert not git(root,'diff','--cached','--name-only').strip()
    receipt['branches'][line]={'root':str(root),'head':git(root,'rev-parse','HEAD').decode().strip(),'before':{p:image((root/p).read_bytes()) for p in expected[line]},'unrelated_before':other(root,expected[line]),'manifest_hash':new[line]}
for line,row in receipt['branches'].items():
    root=pathlib.Path(row['root'])
    subprocess.run(['git','apply',str(PATCHES[line])],cwd=root,check=True)
    for p,data in expected[line].items():assert (root/p).read_bytes()==data,(line,p)
    row['after']={p:image((root/p).read_bytes()) for p in expected[line]}
    row['full_unit_after']={p:image((root/p).read_bytes()) for p in prior['branches'][line]['after']}
    row['unrelated_after']=other(root,expected[line])
    assert row['unrelated_before']==row['unrelated_after']
    subprocess.run(['git','diff','--check','--',*row['after']],cwd=root,check=True)
OUT.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(OUT),'branches':{line:{'changed_paths':len(row['after']),'final_density_paths':len(row['full_unit_after']),'manifest_sha256':row['manifest_hash']} for line,row in receipt['branches'].items()}}))
