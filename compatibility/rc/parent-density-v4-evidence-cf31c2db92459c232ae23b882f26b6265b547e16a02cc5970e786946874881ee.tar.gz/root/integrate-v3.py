import hashlib
import json
import pathlib
import subprocess

OUT=pathlib.Path('/tmp/parent-density-v3-controlled-integration-v1.json')
assert not OUT.exists()
REVIEW=pathlib.Path('/tmp/c04-density-v3-independent-review-v1.json')
assert hashlib.sha256(REVIEW.read_bytes()).hexdigest()=='20df05f1e9de9e549af46b30a4a89bcb4b9a6b7da2b290fe28d3c89a6571712d'
PATCH_HASHES={'21':'a109eb7787e97895c26945325badea762807ba2b681334f2fb60aece85e44598','main':'8b706adcb0b8a1b8f61839286b262574dea0279ebc992dc2df891102a1d896a9'}
LEDGER_HASHES={'21':'304b8fc247fa94cedef2858f6c351587fc2f2abe61cc2242edb3476e919aa592','main':'22a3d4558b080406d6bf089536cb14724cecefa7d362d2cb0424a0b77ec8d0c2'}

def image(data):return {'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
def git(root,*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=0',*args],cwd=root)
def unrelated(root,targets):
    names=git(root,'diff','--name-only','-z').split(b'\0')+git(root,'ls-files','--others','--exclude-standard','-z').split(b'\0')
    return {p.decode():image((root/p.decode()).read_bytes()) for p in names if p and p.decode() not in targets}

receipt={'schema':'parent-density-v3-controlled-integration-v1','review':{'path':str(REVIEW),**image(REVIEW.read_bytes())},'branches':{},'limits':'Implementation integration only. Independent three-case tests used prior profiles and artifacts. Current source profile rejects changed select.html; deliberate density manifest rebase/review/rerun awaits the shared authenticated successor. No current full Sass/coordinator/source/G11 pass.','remote_actions':'none'}
for line in ['21','main']:
    root=pathlib.Path('/home/parallels/.codex/worktrees/codex-closeout-'+line+'/ngx-compat-material-legacy')
    lp=pathlib.Path('/tmp/c02-density-'+line+'-v3-ledger.json')
    patch=pathlib.Path('/tmp/c02-density-'+line+'-v3.patch')
    assert image(lp.read_bytes())['sha256']==LEDGER_HASHES[line]
    assert image(patch.read_bytes())['sha256']==PATCH_HASHES[line]
    ledger=json.loads(lp.read_text());targets=[r['path'] for r in ledger['paths']]
    assert len(targets)==len(set(targets))==18
    assert not git(root,'diff','--cached','--name-only').strip()
    before={}
    for row in ledger['paths']:
        path=root/row['path'];actual=image(path.read_bytes()) if path.exists() else None
        assert (actual['sha256'] if actual else None)==row['base_sha256'],(line,row['path'],actual)
        before[row['path']]=actual
    subprocess.run(['git','apply','--check',str(patch)],cwd=root,check=True)
    receipt['branches'][line]={'root':str(root),'head':git(root,'rev-parse','HEAD').decode().strip(),'ledger':str(lp),'ledger_sha256':LEDGER_HASHES[line],'patch':str(patch),'patch_sha256':PATCH_HASHES[line],'before':before,'unrelated_before':unrelated(root,targets)}
for line,branch in receipt['branches'].items():
    root=pathlib.Path(branch['root']);ledger=json.loads(pathlib.Path(branch['ledger']).read_text())
    subprocess.run(['git','apply',branch['patch']],cwd=root,check=True)
    branch['after']={}
    for row in ledger['paths']:
        actual=image((root/row['path']).read_bytes())
        assert actual=={'sha256':row['proposed_sha256'],'bytes':row['proposed_bytes']},(line,row['path'])
        branch['after'][row['path']]=actual
    branch['unrelated_after']=unrelated(root,branch['after'])
    assert branch['unrelated_before']==branch['unrelated_after']
    subprocess.run(['git','diff','--check','--',*branch['after']],cwd=root,check=True)
OUT.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(OUT),'branches':{line:{'head':row['head'],'exact_reviewed_postimages':len(row['after'])} for line,row in receipt['branches'].items()}}))
