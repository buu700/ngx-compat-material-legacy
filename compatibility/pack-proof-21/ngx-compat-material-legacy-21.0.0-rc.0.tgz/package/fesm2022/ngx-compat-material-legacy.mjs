import { BidiModule } from '@angular/cdk/bidi';
import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';

/**
 * Minimal MatCommonModule stand-in for legacy NgModules.
 * Historical MatCommonModule is gone from current @angular/material/core;
 * export CDK Bidi for directionality consumers.
 */
class MatCommonModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, imports: [BidiModule], exports: [BidiModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, imports: [BidiModule, BidiModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatCommonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [BidiModule],
                    exports: [BidiModule],
                }]
        }] });

/**
 * Package root TypeScript facade.
 * Component entry points are secondary packages (e.g. legacy-button).
 * Sass consumers use `@use '@ngx-compat/material-legacy' as mat` via `_index.scss`.
 */
const NGX_MATERIAL_LEGACY_PACKAGE = '@ngx-compat/material-legacy';

/**
 * Generated bundle index. Do not edit.
 */

export { MatCommonModule, NGX_MATERIAL_LEGACY_PACKAGE };
//# sourceMappingURL=ngx-compat-material-legacy.mjs.map
