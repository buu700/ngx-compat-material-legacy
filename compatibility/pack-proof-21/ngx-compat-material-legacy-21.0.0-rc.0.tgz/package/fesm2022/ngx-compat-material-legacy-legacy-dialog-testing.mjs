import { ContentContainerComponentHarness, TestKey, HarnessPredicate } from '@angular/cdk/testing';
import * as i0 from '@angular/core';
import { Directive, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import * as i1 from '@ngx-compat/material-legacy/legacy-dialog';
import { MatLegacyDialogModule } from '@ngx-compat/material-legacy/legacy-dialog';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatDialogHarnessBase` (removed from Angular Material 22).
 */
/** Base class for the `MatDialogHarness` implementation. */
class _MatDialogHarnessBase extends ContentContainerComponentHarness {
    _title = this.locatorForOptional(".mat-dialog-title" /* MatDialogSection.TITLE */);
    _content = this.locatorForOptional(".mat-dialog-content" /* MatDialogSection.CONTENT */);
    _actions = this.locatorForOptional(".mat-dialog-actions" /* MatDialogSection.ACTIONS */);
    /** Gets the id of the dialog. */
    async getId() {
        const id = await (await this.host()).getAttribute('id');
        return id !== '' ? id : null;
    }
    /** Gets the role of the dialog. */
    async getRole() {
        return (await this.host()).getAttribute('role');
    }
    /** Gets the value of the dialog's "aria-label" attribute. */
    async getAriaLabel() {
        return (await this.host()).getAttribute('aria-label');
    }
    /** Gets the value of the dialog's "aria-labelledby" attribute. */
    async getAriaLabelledby() {
        return (await this.host()).getAttribute('aria-labelledby');
    }
    /** Gets the value of the dialog's "aria-describedby" attribute. */
    async getAriaDescribedby() {
        return (await this.host()).getAttribute('aria-describedby');
    }
    /** Closes the dialog by pressing Escape. */
    async close() {
        await (await this.host()).sendKeys(TestKey.ESCAPE);
    }
    /** Gets the text of the dialog's title section. */
    async getTitleText() {
        return (await this._title())?.text() ?? '';
    }
    /** Gets the text of the dialog's content section. */
    async getContentText() {
        return (await this._content())?.text() ?? '';
    }
    /** Gets the text of the dialog's actions section. */
    async getActionsText() {
        return (await this._actions())?.text() ?? '';
    }
}
/** @docs-private */
function createDialogHarnessPredicate(type, options = {}) {
    return new HarnessPredicate(type, options);
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Harness for interacting with a standard `MatDialog` in tests.
 * @deprecated Use `MatDialogHarness` from `@angular/material/dialog/testing` instead.
 * @breaking-change 17.0.0
 */
class MatLegacyDialogHarness extends _MatDialogHarnessBase {
    static hostSelector = '.mat-dialog-container';
    static with(options = {}) {
        return new HarnessPredicate(MatLegacyDialogHarness, options);
    }
    _title = this.locatorForOptional(".mat-dialog-title" /* MatLegacyDialogSection.TITLE */);
    _content = this.locatorForOptional(".mat-dialog-content" /* MatLegacyDialogSection.CONTENT */);
    _actions = this.locatorForOptional(".mat-dialog-actions" /* MatLegacyDialogSection.ACTIONS */);
}

/** Base class for a component that immediately opens a dialog when created. */
class _MatTestDialogOpenerBase {
    dialog;
    static component;
    static config;
    dialogRef;
    closedResult;
    _afterClosedSubscription;
    constructor(dialog) {
        this.dialog = dialog;
        if (!_MatTestDialogOpenerBase.component) {
            throw new Error(`MatTestDialogOpener does not have a component provided.`);
        }
        this.dialogRef = this.dialog.open(_MatTestDialogOpenerBase.component, _MatTestDialogOpenerBase.config || {});
        this._afterClosedSubscription = this.dialogRef.afterClosed().subscribe(result => {
            this.closedResult = result;
        });
    }
    ngOnDestroy() {
        this._afterClosedSubscription.unsubscribe();
        _MatTestDialogOpenerBase.component = undefined;
        _MatTestDialogOpenerBase.config = undefined;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _MatTestDialogOpenerBase, deps: [{ token: i1.MatLegacyDialog }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: _MatTestDialogOpenerBase, isStandalone: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: _MatTestDialogOpenerBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i1.MatLegacyDialog }] });

/**
 * Test component that immediately opens a dialog when created.
 * @deprecated Use `MatTestDialogOpener` from `@angular/material/dialog/testing` instead.
 * @breaking-change 17.0.0
 */
class MatTestLegacyDialogOpener extends _MatTestDialogOpenerBase {
    constructor(dialog) {
        super(dialog);
    }
    /** Static method that prepares this class to open the provided component. */
    static withComponent(component, config) {
        _MatTestDialogOpenerBase.component = component;
        _MatTestDialogOpenerBase.config = config;
        return MatTestLegacyDialogOpener;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatTestLegacyDialogOpener, deps: [{ token: i1.MatLegacyDialog }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MatTestLegacyDialogOpener, isStandalone: false, selector: "mat-test-dialog-opener", host: { properties: { "attr.mat-id-collision": "null" } }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatTestLegacyDialogOpener, decorators: [{
            type: Component,
            args: [{
                    standalone: false,
                    selector: 'mat-test-dialog-opener',
                    template: '',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[attr.mat-id-collision]': 'null',
                    },
                }]
        }], ctorParameters: () => [{ type: i1.MatLegacyDialog }] });
class MatTestLegacyDialogOpenerModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatTestLegacyDialogOpenerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: MatTestLegacyDialogOpenerModule, declarations: [MatTestLegacyDialogOpener], imports: [MatLegacyDialogModule, NoopAnimationsModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatTestLegacyDialogOpenerModule, imports: [MatLegacyDialogModule, NoopAnimationsModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MatTestLegacyDialogOpenerModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [MatTestLegacyDialogOpener],
                    imports: [MatLegacyDialogModule, NoopAnimationsModule],
                }]
        }] });

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MatLegacyDialogHarness, MatTestLegacyDialogOpener, MatTestLegacyDialogOpenerModule };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-dialog-testing.mjs.map
