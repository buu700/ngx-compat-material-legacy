import * as i0 from '@angular/core';
import { InjectionToken, ElementRef, AfterViewChecked, OnDestroy, ChangeDetectorRef, EventEmitter, QueryList, NgZone } from '@angular/core';
import { FocusableOption, FocusOrigin } from '@angular/cdk/a11y';
import { BooleanInput } from '@angular/cdk/coercion';
import { Subject, Observable } from 'rxjs';
import * as i3 from '@angular/material/core';
import { ErrorStateMatcher } from '@angular/material/core';
export { VERSION as LEGACY_VERSION, DateAdapter as LegacyDateAdapter, ErrorStateMatcher as LegacyErrorStateMatcher, NativeDateAdapter as LegacyNativeDateAdapter, NativeDateModule as LegacyNativeDateModule, RippleGlobalOptions as LegacyRippleGlobalOptions, ShowOnDirtyErrorStateMatcher as LegacyShowOnDirtyErrorStateMatcher, MATERIAL_ANIMATIONS, MAT_DATE_FORMATS as MAT_LEGACY_DATE_FORMATS, MAT_DATE_LOCALE as MAT_LEGACY_DATE_LOCALE, MAT_NATIVE_DATE_FORMATS as MAT_LEGACY_NATIVE_DATE_FORMATS, MAT_RIPPLE_GLOBAL_OPTIONS as MAT_LEGACY_RIPPLE_GLOBAL_OPTIONS, MatDateFormats as MatLegacyDateFormats, MatLine as MatLegacyLine, MatLineModule as MatLegacyLineModule, MatNativeDateModule as MatLegacyNativeDateModule, MatRipple as MatLegacyRipple, MatRippleModule as MatLegacyRippleModule } from '@angular/material/core';
import * as i4 from '@angular/common';
import * as i1 from '@angular/cdk/bidi';
import { FormGroupDirective, NgForm, NgControl } from '@angular/forms';
import { Platform } from '@angular/cdk/platform';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Describes a parent component that manages a list of options.
 * Contains properties that the options can inherit.
 * @docs-private
 */
interface MatOptionParentComponent {
    disableRipple?: boolean;
    multiple?: boolean;
    inertGroups?: boolean;
    hideSingleSelectionIndicator?: boolean;
}
/**
 * Injection token used to provide the parent component to options.
 */
declare const MAT_OPTION_PARENT_COMPONENT: InjectionToken<MatOptionParentComponent>;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** @docs-private */
type Constructor<T> = new (...args: any[]) => T;
/**
 * This is a permissive type for abstract class constructors.
 * @docs-private
 */
type AbstractConstructor<T = object> = abstract new (...args: any[]) => T;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** @docs-private */
interface CanColor {
    /** Theme color palette for the component. */
    color: ThemePalette;
    /** Default color to fall back to if no value is set. */
    defaultColor: ThemePalette | undefined;
}
type CanColorCtor = Constructor<CanColor> & AbstractConstructor<CanColor>;
/** @docs-private */
interface HasElementRef {
    _elementRef: ElementRef;
}
/** Possible color palette values. */
type ThemePalette = 'primary' | 'accent' | 'warn' | undefined;
/** Mixin to augment a directive with a `color` property. */
declare function mixinColor<T extends AbstractConstructor<HasElementRef>>(base: T, defaultColor?: ThemePalette): CanColorCtor & T;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** @docs-private */
interface CanDisable {
    /** Whether the component is disabled. */
    disabled: boolean;
}
type CanDisableCtor = Constructor<CanDisable> & AbstractConstructor<CanDisable>;
/** Mixin to augment a directive with a `disabled` property. */
declare function mixinDisabled<T extends AbstractConstructor<{}>>(base: T): CanDisableCtor & T;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** @docs-private */
interface CanDisableRipple {
    /** Whether ripples are disabled. */
    disableRipple: boolean;
}
type CanDisableRippleCtor = Constructor<CanDisableRipple> & AbstractConstructor<CanDisableRipple>;
/** Mixin to augment a directive with a `disableRipple` property. */
declare function mixinDisableRipple<T extends AbstractConstructor<{}>>(base: T): CanDisableRippleCtor & T;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** @docs-private */
interface HasTabIndex {
    /** Tabindex of the component. */
    tabIndex: number;
    /** Tabindex to which to fall back to if no value is set. */
    defaultTabIndex: number;
}
type HasTabIndexCtor = Constructor<HasTabIndex> & AbstractConstructor<HasTabIndex>;
/** Mixin to augment a directive with a `tabIndex` property. */
declare function mixinTabIndex<T extends AbstractConstructor<CanDisable>>(base: T, defaultTabIndex?: number): HasTabIndexCtor & T;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** @docs-private */
interface CanUpdateErrorState {
    /** Updates the error state based on the provided error state matcher. */
    updateErrorState(): void;
    /** Whether the component is in an error state. */
    errorState: boolean;
    /** An object used to control the error state of the component. */
    errorStateMatcher: ErrorStateMatcher;
}
type CanUpdateErrorStateCtor = Constructor<CanUpdateErrorState> & AbstractConstructor<CanUpdateErrorState>;
/** @docs-private */
interface HasErrorState {
    _parentFormGroup: FormGroupDirective;
    _parentForm: NgForm;
    _defaultErrorStateMatcher: ErrorStateMatcher;
    ngControl: NgControl;
    stateChanges: Subject<void>;
}
/**
 * Mixin to augment a directive with updateErrorState method.
 * For component with `errorState` and need to update `errorState`.
 */
declare function mixinErrorState<T extends AbstractConstructor<HasErrorState>>(base: T): CanUpdateErrorStateCtor & T;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Mixin that adds an initialized property to a directive which, when subscribed to, will emit a
 * value once markInitialized has been called, which should be done during the ngOnInit function.
 * If the subscription is made after it has already been marked as initialized, then it will trigger
 * an emit immediately.
 * @docs-private
 */
interface HasInitialized {
    /** Stream that emits once during the directive/component's ngOnInit. */
    initialized: Observable<void>;
    /**
     * Sets the state as initialized and must be called during ngOnInit to notify subscribers that
     * the directive has been initialized.
     * @docs-private
     */
    _markInitialized: () => void;
}
type HasInitializedCtor = Constructor<HasInitialized>;
/** Mixin to augment a directive with an initialized property that will emits when ngOnInit ends. */
declare function mixinInitialized<T extends Constructor<{}>>(base: T): HasInitializedCtor & T;

/** @docs-private */
declare const _MatOptgroupMixinBase: Constructor<CanDisable> & AbstractConstructor<CanDisable> & {
    new (): {};
};
declare class _MatOptgroupBase extends _MatOptgroupMixinBase implements CanDisable {
    /** Label for the option group. */
    label: string;
    /** Unique id for the underlying label. */
    _labelId: string;
    /** Whether the group is in inert a11y mode. */
    _inert: boolean;
    constructor(parent?: MatOptionParentComponent);
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatOptgroupBase, [{ optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_MatOptgroupBase, never, never, { "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
/**
 * Injection token that can be used to reference instances of `MatOptgroup`. It serves as
 * alternative token to the actual `MatOptgroup` class which could cause unnecessary
 * retention of the class and its component metadata.
 */
declare const MAT_OPTGROUP: InjectionToken<_MatOptgroupBase>;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Event object emitted by MatOption when selected or deselected. */
declare class MatOptionSelectionChange<T = any> {
    /** Reference to the option that emitted the event. */
    source: _MatOptionBase<T>;
    /** Whether the change in the option's value was a result of a user action. */
    isUserInput: boolean;
    constructor(
    /** Reference to the option that emitted the event. */
    source: _MatOptionBase<T>, 
    /** Whether the change in the option's value was a result of a user action. */
    isUserInput?: boolean);
}
declare class _MatOptionBase<T = any> implements FocusableOption, AfterViewChecked, OnDestroy {
    private _element;
    _changeDetectorRef: ChangeDetectorRef;
    private _parent;
    readonly group: _MatOptgroupBase;
    private _selected;
    private _active;
    private _disabled;
    private _mostRecentViewValue;
    /** Whether the wrapping component is in multiple selection mode. */
    get multiple(): boolean | undefined;
    /** Whether or not the option is currently selected. */
    get selected(): boolean;
    /** The form value of the option. */
    value: T;
    /** The unique ID of the option. */
    id: string;
    /** Whether the option is disabled. */
    get disabled(): boolean;
    set disabled(value: BooleanInput);
    /** Whether ripples for the option are disabled. */
    get disableRipple(): boolean;
    /** Whether to display checkmark for single-selection. */
    get hideSingleSelectionIndicator(): boolean;
    /** Event emitted when the option is selected or deselected. */
    readonly onSelectionChange: EventEmitter<MatOptionSelectionChange<T>>;
    /** Element containing the option's text. */
    _text: ElementRef<HTMLElement> | undefined;
    /** Emits when the state of the option changes and any parents have to be notified. */
    readonly _stateChanges: Subject<void>;
    constructor(_element: ElementRef<HTMLElement>, _changeDetectorRef: ChangeDetectorRef, _parent: MatOptionParentComponent, group: _MatOptgroupBase);
    /**
     * Whether or not the option is currently active and ready to be selected.
     * An active option displays styles as if it is focused, but the
     * focus is actually retained somewhere else. This comes in handy
     * for components like autocomplete where focus must remain on the input.
     */
    get active(): boolean;
    /**
     * The displayed value of the option. It is necessary to show the selected option in the
     * select's trigger.
     */
    get viewValue(): string;
    /** Selects the option. */
    select(emitEvent?: boolean): void;
    /** Deselects the option. */
    deselect(emitEvent?: boolean): void;
    /** Sets focus onto this option. */
    focus(_origin?: FocusOrigin, options?: FocusOptions): void;
    /**
     * This method sets display styles on the option to make it appear
     * active. This is used by the ActiveDescendantKeyManager so key
     * events will display the proper options as active on arrow key events.
     */
    setActiveStyles(): void;
    /**
     * This method removes display styles on the option that made it appear
     * active. This is used by the ActiveDescendantKeyManager so key
     * events will display the proper options as active on arrow key events.
     */
    setInactiveStyles(): void;
    /** Gets the label to be used when determining whether the option should be focused. */
    getLabel(): string;
    /** Ensures the option is selected when activated from the keyboard. */
    _handleKeydown(event: KeyboardEvent): void;
    /**
     * `Selects the option while indicating the selection came from the user. Used to
     * determine if the select's view -> model callback should be invoked.`
     */
    _selectViaInteraction(): void;
    /** Returns the correct tabindex for the option depending on disabled state. */
    _getTabIndex(): string;
    /** Gets the host DOM element. */
    _getHostElement(): HTMLElement;
    ngAfterViewChecked(): void;
    ngOnDestroy(): void;
    /** Emits the selection change event. */
    private _emitSelectionChangeEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatOptionBase<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<_MatOptionBase<any>, never, never, { "value": { "alias": "value"; "required": false; }; "id": { "alias": "id"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "onSelectionChange": "onSelectionChange"; }, never, never, true, never>;
}

/**
 * Component that is used to group instances of `mat-option`.
 * @deprecated Use `MatOptgroup` from `@angular/material/core` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyOptgroup extends _MatOptgroupBase {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyOptgroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyOptgroup, "mat-optgroup", ["matOptgroup"], { "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, ["*", "mat-option, ng-container"], false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Single option inside of a `<mat-select>` element.
 * @deprecated Use `MatOption` from `@angular/material/core` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyOption<T = any> extends _MatOptionBase<T> {
    constructor(element: ElementRef<HTMLElement>, changeDetectorRef: ChangeDetectorRef, parent: MatOptionParentComponent, group: MatLegacyOptgroup);
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyOption<any>, [null, null, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyOption<any>, "mat-option", ["matOption"], {}, {}, never, ["*"], false, never>;
}

declare class MatCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatCommonModule, never, [typeof i1.BidiModule], [typeof i1.BidiModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatCommonModule>;
}

/** Possible states for a pseudo checkbox. */
type MatLegacyPseudoCheckboxState = 'unchecked' | 'checked' | 'indeterminate';
/**
 * Decorative checkbox without form control semantics. Parent components own ARIA.
 * Selector/classes match historical mat-pseudo-checkbox for legacy list/option rendering.
 */
declare class MatLegacyPseudoCheckbox {
    /** Display state of the checkbox. */
    state: MatLegacyPseudoCheckboxState;
    /** Whether the checkbox is disabled. */
    disabled: boolean;
    /**
     * Appearance of the pseudo checkbox. Default appearance of 'full' renders a checkmark/mixedmark
     * indicator inside a square box. 'minimal' appearance only renders the checkmark/mixedmark.
     */
    appearance: 'minimal' | 'full';
    /** Resolved through public MATERIAL_ANIMATIONS / reduced-motion policy (F04). */
    protected _animationsDisabled: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyPseudoCheckbox, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyPseudoCheckbox, "mat-pseudo-checkbox", never, { "state": { "alias": "state"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "appearance": { "alias": "appearance"; "required": false; }; }, {}, never, never, true, never>;
    static ngAcceptInputType_disabled: unknown;
}

declare class MatLegacyPseudoCheckboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyPseudoCheckboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacyPseudoCheckboxModule, never, [typeof MatLegacyPseudoCheckbox, typeof i1.BidiModule], [typeof MatLegacyPseudoCheckbox, typeof i1.BidiModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacyPseudoCheckboxModule>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 */

declare function _countGroupLabelsBeforeOption(optionIndex: number, options: QueryList<_MatOptionBase>, optionGroups: QueryList<_MatOptgroupBase>): number;
/**
 * Determines the position to which to scroll a panel in order for an option to be into view.
 * @param optionOffset Offset of the option from the top of the panel.
 * @param optionHeight Height of the options.
 * @param currentScrollPosition Current scroll position of the panel.
 * @param panelHeight Height of the panel.
 * @docs-private
 */
declare function _getOptionScrollPosition(optionOffset: number, optionHeight: number, currentScrollPosition: number, panelHeight: number): number;

/**
 * @deprecated Use `MatOptionModule` from `@angular/material/core` instead.
 * @breaking-change 17.0.0
 */
declare class MatLegacyOptionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyOptionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacyOptionModule, [typeof MatLegacyOption, typeof MatLegacyOptgroup], [typeof i3.MatRippleModule, typeof i4.CommonModule, typeof MatCommonModule, typeof MatLegacyPseudoCheckboxModule], [typeof MatLegacyOption, typeof MatLegacyOptgroup]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacyOptionModule>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned legacy motion helper. Reads the public MATERIAL_ANIMATIONS token and
 * public ANIMATION_MODULE_TYPE. Does not call private Material helpers
 * (_getAnimationsState / _animationsDisabled).
 */

/** Owned state labels for lifecycle/tests (mirrors Material public semantics). */
type LegacyAnimationsState = 'enabled' | 'di-disabled' | 'reduced-motion';
/**
 * Optional override token for unit tests that cannot construct Material's
 * MATERIAL_ANIMATIONS provider graph. Production code should prefer
 * MATERIAL_ANIMATIONS / ANIMATION_MODULE_TYPE.
 */
declare const LEGACY_ANIMATIONS_TEST_OVERRIDE: InjectionToken<LegacyAnimationsState | null>;
/**
 * Resolves whether legacy overlay motion should run.
 * Must be called in an injection context.
 */
declare function getLegacyAnimationsState(): LegacyAnimationsState;
/** True when DI or reduced-motion asks overlays to skip meaningful motion. */
declare function legacyAnimationsDisabled(): boolean;
/** Zero-duration params used when dialog (and similar) should noop motion. */
declare const LEGACY_ZERO_ANIMATION_PARAMS: {
    readonly enterAnimationDuration: "0ms";
    readonly exitAnimationDuration: "0ms";
};
/** Generic zero map for parameterized overlay recipes. */
declare function zeroAnimationParams<T extends Record<string, string>>(defaults: T): T;
/**
 * Build `{value, params}` for Angular animation host bindings.
 * When disabled, every provided default duration becomes `0ms`.
 */
declare function legacyAnimationTriggerState<T extends Record<string, string>>(value: string, defaults: T, disabled: boolean): {
    value: string;
    params: T;
};

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Copyright (c) 2026 Ryan Lester
 */
/** True when the motion event was dispatched on the listening element. */
declare function legacyHostMotionEvent(event: {
    target: EventTarget | null;
    currentTarget: EventTarget | null;
}): boolean;
/**
 * Returns the animation name when it has not already completed.
 * The same name completes once until the caller resets the previous name.
 */
declare function legacyNextMotionCompletion(previous: string | undefined, animationName: string): string | undefined;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Engine-independent motion curve/duration constants (Material 16.2.14).
 */
/** CSS cubic-bezier curves historically exported as AnimationCurves. */
declare class LegacyAnimationCurves {
    static STANDARD_CURVE: string;
    static DECELERATION_CURVE: string;
    static ACCELERATION_CURVE: string;
    static SHARP_CURVE: string;
}
/** CSS durations historically exported as AnimationDurations. */
declare class LegacyAnimationDurations {
    static COMPLEX: string;
    static ENTERING: string;
    static EXITING: string;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Historical sanity-check tokens. Current Material removed MatCommonModule's
 * Hammer/theme/version checks; tokens are preserved for DI identity of consumers
 * that inject them. MatLegacyCommonModule does not re-run Hammer detection.
 */

/** Granular sanity checks historically accepted by MatCommonModule. */
interface LegacyGranularSanityChecks {
    doctype?: boolean;
    theme?: boolean;
    version?: boolean;
}
/** Possible sanity check values. */
type LegacySanityChecks = boolean | LegacyGranularSanityChecks;
/** Injection token that can be used to disable or configure sanity checks. */
declare const MATERIAL_LEGACY_SANITY_CHECKS: InjectionToken<LegacySanityChecks>;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned line-count helper (S25). MatLine / MatLineModule remain public upstream aliases.
 */

/**
 * Helper that takes a query list of lines and sets the correct class on the host.
 * Historical `setLines` behavior: clear stale 2/3/multi classes, then apply based on length.
 */
declare function legacySetLines(lines: QueryList<unknown>, element: ElementRef<HTMLElement>, prefix?: string): void;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Historical MAT_DATE_LOCALE_FACTORY. Current Material inlines the factory on the token;
 * preserve the named export for legacy consumers.
 */
declare function MAT_LEGACY_DATE_LOCALE_FACTORY(): unknown;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Shadow DOM helpers based on Material/CDK 16.2.14 semantics (S03).
 * Do not import current underscore CDK platform helpers.
 */
/** Checks whether the user's browser supports Shadow DOM. */
declare function legacySupportsShadowDom(): boolean;
/**
 * Gets the shadow root of an element, if supported and the element is inside the Shadow DOM.
 * Uses the element's realm (`ownerDocument.defaultView.ShadowRoot`) when reachable rather than
 * an unguarded global `ShadowRoot` constructor.
 */
declare function legacyGetShadowRoot(element: HTMLElement): ShadowRoot | null;
/**
 * Gets the target of an event while accounting for Shadow DOM composed paths.
 * Preserves historical empty/missing composedPath fallback to `event.target`.
 */
declare function legacyGetEventTarget<T extends EventTarget>(event: Event): T | null;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned numeric-recognition helper based on CDK 16.2.14 (S04).
 * Do not import current underscore `_isNumberValue`.
 */
/**
 * Whether the provided value is considered a number for sorting/filtering.
 * Empty strings, whitespace, null, booleans, and mixed suffixes follow historical
 * parseFloat+Number semantics (not truthiness / bare Number()).
 */
declare function legacyIsNumberValue(value: unknown): boolean;

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/** Possible states for a ripple element. */
declare enum LegacyRippleState {
    FADING_IN = 0,
    VISIBLE = 1,
    FADING_OUT = 2,
    HIDDEN = 3
}
/** Configuration for the animation of a ripple. */
interface LegacyRippleAnimationConfig {
    enterDuration?: number;
    exitDuration?: number;
}
/** Extra options for launching a ripple. */
type LegacyRippleConfig = {
    color?: string;
    centered?: boolean;
    radius?: number;
    persistent?: boolean;
    animation?: LegacyRippleAnimationConfig;
    terminateOnPointerUp?: boolean;
};
/**
 * Reference to a previously launched ripple element.
 */
declare class LegacyRippleRef {
    private _renderer;
    /** Reference to the ripple HTML element. */
    element: HTMLElement;
    /** Ripple configuration used for the ripple. */
    config: LegacyRippleConfig;
    _animationForciblyDisabledThroughCss: boolean;
    /** Current state of the ripple. */
    state: LegacyRippleState;
    constructor(_renderer: {
        fadeOutRipple(ref: LegacyRippleRef): void;
    }, 
    /** Reference to the ripple HTML element. */
    element: HTMLElement, 
    /** Ripple configuration used for the ripple. */
    config: LegacyRippleConfig, _animationForciblyDisabledThroughCss?: boolean);
    /** Fades out the ripple element. */
    fadeOut(): void;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned finite ripple renderer (S23/S26). Current RippleRenderer is @docs-private (S21).
 */

/** Target contract for launching ripples. */
interface LegacyRippleTarget {
    rippleConfig: LegacyRippleConfig;
    rippleDisabled: boolean;
}
/** Default enter/exit durations (historical defaultRippleAnimationConfig). */
declare const legacyDefaultRippleAnimationConfig: {
    enterDuration: number;
    exitDuration: number;
};
/**
 * Finite DOM ripple renderer used by legacy chips and tab links.
 * Constructor and public methods match the historical 4-arg form used by those consumers.
 */
declare class LegacyRippleRenderer implements EventListenerObject {
    private _target;
    private _ngZone;
    private _platform;
    private _containerElement;
    private _triggerElement;
    private _isPointerDown;
    private _activeRipples;
    private _mostRecentTransientRipple;
    private _lastTouchStartEvent;
    private _pointerUpEventsRegistered;
    private _containerRect;
    private static _eventManager;
    constructor(_target: LegacyRippleTarget, _ngZone: NgZone, elementOrElementRef: HTMLElement | ElementRef<HTMLElement>, _platform: Platform);
    fadeInRipple(x: number, y: number, config?: LegacyRippleConfig): LegacyRippleRef;
    fadeOutRipple(rippleRef: LegacyRippleRef): void;
    fadeOutAll(): void;
    fadeOutAllNonPersistent(): void;
    setupTriggerEvents(elementOrElementRef: HTMLElement | ElementRef<HTMLElement>): void;
    handleEvent(event: Event): void;
    private _finishRippleTransition;
    private _startFadeOutTransition;
    private _destroyRipple;
    private _onMousedown;
    private _onTouchStart;
    private _onPointerUp;
    private _getActiveRipples;
    _removeTriggerEvents(): void;
}

export { LEGACY_ANIMATIONS_TEST_OVERRIDE, LEGACY_ZERO_ANIMATION_PARAMS, LegacyAnimationCurves, LegacyAnimationDurations, LegacyRippleRef, LegacyRippleRenderer, LegacyRippleState, MATERIAL_LEGACY_SANITY_CHECKS, MAT_LEGACY_DATE_LOCALE_FACTORY, MAT_OPTGROUP as MAT_LEGACY_OPTGROUP, MAT_OPTION_PARENT_COMPONENT as MAT_LEGACY_OPTION_PARENT_COMPONENT, MatCommonModule, MatCommonModule as MatLegacyCommonModule, MatLegacyOptgroup, MatLegacyOption, MatLegacyOptionModule, MatOptionSelectionChange as MatLegacyOptionSelectionChange, MatLegacyPseudoCheckbox, MatLegacyPseudoCheckboxModule, _MatOptgroupBase as _MatLegacyOptgroupBase, _MatOptionBase as _MatLegacyOptionBase, _MatOptgroupBase, _MatOptionBase, _countGroupLabelsBeforeOption as _countGroupLabelsBeforeLegacyOption, _getOptionScrollPosition as _getLegacyOptionScrollPosition, getLegacyAnimationsState, legacyAnimationTriggerState, legacyAnimationsDisabled, legacyDefaultRippleAnimationConfig, legacyGetEventTarget, legacyGetShadowRoot, legacyHostMotionEvent, legacyIsNumberValue, mixinColor as legacyMixinColor, mixinDisableRipple as legacyMixinDisableRipple, mixinDisabled as legacyMixinDisabled, mixinErrorState as legacyMixinErrorState, mixinInitialized as legacyMixinInitialized, mixinTabIndex as legacyMixinTabIndex, legacyNextMotionCompletion, legacySetLines, legacySupportsShadowDom, zeroAnimationParams };
export type { LegacyAnimationsState, CanColor as LegacyCanColor, CanDisable as LegacyCanDisable, CanDisableRipple as LegacyCanDisableRipple, CanUpdateErrorState as LegacyCanUpdateErrorState, LegacyGranularSanityChecks, HasInitialized as LegacyHasInitialized, HasTabIndex as LegacyHasTabIndex, LegacyRippleAnimationConfig, LegacyRippleConfig, LegacyRippleTarget, LegacySanityChecks, ThemePalette as LegacyThemePalette, MatOptionParentComponent as MatLegacyOptionParentComponent, MatLegacyPseudoCheckboxState };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-core.d.ts.map
