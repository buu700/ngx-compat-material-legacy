import * as i0 from '@angular/core';
import { EventEmitter, OnDestroy, ComponentRef, Injector, Type, InjectionToken, TemplateRef, OnInit, OnChanges, ElementRef, SimpleChanges } from '@angular/core';
import * as i3 from '@angular/cdk/dialog';
import { CdkDialogContainer, DialogRef } from '@angular/cdk/dialog';
import { MatDialogConfig, DialogPosition, MatDialogState } from '@angular/material/dialog';
export { AutoFocusTarget as LegacyAutoFocusTarget, DialogPosition as LegacyDialogPosition, DialogRole as LegacyDialogRole, MatDialogState as MatLegacyDialogState } from '@angular/material/dialog';
import * as i4 from '@angular/cdk/overlay';
import { Overlay, ScrollStrategy, OverlayContainer, ComponentType } from '@angular/cdk/overlay';
import { Location } from '@angular/common';
import { Observable, Subject } from 'rxjs';
import { FocusOrigin } from '@angular/cdk/a11y';
import * as i5 from '@angular/cdk/portal';
import * as i1 from '@angular/cdk/bidi';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 `_MatDialogContainerBase` (removed from Angular Material 22).
 * Constructor adapted to current CDK `CdkDialogContainer` inject()-based API.
 */

/** Event that captures the state of dialog container animations. */
interface LegacyDialogAnimationEvent {
    state: 'opened' | 'opening' | 'closing' | 'closed';
    totalTime: number;
}
/**
 * Base class for the `MatDialogContainer`. The base class does not implement
 * animations as these are left to implementers of the dialog container.
 */
declare abstract class _MatDialogContainerBase extends CdkDialogContainer<MatDialogConfig> {
    /** Emits when an animation state changes. */
    _animationStateChanged: EventEmitter<LegacyDialogAnimationEvent>;
    constructor();
    /** Starts the dialog exit animation. */
    abstract _startExitAnimation(): void;
    protected _captureInitialFocus(): void;
    /**
     * Callback for when the open dialog animation has finished. Intended to
     * be called by sub-classes that use different animation implementations.
     */
    protected _openAnimationDone(totalTime: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatDialogContainerBase, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<_MatDialogContainerBase, "ng-component", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Legacy dialog container motion follows Material 22's CSS + timer pattern
 * (no `@angular/animations` engine on the primary entry). Historical
 * `matDialogAnimations` / `matLegacyDialogAnimations` recipes live under
 * `@ngx-compat/material-legacy/legacy-dialog/animations`.
 */

/**
 * Internal component that wraps user-provided dialog content.
 * Animation is based on https://material.io/guidelines/motion/choreography.html.
 * @docs-private
 * @deprecated Use `MatDialogContainer` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyDialogContainer extends _MatDialogContainerBase implements OnDestroy {
    private readonly _legacyAnimationsDisabled;
    /** Whether CSS transitions should run (MATERIAL_ANIMATIONS / reduced-motion / Noop). */
    readonly _animationsEnabled: boolean;
    private _enterAnimationDuration;
    private _exitAnimationDuration;
    private _animationTimer;
    private _hostElement;
    protected _contentAttached(): void;
    private _startOpenAnimation;
    /** Starts the dialog exit animation. */
    _startExitAnimation(): void;
    private _finishDialogOpen;
    private _finishDialogClose;
    private _clearAnimationClasses;
    private _waitForAnimationToComplete;
    private _requestAnimationFrame;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogContainer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MatLegacyDialogContainer, "mat-dialog-container", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 dialog ref adapted for Angular 22 peers. Uses shared
 * `MatDialogState` / `DialogPosition` from `@angular/material/dialog`.
 */

/**
 * Reference to a dialog opened via the MatDialog service.
 * @deprecated Use `MatDialogRef` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyDialogRef<T, R = any> {
    private _ref;
    _containerInstance: _MatDialogContainerBase;
    /** The instance of component opened into the dialog. */
    componentInstance: T;
    /**
     * `ComponentRef` of the component opened into the dialog. Will be
     * null when the dialog is opened using a `TemplateRef`.
     */
    readonly componentRef: ComponentRef<T> | null;
    /** Whether the user is allowed to close the dialog. */
    disableClose: boolean | undefined;
    /** Unique ID for the dialog. */
    id: string;
    /** Subject for notifying the user that the dialog has finished opening. */
    private readonly _afterOpened;
    /** Subject for notifying the user that the dialog has started closing. */
    private readonly _beforeClosed;
    /** Result to be passed to afterClosed. */
    private _result;
    /** Handle to the timeout that's running as a fallback in case the exit animation doesn't fire. */
    private _closeFallbackTimeout;
    /** Current state of the dialog. */
    private _state;
    /** Interaction that caused the dialog to close. */
    private _closeInteractionType;
    constructor(_ref: DialogRef<R, T>, config: MatDialogConfig, _containerInstance: _MatDialogContainerBase);
    /** Close the dialog. */
    close(dialogResult?: R): void;
    /** Gets an observable that is notified when the dialog is finished opening. */
    afterOpened(): Observable<void>;
    /** Gets an observable that is notified when the dialog is finished closing. */
    afterClosed(): Observable<R | undefined>;
    /** Gets an observable that is notified when the dialog has started closing. */
    beforeClosed(): Observable<R | undefined>;
    /** Gets an observable that emits when the overlay's backdrop has been clicked. */
    backdropClick(): Observable<MouseEvent>;
    /** Gets an observable that emits when keydown events are targeted on the overlay. */
    keydownEvents(): Observable<KeyboardEvent>;
    /** Updates the dialog's position. */
    updatePosition(position?: DialogPosition): this;
    /** Updates the dialog's width and height. */
    updateSize(width?: string, height?: string): this;
    /** Add a CSS class or an array of classes to the overlay pane. */
    addPanelClass(classes: string | string[]): this;
    /** Remove a CSS class or an array of classes from the overlay pane. */
    removePanelClass(classes: string | string[]): this;
    /** Gets the current state of the dialog's lifecycle. */
    getState(): MatDialogState;
    private _finishDialogClose;
}
/**
 * Closes the dialog with the specified interaction type.
 * @docs-private
 */
declare function _closeDialogVia<R>(ref: MatLegacyDialogRef<R>, interactionType: FocusOrigin, result?: R): void;

/** @docs-private */
declare function MAT_DIALOG_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy;
/**
 * Base class for dialog services. The base dialog service allows
 * for arbitrary dialog refs and dialog container components.
 */
declare abstract class _MatDialogBase<C extends _MatDialogContainerBase> implements OnDestroy {
    private _overlay;
    private _defaultOptions;
    private _parentDialog;
    private _dialogRefConstructor;
    private _dialogContainerType;
    private _dialogDataToken;
    private readonly _openDialogsAtThisLevel;
    private readonly _afterAllClosedAtThisLevel;
    private readonly _afterOpenedAtThisLevel;
    private _scrollStrategy;
    protected _idPrefix: string;
    private _dialog;
    protected dialogConfigClass: typeof MatDialogConfig;
    /** Keeps track of the currently-open dialogs. */
    get openDialogs(): MatLegacyDialogRef<any>[];
    /** Stream that emits when a dialog has been opened. */
    get afterOpened(): Subject<MatLegacyDialogRef<any>>;
    private _getAfterAllClosed;
    /**
     * Stream that emits when all open dialog have finished closing.
     * Will emit on subscribe if there are no open dialogs to begin with.
     */
    readonly afterAllClosed: Observable<void>;
    constructor(_overlay: Overlay, injector: Injector, _defaultOptions: MatDialogConfig | undefined, _parentDialog: _MatDialogBase<C> | undefined, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 15.0.0
     */
    _overlayContainer: OverlayContainer, scrollStrategy: any, _dialogRefConstructor: Type<MatLegacyDialogRef<any>>, _dialogContainerType: Type<C>, _dialogDataToken: InjectionToken<any>, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 14.0.0
     */
    _animationMode?: 'NoopAnimations' | 'BrowserAnimations');
    open<T, D = any, R = any>(component: ComponentType<T>, config?: MatDialogConfig<D>): MatLegacyDialogRef<T, R>;
    open<T, D = any, R = any>(template: TemplateRef<T>, config?: MatDialogConfig<D>): MatLegacyDialogRef<T, R>;
    open<T, D = any, R = any>(template: ComponentType<T> | TemplateRef<T>, config?: MatDialogConfig<D>): MatLegacyDialogRef<T, R>;
    /** Closes all of the currently-open dialogs. */
    closeAll(): void;
    /**
     * Finds an open dialog by its id.
     * @param id ID to use when looking up the dialog.
     */
    getDialogById(id: string): MatLegacyDialogRef<any> | undefined;
    ngOnDestroy(): void;
    private _closeDialogs;
    static ɵfac: i0.ɵɵFactoryDeclaration<_MatDialogBase<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<_MatDialogBase<any>>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * @deprecated Use `MatDialogConfig` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyDialogConfig<D = any> extends MatDialogConfig<D> {
    /** Duration of the enter animation. Has to be a valid CSS value (e.g. 100ms). */
    enterAnimationDuration?: string;
    /** Duration of the exit animation. Has to be a valid CSS value (e.g. 50ms). */
    exitAnimationDuration?: string;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Injection token that can be used to access the data that was passed in to a dialog.
 * @deprecated Use `MAT_DIALOG_DATA` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare const MAT_LEGACY_DIALOG_DATA: InjectionToken<any>;
/**
 * Injection token that can be used to specify default dialog options.
 * @deprecated Use `MAT_DIALOG_DEFAULT_OPTIONS` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare const MAT_LEGACY_DIALOG_DEFAULT_OPTIONS: InjectionToken<MatLegacyDialogConfig<any>>;
/**
 * Injection token that determines the scroll handling while the dialog is open.
 * @deprecated Use `MAT_DIALOG_SCROLL_STRATEGY` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare const MAT_LEGACY_DIALOG_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
/**
 * @docs-private
 * @deprecated Use `MAT_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare function MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY(overlay: Overlay): () => ScrollStrategy;
/**
 * @docs-private
 * @deprecated Use `MAT_DIALOG_SCROLL_STRATEGY_PROVIDER` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare const MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER: {
    provide: InjectionToken<() => ScrollStrategy>;
    deps: (typeof Overlay)[];
    useFactory: typeof MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY;
};
/**
 * Service to open Material Design modal dialogs.
 * @deprecated Use `MatDialog` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyDialog extends _MatDialogBase<MatLegacyDialogContainer> {
    protected dialogConfigClass: typeof MatLegacyDialogConfig;
    constructor(overlay: Overlay, injector: Injector, 
    /**
     * @deprecated `_location` parameter to be removed.
     * @breaking-change 10.0.0
     */
    _location: Location, defaultOptions: MatLegacyDialogConfig, scrollStrategy: any, parentDialog: MatLegacyDialog, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 15.0.0
     */
    overlayContainer: OverlayContainer, 
    /**
     * @deprecated No longer used. To be removed.
     * @breaking-change 14.0.0
     */
    animationMode?: 'NoopAnimations' | 'BrowserAnimations');
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialog, [null, null, { optional: true; }, { optional: true; }, null, { optional: true; skipSelf: true; }, null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MatLegacyDialog>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Button that will close the current dialog.
 * @deprecated Use `MatDialogClose` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyDialogClose implements OnInit, OnChanges {
    /**
     * Reference to the containing dialog.
     * @deprecated `dialogRef` property to become private.
     * @breaking-change 13.0.0
     */
    dialogRef: MatLegacyDialogRef<any>;
    private _elementRef;
    private _dialog;
    /** Screen reader label for the button. */
    ariaLabel: string;
    /** Default to "button" to prevents accidental form submits. */
    type: 'submit' | 'button' | 'reset';
    /** Dialog close input. */
    dialogResult: any;
    _matDialogClose: any;
    constructor(
    /**
     * Reference to the containing dialog.
     * @deprecated `dialogRef` property to become private.
     * @breaking-change 13.0.0
     */
    dialogRef: MatLegacyDialogRef<any>, _elementRef: ElementRef<HTMLElement>, _dialog: MatLegacyDialog);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    _onButtonClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogClose, [{ optional: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyDialogClose, "[mat-dialog-close], [matDialogClose]", ["matDialogClose"], { "ariaLabel": { "alias": "aria-label"; "required": false; }; "type": { "alias": "type"; "required": false; }; "dialogResult": { "alias": "mat-dialog-close"; "required": false; }; "_matDialogClose": { "alias": "matDialogClose"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Title of a dialog element. Stays fixed to the top of the dialog when scrolling.
 * @deprecated Use `MatDialogTitle` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyDialogTitle implements OnInit, OnDestroy {
    private _dialogRef;
    private _elementRef;
    private _dialog;
    /** Unique id for the dialog title. If none is supplied, it will be auto-generated. */
    id: string;
    constructor(_dialogRef: MatLegacyDialogRef<any>, _elementRef: ElementRef<HTMLElement>, _dialog: MatLegacyDialog);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogTitle, [{ optional: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyDialogTitle, "[mat-dialog-title], [matDialogTitle]", ["matDialogTitle"], { "id": { "alias": "id"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Scrollable content container of a dialog.
 * @deprecated Use `MatDialogContent` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyDialogContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogContent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyDialogContent, "[mat-dialog-content], mat-dialog-content, [matDialogContent]", never, {}, {}, never, never, false, never>;
}
/**
 * Container for the bottom action buttons in a dialog.
 * Stays fixed to the bottom when scrolling.
 * @deprecated Use `MatDialogActions` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyDialogActions {
    /**
     * Horizontal alignment of action buttons.
     */
    align?: 'start' | 'center' | 'end';
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogActions, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MatLegacyDialogActions, "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", never, { "align": { "alias": "align"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MatCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatCommonModule, never, [typeof i1.BidiModule], [typeof i1.BidiModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatCommonModule>;
}

/**
 * @deprecated Use `MatDialogModule` from `@angular/material/dialog` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MatLegacyDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MatLegacyDialogModule, [typeof MatLegacyDialogContainer, typeof MatLegacyDialogClose, typeof MatLegacyDialogTitle, typeof MatLegacyDialogActions, typeof MatLegacyDialogContent], [typeof i3.DialogModule, typeof i4.OverlayModule, typeof i5.PortalModule, typeof MatCommonModule], [typeof MatLegacyDialogContainer, typeof MatLegacyDialogClose, typeof MatLegacyDialogTitle, typeof MatLegacyDialogContent, typeof MatLegacyDialogActions, typeof MatCommonModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MatLegacyDialogModule>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Duration defaults for legacy dialog open/close (CSS or recipe path).
 * Kept free of `@angular/animations` so the primary dialog entry can omit that peer.
 */
/**
 * Default parameters for the animation for backwards compatibility.
 * @docs-private
 */
declare const _defaultParams: {
    params: {
        enterAnimationDuration: string;
        exitAnimationDuration: string;
    };
};
/**
 * Alias used by the legacy dialog container template binding.
 * @docs-private
 * @deprecated Use `_defaultParams` instead.
 * @breaking-change 17.0.0
 */
declare const defaultParams: {
    params: {
        enterAnimationDuration: string;
        exitAnimationDuration: string;
    };
};

export { MAT_LEGACY_DIALOG_DATA, MAT_LEGACY_DIALOG_DEFAULT_OPTIONS, MAT_LEGACY_DIALOG_SCROLL_STRATEGY, MAT_DIALOG_SCROLL_STRATEGY_FACTORY as MAT_LEGACY_DIALOG_SCROLL_STRATEGY_FACTORY, MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER, MAT_LEGACY_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY, MatCommonModule, MatLegacyDialog, MatLegacyDialogActions, MatLegacyDialogClose, MatLegacyDialogConfig, MatLegacyDialogContainer, MatLegacyDialogContent, MatLegacyDialogModule, MatLegacyDialogRef, MatLegacyDialogTitle, _MatDialogBase as _MatLegacyDialogBase, _MatDialogContainerBase as _MatLegacyDialogContainerBase, _closeDialogVia as _closeLegacyDialogVia, _defaultParams, defaultParams };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-dialog.d.ts.map
