import { ContentContainerComponentHarness, ComponentHarnessConstructor, HarnessPredicate, ComponentHarness } from '@angular/cdk/testing';
import { CellHarnessFilters, RowHarnessFilters, MatRowHarnessColumnsText, TableHarnessFilters } from '@angular/material/table/testing';
export { CellHarnessFilters as LegacyCellHarnessFilters, RowHarnessFilters as LegacyRowHarnessFilters, TableHarnessFilters as LegacyTableHarnessFilters, MatTableHarnessColumnsText as MatLegacyTableHarnessColumnsText } from '@angular/material/table/testing';

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned finite cell harness base (S05) using public CDK harness APIs.
 */

/** Owned base for legacy table cell harnesses. */
declare abstract class _MatLegacyCellHarnessBase extends ContentContainerComponentHarness {
    /** Gets the cell's text. */
    getText(): Promise<string>;
    /** Gets the name of the column that the cell belongs to. */
    getColumnName(): Promise<string>;
    protected static _getCellPredicate<T extends _MatLegacyCellHarnessBase>(type: ComponentHarnessConstructor<T>, options: CellHarnessFilters): HarnessPredicate<T>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a standard Angular Material table cell.
 * @deprecated Use `MatCellHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyCellHarness extends _MatLegacyCellHarnessBase {
    static hostSelector: string;
    static with(options?: CellHarnessFilters): HarnessPredicate<MatLegacyCellHarness>;
}
/**
 * Harness for interacting with a standard Angular Material table header cell.
 * @deprecated Use `MatHeaderCellHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyHeaderCellHarness extends _MatLegacyCellHarnessBase {
    static hostSelector: string;
    static with(options?: CellHarnessFilters): HarnessPredicate<MatLegacyHeaderCellHarness>;
}
/**
 * Harness for interacting with a standard Angular Material table footer cell.
 * @deprecated Use `MatFooterCellHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyFooterCellHarness extends _MatLegacyCellHarnessBase {
    static hostSelector: string;
    static with(options?: CellHarnessFilters): HarnessPredicate<MatLegacyFooterCellHarness>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned finite row harness base (S06) using public CDK harness APIs.
 */

/** Text extracted from a table row organized by columns. */
interface MatLegacyRowHarnessColumnsText {
    [columnName: string]: string;
}
/** Owned base for legacy table row harnesses. */
declare abstract class _MatLegacyRowHarnessBase<CellType extends ComponentHarnessConstructor<Cell> & {
    with: (options?: CellHarnessFilters) => HarnessPredicate<Cell>;
}, Cell extends _MatLegacyCellHarnessBase> extends ComponentHarness {
    protected abstract _cellHarness: CellType;
    /** Gets a list of cell harnesses for all cells in the row. */
    getCells(filter?: CellHarnessFilters): Promise<Cell[]>;
    /** Gets the text of the cells in the row. */
    getCellTextByIndex(filter?: CellHarnessFilters): Promise<string[]>;
    /** Gets the text inside the row organized by columns. */
    getCellTextByColumnName(): Promise<MatLegacyRowHarnessColumnsText>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a standard Angular Material table row.
 * @deprecated Use `MatRowHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyRowHarness extends _MatLegacyRowHarnessBase<typeof MatLegacyCellHarness, MatLegacyCellHarness> {
    static hostSelector: string;
    protected _cellHarness: typeof MatLegacyCellHarness;
    static with(options?: RowHarnessFilters): HarnessPredicate<MatLegacyRowHarness>;
}
/**
 * Harness for interacting with a standard Angular Material table header row.
 * @deprecated Use `MatHeaderRowHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyHeaderRowHarness extends _MatLegacyRowHarnessBase<typeof MatLegacyHeaderCellHarness, MatLegacyHeaderCellHarness> {
    static hostSelector: string;
    protected _cellHarness: typeof MatLegacyHeaderCellHarness;
    static with(options?: RowHarnessFilters): HarnessPredicate<MatLegacyHeaderRowHarness>;
}
/**
 * Harness for interacting with a standard Angular Material table footer row.
 * @deprecated Use `MatFooterRowHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyFooterRowHarness extends _MatLegacyRowHarnessBase<typeof MatLegacyFooterCellHarness, MatLegacyFooterCellHarness> {
    static hostSelector: string;
    protected _cellHarness: typeof MatLegacyFooterCellHarness;
    static with(options?: RowHarnessFilters): HarnessPredicate<MatLegacyFooterRowHarness>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 *
 * Owned Material-16 harness base(s) removed from Angular Material 22.
 */

/** Text extracted from a table organized by columns. */
interface MatTableHarnessColumnsText {
    [columnName: string]: {
        text: string[];
        headerText: string[];
        footerText: string[];
    };
}
interface RowBase extends ComponentHarness {
    getCellTextByColumnName(): Promise<MatRowHarnessColumnsText>;
    getCellTextByIndex(): Promise<string[]>;
}
declare abstract class _MatTableHarnessBase<HeaderRowType extends ComponentHarnessConstructor<HeaderRow> & {
    with: (options?: RowHarnessFilters) => HarnessPredicate<HeaderRow>;
}, HeaderRow extends RowBase, RowType extends ComponentHarnessConstructor<Row> & {
    with: (options?: RowHarnessFilters) => HarnessPredicate<Row>;
}, Row extends RowBase, FooterRowType extends ComponentHarnessConstructor<FooterRow> & {
    with: (options?: RowHarnessFilters) => HarnessPredicate<FooterRow>;
}, FooterRow extends RowBase> extends ContentContainerComponentHarness<string> {
    protected abstract _headerRowHarness: HeaderRowType;
    protected abstract _rowHarness: RowType;
    protected abstract _footerRowHarness: FooterRowType;
    /** Gets all of the header rows in a table. */
    getHeaderRows(filter?: RowHarnessFilters): Promise<HeaderRow[]>;
    /** Gets all of the regular data rows in a table. */
    getRows(filter?: RowHarnessFilters): Promise<Row[]>;
    /** Gets all of the footer rows in a table. */
    getFooterRows(filter?: RowHarnessFilters): Promise<FooterRow[]>;
    /** Gets the text inside the entire table organized by rows. */
    getCellTextByIndex(): Promise<string[][]>;
    /** Gets the text inside the entire table organized by columns. */
    getCellTextByColumnName(): Promise<MatTableHarnessColumnsText>;
}

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Harness for interacting with a standard mat-table in tests.
 * @deprecated Use `MatTableHarness` from `@angular/material/table/testing` instead. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
declare class MatLegacyTableHarness extends _MatTableHarnessBase<typeof MatLegacyHeaderRowHarness, MatLegacyHeaderRowHarness, typeof MatLegacyRowHarness, MatLegacyRowHarness, typeof MatLegacyFooterRowHarness, MatLegacyFooterRowHarness> {
    /** The selector for the host element of a `MatTableHarness` instance. */
    static hostSelector: string;
    protected _headerRowHarness: typeof MatLegacyHeaderRowHarness;
    protected _rowHarness: typeof MatLegacyRowHarness;
    protected _footerRowHarness: typeof MatLegacyFooterRowHarness;
    /**
     * Gets a `HarnessPredicate` that can be used to search for a table with specific attributes.
     * @param options Options for narrowing the search
     * @return a `HarnessPredicate` configured with the given options.
     */
    static with(options?: TableHarnessFilters): HarnessPredicate<MatLegacyTableHarness>;
}

export { MatLegacyCellHarness, MatLegacyFooterCellHarness, MatLegacyFooterRowHarness, MatLegacyHeaderCellHarness, MatLegacyHeaderRowHarness, MatLegacyRowHarness, MatLegacyTableHarness, _MatLegacyCellHarnessBase, _MatLegacyRowHarnessBase, _MatTableHarnessBase as _MatLegacyTableHarnessBase };
export type { MatLegacyRowHarnessColumnsText };
//# sourceMappingURL=ngx-compat-material-legacy-legacy-table-testing.d.ts.map
